﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using Monobjc.Cocoa;

namespace Monobjc.Growl
{
    partial class GrowlApplicationBridge
    {
        /// <summary>
        /// <para>Return the <code>NSData</code> to treat as the application icon.</para>
        /// <para>Original signature is '- (NSData *) applicationIconDataForGrowl;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public delegate NSData ApplicationIconDataForGrowlEventHandler();

        /// <summary>
        /// <para>Return the <code>NSImage</code> to treat as the application icon.</para>
        /// <para>Original signature is '- (NSImage *) applicationIconForGrowl;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public delegate NSImage ApplicationIconForGrowlEventHandler();

        /// <summary>
        /// <para>Return the name of this application which will be used for Growl bookkeeping.</para>
        /// <para>Original signature is '- (NSString *) applicationNameForGrowl;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public delegate NSString ApplicationNameForGrowlEventHandler();

        /// <summary>
        /// <para>Return the information to display when installing.</para>
        /// <para>Original signature is '- (NSAttributedString *)growlInstallationInformation;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public delegate NSAttributedString GrowlInstallationInformationEventHandler();

        /// <summary>
        /// <para>Return the title of the installation window.</para>
        /// <para>Original signature is '- (NSString *)growlInstallationWindowTitle;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public delegate NSString GrowlInstallationWindowTitleEventHandler();

        /// <summary>
        /// <para>Informs the delegate that Growl has launched.</para>
        /// <para>Original signature is '- (void) growlIsReady'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public delegate void GrowlIsReadyEventHandler();

        /// <summary>
        /// <para>Informs the delegate that a Growl notification timed out.</para>
        /// <para>Original signature is '- (void) growlNotificationTimedOut:(id)clickContext;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public delegate void GrowlNotificationTimedOutEventHandler(Id clickContext);

        /// <summary>
        /// <para>Informs the delegate that a Growl notification was clicked.</para>
        /// <para>Original signature is '- (void) growlNotificationWasClicked:(id)clickContext;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public delegate void GrowlNotificationWasClickedEventHandler(Id clickContext);

        /// <summary>
        /// <para>Return the information to display when upgrading.</para>
        /// <para>Original signature is '- (NSAttributedString *)growlUpdateInformation;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public delegate NSAttributedString GrowlUpdateInformationEventHandler();

        /// <summary>
        /// <para>Return the title of the upgrade window.</para>
        /// <para>Original signature is '- (NSString *)growlUpdateWindowTitle;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public delegate NSString GrowlUpdateWindowTitleEventHandler();

        /// <summary>
        /// <para>Return the dictionary used to register this application with Growl.</para>
        /// <para>Original signature is '- (NSDictionary *) registrationDictionaryForGrowl;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public delegate NSDictionary RegistrationDictionaryForGrowlEventHandler();

        /// <summary>
        /// Sets the delegate of the <see cref="GrowlApplicationBridge"/> instance.
        /// </summary>
        /// <param name="assignment">The assignment of delegation methods.</param>
        public static void SetDelegate(Action<GrowlApplicationBridgeEventDispatcher> assignment)
        {
            GrowlApplicationBridgeEventDispatcher @delegate = GrowlDelegate.SafeCastAs<GrowlApplicationBridgeEventDispatcher>();
            if (@delegate != null)
            {
                @delegate.Release();
                GrowlDelegate = null;
            }

            if (assignment != null)
            {
                @delegate = new GrowlApplicationBridgeEventDispatcher();
                assignment(@delegate);
                GrowlDelegate = @delegate;
            }
        }

        /// <summary>
        /// Inner event handler that is exposed to the Objective-C runtime and relays delegate messages to listeners.
        /// </summary>
        [ObjectiveCClass]
        public class GrowlApplicationBridgeEventDispatcher : NSObject
        {
            /// <summary>
            /// Static field for a quick access to the GrowlApplicationBridgeEventDispatcher class.
            /// </summary>
            public static readonly Class GrowlApplicationBridgeEventDispatcherClass = Class.GetClassFromType(typeof (GrowlApplicationBridgeEventDispatcher));

            /// <summary>
            /// Initializes a new instance of the <see cref="GrowlApplicationBridgeEventDispatcher"/> class.
            /// </summary>
            public GrowlApplicationBridgeEventDispatcher() {}

            /// <summary>
            /// Initializes a new instance of the <see cref="GrowlApplicationBridgeEventDispatcher"/> class.
            /// </summary>
            /// <param name="nativePointer">The native pointer.</param>
            public GrowlApplicationBridgeEventDispatcher(IntPtr nativePointer)
                : base(nativePointer) {}

            /// <summary>
            /// <para>Returns a Boolean value that indicates whether the receiver implements or inherits a method that can respond to a specified message.</para>
            /// <para>Original signature is '- (BOOL)respondsToSelector:(SEL)aSelector'</para>
            /// <para>Available in Mac OS X v10.0 and later.</para>
            /// </summary>
            /// <param name="aSelector">A selector that identifies a message.</param>
            /// <returns>
            /// YES if the receiver implements or inherits a method that can respond to aSelector, otherwise NO.
            /// </returns>
            [ObjectiveCMessage("respondsToSelector:")]
            public override bool RespondsToSelector(IntPtr aSelector)
            {
                String message = ObjectiveCRuntime.Selector(aSelector);
                switch (message)
                {
                    case "registrationDictionaryForGrowl":
                        return (this.RegistrationDictionaryForGrowl != null);
                    case "applicationNameForGrowl":
                        return (this.ApplicationNameForGrowl != null);
                    case "applicationIconForGrowl":
                        return (this.ApplicationIconForGrowl != null);
                    case "applicationIconDataForGrowl":
                        return (this.ApplicationIconDataForGrowl != null);
                    case "growlIsReady":
                        return (this.GrowlIsReady != null);
                    case "growlNotificationWasClicked:":
                        return (this.GrowlNotificationWasClicked != null);
                    case "growlNotificationTimedOut:":
                        return (this.GrowlNotificationTimedOut != null);
                    case "growlInstallationWindowTitle":
                        return (this.GrowlInstallationWindowTitle != null);
                    case "growlUpdateWindowTitle":
                        return (this.GrowlUpdateWindowTitle != null);
                    case "growlInstallationInformation":
                        return (this.GrowlInstallationInformation != null);
                    case "growlUpdateInformation":
                        return (this.GrowlUpdateInformation != null);
                }
                return this.SendMessageSuper<bool>(GrowlApplicationBridgeEventDispatcherClass, "respondsToSelector:", aSelector);
            }

            /// <summary>
            /// <para>Return the dictionary used to register this application with Growl.</para>
            /// <para>Original signature is '- (NSDictionary *) registrationDictionaryForGrowl;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            public event RegistrationDictionaryForGrowlEventHandler RegistrationDictionaryForGrowl;

            /// <summary>
            /// <para>Return the name of this application which will be used for Growl bookkeeping.</para>
            /// <para>Original signature is '- (NSString *) applicationNameForGrowl;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            public event ApplicationNameForGrowlEventHandler ApplicationNameForGrowl;

            /// <summary>
            /// <para>Return the <code>NSImage</code> to treat as the application icon.</para>
            /// <para>Original signature is '- (NSImage *) applicationIconForGrowl;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            public event ApplicationIconForGrowlEventHandler ApplicationIconForGrowl;

            /// <summary>
            /// <para>Return the <code>NSData</code> to treat as the application icon.</para>
            /// <para>Original signature is '- (NSData *) applicationIconDataForGrowl;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            public event ApplicationIconDataForGrowlEventHandler ApplicationIconDataForGrowl;

            /// <summary>
            /// <para>Informs the delegate that Growl has launched.</para>
            /// <para>Original signature is '- (void) growlIsReady'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            public event GrowlIsReadyEventHandler GrowlIsReady;

            /// <summary>
            /// <para>Informs the delegate that a Growl notification was clicked.</para>
            /// <para>Original signature is '- (void) growlNotificationWasClicked:(id)clickContext;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            public event GrowlNotificationWasClickedEventHandler GrowlNotificationWasClicked;

            /// <summary>
            /// <para>Informs the delegate that a Growl notification timed out.</para>
            /// <para>Original signature is '- (void) growlNotificationTimedOut:(id)clickContext;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            public event GrowlNotificationTimedOutEventHandler GrowlNotificationTimedOut;

            /// <summary>
            /// <para>Return the title of the installation window.</para>
            /// <para>Original signature is '- (NSString *)growlInstallationWindowTitle;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            public event GrowlInstallationWindowTitleEventHandler GrowlInstallationWindowTitle;

            /// <summary>
            /// <para>Return the title of the upgrade window.</para>
            /// <para>Original signature is '- (NSString *)growlUpdateWindowTitle;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            public event GrowlUpdateWindowTitleEventHandler GrowlUpdateWindowTitle;

            /// <summary>
            /// <para>Return the information to display when installing.</para>
            /// <para>Original signature is '- (NSAttributedString *)growlInstallationInformation;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            public event GrowlInstallationInformationEventHandler GrowlInstallationInformation;

            /// <summary>
            /// <para>Return the information to display when upgrading.</para>
            /// <para>Original signature is '- (NSAttributedString *)growlUpdateInformation;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            public event GrowlUpdateInformationEventHandler GrowlUpdateInformation;


            /// <summary>
            /// <para>Return the dictionary used to register this application with Growl.</para>
            /// <para>Original signature is '- (NSDictionary *) registrationDictionaryForGrowl;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            [ObjectiveCMessage("registrationDictionaryForGrowl")]
            public NSDictionary RegistrationDictionaryForGrowlMessage()
            {
                if (this.RegistrationDictionaryForGrowl != null)
                {
                    this.RegistrationDictionaryForGrowl();
                }
                return null;
            }

            /// <summary>
            /// <para>Return the name of this application which will be used for Growl bookkeeping.</para>
            /// <para>Original signature is '- (NSString *) applicationNameForGrowl;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            [ObjectiveCMessage("applicationNameForGrowl")]
            public NSString ApplicationNameForGrowlMessage()
            {
                if (this.ApplicationNameForGrowl != null)
                {
                    return this.ApplicationNameForGrowl();
                }
                return null;
            }

            /// <summary>
            /// <para>Return the <code>NSImage</code> to treat as the application icon.</para>
            /// <para>Original signature is '- (NSImage *) applicationIconForGrowl;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            [ObjectiveCMessage("applicationIconForGrowl")]
            public NSImage ApplicationIconForGrowlMessage()
            {
                if (this.ApplicationIconForGrowl != null)
                {
                    return this.ApplicationIconForGrowl();
                }
                return null;
            }

            /// <summary>
            /// <para>Return the <code>NSData</code> to treat as the application icon.</para>
            /// <para>Original signature is '- (NSData *) applicationIconDataForGrowl;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            [ObjectiveCMessage("applicationIconDataForGrowl")]
            public NSData ApplicationIconDataForGrowlMessage()
            {
                if (this.ApplicationIconDataForGrowl != null)
                {
                    return this.ApplicationIconDataForGrowl();
                }
                return null;
            }

            /// <summary>
            /// <para>Informs the delegate that Growl has launched.</para>
            /// <para>Original signature is '- (void) growlIsReady'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            [ObjectiveCMessage("growlIsReady")]
            public void GrowlIsReadyMessage()
            {
                if (this.GrowlIsReady != null)
                {
                    this.GrowlIsReady();
                }
            }

            /// <summary>
            /// <para>Informs the delegate that a Growl notification was clicked.</para>
            /// <para>Original signature is '- (void) growlNotificationWasClicked:(id)clickContext;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            [ObjectiveCMessage("growlNotificationWasClicked:")]
            public void GrowlNotificationWasClickedMessage(Id clickContext)
            {
                if (this.GrowlNotificationWasClicked != null)
                {
                    this.GrowlNotificationWasClicked(clickContext);
                }
            }

            /// <summary>
            /// <para>Informs the delegate that a Growl notification timed out.</para>
            /// <para>Original signature is '- (void) growlNotificationTimedOut:(id)clickContext;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            [ObjectiveCMessage("growlNotificationTimedOut:")]
            public void GrowlNotificationTimedOutMessage(Id clickContext)
            {
                if (this.GrowlNotificationTimedOut != null)
                {
                    this.GrowlNotificationTimedOut(clickContext);
                }
            }

            /// <summary>
            /// <para>Return the title of the installation window.</para>
            /// <para>Original signature is '- (NSString *)growlInstallationWindowTitle;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            [ObjectiveCMessage("growlInstallationWindowTitle")]
            public NSString GrowlInstallationWindowTitleMessage()
            {
                if (this.GrowlInstallationWindowTitle != null)
                {
                    return this.GrowlInstallationWindowTitle();
                }
                return null;
            }

            /// <summary>
            /// <para>Return the title of the upgrade window.</para>
            /// <para>Original signature is '- (NSString *)growlUpdateWindowTitle;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            [ObjectiveCMessage("growlUpdateWindowTitle")]
            public NSString GrowlUpdateWindowTitleMessage()
            {
                if (this.GrowlUpdateWindowTitle != null)
                {
                    return this.GrowlUpdateWindowTitle();
                }
                return null;
            }

            /// <summary>
            /// <para>Return the information to display when installing.</para>
            /// <para>Original signature is '- (NSAttributedString *)growlInstallationInformation;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            [ObjectiveCMessage("growlInstallationInformation")]
            public NSAttributedString GrowlInstallationInformationMessage()
            {
                if (this.GrowlInstallationInformation != null)
                {
                    return this.GrowlInstallationInformation();
                }
                return null;
            }

            /// <summary>
            /// <para>Return the information to display when upgrading.</para>
            /// <para>Original signature is '- (NSAttributedString *)growlUpdateInformation;'</para>
            /// <para>Available in Growl v1.2 and later.</para>
            /// </summary>
            [ObjectiveCMessage("growlUpdateInformation")]
            public NSAttributedString GrowlUpdateInformationMessage()
            {
                if (this.GrowlUpdateInformation != null)
                {
                    return this.GrowlUpdateInformation();
                }
                return null;
            }


            /// <summary>
            /// Deallocates the memory occupied by the receiver.
            /// </summary>
            [ObjectiveCMessage("dealloc", SynchronizeFields = false)]
            public void Dealloc()
            {
                if (this.RegistrationDictionaryForGrowl != null)
                {
                    foreach (RegistrationDictionaryForGrowlEventHandler handler in this.RegistrationDictionaryForGrowl.GetInvocationList())
                    {
                        this.RegistrationDictionaryForGrowl -= handler;
                    }
                }
                if (this.ApplicationNameForGrowl != null)
                {
                    foreach (ApplicationNameForGrowlEventHandler handler in this.ApplicationNameForGrowl.GetInvocationList())
                    {
                        this.ApplicationNameForGrowl -= handler;
                    }
                }
                if (this.ApplicationIconForGrowl != null)
                {
                    foreach (ApplicationIconForGrowlEventHandler handler in this.ApplicationIconForGrowl.GetInvocationList())
                    {
                        this.ApplicationIconForGrowl -= handler;
                    }
                }
                if (this.ApplicationIconDataForGrowl != null)
                {
                    foreach (ApplicationIconDataForGrowlEventHandler handler in this.ApplicationIconDataForGrowl.GetInvocationList())
                    {
                        this.ApplicationIconDataForGrowl -= handler;
                    }
                }
                if (this.GrowlIsReady != null)
                {
                    foreach (GrowlIsReadyEventHandler handler in this.GrowlIsReady.GetInvocationList())
                    {
                        this.GrowlIsReady -= handler;
                    }
                }
                if (this.GrowlNotificationWasClicked != null)
                {
                    foreach (GrowlNotificationWasClickedEventHandler handler in this.GrowlNotificationWasClicked.GetInvocationList())
                    {
                        this.GrowlNotificationWasClicked -= handler;
                    }
                }
                if (this.GrowlNotificationTimedOut != null)
                {
                    foreach (GrowlNotificationTimedOutEventHandler handler in this.GrowlNotificationTimedOut.GetInvocationList())
                    {
                        this.GrowlNotificationTimedOut -= handler;
                    }
                }
                if (this.GrowlInstallationWindowTitle != null)
                {
                    foreach (GrowlInstallationWindowTitleEventHandler handler in this.GrowlInstallationWindowTitle.GetInvocationList())
                    {
                        this.GrowlInstallationWindowTitle -= handler;
                    }
                }
                if (this.GrowlUpdateWindowTitle != null)
                {
                    foreach (GrowlUpdateWindowTitleEventHandler handler in this.GrowlUpdateWindowTitle.GetInvocationList())
                    {
                        this.GrowlUpdateWindowTitle -= handler;
                    }
                }
                if (this.GrowlInstallationInformation != null)
                {
                    foreach (GrowlInstallationInformationEventHandler handler in this.GrowlInstallationInformation.GetInvocationList())
                    {
                        this.GrowlInstallationInformation -= handler;
                    }
                }
                if (this.GrowlUpdateInformation != null)
                {
                    foreach (GrowlUpdateInformationEventHandler handler in this.GrowlUpdateInformation.GetInvocationList())
                    {
                        this.GrowlUpdateInformation -= handler;
                    }
                }

                this.SendMessageSuper(GrowlApplicationBridgeClass, "dealloc");
            }
        }
    }
}