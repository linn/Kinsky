﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using Monobjc.Cocoa;

namespace Monobjc.Growl
{
    /// <summary>
    /// Managed wrapper for GrowlApplicationBridge Objective-C class.
    /// </summary>
    [ObjectiveCClass]
    public partial class GrowlApplicationBridge : NSObject
    {
        /// <summary>
        /// Static field for a quick access to the GrowlApplicationBridge class.
        /// </summary>
        public static readonly Class GrowlApplicationBridgeClass = Class.GetClassFromType(typeof(GrowlApplicationBridge));

        /// <summary>
        /// Initializes a new instance of the <see cref="GrowlApplicationBridge"/> class.
        /// </summary>
        public GrowlApplicationBridge() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="GrowlApplicationBridge"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public GrowlApplicationBridge(IntPtr nativePointer) : base(nativePointer) {}

        /// <summary>
        /// Initializes a new instance of the <see cref="GrowlApplicationBridge"/> class.
        /// </summary>
        /// <param name="selector">The selector.</param>
        /// <param name="firstParam">The first param.</param>
        /// <param name="parameters">The parameters.</param>
        protected GrowlApplicationBridge(string selector, object firstParam, params object[] parameters) : base(selector, firstParam, parameters) {}
    }
}
