﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.Growl
{
    partial class GrowlApplicationBridge
    {
        /// <summary>
        /// <para>Obtains a registration dictionary, filled out to the best of GrowlApplicationBridge's knowledge.</para>
        /// <para>Original signature is '+ (NSDictionary *) bestRegistrationDictionary;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <value>A registration dictionary.</value>
        public static NSDictionary BestRegistrationDictionary
        {
            get { return ObjectiveCRuntime.SendMessage<NSDictionary>(GrowlApplicationBridgeClass, "bestRegistrationDictionary"); }
        }

        /// <summary>
        /// <para>Gets the framework info dictionary.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <value>The framework info dictionary.</value>
        public static NSDictionary FrameworkInfoDictionary
        {
            get { return ObjectiveCRuntime.SendMessage<NSDictionary>(GrowlApplicationBridgeClass, "frameworkInfoDictionary"); }
        }

        /// <summary>
        /// <para>Get or set the object which will be responsible for providing and receiving Growl information.</para>
        /// <para>Original signature is '+ (NSObject&lt;GrowlApplicationBridgeDelegate&gt; *) growlDelegate;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <value>The Growl delegate.</value>
        public static Id GrowlDelegate
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(GrowlApplicationBridgeClass, "growlDelegate"); }
            set { ObjectiveCRuntime.SendMessage(GrowlApplicationBridgeClass, "setGrowlDelegate:", value); }
        }

        /// <summary>
        /// <para>Detects whether Growl is installed.</para>
        /// <para>Original signature is '+ (BOOL) isGrowlInstalled;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <value>Returns YES if Growl is installed, NO otherwise.</value>
        public static bool IsGrowlInstalled
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(GrowlApplicationBridgeClass, "isGrowlInstalled"); }
        }

        /// <summary>
        /// <para>Detects whether GrowlHelperApp is currently running.</para>
        /// <para>Original signature is '+ (BOOL) isGrowlRunning;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <value>Returns YES if Growl is installed, NO otherwise.</value>
        public static bool IsGrowlRunning
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(GrowlApplicationBridgeClass, "isGrowlRunning"); }
        }

        /// <summary>
        /// <para>Asks the delegate for a registration dictionary.</para>
        /// <para>Original signature is '+ (NSDictionary *) registrationDictionaryFromDelegate;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <value>A registration dictionary.</value>
        public static NSDictionary RegistrationDictionaryFromDelegate
        {
            get { return ObjectiveCRuntime.SendMessage<NSDictionary>(GrowlApplicationBridgeClass, "registrationDictionaryFromDelegate"); }
        }

        /// <summary>
        /// <para>Reports whether GrowlApplicationBridge will register with Growl when Growl next launches.</para>
        /// <para>Original signature is '+ (BOOL) willRegisterWhenGrowlIsReady;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <value>
        /// 	<code>YES</code> if GrowlApplicationBridge will register with Growl.
        /// </value>
        public static bool WillRegisterWhenGrowlIsReady
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(GrowlApplicationBridgeClass, "willRegisterWhenGrowlIsReady"); }
            set { ObjectiveCRuntime.SendMessage(GrowlApplicationBridgeClass, "setWillRegisterWhenGrowlIsReady:", value); }
        }

        /// <summary>
        /// <para>Tries to fill in missing keys in a notification dictionary.</para>
        /// <para>Original signature is '+ (NSDictionary *) registrationDictionaryFromBundle:(NSBundle *)bundle;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <param name="regDict">The dictionary to fill in.</param>
        /// <returns>The dictionary with the keys filled in. This will be a separate instance from a regDict.</returns>
        public static NSDictionary NotificationDictionaryByFillingInDictionary(NSDictionary regDict)
        {
            return ObjectiveCRuntime.SendMessage<NSDictionary>(GrowlApplicationBridgeClass, "notificationDictionaryByFillingInDictionary:", regDict);
        }

        /// <summary>
        /// <para>DetectsNotifies using a userInfo dictionary suitable for passing to <see cref="NSDistributedNotificationCenter"/>.</para>
        /// <para>Original signature is '+ (void) notifyWithDictionary:(NSDictionary *)userInfo;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <param name="userInfo">The dictionary to notify with.</param>
        public static void NotifyWithDictionary(NSDictionary userInfo)
        {
            ObjectiveCRuntime.SendMessage(GrowlApplicationBridgeClass, "notifyWithDictionary:", userInfo);
        }

        /// <summary>
        /// <para>Send a Growl notification.</para>
        /// <para>Original signature is '+ (void) notifyWithTitle:(NSString *)title description:(NSString *)description notificationName:(NSString *)notifName iconData:(NSData *)iconData priority:(signed int)priority isSticky:(BOOL)isSticky clickContext:(id)clickContext;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <param name="title">The title of the notification displayed to the user.</param>
        /// <param name="description">The full description of the notification displayed to the user.</param>
        /// <param name="notifName">The internal name of the notification. Should be human-readable, as it will be displayed in the Growl preference pane.</param>
        /// <param name="iconData"><see cref="NSData"/> object to show with the notification as its icon. If <code>nil</code>, the application's icon will be used instead.</param>
        /// <param name="priority">The priority of the notification. The default value is 0; positive values are higher priority and negative values are lower priority. Not all Growl displays support priority.</param>
        /// <param name="isSticky">If YES, the notification will remain on screen until clicked. Not all Growl displays support sticky notifications.</param>
        /// <param name="clickContext">A context passed back to the Growl delegate if it implements -(void)growlNotificationWasClicked: and the notification is clicked. Not all display plugins support clicking. The clickContext must be plist-encodable (completely of <see cref="NSString"/>, <see cref="NSArray"/>, <see cref="NSNumber"/>, <see cref="NSDictionary"/>, and <see cref="NSData"/> types).</param>
        public static void NotifyWithTitleDescriptionNotificationNameIconDataPriorityIsStickyClickContext(NSString title,
                                                                                                   NSString description,
                                                                                                   NSString notifName,
                                                                                                   NSData iconData,
                                                                                                   int priority,
                                                                                                   bool isSticky,
                                                                                                   Id clickContext)
        {
            ObjectiveCRuntime.SendMessage(GrowlApplicationBridgeClass,
                                          "notifyWithTitle:description:notificationName:iconData:priority:isSticky:clickContext:",
                                          title,
                                          description,
                                          notifName,
                                          iconData,
                                          priority,
                                          isSticky,
                                          clickContext);
        }

        /// <summary>
        /// <para>Send a Growl notification.</para>
        /// <para>Original signature is '+ (void) notifyWithTitle:(NSString *)title description:(NSString *)description notificationName:(NSString *)notifName iconData:(NSData *)iconData priority:(signed int)priority isSticky:(BOOL)isSticky clickContext:(id)clickContext identifier:(NSString *)identifier;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <param name="title">The title of the notification displayed to the user.</param>
        /// <param name="description">The full description of the notification displayed to the user.</param>
        /// <param name="notifName">The internal name of the notification. Should be human-readable, as it will be displayed in the Growl preference pane.</param>
        /// <param name="iconData"><see cref="NSData"/> object to show with the notification as its icon. If <code>nil</code>, the application's icon will be used instead.</param>
        /// <param name="priority">The priority of the notification. The default value is 0; positive values are higher priority and negative values are lower priority. Not all Growl displays support priority.</param>
        /// <param name="isSticky">If YES, the notification will remain on screen until clicked. Not all Growl displays support sticky notifications.</param>
        /// <param name="clickContext">A context passed back to the Growl delegate if it implements -(void)growlNotificationWasClicked: and the notification is clicked. Not all display plugins support clicking. The clickContext must be plist-encodable (completely of <see cref="NSString"/>, <see cref="NSArray"/>, <see cref="NSNumber"/>, <see cref="NSDictionary"/>, and <see cref="NSData"/> types).</param>
        /// <param name="identifier">An identifier for this notification. Notifications with equal identifiers are coalesced.</param>
        public static void NotifyWithTitleDescriptionNotificationNameIconDataPriorityIsStickyClickContextIdentifier(NSString title,
                                                                                                   NSString description,
                                                                                                   NSString notifName,
                                                                                                   NSData iconData,
                                                                                                   int priority,
                                                                                                   bool isSticky,
                                                                                                   Id clickContext,
                                                                                                   NSString identifier)
        {
            ObjectiveCRuntime.SendMessage(GrowlApplicationBridgeClass,
                                          "notifyWithTitle:description:notificationName:iconData:priority:isSticky:clickContext:identifier:",
                                          title,
                                          description,
                                          notifName,
                                          iconData,
                                          priority,
                                          isSticky,
                                          clickContext,
                                          identifier);
        }

        /// <summary>
        /// <para>Register your application with Growl without setting a delegate.</para>
        /// <para>Original signature is '+ (BOOL) registerWithDictionary:(NSDictionary *)c;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <param name="c">The dictionary.</param>
        public static bool RegisterWithDictionary(NSDictionary c)
        {
            return ObjectiveCRuntime.SendMessage<bool>(GrowlApplicationBridgeClass, "registerWithDictionary:", c);
        }

        /// <summary>
        /// <para>Tries to fill in missing keys in a registration dictionary.</para>
        /// <para>Original signature is '+ (NSDictionary *) registrationDictionaryByFillingInDictionary:(NSDictionary *)regDict;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <param name="regDict">The dictionary to fill in.</param>
        /// <returns>The dictionary with the keys filled in. This is an autoreleased copy of <code>regDict</code>.</returns>
        public static NSDictionary RegistrationDictionaryByFillingInDictionary(NSDictionary regDict)
        {
            return ObjectiveCRuntime.SendMessage<NSDictionary>(GrowlApplicationBridgeClass, "registrationDictionaryByFillingInDictionary:", regDict);
        }

        /// <summary>
        /// <para>Tries to fill in missing keys in a registration dictionary.</para>
        /// <para>Original signature is '+ (NSDictionary *) registrationDictionaryByFillingInDictionary:(NSDictionary *)regDict;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <param name="regDict">The dictionary to fill in.</param>
        /// <param name="keys">The keys to fill in. If <code>nil</code>, any missing keys are filled in.</param>
        /// <returns>
        /// The dictionary with the keys filled in. This is an autoreleased copy of <code>regDict</code>.
        /// </returns>
        public static NSDictionary RegistrationDictionaryByFillingInDictionaryRestrictToKeys(NSDictionary regDict, NSSet keys)
        {
            return ObjectiveCRuntime.SendMessage<NSDictionary>(GrowlApplicationBridgeClass, "registrationDictionaryByFillingInDictionary:restrictToKeys:", regDict, keys);
        }

        /// <summary>
        /// <para>Looks in a bundle for a registration dictionary.</para>
        /// <para>Original signature is '+ (NSDictionary *) registrationDictionaryFromBundle:(NSBundle *)bundle;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        /// <param name="bundle">The bundle to scan.</param>
        /// <returns>A registration dictionary.</returns>
        public static NSDictionary RegistrationDictionaryFromBundle(NSBundle bundle)
        {
            return ObjectiveCRuntime.SendMessage<NSDictionary>(GrowlApplicationBridgeClass, "registrationDictionaryFromBundle:", bundle);
        }

        /// <summary>
        /// <para>Reregister the notifications for this application.</para>
        /// <para>Original signature is '+ (void) reregisterGrowlNotifications;'</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static void ReregisterGrowlNotifications()
        {
            ObjectiveCRuntime.SendMessage(GrowlApplicationBridgeClass, "reregisterGrowlNotifications");
        }
    }
}