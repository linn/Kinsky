﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.Growl
{
    partial class GrowlFramework
    {
        /// <summary>
        /// <para>The image data for your application's icon.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_APP_ICON = NSString.NSPinnedString("ApplicationIcon");

        /// <summary>
        /// <para>The bundle identifier of your application.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_APP_ID = NSString.NSPinnedString("ApplicationId");

        /// <summary>
        /// <para>The name of your application.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_APP_NAME = NSString.NSPinnedString("ApplicationName");

        /// <summary>
        /// <para>The process identifier of the process which sends this</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_APP_PID = NSString.NSPinnedString("ApplicationPID");

        /// <summary>
        /// <para>The distributed notification for registering your application.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_APP_REGISTRATION = NSString.NSPinnedString("GrowlApplicationRegistrationNotification");

        /// <summary>
        /// <para>The distributed notification for confirming registration.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_APP_REGISTRATION_CONF = NSString.NSPinnedString("GrowlApplicationRegistrationConfirmationNotification");

        /// <summary>
        /// <para>The name of a display plugin which should be used for this notification.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_DISPLAY_PLUGIN = NSString.NSPinnedString("NotificationDisplayPlugin");

        /// <summary>
        /// <para>The distributed notification sent when Growl starts up.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_IS_READY = NSString.NSPinnedString("Lend Me Some Sugar; I Am Your Neighbor!");

        /// <summary>
        /// <para>Used internally as the key for the clickedContext passed over DNC.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_KEY_CLICKED_CONTEXT = NSString.NSPinnedString("ClickedContext");

        /// <summary>
        /// <para>The distributed notification for Growl notifications.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION = NSString.NSPinnedString("GrowlNotification");

        /// <summary>
        /// <para>Image data for the application icon, in case GROWL_APP_ICON does not apply for some reason. Must be in a format supported by NSImage, such as TIFF, PNG, GIF, JPEG, BMP, PICT, or PDF.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_APP_ICON = NSString.NSPinnedString("NotificationAppIcon");

        /// <summary>
        /// <para>Identifies which notification was clicked.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_CLICK_CONTEXT = NSString.NSPinnedString("NotificationClickContext");

        /// <summary>
        /// <para>The distributed notification sent when a supported notification is clicked.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_CLICKED = NSString.NSPinnedString("GrowlClicked!");

        /// <summary>
        /// <para>The description to display in the notification.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_DESCRIPTION = NSString.NSPinnedString("NotificationDescription");

        /// <summary>
        /// <para>Image data for the notification icon. Must be in a format</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_ICON = NSString.NSPinnedString("NotificationIcon");

        /// <summary>
        /// <para>An identifier for the notification for coalescing purposes.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_IDENTIFIER = NSString.NSPinnedString("GrowlNotificationIdentifier");

        /// <summary>
        /// <para>The name of the notification.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_NAME = NSString.NSPinnedString("NotificationName");

        /// <summary>
        /// <para>The priority of the notification as an integer number from -2 to +2 (+2 being highest).</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_PRIORITY = NSString.NSPinnedString("NotificationPriority");

        /// <summary>
        /// <para>If this key is set, it should contain a double value wrapped</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_PROGRESS = NSString.NSPinnedString("NotificationProgress");

        /// <summary>
        /// <para>A Boolean number controlling whether the notification is sticky.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_STICKY = NSString.NSPinnedString("NotificationSticky");

        /// <summary>
        /// <para>The time-out for the notification.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_TIMED_OUT = NSString.NSPinnedString("GrowlTimedOut!");

        /// <summary>
        /// <para>The title to display in the notification.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATION_TITLE = NSString.NSPinnedString("NotificationTitle");

        /// <summary>
        /// <para>The array of all notifications your application can send.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATIONS_ALL = NSString.NSPinnedString("AllNotifications");

        /// <summary>
        /// <para>The array of notifications to turn on by default.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATIONS_DEFAULT = NSString.NSPinnedString("DefaultNotifications");

        /// <summary>
        /// <para>A dictionary of descriptions of _when_ each notification occurs</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATIONS_DESCRIPTIONS = NSString.NSPinnedString("NotificationDescriptions");

        /// <summary>
        /// <para>A dictionary of human-readable names for your notifications.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_NOTIFICATIONS_HUMAN_READABLE_NAMES = NSString.NSPinnedString("HumanReadableNames");

        /// <summary>
        /// <para>A distributed notification to check whether Growl is running.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_PING = NSString.NSPinnedString("Honey, Mind Taking Out The Trash");

        /// <summary>
        /// <para>The distributed notification sent in reply to GROWL_PING.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_PONG = NSString.NSPinnedString("What Do You Want From Me, Woman");


        /// <summary>
        /// <para>MISSING</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_POSITION_PREFERENCE_KEY = NSString.NSPinnedString("GrowlSelectedPosition");

        /// <summary>
        /// <para>The filename extension for registration dictionaries.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_REG_DICT_EXTENSION = NSString.NSPinnedString("growlRegDict");

        /// <summary>
        /// <para>The distributed notification name that tells Growl to shutdown.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_SHUTDOWN = NSString.NSPinnedString("GrowlShutdown");

        /// <summary>
        /// <para>The version of your registration ticket.</para>
        /// <para>Available in Growl v1.2 and later.</para>
        /// </summary>
        public static readonly NSString GROWL_TICKET_VERSION = NSString.NSPinnedString("TicketVersion");
    }
}