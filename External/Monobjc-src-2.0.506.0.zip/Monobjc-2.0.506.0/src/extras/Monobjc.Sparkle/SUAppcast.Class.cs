﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.Sparkle
{
    partial class SUAppcast
    {
        /// <summary>
        /// <para>Original signature is '- (void)fetchAppcastFromURL:(NSURL *)url'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual void FetchAppcastFromURL(NSURL url)
        {
            ObjectiveCRuntime.SendMessage(this, "fetchAppcastFromURL:", url);
        }

        /// <summary>
        /// <para>Original signature is '- (void)setDelegate:(id)delegate'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual Id Delegate
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "delegate"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDelegate:", value); }
        }

        /// <summary>
        /// <para>Original signature is '- (void)setUserAgentString:(NSString *)userAgentString'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual void SetUserAgentString(NSString userAgentString)
        {
            ObjectiveCRuntime.SendMessage(this, "setUserAgentString:", userAgentString);
        }

        /// <summary>
        /// <para>Original signature is '- (NSArray *)items'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSArray Items
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "items"); }
        }
    }
}