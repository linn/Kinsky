//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.CompilerServices;
using Monobjc.Cocoa;

namespace Monobjc.Sparkle
{
    partial class SUAppcast
    {
        /// <summary>
        /// Delegate to subscribe to <see cref="SUAppcast.AppcastDidFinishLoading"/>.
        /// </summary>
        public delegate void AppcastDidFinishLoadingEventHandler(SUAppcast appcast);

        /// <summary>
        /// Delegate to subscribe to <see cref="SUAppcast.AppcastFailedToLoadWithError"/>.
        /// </summary>
        public delegate void AppcastFailedToLoadWithErrorEventHandler(SUAppcast appcast, NSError error);

        /// <summary>
        /// <para>Original signature is '- (void)appcastDidFinishLoading:(SUAppcast *)appcast'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public event AppcastDidFinishLoadingEventHandler AppcastDidFinishLoading
        {
            add { this.GetEventDispatcher().AppcastDidFinishLoadingEvent += value; }
            remove { this.GetEventDispatcher().AppcastDidFinishLoadingEvent -= value; }
        }

        /// <summary>
        /// <para>Original signature is '- (void)appcast:(SUAppcast *)appcast failedToLoadWithError:(NSError *)error'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public event AppcastFailedToLoadWithErrorEventHandler AppcastFailedToLoadWithError
        {
            add { this.GetEventDispatcher().AppcastFailedToLoadWithErrorEvent += value; }
            remove { this.GetEventDispatcher().AppcastFailedToLoadWithErrorEvent -= value; }
        }

        private SUAppcastEventDispatcher dispatcher;

        /// <summary>
        /// Return the event handler that relays delegate messages.
        /// </summary>
        [MethodImpl(MethodImplOptions.Synchronized)]
        protected SUAppcastEventDispatcher GetEventDispatcher()
        {
            if (this.dispatcher == null)
            {
                this.dispatcher = new SUAppcastEventDispatcher();
                this.Delegate = this.dispatcher;
            }
            return this.dispatcher;
        }

        /// <summary>
        /// Inner event handler that is exposed to the Objective-C runtime and relays delegate messages to listeners.
        /// </summary>
        [ObjectiveCClass]
        public class SUAppcastEventDispatcher : NSObject
        {
            /// <summary>
            /// Static field for a quick access to the SUAppcastEventDispatcher class.
            /// </summary>
            public static readonly Class SUAppcastEventDispatcherClass = Class.GetClassFromType(typeof (SUAppcastEventDispatcher));

            /// <summary>
            /// Initializes a new instance of the <see cref="SUAppcastEventDispatcher"/> class.
            /// </summary>
            public SUAppcastEventDispatcher() {}

            /// <summary>
            /// Initializes a new instance of the <see cref="SUAppcastEventDispatcher"/> class.
            /// </summary>
            /// <param name="nativePointer">The native pointer.</param>
            public SUAppcastEventDispatcher(IntPtr nativePointer)
                : base(nativePointer) {}

            /// <summary>
            /// <para>Returns a Boolean value that indicates whether the receiver implements or inherits a method that can respond to a specified message.</para>
            /// <para>Original signature is '- (BOOL)respondsToSelector:(SEL)aSelector'</para>
            /// <para>Available in Mac OS X v10.0 and later.</para>
            /// </summary>
            /// <param name="aSelector">A selector that identifies a message.</param>
            /// <returns>
            /// YES if the receiver implements or inherits a method that can respond to aSelector, otherwise NO.
            /// </returns>
            [ObjectiveCMessage("respondsToSelector:")]
            public override bool RespondsToSelector(IntPtr aSelector)
            {
                String message = ObjectiveCRuntime.Selector(aSelector);

                if (message.Equals("appcastDidFinishLoading:"))
                {
                    return (this.AppcastDidFinishLoadingEvent != null);
                }
                if (message.Equals("appcast:failedToLoadWithError:"))
                {
                    return (this.AppcastFailedToLoadWithErrorEvent != null);
                }

                return ObjectiveCRuntime.SendMessageSuper<bool>(this, SUAppcastEventDispatcherClass, "respondsToSelector:", aSelector);
            }

            /// <summary>
            /// Event handler to dispatch calls to "appcastDidFinishLoading:".
            /// </summary>
            public event AppcastDidFinishLoadingEventHandler AppcastDidFinishLoadingEvent;

            /// <summary>
            /// Event handler to dispatch calls to "appcast:failedToLoadWithError:".
            /// </summary>
            public event AppcastFailedToLoadWithErrorEventHandler AppcastFailedToLoadWithErrorEvent;

            /// <summary>
            /// <para>Original signature is '- (void)appcastDidFinishLoading:(SUAppcast *)appcast'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("appcastDidFinishLoading:")]
            public void AppcastDidFinishLoading(SUAppcast appcast)
            {
                if (this.AppcastDidFinishLoadingEvent != null)
                {
                    this.AppcastDidFinishLoadingEvent(appcast);
                }
            }

            /// <summary>
            /// <para>Original signature is '- (void)appcast:(SUAppcast *)appcast failedToLoadWithError:(NSError *)error'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("appcast:failedToLoadWithError:")]
            public void AppcastFailedToLoadWithError(SUAppcast appcast, NSError error)
            {
                if (this.AppcastFailedToLoadWithErrorEvent != null)
                {
                    this.AppcastFailedToLoadWithErrorEvent(appcast, error);
                }
            }
        }
    }
}