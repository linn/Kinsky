//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using Monobjc.Cocoa;

namespace Monobjc.Sparkle
{
    partial class SUUpdater
    {
        /// <summary>
        /// <para>This method allows you to add extra parameters to the appcast URL, potentially based on whether or not Sparkle will also be sending along the system profile. This method should return an array of dictionaries with keys: "key", "value", "displayKey", "displayValue", the latter two being specifically for display to the user.</para>
        /// <para>Original signature is '- (NSArray *)feedParametersForUpdater:(SUUpdater *)updater sendingSystemProfile:(BOOL)sendingProfile;'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public delegate NSArray FeedParametersForUpdaterSendingSystemProfileEventHandler(SUUpdater updater, bool sendingProfile);

        /// <summary>
        /// <para>Use this to override the default behavior for Sparkle prompting the user about automatic update checks.</para>
        /// <para>Original signature is '- (BOOL)updaterShouldPromptForPermissionToCheckForUpdates:(SUUpdater *)bundle;'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public delegate bool UpdaterShouldPromptForPermissionToCheckForUpdatesEventHandler(SUUpdater bundle);

        /// <summary>
        /// <para>Implement this if you want to do some special handling with the appcast once it finishes loading.</para>
        /// <para>Original signature is '- (void)updater:(SUUpdater *)updater didFinishLoadingAppcast:(SUAppcast *)appcast;'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public delegate void UpdaterDidFinishLoadingAppcastEventHandler(SUUpdater updater, SUAppcast appcast);

        /// <summary>
        /// <para>If you're using special logic or extensions in your appcast, implement this to use your own logic for finding a valid update, if any, in the given appcast.</para>
        /// <para>Original signature is '- (SUAppcastItem *)bestValidUpdateInAppcast:(SUAppcast *)appcast forUpdater:(SUUpdater *)bundle;'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public delegate SUAppcastItem BestValidUpdateInAppcastForUpdaterEventHandler(SUAppcast appcast, SUUpdater updater);

        /// <summary>
        /// <para>Sent when a valid update is found by the update driver.</para>
        /// <para>Original signature is '- (void)updater:(SUUpdater *)updater didFindValidUpdate:(SUAppcastItem *)update;'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public delegate void UpdaterDidFindValidUpdateEventHandler(SUUpdater updater, SUAppcastItem update);

        /// <summary>
        /// <para>Sent when a valid update is not found.</para>
        /// <para>Original signature is '- (void)updaterDidNotFindUpdate:(SUUpdater *)update;'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public delegate void UpdaterDidNotFindUpdateEventHandler(SUUpdater update);

        /// <summary>
        /// <para>Sent immediately before installing the specified update.</para>
        /// <para>Original signature is '- (void)updater:(SUUpdater *)updater willInstallUpdate:(SUAppcastItem *)update;'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public delegate void UpdaterWillInstallUpdateEventHandler(SUUpdater updater, SUAppcastItem update);

        /// <summary>
        /// <para>Return YES to delay the relaunch until you do some processing; invoke the given NSInvocation to continue.</para>
        /// <para>Original signature is '- (BOOL)updater:(SUUpdater *)updater shouldPostponeRelaunchForUpdate:(SUAppcastItem *)update untilInvoking:(NSInvocation *)invocation;'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public delegate bool UpdaterShouldPostponeRelaunchForUpdateUntilInvokingEventHandler(SUUpdater updater, SUAppcastItem update, NSInvocation invocation);

        /// <summary>
        /// <para>Called immediately before relaunching.</para>
        /// <para>Original signature is '- (void)updaterWillRelaunchApplication:(SUUpdater *)updater;'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public delegate void UpdaterWillRelaunchApplicationEventHandler(SUUpdater updater);

        /// <summary>
        /// <para>This method allows you to provide a custom version comparator.</para>
        /// <para>If you don't implement this method or return nil, the standard version comparator will be used.</para>
        /// <para>Original signature is '- (id &lt;SUVersionComparison&gt;)versionComparatorForUpdater:(SUUpdater *)updater;'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public delegate ISUVersionComparisonProtocol VersionComparatorForUpdaterEventHandler(SUUpdater updater);

        /// <summary>
        /// <para>Returns the path which is used to relaunch the client after the update is installed. By default, the path of the host bundle.</para>
        /// <para>Original signature is '- (NSString *)pathToRelaunchForUpdater:(SUUpdater *)updater;'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public delegate NSString PathToRelaunchForUpdaterEventHandler(SUUpdater updater);

        /// <summary>
        /// Sets the delegate of the <see cref="SUUpdater"/> instance.
        /// </summary>
        /// <param name="assignment">The assignment of delegation methods.</param>
        public void SetDelegate(Action<SUUpdaterEventDispatcher> assignment)
        {
            SUUpdaterEventDispatcher @delegate = this.Delegate.SafeCastAs<SUUpdaterEventDispatcher>();
            if (@delegate != null)
            {
                @delegate.Release();
                this.Delegate = null;
            }

            if (assignment != null)
            {
                @delegate = new SUUpdaterEventDispatcher();
                assignment(@delegate);
                this.Delegate = @delegate;
            }
        }

        /// <summary>
        /// Inner event handler that is exposed to the Objective-C runtime and relays delegate messages to listeners.
        /// </summary>
        [ObjectiveCClass]
        public class SUUpdaterEventDispatcher : NSObject
        {
            /// <summary>
            /// Static field for a quick access to the SUAppcastEventDispatcher class.
            /// </summary>
            public static readonly Class SUUpdaterEventDispatcherClass = Class.GetClassFromType(typeof (SUUpdaterEventDispatcher));

            /// <summary>
            /// Initializes a new instance of the <see cref="SUUpdaterEventDispatcher"/> class.
            /// </summary>
            public SUUpdaterEventDispatcher() {}

            /// <summary>
            /// Initializes a new instance of the <see cref="SUUpdaterEventDispatcher"/> class.
            /// </summary>
            /// <param name="nativePointer">The native pointer.</param>
            public SUUpdaterEventDispatcher(IntPtr nativePointer)
                : base(nativePointer) {}

            /// <summary>
            /// <para>Returns a Boolean value that indicates whether the receiver implements or inherits a method that can respond to a specified message.</para>
            /// <para>Original signature is '- (BOOL)respondsToSelector:(SEL)aSelector'</para>
            /// <para>Available in Mac OS X v10.0 and later.</para>
            /// </summary>
            /// <param name="aSelector">A selector that identifies a message.</param>
            /// <returns>
            /// YES if the receiver implements or inherits a method that can respond to aSelector, otherwise NO.
            /// </returns>
            [ObjectiveCMessage("respondsToSelector:")]
            public override bool RespondsToSelector(IntPtr aSelector)
            {
                String message = ObjectiveCRuntime.Selector(aSelector);
                switch (message)
                {
                    case "feedParametersForUpdater:sendingSystemProfile:":
                        return (this.FeedParametersForUpdaterSendingSystemProfileEvent != null);
                    case "updaterShouldPromptForPermissionToCheckForUpdates:":
                        return (this.UpdaterShouldPromptForPermissionToCheckForUpdatesEvent != null);
                    case "updater:didFinishLoadingAppcast:":
                        return (this.UpdaterDidFinishLoadingAppcastEvent != null);
                    case "bestValidUpdateInAppcast:forUpdater:":
                        return (this.BestValidUpdateInAppcastForUpdaterEvent != null);
                    case "updater:didFindValidUpdate:":
                        return (this.UpdaterDidFindValidUpdateEvent != null);
                    case "updaterDidNotFindUpdate:":
                        return (this.UpdaterDidNotFindUpdateEvent != null);
                    case "updater:willInstallUpdate:":
                        return (this.UpdaterWillInstallUpdateEvent != null);
                    case "updater:shouldPostponeRelaunchForUpdate:untilInvoking:":
                        return (this.UpdaterShouldPostponeRelaunchForUpdateUntilInvokingEvent != null);
                    case "updaterWillRelaunchApplication:":
                        return (this.UpdaterWillRelaunchApplicationEvent != null);
                    case "versionComparatorForUpdater:":
                        return (this.VersionComparatorForUpdaterEvent != null);
                    case "pathToRelaunchForUpdater:":
                        return (this.PathToRelaunchForUpdaterEvent != null);
                }

                return ObjectiveCRuntime.SendMessageSuper<bool>(this, SUUpdaterEventDispatcherClass, "respondsToSelector:", aSelector);
            }

            /// <summary>
            /// <para>This method allows you to add extra parameters to the appcast URL, potentially based on whether or not Sparkle will also be sending along the system profile. This method should return an array of dictionaries with keys: "key", "value", "displayKey", "displayValue", the latter two being specifically for display to the user.</para>
            /// <para>Original signature is '- (NSArray *)feedParametersForUpdater:(SUUpdater *)updater sendingSystemProfile:(BOOL)sendingProfile;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            public event FeedParametersForUpdaterSendingSystemProfileEventHandler FeedParametersForUpdaterSendingSystemProfileEvent;

            /// <summary>
            /// <para>Use this to override the default behavior for Sparkle prompting the user about automatic update checks.</para>
            /// <para>Original signature is '- (BOOL)updaterShouldPromptForPermissionToCheckForUpdates:(SUUpdater *)bundle;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            public event UpdaterShouldPromptForPermissionToCheckForUpdatesEventHandler UpdaterShouldPromptForPermissionToCheckForUpdatesEvent;

            /// <summary>
            /// <para>Implement this if you want to do some special handling with the appcast once it finishes loading.</para>
            /// <para>Original signature is '- (void)updater:(SUUpdater *)updater didFinishLoadingAppcast:(SUAppcast *)appcast;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            public event UpdaterDidFinishLoadingAppcastEventHandler UpdaterDidFinishLoadingAppcastEvent;

            /// <summary>
            /// <para>If you're using special logic or extensions in your appcast, implement this to use your own logic for finding a valid update, if any, in the given appcast.</para>
            /// <para>Original signature is '- (SUAppcastItem *)bestValidUpdateInAppcast:(SUAppcast *)appcast forUpdater:(SUUpdater *)bundle;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            public event BestValidUpdateInAppcastForUpdaterEventHandler BestValidUpdateInAppcastForUpdaterEvent;

            /// <summary>
            /// <para>Sent when a valid update is found by the update driver.</para>
            /// <para>Original signature is '- (void)updater:(SUUpdater *)updater didFindValidUpdate:(SUAppcastItem *)update;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            public event UpdaterDidFindValidUpdateEventHandler UpdaterDidFindValidUpdateEvent;

            /// <summary>
            /// <para>Sent when a valid update is not found.</para>
            /// <para>Original signature is '- (void)updaterDidNotFindUpdate:(SUUpdater *)update;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            public event UpdaterDidNotFindUpdateEventHandler UpdaterDidNotFindUpdateEvent;

            /// <summary>
            /// <para>Sent immediately before installing the specified update.</para>
            /// <para>Original signature is '- (void)updater:(SUUpdater *)updater willInstallUpdate:(SUAppcastItem *)update;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            public event UpdaterWillInstallUpdateEventHandler UpdaterWillInstallUpdateEvent;

            /// <summary>
            /// <para>Return YES to delay the relaunch until you do some processing; invoke the given NSInvocation to continue.</para>
            /// <para>Original signature is '- (BOOL)updater:(SUUpdater *)updater shouldPostponeRelaunchForUpdate:(SUAppcastItem *)update untilInvoking:(NSInvocation *)invocation;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            public event UpdaterShouldPostponeRelaunchForUpdateUntilInvokingEventHandler UpdaterShouldPostponeRelaunchForUpdateUntilInvokingEvent;

            /// <summary>
            /// <para>Called immediately before relaunching.</para>
            /// <para>Original signature is '- (void)updaterWillRelaunchApplication:(SUUpdater *)updater;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            public event UpdaterWillRelaunchApplicationEventHandler UpdaterWillRelaunchApplicationEvent;

            /// <summary>
            /// <para>This method allows you to provide a custom version comparator.</para>
            /// <para>If you don't implement this method or return nil, the standard version comparator will be used.</para>
            /// <para>Original signature is '- (id &lt;SUVersionComparison&gt;)versionComparatorForUpdater:(SUUpdater *)updater;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            public event VersionComparatorForUpdaterEventHandler VersionComparatorForUpdaterEvent;

            /// <summary>
            /// <para>Returns the path which is used to relaunch the client after the update is installed. By default, the path of the host bundle.</para>
            /// <para>Original signature is '- (NSString *)pathToRelaunchForUpdater:(SUUpdater *)updater;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            public event PathToRelaunchForUpdaterEventHandler PathToRelaunchForUpdaterEvent;

            /// <summary>
            /// <para>This method allows you to add extra parameters to the appcast URL, potentially based on whether or not Sparkle will also be sending along the system profile. This method should return an array of dictionaries with keys: "key", "value", "displayKey", "displayValue", the latter two being specifically for display to the user.</para>
            /// <para>Original signature is '- (NSArray *)feedParametersForUpdater:(SUUpdater *)updater sendingSystemProfile:(BOOL)sendingProfile;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("feedParametersForUpdater:sendingSystemProfile:")]
            public NSArray FeedParametersForUpdaterSendingSystemProfile(SUUpdater updater, bool sendingProfile)
            {
                NSArray result = NSArray.Array;
                if (this.FeedParametersForUpdaterSendingSystemProfileEvent != null)
                {
                    result = this.FeedParametersForUpdaterSendingSystemProfileEvent(updater, sendingProfile);
                }
                return result;
            }

            /// <summary>
            /// <para>Use this to override the default behavior for Sparkle prompting the user about automatic update checks.</para>
            /// <para>Original signature is '- (BOOL)updaterShouldPromptForPermissionToCheckForUpdates:(SUUpdater *)bundle;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("updaterShouldPromptForPermissionToCheckForUpdates:")]
            public bool UpdaterShouldPromptForPermissionToCheckForUpdates(SUUpdater updater)
            {
                bool result = false;
                if (this.UpdaterShouldPromptForPermissionToCheckForUpdatesEvent != null)
                {
                    result = this.UpdaterShouldPromptForPermissionToCheckForUpdatesEvent(updater);
                }
                return result;
            }

            /// <summary>
            /// <para>Implement this if you want to do some special handling with the appcast once it finishes loading.</para>
            /// <para>Original signature is '- (void)updater:(SUUpdater *)updater didFinishLoadingAppcast:(SUAppcast *)appcast;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("updater:didFinishLoadingAppcast:")]
            public void UpdaterDidFinishLoadingAppcast(SUUpdater updater, SUAppcast appcast)
            {
                if (this.UpdaterDidFinishLoadingAppcastEvent != null)
                {
                    this.UpdaterDidFinishLoadingAppcastEvent(updater, appcast);
                }
            }

            /// <summary>
            /// <para>If you're using special logic or extensions in your appcast, implement this to use your own logic for finding a valid update, if any, in the given appcast.</para>
            /// <para>Original signature is '- (SUAppcastItem *)bestValidUpdateInAppcast:(SUAppcast *)appcast forUpdater:(SUUpdater *)bundle;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("bestValidUpdateInAppcast:forUpdater:")]
            public SUAppcastItem BestValidUpdateInAppcastForUpdater(SUAppcast appcast, SUUpdater updater)
            {
                SUAppcastItem result = null;
                if (this.BestValidUpdateInAppcastForUpdaterEvent != null)
                {
                    result = this.BestValidUpdateInAppcastForUpdaterEvent(appcast, updater);
                }
                return result;
            }

            /// <summary>
            /// <para>Sent when a valid update is found by the update driver.</para>
            /// <para>Original signature is '- (void)updater:(SUUpdater *)updater didFindValidUpdate:(SUAppcastItem *)update;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("updater:didFindValidUpdate:")]
            public void UpdaterDidFindValidUpdate(SUUpdater updater, SUAppcastItem update)
            {
                if (this.UpdaterDidFindValidUpdateEvent != null)
                {
                    this.UpdaterDidFindValidUpdateEvent(updater, update);
                }
            }

            /// <summary>
            /// <para>Sent when a valid update is not found.</para>
            /// <para>Original signature is '- (void)updaterDidNotFindUpdate:(SUUpdater *)update;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("updaterDidNotFindUpdate:")]
            public void UpdaterDidNotFindUpdate(SUUpdater update)
            {
                if (this.UpdaterDidNotFindUpdateEvent != null)
                {
                    this.UpdaterDidNotFindUpdateEvent(update);
                }
            }

            /// <summary>
            /// <para>Sent immediately before installing the specified update.</para>
            /// <para>Original signature is '- (void)updater:(SUUpdater *)updater willInstallUpdate:(SUAppcastItem *)update;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("updater:willInstallUpdate:")]
            public void UpdaterWillInstallUpdate(SUUpdater updater, SUAppcastItem update)
            {
                if (this.UpdaterWillInstallUpdateEvent != null)
                {
                    this.UpdaterWillInstallUpdateEvent(updater, update);
                }
            }

            /// <summary>
            /// <para>Return YES to delay the relaunch until you do some processing; invoke the given NSInvocation to continue.</para>
            /// <para>Original signature is '- (BOOL)updater:(SUUpdater *)updater shouldPostponeRelaunchForUpdate:(SUAppcastItem *)update untilInvoking:(NSInvocation *)invocation;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("updater:shouldPostponeRelaunchForUpdate:untilInvoking:")]
            public bool UpdaterShouldPostponeRelaunchForUpdateUntilInvoking(SUUpdater updater, SUAppcastItem update, NSInvocation invocation)
            {
                bool result = false;
                if (this.UpdaterShouldPostponeRelaunchForUpdateUntilInvokingEvent != null)
                {
                    result = this.UpdaterShouldPostponeRelaunchForUpdateUntilInvokingEvent(updater, update, invocation);
                }
                return result;
            }

            /// <summary>
            /// <para>Called immediately before relaunching.</para>
            /// <para>Original signature is '- (void)updaterWillRelaunchApplication:(SUUpdater *)updater;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("updaterWillRelaunchApplication:")]
            public void UpdaterWillRelaunchApplication(SUUpdater update)
            {
                if (this.UpdaterWillRelaunchApplicationEvent != null)
                {
                    this.UpdaterWillRelaunchApplicationEvent(update);
                }
            }

            /// <summary>
            /// <para>This method allows you to provide a custom version comparator.</para>
            /// <para>If you don't implement this method or return nil, the standard version comparator will be used.</para>
            /// <para>Original signature is '- (id &lt;SUVersionComparison&gt;)versionComparatorForUpdater:(SUUpdater *)updater;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("versionComparatorForUpdater:")]
            public ISUVersionComparisonProtocol VersionComparatorForUpdater(SUUpdater updater)
            {
                ISUVersionComparisonProtocol result = null;
                if (this.VersionComparatorForUpdaterEvent != null)
                {
                    result = this.VersionComparatorForUpdaterEvent(updater);
                }
                return result;
            }

            /// <summary>
            /// <para>Returns the path which is used to relaunch the client after the update is installed. By default, the path of the host bundle.</para>
            /// <para>Original signature is '- (NSString *)pathToRelaunchForUpdater:(SUUpdater *)updater;'</para>
            /// <para>Available in Sparkle 1.5b6 and later.</para>
            /// </summary>
            [ObjectiveCMessage("pathToRelaunchForUpdater:")]
            public NSString PathToRelaunchForUpdater(SUUpdater updater)
            {
                NSString result = null;
                if (this.PathToRelaunchForUpdaterEvent != null)
                {
                    result = this.PathToRelaunchForUpdaterEvent(updater);
                }
                return result;
            }
        }
    }
}