﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.Sparkle
{
    partial class SUUpdater
    {
        /// <summary>
        /// <para>Original signature is '+ (SUUpdater *)sharedUpdater'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public static SUUpdater SharedUpdater
        {
            get { return ObjectiveCRuntime.SendMessage<SUUpdater>(SUUpdaterClass, "sharedUpdater"); }
        }

        /// <summary>
        /// <para>Original signature is '+ (SUUpdater *)updaterForBundle:(NSBundle *)bundle'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public static SUUpdater UpdaterForBundle(NSBundle bundle)
        {
            return ObjectiveCRuntime.SendMessage<SUUpdater>(SUUpdaterClass, "updaterForBundle:", bundle);
        }

        /// <summary>
        /// <para>Original signature is '- (NSBundle *)hostBundle'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSBundle HostBundle
        {
            get { return ObjectiveCRuntime.SendMessage<NSBundle>(this, "hostBundle"); }
        }

        /// <summary>
        /// <para>Original signature is '- (id)delegate'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual Id Delegate
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "delegate"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDelegate:", value); }
        }

        /// <summary>
        /// <para>Original signature is '- (BOOL)automaticallyChecksForUpdates'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual bool AutomaticallyChecksForUpdates
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "automaticallyChecksForUpdates"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAutomaticallyChecksForUpdates:", value); }
        }

        /// <summary>
        /// <para>Original signature is '- (NSTimeInterval)updateCheckInterval'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual double UpdateCheckInterval
        {
            get { return ObjectiveCRuntime.SendMessage<double>(this, "updateCheckInterval"); }
            set { ObjectiveCRuntime.SendMessage(this, "setUpdateCheckInterval:", value); }
        }

        /// <summary>
        /// <para>Original signature is '- (NSURL *)feedURL'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSURL FeedURL
        {
            get { return ObjectiveCRuntime.SendMessage<NSURL>(this, "feedURL"); }
            set { ObjectiveCRuntime.SendMessage(this, "setFeedURL:", value); }
        }

        /// <summary>
        /// <para>Original signature is '- (BOOL)sendsSystemProfile'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual bool SendsSystemProfile
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "sendsSystemProfile"); }
            set { ObjectiveCRuntime.SendMessage(this, "setSendsSystemProfile:", value); }
        }

        /// <summary>
        /// <para>Original signature is '- (BOOL)automaticallyDownloadsUpdates'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual bool AutomaticallyDownloadsUpdates
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "automaticallyDownloadsUpdates"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAutomaticallyDownloadsUpdates:", value); }
        }

        /// <summary>
        /// <para>This IBAction is meant for a main menu item. Hook up any menu item to this action,
        /// and Sparkle will check for updates and report back its findings verbosely.</para>
        /// <para>Original signature is '- (IBAction)checkForUpdates:sender'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual void CheckForUpdates(Id sender)
        {
            ObjectiveCRuntime.SendMessage(this, "checkForUpdates:", sender);
        }

        /// <summary>
        /// <para>This kicks off an update meant to be programmatically initiated. That is, it will display no UI unless it actually finds an update,
        /// in which case it proceeds as usual. If the fully automated updating is turned on, however, this will invoke that behavior, and if an
        /// update is found, it will be downloaded and prepped for installation.</para>
        /// <para>Original signature is '- (void)checkForUpdatesInBackground'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual void CheckForUpdatesInBackground()
        {
            ObjectiveCRuntime.SendMessage(this, "checkForUpdatesInBackground");
        }

        /// <summary>
        /// <para>Date of last update check. Returns null if no check has been performed.</para>
        /// <para>Original signature is '- (NSDate *)lastUpdateCheckDate'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSDate LastUpdateCheckDate
        {
            get { return ObjectiveCRuntime.SendMessage<NSDate>(this, "lastUpdateCheckDate"); }
        }

        /// <summary>
        /// <para>This begins a "probing" check for updates which will not actually offer to update to that version. The delegate methods, though,
        /// (up to updater:didFindValidUpdate: and updaterDidNotFindUpdate:), are called, so you can use that information in your UI.</para>
        /// <para>Original signature is '- (void)checkForUpdateInformation'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual void CheckForUpdateInformation()
        {
            ObjectiveCRuntime.SendMessage(this, "checkForUpdateInformation");
        }

        /// <summary>
        /// <para>Call this to appropriately schedule or cancel the update checking timer according to the preferences for time interval and automatic checks.</para>
        /// <para>Original signature is '- (void)resetUpdateCycle'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual void ResetUpdateCycle()
        {
            ObjectiveCRuntime.SendMessage(this, "resetUpdateCycle");
        }

        /// <summary>
        /// <para>Original signature is '- (bool)updateInProgress'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual bool UpdateInProgress
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "updateInProgress"); }
        }
    }
}