﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.Sparkle
{
    partial class SUAppcastItem
    {
        /// <summary>
        /// <para>Initializes with data from a dictionary provided by the RSS class.</para>
        /// <para>Original signature is '- (id)initWithDictionary:(NSDictionary *)dict'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual Id InitWithDictionary(NSDictionary dict)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithDictionary:", dict);
        }

        /// <summary>
        /// <para>Original signature is '- (NSString *)title'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSString Title
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "title"); }
        }

        /// <summary>
        /// <para>Original signature is '- (NSString *)versionString'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSString VersionString
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "versionString"); }
        }

        /// <summary>
        /// <para>Original signature is '- (NSString *)displayVersionString'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSString DisplayVersionString
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "displayVersionString"); }
        }

        /// <summary>
        /// <para>Original signature is '- (NSDate *)date'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSDate Date
        {
            get { return ObjectiveCRuntime.SendMessage<NSDate>(this, "date"); }
        }

        /// <summary>
        /// <para>Original signature is '- (NSString *)itemDescription'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        /// <value></value>
        public NSString ItemDescription
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "itemDescription"); }
        }

        /// <summary>
        /// <para>Original signature is '- (NSURL *)releaseNotesURL'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSURL ReleaseNotesURL
        {
            get { return ObjectiveCRuntime.SendMessage<NSURL>(this, "releaseNotesURL"); }
        }

        /// <summary>
        /// <para>Original signature is '- (NSURL *)fileURL'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSURL FileURL
        {
            get { return ObjectiveCRuntime.SendMessage<NSURL>(this, "fileURL"); }
        }

        /// <summary>
        /// <para>Original signature is '- (NSString *)DSASignature'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSString DSASignature
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "DSASignature"); }
        }

        /// <summary>
        /// <para>Original signature is '- (NSString *)minimumSystemVersion'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSString MinimumSystemVersion
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "minimumSystemVersion"); }
        }

        /// <summary>
        /// <para>Returns the dictionary provided in initWithDictionary; this might be useful later for extensions.</para>
        /// <para>Original signature is '- (NSDictionary *)propertiesDictionary'</para>
        /// <para>Available in Sparkle 1.5b6 and later.</para>
        /// </summary>
        public virtual NSDictionary PropertiesDictionary
        {
            get { return ObjectiveCRuntime.SendMessage<NSDictionary>(this, "propertiesDictionary"); }
        }
    }
}