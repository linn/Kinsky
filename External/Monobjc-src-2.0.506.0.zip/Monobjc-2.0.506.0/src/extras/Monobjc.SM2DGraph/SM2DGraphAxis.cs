//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.SM2DGraph
{
    /// <summary>
    /// <para>When dealing with various properties of graph axis, these constants should be used.</para>
    /// </summary>
    public enum SM2DGraphAxis
    {
        /// <summary>
        /// <para>The Y axis of the graph.</para>
        /// </summary>
        kSM2DGraph_Axis_Y = 0,
        /// <summary>
        /// <para>The X axis of the graph.</para>
        /// </summary>
        kSM2DGraph_Axis_X = 1,
        /// <summary>
        /// <para>Y axis on the right side of the graph.</para>
        /// </summary>
        kSM2DGraph_Axis_Y_Right = 2,
        /// <summary>
        /// <para>Y axis on left side of graph - equal to kSM2DGraph_Axis_Y.</para>
        /// </summary>
        kSM2DGraph_Axis_Y_Left = kSM2DGraph_Axis_Y
    }
}