﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.SM2DGraph
{
    partial class SMPieChartView
    {
        /// <summary>
        /// 	<para>Returns the attributed title of the pie chart. The default is no title (nil).</para>
        /// 	<para>Original signature is '- (NSAttributedString *)attributedTitle;'</para>
        /// </summary>
        /// <value>An autoreleased string or nil.</value>
        public virtual NSAttributedString AttributedTitle
        {
            get { return ObjectiveCRuntime.SendMessage<NSAttributedString>(this, "attributedTitle"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAttributedTitle:", value); }
        }

        /// <summary>
        /// 	<para>Returns the color used to draw the background of the receiver. The default background color is white.</para>
        /// 	<para>Original signature is '- (NSColor *)backgroundColor;'</para>
        /// </summary>
        /// <value>The color used to draw the background.</value>
        public virtual NSColor BackgroundColor
        {
            get { return ObjectiveCRuntime.SendMessage<NSColor>(this, "backgroundColor"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBackgroundColor:", value); }
        }

        /// <summary>
        /// 	<para>Returns the color used to draw the border of each slice. The default color is black.</para>
        /// 	<para>Original signature is '- (NSColor *)borderColor;'</para>
        /// </summary>
        /// <value>The color used to draw the border of each slice.</value>
        public virtual NSColor BorderColor
        {
            get { return ObjectiveCRuntime.SendMessage<NSColor>(this, "borderColor"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBorderColor:", value); }
        }

        /// <summary>
        /// 	<para>Returns the object that slice data is pulled from.</para>
        /// 	<para>Original signature is '- (id)dataSource;'</para>
        /// </summary>
        /// <value>The data source object of the pie view.</value>
        public virtual Id DataSource
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "dataSource"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDataSource:", value); }
        }

        /// <summary>
        /// 	<para>Returns the delegate object for the pie view.</para>
        /// 	<para>Original signature is '- (id)delegate;'</para>
        /// </summary>
        /// <value>The delegate object.</value>
        public virtual Id Delegate
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "delegate"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDelegate:", value); }
        }

        /// <summary>
        /// 	<para>Returns the pixel offset from the center of the chart to draw exploded slices of the pie. The default is zero.</para>
        /// 	<para>Original signature is '- (float)explodeDistance;'</para>
        /// </summary>
        /// <value>The number of pixels to offset exploded parts of the pie.</value>
        public virtual float ExplodeDistance
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "explodeDistance"); }
            set { ObjectiveCRuntime.SendMessage(this, "setExplodeDistance:", value); }
        }

        /// <summary>
        /// 	<para>Returns an autoreleased image of the entire chart view. This image is filled with a white background first, so it should not have any transparent parts.</para>
        /// 	<para>Original signature is '- (NSImage *)imageOfView;'</para>
        /// </summary>
        /// <value>An NSImage object of the entire chart view.</value>
        public virtual NSImage ImageOfView
        {
            get { return ObjectiveCRuntime.SendMessage<NSImage>(this, "imageOfView"); }
        }

        /// <summary>
        /// 	<para>Returns the position of labels for the pie chart. The default is no labels.</para>
        /// 	<para>Original signature is '- (SMLabelPositionEnum)labelPosition;'</para>
        /// </summary>
        /// <value>The position of labels.</value>
        public virtual SMLabelPosition LabelPosition
        {
            get { return ObjectiveCRuntime.SendMessage<SMLabelPosition>(this, "labelPosition"); }
            set { ObjectiveCRuntime.SendMessage(this, "setLabelPosition:", value); }
        }

        /// <summary>
        /// 	<para>Returns the tag of the receiver. This is an integer you can use for whatever you'd like.</para>
        /// 	<para>Original signature is '- (int)tag;'</para>
        /// </summary>
        /// <value>The tag of the receiver.</value>
        public new virtual int Tag
        {
            get { return ObjectiveCRuntime.SendMessage<int>(this, "tag"); }
            set { ObjectiveCRuntime.SendMessage(this, "setTag:", value); }
        }

        /// <summary>
        /// 	<para>Returns the title of the pie chart. The default is no title (nil).</para>
        /// 	<para>Original signature is '- (NSString *)title'</para>
        /// </summary>
        /// <value>An autoreleased string or nil.</value>
        public virtual NSString Title
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "title"); }
            set { ObjectiveCRuntime.SendMessage(this, "setTitle:", value); }
        }

        /// <summary>
        /// 	<para>Returns the position of the title. The default is <see cref="SMTitlePosition.SMTitlePositionBelow"/>.</para>
        /// 	<para>Original signature is '- (SMTitlePosition)titlePosition;'</para>
        /// </summary>
        /// <value>The number of position to draw the title in.</value>
        public virtual SMTitlePosition TitlePosition
        {
            get { return ObjectiveCRuntime.SendMessage<SMTitlePosition>(this, "titlePosition"); }
            set { ObjectiveCRuntime.SendMessage(this, "setTitlePosition:", value); }
        }

        /// <summary>
        /// 	<para>Converts a point from a given window/view coordinate system to a slice of the pie, or -1 if the click was not on a slice of the pie. For example, if there are two slices of the pie (left half and right half) and the user clicks on the left half, this would return 0.</para>
        /// 	<para>Original signature is '- (int)convertToSliceFromPoint:(NSPoint)inPoint fromView:(NSView *)inView;'</para>
        /// </summary>
        /// <param name="inPoint">The point to be converted.</param>
        /// <param name="inView">The inPoint parameter is in this view's coordinate system. A value of nil means the window's coordinate system.</param>
        /// <returns>The slice of the pie that was clicked on. If the point is not on a slice of pie, returns -1.</returns>
        public virtual int ConvertToSliceFromPointFromView(NSPoint inPoint, NSView inView)
        {
            return ObjectiveCRuntime.SendMessage<int>(this, "convertToSliceFromPoint:fromView:", inPoint, inView);
        }

        /// <summary>
        /// 	<para>Simple cover method that calls -reloadData, then -reloadAttributes.</para>
        /// 	<para>Original signature is '- (IBAction)refreshDisplay:(id)sender;'</para>
        /// </summary>
        /// <param name="sender">The sender.</param>
        public virtual void RefreshDisplay(Id sender)
        {
            ObjectiveCRuntime.SendMessage(this, "refreshDisplay:", sender);
        }

        /// <summary>
        /// 	<para>Reloads all slice attributes from the datasource and schedules the chart for redrawing. The slice data is not reloaded.</para>
        /// 	<para>Original signature is '- (void)reloadAttributes;'</para>
        /// </summary>
        public virtual void ReloadAttributes()
        {
            ObjectiveCRuntime.SendMessage(this, "reloadAttributes");
        }

        /// <summary>
        /// 	<para>Reloads a specific slice's attributes from the datasource and schedules the chart for redrawing. The slice data is not reloaded.</para>
        /// 	<para>Original signature is '- (void)reloadAttributesForSliceIndex:(unsigned int)inSliceIndex;'</para>
        /// </summary>
        /// <param name="inSliceIndex">The zero based index of the slice to reload.</param>
        public virtual void ReloadAttributesForSliceIndex(uint inSliceIndex)
        {
            ObjectiveCRuntime.SendMessage(this, "reloadAttributesForSliceIndex:", inSliceIndex);
        }

        /// <summary>
        /// 	<para>Reloads all slice data from the datasource and schedules the chart for redrawing.</para>
        /// 	<para>Original signature is '- (void)reloadData;'</para>
        /// </summary>
        public virtual void ReloadData()
        {
            ObjectiveCRuntime.SendMessage(this, "reloadData");
        }
    }
}