//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.SM2DGraph
{
    /// <summary>
    /// <para>Symbols that can be used on line style graphs. Does nothing for bar style lines.</para>
    /// </summary>
    public enum SM2DGraphSymbolType
    {
        /// <summary>
        /// <para>Plain lines - no symbol marking points.</para>
        /// </summary>
        kSM2DGraph_Symbol_None = 0,
        /// <summary>
        /// <para>Open triangle marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_Triangle,
        /// <summary>
        /// <para>Open diamond marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_Diamond,
        /// <summary>
        /// <para>Open circle marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_Circle,
        /// <summary>
        /// <para>X marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_X,
        /// <summary>
        /// <para>Plus symbol marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_Plus,
        /// <summary>
        /// <para>Filled circle marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_FilledCircle,
        /// <summary>
        /// <para>Square marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_Square,
        /// <summary>
        /// <para>Star marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_Star,
        /// <summary>
        /// <para>Down-pointing triangle marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_InvertedTriangle,
        /// <summary>
        /// <para>Filled square marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_FilledSquare,
        /// <summary>
        /// <para>Filled triangle marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_FilledTriangle,
        /// <summary>
        /// <para>Filled diamond marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_FilledDiamond,
        /// <summary>
        /// <para>Filled down-pointing triangle marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_FilledInvertedTriangle,
        /// <summary>
        /// <para>Filled star marking line points.</para>
        /// </summary>
        kSM2DGraph_Symbol_FilledStar,
        /// <summary>
        /// <para>Default symbol for lines - equal to kSM2DGraph_Symbol_None.</para>
        /// </summary>
        kSM2DGraph_Symbol_Default = kSM2DGraph_Symbol_None
    }
}