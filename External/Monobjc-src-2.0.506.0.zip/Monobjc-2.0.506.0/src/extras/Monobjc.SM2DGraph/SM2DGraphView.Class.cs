﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.SM2DGraph
{
    partial class SM2DGraphView
    {
        /// <summary>
        /// 	<para>Returns the pixel width of a bar for bar graphs.  Useful for calculating graph insets if multiple line bar graphs are going to be displayed.</para>
        /// 	<para>Original signature is '+ (float)barWidth;'</para>
        /// </summary>
        /// <value>The width (in pixels) of a bar for bar graphs.</value>
        public static float BarWidth
        {
            get { return ObjectiveCRuntime.SendMessage<float>(SM2DGraphViewClass, "barWidth"); }
        }

        /// <summary>
        /// 	<para>Returns the attributed string title drawn at the top of the graph.  The default title is blank.</para>
        /// 	<para>Original signature is '- (NSAttributedString *)attributedTitle;'</para>
        /// </summary>
        /// <value>The title of the graph as an attributed string.</value>
        public virtual NSAttributedString AttributedTitle
        {
            get { return ObjectiveCRuntime.SendMessage<NSAttributedString>(this, "attributedTitle"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAttributedTitle:", value); }
        }

        /// <summary>
        /// 	<para>Returns the color used to draw the background of the receiver. The default background color is white.</para>
        /// 	<para>Original signature is '- (NSColor *)backgroundColor;'</para>
        /// </summary>
        /// <value>The color used to draw the background.</value>
        public virtual NSColor BackgroundColor
        {
            get { return ObjectiveCRuntime.SendMessage<NSColor>(this, "backgroundColor"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBackgroundColor:", value); }
        }

        /// <summary>
        /// 	<para>Returns the color used to draw the border of the graph area. The default color is black.</para>
        /// 	<para>Original signature is '- (NSColor *)borderColor;'</para>
        /// </summary>
        /// <value>The color used to draw the border of the graph area.</value>
        public virtual NSColor BorderColor
        {
            get { return ObjectiveCRuntime.SendMessage<NSColor>(this, "borderColor"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBorderColor:", value); }
        }

        /// <summary>
        /// 	<para>Returns the object that line data is pulled from.</para>
        /// 	<para>Original signature is '- (id)dataSource;'</para>
        /// </summary>
        /// <value>The data source object of the graph view.</value>
        public virtual Id DataSource
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "dataSource"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDataSource:", value); }
        }

        /// <summary>
        /// 	<para>Returns the delegate object for the graph view.</para>
        /// 	<para>Original signature is '- (id)delegate;'</para>
        /// </summary>
        /// <value>The delegate object.</value>
        public virtual Id Delegate
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "delegate"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDelegate:", value); }
        }

        /// <summary>
        /// 	<para>Returns YES if the receiver draws grid lines on the graph, NO if it doesn't. The default is NO.</para>
        /// 	<para>Original signature is '- (BOOL)drawsGrid;'</para>
        /// </summary>
        /// <value>YES if the receiver draws grid lines, NO if it doesn't.</value>
        public virtual bool DrawsGrid
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "drawsGrid"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDrawsGrid:", value); }
        }

        /// <summary>
        /// 	<para>Returns the area the will be taken up by the graph itself.  Labels will be drawn outside of this rectangle, but within the view's area.</para>
        /// 	<para>Original signature is '- (NSRect)graphPaperRect;'</para>
        /// </summary>
        /// <value>	An NSRect in the receivers coordinates which is contains the actual graph area.</value>
        public virtual NSRect GraphPaperRect
        {
            get { return ObjectiveCRuntime.SendMessage<NSRect>(this, "graphPaperRect"); }
        }

        /// <summary>
        /// 	<para>Returns the color used to draw grid lines. The default color is blue.</para>
        /// 	<para>Original signature is ''</para>
        /// </summary>
        /// <value>The color used to draw grid lines.</value>
        public virtual NSColor GridColor
        {
            get { return ObjectiveCRuntime.SendMessage<NSColor>(this, "gridColor"); }
            set { ObjectiveCRuntime.SendMessage(this, "setGridColor:", value); }
        }

        /// <summary>
        /// 	<para>Returns an autoreleased image of the entire graph view. This image is filled with a white background first, so it should not have any transparent parts.</para>
        /// 	<para>Original signature is '- (NSImage *)imageOfView;'</para>
        /// </summary>
        /// <value>An NSImage object of the entire graph view.</value>
        public virtual NSImage ImageOfView
        {
            get { return ObjectiveCRuntime.SendMessage<NSImage>(this, "imageOfView"); }
        }

        /// <summary>
        /// 	<para>Returns the state of the liveRefresh flag. This flag is only used in the -addDataPoint:toLineIndex: method to determine if the graph should be automatically redrawn or not. The default value is NO.</para>
        /// 	<para>Original signature is '- (BOOL)liveRefresh;'</para>
        /// </summary>
        /// <value>The state of the liveRefresh flag.</value>
        public virtual bool LiveRefresh
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "liveRefresh"); }
            set { ObjectiveCRuntime.SendMessage(this, "setLiveRefresh:", value); }
        }

        /// <summary>
        /// 	<para>Returns the tag of the receiver.  This is an integer you can use for whatever you'd like.</para>
        /// 	<para>Original signature is '- (int)tag'</para>
        /// </summary>
        /// <value>The tag of the receiver.</value>
        public new int Tag
        {
            get { return ObjectiveCRuntime.SendMessage<int>(this, "tag"); }
            set { ObjectiveCRuntime.SendMessage(this, "setTag:", value); }
        }

        /// <summary>
        /// 	<para>Returns the title drawn at the top of the graph.  The default title is blank.</para>
        /// 	<para>Original signature is '- (NSString *)title;'</para>
        /// </summary>
        /// <value>The title of the graph.</value>
        public virtual NSString Title
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "title"); }
            set { ObjectiveCRuntime.SendMessage(this, "setTitle:", value); }
        }

        /// <summary>
        /// 	<para>Adds a point to the end of a specific line's data. The data must have either been nil previously, returned as a NSMutableArray by the dataSources -twoDGraphView:dataForLineIndex: method, or returned as a NSMutableData by the dataSources -twoDGraphView:dataObjectForLineIndex: method. The graph is scheduled for redrawing if the liveRefresh flag is set for the view. This can be used for incremental graphing, such as when each point requires significant calculation.</para>
        /// 	<para>Original signature is '- (void)addDataPoint:(NSPoint)inPoint toLineIndex:(unsigned int)inLineIndex;'</para>
        /// </summary>
        /// <param name="inPoint">A point to add to the end of the line's data.</param>
        /// <param name="inLineIndex">The zero based index of the line to add to.</param>
        public virtual void AddDataPointToLineIndex(NSPoint inPoint, uint inLineIndex)
        {
            ObjectiveCRuntime.SendMessage(this, "addDataPoint:toLineIndex:", inPoint, inLineIndex);
        }

        /// <summary>
        /// 	<para>Returns the pixel inset from the edge of the graph paper area to start the axis range. The default is zero.</para>
        /// 	<para>Original signature is '- (float)axisInsetForAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="inAxis">The axis to return.</param>
        /// <returns>The number of pixels to inset the line range.</returns>
        public virtual float AxisInsetForAxis(SM2DGraphAxis inAxis)
        {
            return ObjectiveCRuntime.SendMessage<float>(this, "axisInsetForAxis:", inAxis);
        }

        /// <summary>
        /// 	<para>Converts a point from a given window/view coordinate system to a point in the coordinate system of a given line on the graph. For example, if the x range values for a line are from -10.0 to +10.0 the returned point will be in this range.</para>
        /// 	<para>Original signature is '- (NSPoint)convertPoint:(NSPoint)inPoint fromView:(NSView *)inView toLineIndex:(unsigned int)inLineIndex;'</para>
        /// </summary>
        /// <param name="inPoint">The point to be converted.</param>
        /// <param name="inView">The inPoint parameter is in this view's coordinate system. A value of nil means the window's coordinate system.</param>
        /// <param name="inLineIndex">Zero based index of a line displayed on the graph.</param>
        /// <returns>The point after conversion to the appropriate line's scale.</returns>
        public virtual NSPoint ConvertPointFromViewToLineIndex(NSPoint inPoint, NSView inView, uint inLineIndex)
        {
            return ObjectiveCRuntime.SendMessage<NSPoint>(this, "convertPoint:fromView:toLineIndex:", inPoint, inView, inLineIndex);
        }

        /// <summary>
        /// 	<para>Can draw a straight line at zero for the first line. This is useful if your range goes both above and below zero, and zero does not land on a standard grid line. The default is NO.</para>
        /// 	<para>Original signature is '- (BOOL)drawsLineAtZeroForAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="inAxis">The axis to return.</param>
        /// <returns>YES if drawing a straight line at zero for the first line.</returns>
        public virtual bool DrawsLineAtZeroForAxis(SM2DGraphAxis inAxis)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "drawsLineAtZeroForAxis:", inAxis);
        }

        /// <summary>
        /// 	<para>Returns the axis label for an axis. The default is no label (nil).</para>
        /// 	<para>Original signature is '- (NSString *)labelForAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="inAxis">The axis to return.</param>
        /// <returns>An autoreleased string or nil.</returns>
        public virtual NSString LabelForAxis(SM2DGraphAxis inAxis)
        {
            return ObjectiveCRuntime.SendMessage<NSString>(this, "labelForAxis:", inAxis);
        }

        /// <summary>
        /// 	<para>Returns the number of minor tick marks between each major tick mark for an axis. The default is no minor tick marks.</para>
        /// 	<para>Original signature is '- (int)numberOfMinorTickMarksForAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="inAxis">The axis to count.</param>
        /// <returns>The number of minor tick marks for an axis.</returns>
        public virtual int NumberOfMinorTickMarksForAxis(SM2DGraphAxis inAxis)
        {
            return ObjectiveCRuntime.SendMessage<int>(this, "numberOfMinorTickMarksForAxis:", inAxis);
        }

        /// <summary>
        /// 	<para>Returns the number of major tick marks for an axis. The default is no tick marks.</para>
        /// 	<para>Original signature is '- (int)numberOfTickMarksForAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="inAxis">The axis to count.</param>
        /// <returns>The number of major tick marks for an axis.</returns>
        public virtual int NumberOfTickMarksForAxis(SM2DGraphAxis inAxis)
        {
            return ObjectiveCRuntime.SendMessage<int>(this, "numberOfTickMarksForAxis:", inAxis);
        }

        /// <summary>
        /// 	<para>Simple cover method that calls -reloadData, then -reloadAttributes.</para>
        /// 	<para>Original signature is '- (IBAction)refreshDisplay:(id)sender;'</para>
        /// </summary>
        /// <param name="sender">The sender.</param>
        public virtual void RefreshDisplay(Id sender)
        {
            ObjectiveCRuntime.SendMessage(this, "refreshDisplay:", sender);
        }

        /// <summary>
        /// 	<para>Reloads all line attributes from the datasource and schedules the graph for redrawing. The line data points are not reloaded.</para>
        /// 	<para>Original signature is '- (void)reloadAttributes;'</para>
        /// </summary>
        public virtual void ReloadAttributes()
        {
            ObjectiveCRuntime.SendMessage(this, "reloadAttributes");
        }

        /// <summary>
        /// 	<para>Reloads a specific line's attributes from the datasource and schedules the graph for redrawing. The line data points are not reloaded.</para>
        /// 	<para>Original signature is '- (void)reloadAttributesForLineIndex:(unsigned int)inLineIndex;'</para>
        /// </summary>
        /// <param name="inLineIndex">The zero based index of the line to reload.</param>
        public virtual void ReloadAttributesForLineIndex(uint inLineIndex)
        {
            ObjectiveCRuntime.SendMessage(this, "reloadAttributesForLineIndex:", inLineIndex);
        }

        /// <summary>
        /// 	<para>Reloads all line data from the datasource and schedules the graph for redrawing.</para>
        /// 	<para>Original signature is '- (void)reloadData;'</para>
        /// </summary>
        public virtual void ReloadData()
        {
            ObjectiveCRuntime.SendMessage(this, "reloadData");
        }

        /// <summary>
        /// 	<para>Reloads a specific line's data from the datasource and schedules the graph for redrawing.</para>
        /// 	<para>Original signature is '- (void)reloadDataForLineIndex:(unsigned int)inLineIndex;'</para>
        /// </summary>
        /// <param name="inLineIndex">The zero based index of the line to reload.</param>
        public virtual void ReloadDataForLineIndex(uint inLineIndex)
        {
            ObjectiveCRuntime.SendMessage(this, "reloadDataForLineIndex:", inLineIndex);
        }

        /// <summary>
        /// 	<para>Sets the pixel inset from the edge of the graph paper area to start the axis range. The default is zero.</para>
        /// 	<para>Original signature is '- (void)setAxisInset:(float)inInset forAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="inInset">The number of pixels to inset the line range.</param>
        /// <param name="inAxis">The axis to change.</param>
        public virtual void SetAxisInsetForAxis(float inInset, SM2DGraphAxis inAxis)
        {
            ObjectiveCRuntime.SendMessage(this, "setAxisInset:forAxis:", inInset, inAxis);
        }

        /// <summary>
        /// 	<para>Can draw a straight line at zero for the first line. This is useful if your range goes both above and below zero, and zero does not land on a standard grid line. The default is NO.</para>
        /// 	<para>Original signature is '- (void)setDrawsLineAtZero:(BOOL)inNewValue forAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="inNewValue">Set to YES if you want to draw a straight line at zero for the first line.</param>
        /// <param name="inAxis">The axis to change.</param>
        public virtual void SetDrawsLineAtZeroForAxis(bool inNewValue, SM2DGraphAxis inAxis)
        {
            ObjectiveCRuntime.SendMessage(this, "setDrawsLineAtZero:forAxis:", inNewValue, inAxis);
        }

        /// <summary>
        /// 	<para>Sets the axis label for an axis. The default is no label (nil).</para>
        /// 	<para>Original signature is '- (void)setLabel:(NSString *)inNewLabel forAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="inNewLabel">The new label. If nil, any existing label is removed.</param>
        /// <param name="inAxis">The axis to label.</param>
        public virtual void SetLabelForAxis(NSString inNewLabel, SM2DGraphAxis inAxis)
        {
            ObjectiveCRuntime.SendMessage(this, "setLabel:forAxis:", inNewLabel, inAxis);
        }

        /// <summary>
        /// 	<para>Sets the number of minor tick marks between each major tick mark for an axis. The default is no minor tick marks.</para>
        /// 	<para>Original signature is '- (void)setNumberOfMinorTickMarks:(int)count forAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="count">The number of minor tick marks between major tick marks.</param>
        /// <param name="inAxis">The axis to change.</param>
        public virtual void SetNumberOfMinorTickMarksForAxis(int count, SM2DGraphAxis inAxis)
        {
            ObjectiveCRuntime.SendMessage(this, "setNumberOfMinorTickMarks:forAxis:", count, inAxis);
        }

        /// <summary>
        /// 	<para>Sets the number of major tick marks for an axis. The default is no tick marks.</para>
        /// 	<para>Original signature is '- (void)setNumberOfTickMarks:(int)count forAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="count">The number of major tick marks. Should not be one.</param>
        /// <param name="inAxis">The axis to change.</param>
        public virtual void SetNumberOfTickMarksForAxis(int count, SM2DGraphAxis inAxis)
        {
            ObjectiveCRuntime.SendMessage(this, "setNumberOfTickMarks:forAxis:", count, inAxis);
        }

        /// <summary>
        /// 	<para>Sets the position to draw tick marks for an axis. The default is <see cref="NSTickMarkPosition.NSTickMarkBelow"/> and <see cref="NSTickMarkPosition.NSTickMarkRight"/>. Note: Currently, this setting is remembered but does nothing.</para>
        /// 	<para>Original signature is '- (void)setTickMarkPosition:(NSTickMarkPosition)position forAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="position">The position to draw tick marks.</param>
        /// <param name="inAxis">The axis to change.</param>
        public virtual void SetTickMarkPositionForAxis(NSTickMarkPosition position, SM2DGraphAxis inAxis)
        {
            ObjectiveCRuntime.SendMessage(this, "setTickMarkPosition:forAxis:", position, inAxis);
        }

        /// <summary>
        /// 	<para>Returns the position to draw tick marks for an axis. The default is NSTickMarkBelow and NSTickMarkRight. Note: Currently, this setting is remembered but does nothing.</para>
        /// 	<para>Original signature is '- (NSTickMarkPosition)tickMarkPositionForAxis:(SM2DGraphAxisEnum)inAxis;'</para>
        /// </summary>
        /// <param name="inAxis">The axis to return.</param>
        /// <returns>The position to draw tick marks for an axis.</returns>
        public virtual NSTickMarkPosition TickMarkPositionForAxis(SM2DGraphAxis inAxis)
        {
            return ObjectiveCRuntime.SendMessage<NSTickMarkPosition>(this, "tickMarkPositionForAxis:", inAxis);
        }
    }
}