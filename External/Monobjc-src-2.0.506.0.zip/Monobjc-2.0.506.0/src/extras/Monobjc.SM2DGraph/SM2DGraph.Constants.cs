//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.SM2DGraph
{
    public partial class SM2DGraph
    {
        /// <summary>
        /// <para>This is a key to be used in the -twoDGraphView:attributesForLineIndex: dictionary. If this key is present with any value, the line will be drawn as a series of bars instead of as a line.</para>
        /// </summary>
        public static readonly NSString SM2DGraphBarStyleAttributeName = NSString.NSPinnedString("SM2DGraphBarStyleAttributeName");

        /// <summary>
        /// <para>This is a key to be used in the -twoDGraphView:attributesForLineIndex: dictionary. If this key is present with any value, the line will not be anti-aliased. This does not affect lines with the bar style.</para>
        /// </summary>
        public static readonly NSString SM2DGraphDontAntialiasAttributeName = NSString.NSPinnedString("SM2DGraphDontAntialiasAttributeName");

        /// <summary>
        /// <para>This is a key to be used in the -twoDGraphView:attributesForLineIndex: dictionary. The value represents the symbol that will be drawn at each data point. If this key is not present, no symbol will be drawn at the data points.</para>
        /// </summary>
        public static readonly NSString SM2DGraphLineSymbolAttributeName = NSString.NSPinnedString("SM2DGraphLineSymbolAttributeName");

        /// <summary>
        /// <para>This is a key to be used in the -twoDGraphView:attributesForLineIndex: dictionary. The value represents how thick the line will be drawn. If this key is not present, a default value of kSM2DGraph_Width_Default is used.</para>
        /// </summary>
        public static readonly NSString SM2DGraphLineWidthAttributeName = NSString.NSPinnedString("SM2DGraphLineWidthAttributeName");
    }
}