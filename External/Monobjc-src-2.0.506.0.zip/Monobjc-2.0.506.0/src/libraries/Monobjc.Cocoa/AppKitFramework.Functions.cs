//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;
using NSWindowDepth = System.Int32;
using NSGlyph = System.UInt16;

namespace Monobjc.Cocoa
{
    public partial class AppKitFramework
    {
        #region Process Related Functions

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern int GetCurrentProcess(ref IntPtr psn);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern int TransformProcessType(ref IntPtr psn, ProcessApplicationTransformState type);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern int SetFrontProcess(ref IntPtr psn);

        #endregion

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString NSAccessibilityActionDescription([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString action);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSAccessibilityPostNotification([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id element,
                                                                  [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString notification);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSAccessibilityRaiseBadArgumentException([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id element,
                                                                           [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString attribute,
                                                                           [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof(IdMarshaler<Id>))] Id value);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString NSAccessibilityRoleDescription([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString role,
                                                                     [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString subrole);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString NSAccessibilityRoleDescriptionForUIElement([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id element);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSArray>))]
        public static extern NSArray NSAccessibilityUnignoredChildren([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSArray>))] NSArray originalChildren);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSArray>))]
        public static extern NSArray NSAccessibilityUnignoredChildrenForOnlyChild([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id originalChild);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))]
        public static extern Id NSAccessibilityUnignoredDescendant([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id element);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern bool NSApplicationLoad();

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern int NSApplicationMain(int argc, String[] argv);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern NSWindowDepth[] NSAvailableWindowDepths();

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSBeep();

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSBeginAlertSheet([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString title,
                                                    [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString defaultButton,
                                                    [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString alternateButton,
                                                    [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString otherButton,
                                                    [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSWindow>))] NSWindow docWindow,
                                                    [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id modalDelegate,
                                                    IntPtr didEndIntPtrector,
                                                    IntPtr didDismissIntPtrector,
                                                    IntPtr contextInfo,
                                                    [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString msg);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSBeginCriticalAlertSheet([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString title,
                                                            [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString defaultButton,
                                                            [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString alternateButton,
                                                            [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString otherButton,
                                                            [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSWindow>))] NSWindow docWindow,
                                                            [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id modalDelegate,
                                                            IntPtr didEndIntPtrector,
                                                            IntPtr didDismissIntPtrector,
                                                            IntPtr contextInfo,
                                                            [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString msg);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSBeginInformationalAlertSheet([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString title,
                                                                 [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString defaultButton,
                                                                 [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString alternateButton,
                                                                 [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString otherButton,
                                                                 [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSWindow>))] NSWindow docWindow,
                                                                 [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id modalDelegate,
                                                                 IntPtr didEndIntPtrector,
                                                                 IntPtr didDismissIntPtrector,
                                                                 IntPtr contextInfo,
                                                                 [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString msg);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern NSWindowDepth NSBestDepth([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString colorSpace,
                                                       int bps,
                                                       int bpp,
                                                       bool planar,
                                                       ref bool exactMatch);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern int NSBitsPerPixelFromDepth(NSWindowDepth depth);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern int NSBitsPerSampleFromDepth(NSWindowDepth depth);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString NSColorSpaceFromDepth(int depth);

        //[DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        //public static extern int NSConvertGlyphsToPackedGlyphs(NSGlyph *glBuf, int count, NSMultibyteGlyphPacking packing, char *packedGlyphs);
        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSCopyBits(int srcGState, NSRect srcRect, NSPoint destPoint);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSCountWindows(ref int count);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSCountWindowsForContext(int context, ref int count);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString NSCreateFileContentsPboardType([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString fileType);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString NSCreateFilenamePboardType([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString fileType);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSDisableScreenUpdates();

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSDottedFrameRect(NSRect aRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSDrawBitmap(NSRect rect,
                                               int pixelsWide,
                                               int pixelsHigh,
                                               int bitsPerSample,
                                               int samplesPerPixel,
                                               int bitsPerPixel,
                                               int bytesPerRow,
                                               bool isPlanar,
                                               bool hasAlpha,
                                               [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSColorSpace>))] NSColorSpace colorSpace,
                                               char[] data);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSDrawButton(NSRect aRect, NSRect clipRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern NSRect NSDrawColorTiledRects(NSRect boundsRect, NSRect clipRect, ref NSRectEdge sides, IntPtr colors, int count);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSDrawDarkBezel(NSRect boundsRect, NSRect clipRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSDrawGrayBezel(NSRect boundsRect, NSRect clipRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSDrawGroove(NSRect boundsRect, NSRect clipRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSDrawLightBezel(NSRect boundsRect, NSRect clipRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern NSRect NSDrawTiledRects(NSRect boundsRect, NSRect clipRect, NSRectEdge[] sides, float[] grays, int count);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSDrawWhiteBezel(NSRect aRect, NSRect clipRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSDrawWindowBackground(NSRect aRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSEnableScreenUpdates();

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSEraseRect(NSRect aRect);

        public static NSEventMask NSEventMaskFromType(NSEventType type)
        {
            return (NSEventMask)(1 << (int)type);
        }

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSFrameRect(NSRect aRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSFrameRectWithWidth(NSRect aRect, float frameWidth);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSFrameRectWithWidthUsingOperation(NSRect aRect, float frameWidth, NSCompositingOperation op);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))]
        public static extern Id NSGetAlertPanel([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString title,
                                                [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString msg,
                                                [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString defaultButton,
                                                [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString alternateButton,
                                                [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString otherButton);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))]
        public static extern Id NSGetCriticalAlertPanel([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString title,
                                                        [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString msg,
                                                        [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString defaultButton,
                                                        [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString alternateButton,
                                                        [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString otherButton);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString NSGetFileType([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString pboardType);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSArray>))]
        public static extern NSArray NSGetFileTypes([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSArray>))] NSArray pboardTypes);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))]
        public static extern Id NSGetInformationalAlertPanel([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString title,
                                                             [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString msg,
                                                             [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString defaultButton,
                                                             [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString alternateButton,
                                                             [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString otherButton);

        //[DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        //public static extern int NSGetWindowServerMemory(int context,
        //                                                 ref int virtualMemory,
        //                                                 ref int windowBackingMemory,
        //                                                 NSString windowDumpStream);

        //public static extern void NSGlyphInfoAtIndex(int IX);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSHighlightRect(NSRect aRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern NSInterfaceStyle NSInterfaceStyleForKey([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString key,
                                                                     [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSResponder>))] NSResponder responder);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern bool NSIsControllerMarker([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id obj);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern int NSNumberOfColorComponents([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString colorSpaceName);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSOpenGLGetOption(NSOpenGLGlobalOption pname, ref long param);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSOpenGLGetVersion(ref long major, ref long minor);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSOpenGLSetOption(NSOpenGLGlobalOption pname, long param);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern bool NSPerformService([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString itemName,
                                                   [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSPasteboard>))] NSPasteboard pboard);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern bool NSPlanarFromDepth(NSWindowDepth depth);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSColor>))]
        public static extern NSColor NSReadPixel(NSPoint passedPoint);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSRectClip(NSRect aRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSRectClipList(NSRect[] rects, int count);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSRectFill(NSRect aRect);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSRectFillList(NSRect[] rects, int count);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSRectFillListUsingOperation(NSRect[] rects, int count, NSCompositingOperation op);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSRectFillListWithColors(NSRect[] rects, NSColor[] colors, int count);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSRectFillListWithColorsUsingOperation(NSRect[] rects, NSColor[] colors, int count, NSCompositingOperation op);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSRectFillListWithGrays(NSRect[] rects, float[] grays, int count);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSRectFillUsingOperation(NSRect aRect, NSCompositingOperation op);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSRegisterServicesProvider([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id provider,
                                                             [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString name);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSReleaseAlertPanel([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id alertPanel);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern int NSRunAlertPanel([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString title,
                                                 [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString msg,
                                                 [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString defaultButton,
                                                 [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString alternateButton,
                                                 [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString otherButton);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern int NSRunCriticalAlertPanel([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString title,
                                                         [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString msg,
                                                         [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString defaultButton,
                                                         [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString alternateButton,
                                                         [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString otherButton);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern int NSRunInformationalAlertPanel([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString title,
                                                              [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString msg,
                                                              [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString defaultButton,
                                                              [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString alternateButton,
                                                              [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString otherButton);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSSetFocusRingStyle(NSFocusRingPlacement placement);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern int NSSetShowsServicesMenuItem([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString itemName,
                                                            bool enabled);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSShowAnimationEffect(NSAnimationEffect animationEffect,
                                                        NSPoint centerLocation,
                                                        NSSize size,
                                                        [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<Id>))] Id animationDelegate,
                                                        IntPtr didEndSelector,
                                                        IntPtr contextInfo);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern bool NSShowsServicesMenuItem([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString itemName);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSUnregisterServicesProvider([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString name);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSUpdateDynamicServices();

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSWindowList(int size, int[] list);

        [DllImport("/System/Library/Frameworks/AppKit.framework/AppKit")]
        public static extern void NSWindowListForContext(int context, int size, int[] list);
    }
}
