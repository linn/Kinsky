//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CALayer : ICAMediaTiming
    {
        public virtual bool Autoreverses
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "autoreverses"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAutoreverses:", value); }
        }

        public virtual double BeginTime
        {
            get { return ObjectiveCRuntime.SendMessage<double>(this, "beginTime"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBeginTime:", value); }
        }

        public virtual double Duration
        {
            get { return ObjectiveCRuntime.SendMessage<double>(this, "duration"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDuration:", value); }
        }

        public virtual NSString FillMode
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "fillMode"); }
            set { ObjectiveCRuntime.SendMessage(this, "setFillMode:", value); }
        }

        public virtual float RepeatCount
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "repeatCount"); }
            set { ObjectiveCRuntime.SendMessage(this, "setRepeatCount:", value); }
        }

        public virtual double RepeatDuration
        {
            get { return ObjectiveCRuntime.SendMessage<double>(this, "repeatDuration"); }
            set { ObjectiveCRuntime.SendMessage(this, "setRepeatDuration:", value); }
        }

        public virtual float Speed
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "speed"); }
            set { ObjectiveCRuntime.SendMessage(this, "setSpeed:", value); }
        }

        public virtual double TimeOffset
        {
            get { return ObjectiveCRuntime.SendMessage<double>(this, "timeOffset"); }
            set { ObjectiveCRuntime.SendMessage(this, "setTimeOffset:", value); }
        }
    }
#endif
}
