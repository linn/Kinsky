﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;
using CGContextRef = System.IntPtr;
using CGPathRef = System.IntPtr;
using CGImageRef = System.IntPtr;
using CGGradientRef = System.IntPtr;
using CGPDFDocumentRef = System.IntPtr;
using CGPDFPageRef = System.IntPtr;
using CGShadingRef = System.IntPtr;
using CGColorRef = System.IntPtr;
using CGColorSpaceRef = System.IntPtr;
using CGPatternRef = System.IntPtr;
using CGFontRef = System.IntPtr;
using CGFloat = System.Single;
using CGGlyph = System.UInt16;

namespace Monobjc.Cocoa
{
    public class CGContext
    {
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextAddArc")]
        public static extern void AddArc(CGContextRef c, CGFloat x, CGFloat y, CGFloat radius, CGFloat startAngle, CGFloat endAngle, int clockwise);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextAddArcToPoint")]
        public static extern void AddArcToPoint(CGContextRef c, CGFloat x1, CGFloat y1, CGFloat x2, CGFloat y2, CGFloat radius);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextAddCurveToPoint")]
        public static extern void AddCurveToPoint(CGContextRef c, CGFloat cp1x, CGFloat cp1y, CGFloat cp2x, CGFloat cp2y, CGFloat x, CGFloat y);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextAddEllipseInRect")]
        public static extern void AddEllipseInRect(CGContextRef context, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextAddLines")]
        public static extern void AddLines(CGContextRef c, CGPoint[] points, uint count);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextAddLineToPoint")]
        public static extern void AddLineToPoint(CGContextRef c, CGFloat x, CGFloat y);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextAddPath")]
        public static extern void AddPath(CGContextRef context, CGPathRef path);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextAddQuadCurveToPoint")]
        public static extern void AddQuadCurveToPoint(CGContextRef c, CGFloat cpx, CGFloat cpy, CGFloat x, CGFloat y);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextAddRect")]
        public static extern void AddRect(CGContextRef c, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextAddRects")]
        public static extern void AddRects(CGContextRef c, CGRect[] rects, uint count);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextBeginPage")]
        public static extern void BeginPage(CGContextRef c, ref CGRect mediaBox);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextBeginPath")]
        public static extern void BeginPath(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextBeginTransparencyLayer")]
        public static extern void BeginTransparencyLayer(CGContextRef context, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary auxiliaryInfo);

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextBeginTransparencyLayerWithRect")]
        public static extern void BeginTransparencyLayerWithRect(CGContextRef context, CGRect rect, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary auxiliaryInfo);
#endif

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextClearRect")]
        public static extern void ClearRect(CGContextRef c, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextClip")]
        public static extern void Clip(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextClipToMask")]
        public static extern void ClipToMask(CGContextRef c, CGRect rect, CGImageRef mask);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextClipToRect")]
        public static extern void ClipToRect(CGContextRef c, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextClipToRects")]
        public static extern void ClipToRects(CGContextRef c, CGRect[] rects, uint count);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextClosePath")]
        public static extern void ClosePath(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextConcatCTM")]
        public static extern void ConcatCTM(CGContextRef c, CGAffineTransform transform);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextConvertPointToDeviceSpace")]
        public static extern CGPoint ConvertPointToDeviceSpace(CGContextRef c, CGPoint point);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextConvertPointToUserSpace")]
        public static extern CGPoint ConvertPointToUserSpace(CGContextRef c, CGPoint point);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextConvertRectToDeviceSpace")]
        public static extern CGRect ConvertRectToDeviceSpace(CGContextRef c, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextConvertRectToUserSpace")]
        public static extern CGRect ConvertRectToUserSpace(CGContextRef c, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextConvertSizeToDeviceSpace")]
        public static extern CGSize ConvertSizeToDeviceSpace(CGContextRef c, CGSize size);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextConvertSizeToUserSpace")]
        public static extern CGSize ConvertSizeToUserSpace(CGContextRef c, CGSize size);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextDrawImage")]
        public static extern void DrawImage(CGContextRef c, CGRect rect, CGImageRef image);

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextDrawLinearGradient")]
        public static extern void DrawLinearGradient(CGContextRef context, CGGradientRef gradient, CGPoint startPoint, CGPoint endPoint, CGGradientDrawingOptions options);
#endif

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextDrawPath")]
        public static extern void DrawPath(CGContextRef c, CGPathDrawingMode mode);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextDrawPDFDocument")]
        public static extern void DrawPDFDocument(CGContextRef c, CGRect rect, CGPDFDocumentRef document, int page);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextDrawPDFPage")]
        public static extern void DrawPDFPage(CGContextRef c, CGPDFPageRef page);

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextDrawRadialGradient")]
        public static extern void DrawRadialGradient(CGContextRef context, CGGradientRef gradient, CGPoint startCenter, CGFloat startRadius, CGPoint endCenter, CGFloat endRadius, CGGradientDrawingOptions options);
#endif

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextDrawShading")]
        public static extern void DrawShading(CGContextRef c, CGShadingRef shading);

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextDrawTiledImage")]
        public static extern void DrawTiledImage(CGContextRef context, CGRect rect, CGImageRef image);
#endif

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextEndPage")]
        public static extern void EndPage(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextEndTransparencyLayer")]
        public static extern void EndTransparencyLayer(CGContextRef context);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextEOClip")]
        public static extern void EOClip(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextEOFillPath")]
        public static extern void EOFillPath(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextFillEllipseInRect")]
        public static extern void FillEllipseInRect(CGContextRef context, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextFillPath")]
        public static extern void FillPath(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextFillRect")]
        public static extern void FillRect(CGContextRef c, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextFillRects")]
        public static extern void FillRects(CGContextRef c, CGRect[] rects, uint count);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextFlush")]
        public static extern void Flush(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextGetClipBoundingBox")]
        public static extern CGRect GetClipBoundingBox(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextGetCTM")]
        public static extern CGAffineTransform GetCTM(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextGetInterpolationQuality")]
        public static extern CGInterpolationQuality GetInterpolationQuality(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextGetPathBoundingBox")]
        public static extern CGRect GetPathBoundingBox(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextGetPathCurrentPoint")]
        public static extern CGPoint GetPathCurrentPoint(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextGetTextMatrix")]
        public static extern CGAffineTransform GetTextMatrix(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextGetTextPosition")]
        public static extern CGPoint GetTextPosition(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextGetTypeID")]
        public static extern uint GetTypeID();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextGetUserSpaceToDeviceSpaceTransform")]
        public static extern CGAffineTransform GetUserSpaceToDeviceSpaceTransform(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextIsPathEmpty")]
        public static extern bool IsPathEmpty(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextMoveToPoint")]
        public static extern void MoveToPoint(CGContextRef c, CGFloat x, CGFloat y);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextPathContainsPoint")]
        public static extern bool PathContainsPoint(CGContextRef context, CGPoint point, CGPathDrawingMode mode);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextRelease")]
        public static extern void Release(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextReplacePathWithStrokedPath")]
        public static extern void ReplacePathWithStrokedPath(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextRestoreGState")]
        public static extern void RestoreGState(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextRetain")]
        public static extern CGContextRef Retain(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextRotateCTM")]
        public static extern void RotateCTM(CGContextRef c, CGFloat angle);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSaveGState")]
        public static extern void SaveGState(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextScaleCTM")]
        public static extern void ScaleCTM(CGContextRef c, CGFloat sx, CGFloat sy);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSelectFont")]
        public static extern void SelectFont(CGContextRef c, String name, CGFloat size, CGTextEncoding textEncoding);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetAllowsAntialiasing")]
        public static extern void SetAllowsAntialiasing(CGContextRef context, bool allowsAntialiasing);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetAlpha")]
        public static extern void SetAlpha(CGContextRef c, CGFloat alpha);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetBlendMode")]
        public static extern void SetBlendMode(CGContextRef context, CGBlendMode mode);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetCharacterSpacing")]
        public static extern void SetCharacterSpacing(CGContextRef c, CGFloat spacing);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetCMYKFillColor")]
        public static extern void SetCMYKFillColor(CGContextRef c, CGFloat cyan, CGFloat magenta, CGFloat yellow, CGFloat black, CGFloat alpha);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetCMYKStrokeColor")]
        public static extern void SetCMYKStrokeColor(CGContextRef c, CGFloat cyan, CGFloat magenta, CGFloat yellow, CGFloat black, CGFloat alpha);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetFillColor")]
        public static extern void SetFillColor(CGContextRef c, CGFloat[] components);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetFillColorSpace")]
        public static extern void SetFillColorSpace(CGContextRef c, CGColorSpaceRef colorspace);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetFillColorWithColor")]
        public static extern void SetFillColorWithColor(CGContextRef c, CGColorRef color);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetFillPattern")]
        public static extern void SetFillPattern(CGContextRef c, CGPatternRef pattern, CGFloat[] components);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetFlatness")]
        public static extern void SetFlatness(CGContextRef c, CGFloat flatness);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetFont")]
        public static extern void SetFont(CGContextRef c, CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetFontSize")]
        public static extern void SetFontSize(CGContextRef c, CGFloat size);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetGrayFillColor")]
        public static extern void SetGrayFillColor(CGContextRef c, CGFloat gray, CGFloat alpha);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetGrayStrokeColor")]
        public static extern void SetGrayStrokeColor(CGContextRef c, CGFloat gray, CGFloat alpha);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetInterpolationQuality")]
        public static extern void SetInterpolationQuality(CGContextRef c, CGInterpolationQuality quality);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetLineCap")]
        public static extern void SetLineCap(CGContextRef c, CGLineCap cap);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetLineDash")]
        public static extern void SetLineDash(CGContextRef c, CGFloat phase, CGFloat[] lengths, uint count);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetLineJoin")]
        public static extern void SetLineJoin(CGContextRef c, CGLineJoin join);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetLineWidth")]
        public static extern void SetLineWidth(CGContextRef c, CGFloat width);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetMiterLimit")]
        public static extern void SetMiterLimit(CGContextRef c, CGFloat limit);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetPatternPhase")]
        public static extern void SetPatternPhase(CGContextRef c, CGSize phase);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetRenderingIntent")]
        public static extern void SetRenderingIntent(CGContextRef c, CGColorRenderingIntent intent);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetRGBFillColor")]
        public static extern void SetRGBFillColor(CGContextRef c, CGFloat red, CGFloat green, CGFloat blue, CGFloat alpha);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetRGBStrokeColor")]
        public static extern void SetRGBStrokeColor(CGContextRef c, CGFloat red, CGFloat green, CGFloat blue, CGFloat alpha);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetShadow")]
        public static extern void SetShadow(CGContextRef context, CGSize offset, CGFloat blur);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetShadowWithColor")]
        public static extern void SetShadowWithColor(CGContextRef context, CGSize offset, CGFloat blur, CGColorRef color);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetShouldAntialias")]
        public static extern void SetShouldAntialias(CGContextRef c, bool shouldAntialias);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetShouldSmoothFonts")]
        public static extern void SetShouldSmoothFonts(CGContextRef c, bool shouldSmoothFonts);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetStrokeColor")]
        public static extern void SetStrokeColor(CGContextRef c, CGFloat[] components);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetStrokeColorSpace")]
        public static extern void SetStrokeColorSpace(CGContextRef c, CGColorSpaceRef colorspace);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetStrokeColorWithColor")]
        public static extern void SetStrokeColorWithColor(CGContextRef c, CGColorRef color);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetStrokePattern")]
        public static extern void SetStrokePattern(CGContextRef c, CGPatternRef pattern, CGFloat[] components);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetTextDrawingMode")]
        public static extern void SetTextDrawingMode(CGContextRef c, CGTextDrawingMode mode);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetTextMatrix")]
        public static extern void SetTextMatrix(CGContextRef c, CGAffineTransform t);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSetTextPosition")]
        public static extern void SetTextPosition(CGContextRef c, CGFloat x, CGFloat y);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextShowGlyphs")]
        public static extern void ShowGlyphs(CGContextRef c, CGGlyph[] g, uint count);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextShowGlyphsAtPoint")]
        public static extern void ShowGlyphsAtPoint(CGContextRef c, CGFloat x, CGFloat y, CGGlyph[] glyphs, uint count);

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextShowGlyphsAtPositions")]
        public static extern void ShowGlyphsAtPositions(CGContextRef context, CGGlyph[] glyphs, CGPoint[] positions, uint count);
#endif

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextShowGlyphsWithAdvances")]
        public static extern void ShowGlyphsWithAdvances(CGContextRef c, CGGlyph[] glyphs, CGSize[] advances, uint count);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextShowText")]
        public static extern void ShowText(CGContextRef c, String bytes, uint length);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextShowTextAtPoint")]
        public static extern void ShowTextAtPoint(CGContextRef c, CGFloat x, CGFloat y, String bytes, uint length);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextStrokeEllipseInRect")]
        public static extern void StrokeEllipseInRect(CGContextRef context, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextStrokeLineSegments")]
        public static extern void StrokeLineSegments(CGContextRef c, CGPoint[] points, uint count);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextStrokePath")]
        public static extern void StrokePath(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextStrokeRect")]
        public static extern void StrokeRect(CGContextRef c, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextStrokeRectWithWidth")]
        public static extern void StrokeRectWithWidth(CGContextRef c, CGRect rect, CGFloat width);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextSynchronize")]
        public static extern void Synchronize(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGContextTranslateCTM")]
        public static extern void TranslateCTM(CGContextRef c, CGFloat tx, CGFloat ty);
    }
}
