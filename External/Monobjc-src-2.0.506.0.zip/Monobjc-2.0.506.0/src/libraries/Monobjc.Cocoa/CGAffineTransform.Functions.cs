//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
    public partial struct CGAffineTransform
    {
        public static CGAffineTransform Concat(CGAffineTransform t1, CGAffineTransform t2)
        {
            // TODO : To implement
            throw new NotImplementedException();
        }

        public static bool EqualToTransform(CGAffineTransform t1, CGAffineTransform t2)
        {
            return Equals(t1, t2);
        }

        public static CGAffineTransform Invert(CGAffineTransform t)
        {
            // TODO : To implement
            throw new NotImplementedException();
        }

        public static bool IsIdentity(CGAffineTransform t)
        {
            return ((t.a == 1.0f) &&
                    (t.b == 0.0f) &&
                    (t.c == 0.0f) &&
                    (t.d == 1.0f) &&
                    (t.tx == 0.0f) &&
                    (t.ty == 0.0f));
        }

        public static CGAffineTransform Make(float a, float b, float c, float d, float tx, float ty)
        {
            return new CGAffineTransform
                       {
                           a = a, 
                           b = b, 
                           c = c, 
                           d = d,
                           tx = tx, 
                           ty = ty
                       };
        }

        public static CGAffineTransform MakeRotation(float angle)
        {
            return new CGAffineTransform
                       {
                           a = ((float) Math.Cos(angle)),
                           b = ((float) Math.Sin(angle)), 
                           c = (-(float) Math.Sin(angle)),
                           d = ((float) Math.Cos(angle)), 
                           tx = 0.0f,
                           ty = 0.0f
                       };
        }

        public static CGAffineTransform MakeScale(float sx, float sy)
        {
            return new CGAffineTransform
                       {
                           a = sx, 
                           b = 0.0f, 
                           c = 0.0f, 
                           d = sy, 
                           tx = 0.0f, 
                           ty = 0.0f
                       };
        }

        public static CGAffineTransform MakeTranslation(float tx, float ty)
        {
            return new CGAffineTransform
                       {
                           a = 1.0f, 
                           b = 0.0f, 
                           c = 0.0f, 
                           d = 1.0f, 
                           tx = tx, 
                           ty = ty
                       };
        }

        public static CGAffineTransform Rotate(CGAffineTransform t, float angle)
        {
            return new CGAffineTransform
                       {
                           a = ((float) (t.a*Math.Cos(angle) - t.b*Math.Sin(angle))),     
                           b = ((float) (t.a*Math.Sin(angle) + t.b*Math.Cos(angle))),      
                           c = ((float) (t.c*Math.Cos(angle) - t.d*Math.Sin(angle))),        
                           d = ((float) (t.c*Math.Sin(angle) + t.d*Math.Cos(angle))),        
                           tx = ((float) (t.tx*Math.Cos(angle) - t.ty*Math.Sin(angle))),       
                           ty = ((float) (t.tx*Math.Sin(angle) + t.ty*Math.Cos(angle)))
                       };
        }

        public static CGAffineTransform Scale(CGAffineTransform t, float sx, float sy)
        {
            return new CGAffineTransform
                       {
                           a = (t.a*sx), 
                           b = (t.b*sx), 
                           c = (t.c*sy),
                           d = (t.d*sy),
                           tx = (t.tx*sx),
                           ty = (t.ty*sy)
                       };
        }

        public static CGAffineTransform Translate(CGAffineTransform t, float tx, float ty)
        {
            return new CGAffineTransform
                       {
                           a = t.a,
                           b = t.b,
                           c = t.c, 
                           d = t.d,
                           tx = (t.tx + tx),
                           ty = (t.ty + ty)
                       };
        }

        public static CGPoint CGPointApplyAffineTransform(CGPoint point, CGAffineTransform t)
        {
            return new CGPoint
                       {
                           x = (t.a*point.x + t.c*point.y + t.tx), 
                           y = (t.b*point.x + t.d*point.y + t.ty)
                       };
        }

        public static CGRect CGRectApplyAffineTransform(CGRect rect, CGAffineTransform t)
        {
            // TODO : To implement
            throw new NotImplementedException();
        }

        public static CGSize CGSizeApplyAffineTransform(CGSize size, CGAffineTransform t)
        {
            return new CGSize
                       {
                           width = (t.a*size.width + t.c*size.height + t.tx), 
                           height = (t.b*size.width + t.d*size.height + t.ty)
                       };
        }

        public static CGAffineTransform CGAffineTransformIdentity()
        {
            return new CGAffineTransform(1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f);
        }
    }
}
