﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CABasicAnimation
    {
        public new static CABasicAnimation Animation
        {
            get { return ObjectiveCRuntime.SendMessage<CABasicAnimation>(CABasicAnimationClass, "animation"); }
        }

        public new static CABasicAnimation AnimationWithKeyPath(NSString keyPath)
        {
            return ObjectiveCRuntime.SendMessage<CABasicAnimation>(CABasicAnimationClass, "animationWithKeyPath:", keyPath);
        }

        public virtual Id ByValue
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "byValue"); }
            set { ObjectiveCRuntime.SendMessage(this, "setByValue:", value); }
        }

        public virtual Id FromValue
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "fromValue"); }
            set { ObjectiveCRuntime.SendMessage(this, "setFromValue:", value); }
        }

        public virtual Id ToValue
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "toValue"); }
            set { ObjectiveCRuntime.SendMessage(this, "setToValue:", value); }
        }
    }
#endif
}
