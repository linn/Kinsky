//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using CGColorRef = System.IntPtr;
using CGPathRef = System.IntPtr;

namespace Monobjc.Cocoa
{
#if MACOSX_10_6
    partial class CAShapeLayer
    {
        public virtual CGColorRef FillColor
        {
            get { return ObjectiveCRuntime.SendMessage<CGColorRef>(this, "fillColor"); }
            set { ObjectiveCRuntime.SendMessage(this, "setFillColor:", value); }
        }

        public virtual NSString FillRule
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "fillRule"); }
            set { ObjectiveCRuntime.SendMessage(this, "setFillRule:", value); }
        }

        public virtual NSString LineCap
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "lineCap"); }
            set { ObjectiveCRuntime.SendMessage(this, "setLineCap:", value); }
        }

        public virtual NSString LineDashPattern
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "lineDashPattern"); }
            set { ObjectiveCRuntime.SendMessage(this, "setLineDashPattern:", value); }
        }

        public virtual float LineDashPhase
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "lineDashPhase"); }
            set { ObjectiveCRuntime.SendMessage(this, "setLineDashPhase:", value); }
        }

        public virtual NSString LineJoin
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "lineJoin"); }
            set { ObjectiveCRuntime.SendMessage(this, "setLineJoin:", value); }
        }

        public virtual float LineWidth
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "lineWidth"); }
            set { ObjectiveCRuntime.SendMessage(this, "setLineWidth:", value); }
        }

        public virtual float MiterLimit
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "miterLimit"); }
            set { ObjectiveCRuntime.SendMessage(this, "setMiterLimit:", value); }
        }

        public virtual CGColorRef Path
        {
            get { return ObjectiveCRuntime.SendMessage<CGColorRef>(this, "path"); }
            set { ObjectiveCRuntime.SendMessage(this, "setPath:", value); }
        }

        public virtual CGColorRef StrokeColor
        {
            get { return ObjectiveCRuntime.SendMessage<CGColorRef>(this, "strokeColor"); }
            set { ObjectiveCRuntime.SendMessage(this, "setStrokeColor:", value); }
        }
    }
#endif
}
