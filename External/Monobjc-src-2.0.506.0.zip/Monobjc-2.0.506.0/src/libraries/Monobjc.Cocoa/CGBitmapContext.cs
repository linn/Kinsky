﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;
using CGContextRef = System.IntPtr;
using CGImageRef = System.IntPtr;
using CGColorSpaceRef = System.IntPtr;

namespace Monobjc.Cocoa
{
    public class CGBitmapContext
    {
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGBitmapContextCreate")]
        public static extern CGContextRef Create(CGContextRef data, uint width, uint height, uint bitsPerComponent, uint bytesPerRow, CGColorSpaceRef colorspace, CGBitmapInfo bitmapInfo);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGBitmapContextCreateImage")]
        public static extern CGImageRef CreateImage(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGBitmapContextGetAlphaInfo")]
        public static extern CGImageAlphaInfo GetAlphaInfo(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGBitmapContextGetBitmapInfo")]
        public static extern CGBitmapInfo GetBitmapInfo(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGBitmapContextGetBitsPerComponent")]
        public static extern uint GetBitsPerComponent(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGBitmapContextGetBitsPerPixel")]
        public static extern uint GetBitsPerPixel(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGBitmapContextGetBytesPerRow")]
        public static extern uint GetBytesPerRow(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGBitmapContextGetColorSpace")]
        public static extern CGColorSpaceRef GetColorSpace(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGBitmapContextGetData")]
        public static extern CGContextRef GetData(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGBitmapContextGetHeight")]
        public static extern uint GetHeight(CGContextRef c);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGBitmapContextGetWidth")]
        public static extern uint GetWidth(CGContextRef c);
    }
}
