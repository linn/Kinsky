﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;
using CGImageDestinationRef=System.IntPtr;
using CGImageRef=System.IntPtr;
using CGImageSourceRef=System.IntPtr;
using CGDataConsumerRef=System.IntPtr;

namespace Monobjc.Cocoa
{
    public class CGImageDestination
    {
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageDestinationAddImage")]
        public static extern void AddImage(CGImageDestinationRef idst, CGImageRef image, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary properties);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageDestinationAddImageFromSource")]
        public static extern void AddImageFromSource(CGImageDestinationRef idst, CGImageSourceRef isrc, uint index, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary properties);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGImageDestinationCopyTypeIdentifiers")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSArray>))]
        public static extern NSArray CopyTypeIdentifiers();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageDestinationCreateWithData")]
        public static extern CGImageDestinationRef CreateWithData([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSMutableData>))] NSMutableData data,
                                                                                    [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString type, uint count,
                                                                                    [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary options);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageDestinationCreateWithDataConsumer")]
        public static extern CGImageDestinationRef CreateWithDataConsumer(CGDataConsumerRef consumer, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString type, uint count,
                                                                                            [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary options);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageDestinationCreateWithURL")]
        public static extern CGImageDestinationRef CreateWithURL([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSURL>))] NSURL url,
                                                                                   [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString type, uint count,
                                                                                   [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary options);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageDestinationFinalize")]
        public static extern bool Finalize(CGImageDestinationRef idst);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageDestinationGetTypeID")]
        public static extern uint GetTypeID();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageDestinationSetProperties")]
        public static extern void SetProperties(CGImageDestinationRef idst, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary properties);

        public static readonly NSString kCGImageDestinationLossyCompressionQuality = NSString.NSPinnedString("kCGImageDestinationLossyCompressionQuality");

        public static readonly NSString kCGImageDestinationBackgroundColor = NSString.NSPinnedString("kCGImageDestinationBackgroundColor");
    }
}
