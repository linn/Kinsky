//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;

namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    [StructLayout(LayoutKind.Sequential)]
    public partial struct CATransform3D : IEquatable<CATransform3D>
    {
        public static readonly CATransform3D Identity = new CATransform3D(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);

        public float m11;

        public float m12;

        public float m13;

        public float m14;

        public float m21;

        public float m22;

        public float m23;

        public float m24;

        public float m31;

        public float m32;

        public float m33;

        public float m34;

        public float m41;

        public float m42;

        public float m43;

        public float m44;

        public CATransform3D(float m11, float m12, float m13, float m14, float m21, float m22, float m23, float m24, float m31, float m32, float m33, float m34, float m41, float m42, float m43, float m44)
        {
            this.m11 = m11;
            this.m12 = m12;
            this.m13 = m13;
            this.m14 = m14;
            this.m21 = m21;
            this.m22 = m22;
            this.m23 = m23;
            this.m24 = m24;
            this.m31 = m31;
            this.m32 = m32;
            this.m33 = m33;
            this.m34 = m34;
            this.m41 = m41;
            this.m42 = m42;
            this.m43 = m43;
            this.m44 = m44;
        }

        public static bool operator !=(CATransform3D caTransform3D1, CATransform3D caTransform3D2)
        {
            return !caTransform3D1.Equals(caTransform3D2);
        }

        public static bool operator ==(CATransform3D caTransform3D1, CATransform3D caTransform3D2)
        {
            return caTransform3D1.Equals(caTransform3D2);
        }

        public bool Equals(CATransform3D caTransform3D)
        {
            if (m11 != caTransform3D.m11)
            {
                return false;
            }
            if (m12 != caTransform3D.m12)
            {
                return false;
            }
            if (m13 != caTransform3D.m13)
            {
                return false;
            }
            if (m14 != caTransform3D.m14)
            {
                return false;
            }
            if (m21 != caTransform3D.m21)
            {
                return false;
            }
            if (m22 != caTransform3D.m22)
            {
                return false;
            }
            if (m23 != caTransform3D.m23)
            {
                return false;
            }
            if (m24 != caTransform3D.m24)
            {
                return false;
            }
            if (m31 != caTransform3D.m31)
            {
                return false;
            }
            if (m32 != caTransform3D.m32)
            {
                return false;
            }
            if (m33 != caTransform3D.m33)
            {
                return false;
            }
            if (m34 != caTransform3D.m34)
            {
                return false;
            }
            if (m41 != caTransform3D.m41)
            {
                return false;
            }
            if (m42 != caTransform3D.m42)
            {
                return false;
            }
            if (m43 != caTransform3D.m43)
            {
                return false;
            }
            if (m44 != caTransform3D.m44)
            {
                return false;
            }
            return true;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is CATransform3D))
            {
                return false;
            }
            return Equals((CATransform3D) obj);
        }

        public override int GetHashCode()
        {
            int result = m11.GetHashCode();
            result = 29*result + m12.GetHashCode();
            result = 29*result + m13.GetHashCode();
            result = 29*result + m14.GetHashCode();
            result = 29*result + m21.GetHashCode();
            result = 29*result + m22.GetHashCode();
            result = 29*result + m23.GetHashCode();
            result = 29*result + m24.GetHashCode();
            result = 29*result + m31.GetHashCode();
            result = 29*result + m32.GetHashCode();
            result = 29*result + m33.GetHashCode();
            result = 29*result + m34.GetHashCode();
            result = 29*result + m41.GetHashCode();
            result = 29*result + m42.GetHashCode();
            result = 29*result + m43.GetHashCode();
            result = 29*result + m44.GetHashCode();
            return result;
        }
    }
#endif
}
