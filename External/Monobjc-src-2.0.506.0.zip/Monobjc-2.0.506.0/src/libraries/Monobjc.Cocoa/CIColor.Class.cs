//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
    public partial class CIColor
    {
        public static CIColor ColorWithCGColor(IntPtr c)
        {
            return ObjectiveCRuntime.SendMessage<CIColor>(CIColorClass, "colorWithCGColor:", c);
        }

        public static CIColor ColorWithRedGreenBlue(float r, float g, float b)
        {
            return ObjectiveCRuntime.SendMessage<CIColor>(CIColorClass, "colorWithRed:green:blue:", r, g, b);
        }

        public static CIColor ColorWithRedGreenBlueAlpha(float r, float g, float b, float a)
        {
            return ObjectiveCRuntime.SendMessage<CIColor>(CIColorClass, "colorWithRed:green:blue:alpha:", r, g, b, a);
        }

        public static CIColor ColorWithString(NSString representation)
        {
            return ObjectiveCRuntime.SendMessage<CIColor>(CIColorClass, "colorWithString:", representation);
        }

        public virtual Id InitWithCGColor(IntPtr c)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithCGColor:", c);
        }

        public virtual float Alpha
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "alpha"); }
        }

        public virtual float Blue
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "blue"); }
        }

        public virtual IntPtr ColorSpace
        {
            get { return ObjectiveCRuntime.SendMessage<IntPtr>(this, "colorSpace"); }
        }

        public virtual float[] Components
        {
            get { return ObjectiveCRuntime.SendMessage<float[]>(this, "components"); }
        }

        public virtual float Green
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "green"); }
        }

        public virtual uint NumberOfComponents
        {
            get { return ObjectiveCRuntime.SendMessage<uint>(this, "numberOfComponents"); }
        }

        public virtual float Red
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "red"); }
        }

        public virtual NSString StringRepresentation
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "stringRepresentation"); }
        }
    }
}
