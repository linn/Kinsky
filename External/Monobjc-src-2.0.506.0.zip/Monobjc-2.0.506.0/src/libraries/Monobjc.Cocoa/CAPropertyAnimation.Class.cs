//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CAPropertyAnimation
    {
        public static Id Additive(NSString keyPath)
        {
            return ObjectiveCRuntime.SendMessage<Id>(CAPropertyAnimationClass, "additive", keyPath);
        }

        public static Id Cumulative(NSString keyPath)
        {
            return ObjectiveCRuntime.SendMessage<Id>(CAPropertyAnimationClass, "cumulative", keyPath);
        }

        public static Id KeyPath(NSString keyPath)
        {
            return ObjectiveCRuntime.SendMessage<Id>(CAPropertyAnimationClass, "keyPath", keyPath);
        }

        public new static CAPropertyAnimation Animation
        {
            get { return ObjectiveCRuntime.SendMessage<CAPropertyAnimation>(CAPropertyAnimationClass, "animation"); }
        }

        public static CAPropertyAnimation AnimationWithKeyPath(NSString keyPath)
        {
            return ObjectiveCRuntime.SendMessage<CAPropertyAnimation>(CAPropertyAnimationClass, "animationWithKeyPath:", keyPath);
        }

        public virtual bool IsAdditive
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "isAdditive"); }
        }

        public virtual bool IsCumulative
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "isCumulative"); }
        }

#if MACOSX_10_6
        public virtual CAValueFunction ValueFunction
        {
            get { return ObjectiveCRuntime.SendMessage<CAValueFunction>(this, "valueFunction"); }
            set { ObjectiveCRuntime.SendMessage(this, "setValueFunction:", value); }
        }
#endif
    }
#endif
}
