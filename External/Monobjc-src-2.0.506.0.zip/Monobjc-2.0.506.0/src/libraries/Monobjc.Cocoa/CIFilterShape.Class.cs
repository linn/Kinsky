﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
    public partial class CIFilterShape
    {
        public static CIFilterShape ShapeWithRect(CGRect r)
        {
            return ObjectiveCRuntime.SendMessage<CIFilterShape>(CIFilterShapeClass, "shapeWithRect:", r);
        }

        public virtual Id InitWithRect(CGRect r)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithRect:", r);
        }

        public virtual CIFilterShape InsetByXY(int dx, int dy)
        {
            return ObjectiveCRuntime.SendMessage<CIFilterShape>(this, "insetByX:Y:", dx, dy);
        }

        public virtual CIFilterShape IntersectWith(CIFilterShape s2)
        {
            return ObjectiveCRuntime.SendMessage<CIFilterShape>(this, "intersectWith:", s2);
        }

        public virtual CIFilterShape IntersectWithRect(CGRect r)
        {
            return ObjectiveCRuntime.SendMessage<CIFilterShape>(this, "intersectWithRect:", r);
        }

        public virtual CIFilterShape TransformByInterior(CGAffineTransform m, bool flag)
        {
            return ObjectiveCRuntime.SendMessage<CIFilterShape>(this, "transformBy:interior:", m, flag);
        }

        public virtual CIFilterShape UnionWith(CIFilterShape s2)
        {
            return ObjectiveCRuntime.SendMessage<CIFilterShape>(this, "unionWith:", s2);
        }

        public virtual CIFilterShape UnionWithRect(CGRect r)
        {
            return ObjectiveCRuntime.SendMessage<CIFilterShape>(this, "unionWithRect:", r);
        }
    }
}
