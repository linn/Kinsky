//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
    public partial class CIContext
    {
        public static CIContext ContextWithCGContextOptions(IntPtr ctx, NSDictionary dict)
        {
            return ObjectiveCRuntime.SendMessage<CIContext>(CIContextClass, "contextWithCGContext:options:", ctx, dict);
        }

        public static CIContext ContextWithCGLContextPixelFormatOptions(IntPtr ctx, IntPtr pf, NSDictionary dict)
        {
            return ObjectiveCRuntime.SendMessage<CIContext>(CIContextClass, "contextWithCGLContext:pixelFormat:options:", ctx, pf, dict);
        }

        public virtual void ClearCaches()
        {
            ObjectiveCRuntime.SendMessage(this, "clearCaches");
        }

        public virtual IntPtr CreateCGImageFromRect(CIImage im, CGRect r)
        {
            return ObjectiveCRuntime.SendMessage<IntPtr>(this, "createCGImage:fromRect:", im, r);
        }

#if MACOSX_10_5
        public virtual IntPtr CreateCGImageFromRectFormatColorSpace(CIImage im, CGRect r, CIFormat f, IntPtr cs)
        {
            return ObjectiveCRuntime.SendMessage<IntPtr>(this, "createCGImage:fromRect:format:colorSpace:", im, r, f, cs);
        }
#endif

        public virtual IntPtr CreateCGLayerWithSizeInfo(CGSize size, NSDictionary d)
        {
            return ObjectiveCRuntime.SendMessage<IntPtr>(this, "createCGLayerWithSize:info:", size, d);
        }

        public virtual void DrawImageAtPointFromRect(CIImage im, CGPoint p, CGRect src)
        {
            ObjectiveCRuntime.SendMessage(this, "drawImage:atPoint:fromRect:", im, p, src);
        }

        public virtual void DrawImageInRectFromRect(CIImage im, CGRect dest, CGRect src)
        {
            ObjectiveCRuntime.SendMessage(this, "drawImage:inRect:fromRect:", im, dest, src);
        }

        public virtual void ReclaimResources()
        {
            ObjectiveCRuntime.SendMessage(this, "reclaimResources");
        }

#if MACOSX_10_5
        public virtual void RenderToBitmapRowBytesBoundsFormatColorSpace(CIImage im, IntPtr data, IntPtr rb, CGRect r, CIFormat f, IntPtr cs)
        {
            ObjectiveCRuntime.SendMessage(this, "render:toBitmap:rowBytes:bounds:format:colorSpace:", im, data, rb, r, f, cs);
        }
#endif
    }
}
