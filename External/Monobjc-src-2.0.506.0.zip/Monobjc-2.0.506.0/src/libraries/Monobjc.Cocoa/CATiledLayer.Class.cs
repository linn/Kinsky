﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CATiledLayer
    {
        public uint LevelsOfDetail
        {
            get { return ObjectiveCRuntime.SendMessage<uint>(CATiledLayerClass, "levelsOfDetail"); }
            set { ObjectiveCRuntime.SendMessage(CATiledLayerClass, "setLevelsOfDetail:", value); }
        }

        public uint LevelsOfDetailBias
        {
            get { return ObjectiveCRuntime.SendMessage<uint>(CATiledLayerClass, "levelsOfDetailBias"); }
            set { ObjectiveCRuntime.SendMessage(CATiledLayerClass, "setLevelsOfDetailBias:", value); }
        }

        public CGSize TileSize
        {
            get { return ObjectiveCRuntime.SendMessage<CGSize>(CATiledLayerClass, "tileSize"); }
            set { ObjectiveCRuntime.SendMessage(CATiledLayerClass, "setTileSize:", value); }
        }

        public static double FadeDuration
        {
            get { return ObjectiveCRuntime.SendMessage<double>(CATiledLayerClass, "fadeDuration"); }
        }
    }
#endif
}
