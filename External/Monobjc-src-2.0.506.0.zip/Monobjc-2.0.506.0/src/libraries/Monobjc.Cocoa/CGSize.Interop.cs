//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
    public partial struct CGSize
    {
        public static CGSize Add(CGSize size1, CGSize size2)
        {
            return new CGSize(size1.width + size2.width, size1.height + size2.height);
        }

        public static CGSize Substract(CGSize size1, CGSize size2)
        {
            return new CGSize(size1.width - size2.width, size1.height - size2.height);
        }

        public static CGSize Multiply(CGSize size, float factor)
        {
            return new CGSize(size.width*factor, size.height*factor);
        }

        public static CGSize Divide(CGSize size, float factor)
        {
            return new CGSize(size.width/factor, size.height/factor);
        }

        public static CGSize operator +(CGSize size1, CGSize size2)
        {
            return Add(size1, size2);
        }

        public static CGSize operator -(CGSize size1, CGSize size2)
        {
            return Substract(size1, size2);
        }

        public static CGSize operator *(CGSize size, float factor)
        {
            return Multiply(size, factor);
        }

        public static CGSize operator /(CGSize size, float factor)
        {
            return Divide(size, factor);
        }
    }
}
