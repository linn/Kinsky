//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
    public partial class CIImage
    {
        public static CIImage ImageWithBitmapDataBytesPerRowSizeFormatColorSpace(NSData d, uint bpr, CGSize size, CIFormat f, IntPtr cs)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithBitmapData:bytesPerRow:size:format:colorSpace:", d, bpr, size, f, cs);
        }

        public static CIImage ImageWithCGImage(IntPtr image)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithCGImage:", image);
        }

        public static CIImage ImageWithCGImageOptions(IntPtr image, NSDictionary d)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithCGImage:options:", image, d);
        }

        public static CIImage ImageWithCGLayer(IntPtr layer)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithCGLayer:", layer);
        }

        public static CIImage ImageWithCGLayerOptions(IntPtr layer, NSDictionary d)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithCGLayer:options:", layer, d);
        }

#if MACOSX_10_5
        public static CIImage ImageWithColor(CIColor color)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithColor:", color);
        }
#endif

        public static CIImage ImageWithContentsOfURL(NSURL url)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithContentsOfURL:", url);
        }

        public static CIImage ImageWithContentsOfURLOptions(NSURL url, NSDictionary d)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithContentsOfURL:options:", url, d);
        }

        public static CIImage ImageWithCVImageBuffer(IntPtr imageBuffer)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithCVImageBuffer:", imageBuffer);
        }

        public static CIImage ImageWithCVImageBufferOptions(IntPtr imageBuffer, NSDictionary dict)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithCVImageBuffer:options:", imageBuffer, dict);
        }

        public static CIImage ImageWithData(NSData data)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithData:", data);
        }

        public static CIImage ImageWithDataOptions(NSData data, NSDictionary d)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithData:options:", data, d);
        }

        public static CIImage ImageWithImageProviderSizeFormatColorSpaceOptions(Id p, uint width, uint height, CIFormat f, IntPtr cs, NSDictionary dict)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithImageProvider:size::format:colorSpace:options:", p, width, height, f, cs, dict);
        }

        public static CIImage ImageWithTextureSizeFlippedColorSpace(uint name, CGSize size, bool flag, IntPtr cs)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "imageWithTexture:size:flipped:colorSpace:", name, size, flag, cs);
        }

        public virtual CIImage ImageByApplyingTransform(CGAffineTransform matrix)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(this, "imageByApplyingTransform:", matrix);
        }

#if MACOSX_10_5
        public virtual CIImage ImageByCroppingToRect(CGRect r)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(this, "imageByCroppingToRect:", r);
        }
#endif

        public virtual Id InitWithBitmapDataBytesPerRowSizeFormatColorSpace(NSData d, uint bpr, CGSize size, CIFormat f, IntPtr c)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithBitmapData:bytesPerRow:size:format:colorSpace:", d, bpr, size, f, c);
        }

        public virtual Id InitWithCGImage(IntPtr image)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithCGImage:", image);
        }

        public virtual Id InitWithCGImageOptions(IntPtr image, NSDictionary d)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithCGImage:options:", image, d);
        }

        public virtual Id InitWithCGLayer(IntPtr layer)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithCGLayer:", layer);
        }

        public virtual Id InitWithCGLayerOptions(IntPtr layer, NSDictionary d)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithCGLayer:options:", layer, d);
        }

#if MACOSX_10_5
        public virtual Id InitWithColor(CIColor color)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithColor:", color);
        }
#endif

        public virtual Id InitWithContentsOfURL(NSURL url)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithContentsOfURL:", url);
        }

        public virtual Id InitWithContentsOfURLOptions(NSURL url, NSDictionary d)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithContentsOfURL:options:", url, d);
        }

        public virtual Id InitWithCVImageBuffer(IntPtr imageBuffer)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithCVImageBuffer:", imageBuffer);
        }

        public virtual Id InitWithCVImageBufferOptions(IntPtr imageBuffer, NSDictionary dict)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithCVImageBuffer:options:", imageBuffer, dict);
        }

        public virtual Id InitWithData(NSData data)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithData:", data);
        }

        public virtual Id InitWithDataOptions(NSData data, NSDictionary d)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithData:options:", data, d);
        }

        public virtual Id InitWithImageProviderSizeFormatColorSpaceOptions(Id p, uint width, uint height, CIFormat f, IntPtr cs, NSDictionary dict)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithImageProvider:size::format:colorSpace:options:", p, width, height, f, cs, dict);
        }

        public virtual Id InitWithTextureSizeFlippedColorSpace(uint name, CGSize size, bool flag, IntPtr cs)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithTexture:size:flipped:colorSpace:", name, size, flag, cs);
        }

#if MACOSX_10_5
        public static CIImage EmptyImage
        {
            get { return ObjectiveCRuntime.SendMessage<CIImage>(CIImageClass, "emptyImage"); }
        }
#endif

        public virtual CIFilterShape Definition
        {
            get { return ObjectiveCRuntime.SendMessage<CIFilterShape>(this, "definition"); }
        }

        public virtual CGRect Extent
        {
            get { return ObjectiveCRuntime.SendMessage<CGRect>(this, "extent"); }
        }
    }
}
