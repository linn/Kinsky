//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace Monobjc.Cocoa
{
    [StructLayout(LayoutKind.Sequential)]
    public partial struct CGRect : IEquatable<CGRect>
    {
        public CGPoint origin;

        public CGSize size;

        public CGRect(float x, float y, float width, float height)
        {
            this.origin.x = x;
            this.origin.y = y;
            this.size.width = width;
            this.size.height = height;
        }

        public CGRect(CGPoint origin, CGSize size)
        {
            this.origin = origin;
            this.size = size;
        }

        public override String ToString()
        {
            return String.Format(CultureInfo.CurrentCulture, "CGRect({0}, {1})", this.origin, this.size);
        }

        public static bool operator !=(CGRect cgRect1, CGRect cgRect2)
        {
            return !cgRect1.Equals(cgRect2);
        }

        public static bool operator ==(CGRect cgRect1, CGRect cgRect2)
        {
            return cgRect1.Equals(cgRect2);
        }

        public bool Equals(CGRect cgRect)
        {
            return Equals(this.origin, cgRect.origin) && Equals(this.size, cgRect.size);
        }

        public override bool Equals(object obj)
        {
            if (!(obj is CGRect))
            {
                return false;
            }
            return Equals((CGRect) obj);
        }

        public override int GetHashCode()
        {
            return this.origin.GetHashCode() + 29*this.size.GetHashCode();
        }
    }
}
