//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
    partial class CGColor
    {
#if MACOSX_10_5
        public static readonly IntPtr TransparentColor = CreateGenericRGB(1f, 1f, 1f, 0f);

        public static readonly IntPtr AliceBlueColor = CreateGenericRGB(0.9411765f, 0.972549f, 1f, 1f);

        public static readonly IntPtr AntiqueWhiteColor = CreateGenericRGB(0.9803922f, 0.9215686f, 0.8431373f, 1f);

        public static readonly IntPtr AquaColor = CreateGenericRGB(0f, 1f, 1f, 1f);

        public static readonly IntPtr AquamarineColor = CreateGenericRGB(0.4980392f, 1f, 0.8313726f, 1f);

        public static readonly IntPtr AzureColor = CreateGenericRGB(0.9411765f, 1f, 1f, 1f);

        public static readonly IntPtr BeigeColor = CreateGenericRGB(0.9607843f, 0.9607843f, 0.8627451f, 1f);

        public static readonly IntPtr BisqueColor = CreateGenericRGB(1f, 0.8941177f, 0.7686275f, 1f);

        public static readonly IntPtr BlackColor = CreateGenericRGB(0f, 0f, 0f, 1f);

        public static readonly IntPtr BlanchedAlmondColor = CreateGenericRGB(1f, 0.9215686f, 0.8039216f, 1f);

        public static readonly IntPtr BlueColor = CreateGenericRGB(0f, 0f, 1f, 1f);

        public static readonly IntPtr BlueVioletColor = CreateGenericRGB(0.5411765f, 0.1686275f, 0.8862745f, 1f);

        public static readonly IntPtr BrownColor = CreateGenericRGB(0.6470588f, 0.1647059f, 0.1647059f, 1f);

        public static readonly IntPtr BurlyWoodColor = CreateGenericRGB(0.8705882f, 0.7215686f, 0.5294118f, 1f);

        public static readonly IntPtr CadetBlueColor = CreateGenericRGB(0.372549f, 0.6196079f, 0.627451f, 1f);

        public static readonly IntPtr ChartreuseColor = CreateGenericRGB(0.4980392f, 1f, 0f, 1f);

        public static readonly IntPtr ChocolateColor = CreateGenericRGB(0.8235294f, 0.4117647f, 0.1176471f, 1f);

        public static readonly IntPtr CoralColor = CreateGenericRGB(1f, 0.4980392f, 0.3137255f, 1f);

        public static readonly IntPtr CornflowerBlueColor = CreateGenericRGB(0.3921569f, 0.5843138f, 0.9294118f, 1f);

        public static readonly IntPtr CornsilkColor = CreateGenericRGB(1f, 0.972549f, 0.8627451f, 1f);

        public static readonly IntPtr CrimsonColor = CreateGenericRGB(0.8627451f, 0.07843138f, 0.2352941f, 1f);

        public static readonly IntPtr CyanColor = CreateGenericRGB(0f, 1f, 1f, 1f);

        public static readonly IntPtr DarkBlueColor = CreateGenericRGB(0f, 0f, 0.5450981f, 1f);

        public static readonly IntPtr DarkCyanColor = CreateGenericRGB(0f, 0.5450981f, 0.5450981f, 1f);

        public static readonly IntPtr DarkGoldenrodColor = CreateGenericRGB(0.7215686f, 0.5254902f, 0.04313726f, 1f);

        public static readonly IntPtr DarkGrayColor = CreateGenericRGB(0.6627451f, 0.6627451f, 0.6627451f, 1f);

        public static readonly IntPtr DarkGreenColor = CreateGenericRGB(0f, 0.3921569f, 0f, 1f);

        public static readonly IntPtr DarkKhakiColor = CreateGenericRGB(0.7411765f, 0.7176471f, 0.4196078f, 1f);

        public static readonly IntPtr DarkMagentaColor = CreateGenericRGB(0.5450981f, 0f, 0.5450981f, 1f);

        public static readonly IntPtr DarkOliveGreenColor = CreateGenericRGB(0.3333333f, 0.4196078f, 0.1843137f, 1f);

        public static readonly IntPtr DarkOrangeColor = CreateGenericRGB(1f, 0.5490196f, 0f, 1f);

        public static readonly IntPtr DarkOrchidColor = CreateGenericRGB(0.6f, 0.1960784f, 0.8f, 1f);

        public static readonly IntPtr DarkRedColor = CreateGenericRGB(0.5450981f, 0f, 0f, 1f);

        public static readonly IntPtr DarkSalmonColor = CreateGenericRGB(0.9137255f, 0.5882353f, 0.4784314f, 1f);

        public static readonly IntPtr DarkSeaGreenColor = CreateGenericRGB(0.5607843f, 0.7372549f, 0.5450981f, 1f);

        public static readonly IntPtr DarkSlateBlueColor = CreateGenericRGB(0.282353f, 0.2392157f, 0.5450981f, 1f);

        public static readonly IntPtr DarkSlateGrayColor = CreateGenericRGB(0.1843137f, 0.3098039f, 0.3098039f, 1f);

        public static readonly IntPtr DarkTurquoiseColor = CreateGenericRGB(0f, 0.8078431f, 0.8196079f, 1f);

        public static readonly IntPtr DarkVioletColor = CreateGenericRGB(0.5803922f, 0f, 0.827451f, 1f);

        public static readonly IntPtr DeepPinkColor = CreateGenericRGB(1f, 0.07843138f, 0.5764706f, 1f);

        public static readonly IntPtr DeepSkyBlueColor = CreateGenericRGB(0f, 0.7490196f, 1f, 1f);

        public static readonly IntPtr DimGrayColor = CreateGenericRGB(0.4117647f, 0.4117647f, 0.4117647f, 1f);

        public static readonly IntPtr DodgerBlueColor = CreateGenericRGB(0.1176471f, 0.5647059f, 1f, 1f);

        public static readonly IntPtr FirebrickColor = CreateGenericRGB(0.6980392f, 0.1333333f, 0.1333333f, 1f);

        public static readonly IntPtr FloralWhiteColor = CreateGenericRGB(1f, 0.9803922f, 0.9411765f, 1f);

        public static readonly IntPtr ForestGreenColor = CreateGenericRGB(0.1333333f, 0.5450981f, 0.1333333f, 1f);

        public static readonly IntPtr FuchsiaColor = CreateGenericRGB(1f, 0f, 1f, 1f);

        public static readonly IntPtr GainsboroColor = CreateGenericRGB(0.8627451f, 0.8627451f, 0.8627451f, 1f);

        public static readonly IntPtr GhostWhiteColor = CreateGenericRGB(0.972549f, 0.972549f, 1f, 1f);

        public static readonly IntPtr GoldColor = CreateGenericRGB(1f, 0.8431373f, 0f, 1f);

        public static readonly IntPtr GoldenrodColor = CreateGenericRGB(0.854902f, 0.6470588f, 0.1254902f, 1f);

        public static readonly IntPtr GrayColor = CreateGenericRGB(0.5019608f, 0.5019608f, 0.5019608f, 1f);

        public static readonly IntPtr GreenColor = CreateGenericRGB(0f, 0.5019608f, 0f, 1f);

        public static readonly IntPtr GreenYellowColor = CreateGenericRGB(0.6784314f, 1f, 0.1843137f, 1f);

        public static readonly IntPtr HoneydewColor = CreateGenericRGB(0.9411765f, 1f, 0.9411765f, 1f);

        public static readonly IntPtr HotPinkColor = CreateGenericRGB(1f, 0.4117647f, 0.7058824f, 1f);

        public static readonly IntPtr IndianRedColor = CreateGenericRGB(0.8039216f, 0.3607843f, 0.3607843f, 1f);

        public static readonly IntPtr IndigoColor = CreateGenericRGB(0.2941177f, 0f, 0.509804f, 1f);

        public static readonly IntPtr IvoryColor = CreateGenericRGB(1f, 1f, 0.9411765f, 1f);

        public static readonly IntPtr KhakiColor = CreateGenericRGB(0.9411765f, 0.9019608f, 0.5490196f, 1f);

        public static readonly IntPtr LavenderColor = CreateGenericRGB(0.9019608f, 0.9019608f, 0.9803922f, 1f);

        public static readonly IntPtr LavenderBlushColor = CreateGenericRGB(1f, 0.9411765f, 0.9607843f, 1f);

        public static readonly IntPtr LawnGreenColor = CreateGenericRGB(0.4862745f, 0.9882353f, 0f, 1f);

        public static readonly IntPtr LemonChiffonColor = CreateGenericRGB(1f, 0.9803922f, 0.8039216f, 1f);

        public static readonly IntPtr LightBlueColor = CreateGenericRGB(0.6784314f, 0.8470588f, 0.9019608f, 1f);

        public static readonly IntPtr LightCoralColor = CreateGenericRGB(0.9411765f, 0.5019608f, 0.5019608f, 1f);

        public static readonly IntPtr LightCyanColor = CreateGenericRGB(0.8784314f, 1f, 1f, 1f);

        public static readonly IntPtr LightGoldenrodYellowColor = CreateGenericRGB(0.9803922f, 0.9803922f, 0.8235294f, 1f);

        public static readonly IntPtr LightGreenColor = CreateGenericRGB(0.5647059f, 0.9333333f, 0.5647059f, 1f);

        public static readonly IntPtr LightGrayColor = CreateGenericRGB(0.827451f, 0.827451f, 0.827451f, 1f);

        public static readonly IntPtr LightPinkColor = CreateGenericRGB(1f, 0.7137255f, 0.7568628f, 1f);

        public static readonly IntPtr LightSalmonColor = CreateGenericRGB(1f, 0.627451f, 0.4784314f, 1f);

        public static readonly IntPtr LightSeaGreenColor = CreateGenericRGB(0.1254902f, 0.6980392f, 0.6666667f, 1f);

        public static readonly IntPtr LightSkyBlueColor = CreateGenericRGB(0.5294118f, 0.8078431f, 0.9803922f, 1f);

        public static readonly IntPtr LightSlateGrayColor = CreateGenericRGB(0.4666667f, 0.5333334f, 0.6f, 1f);

        public static readonly IntPtr LightSteelBlueColor = CreateGenericRGB(0.6901961f, 0.7686275f, 0.8705882f, 1f);

        public static readonly IntPtr LightYellowColor = CreateGenericRGB(1f, 1f, 0.8784314f, 1f);

        public static readonly IntPtr LimeColor = CreateGenericRGB(0f, 1f, 0f, 1f);

        public static readonly IntPtr LimeGreenColor = CreateGenericRGB(0.1960784f, 0.8039216f, 0.1960784f, 1f);

        public static readonly IntPtr LinenColor = CreateGenericRGB(0.9803922f, 0.9411765f, 0.9019608f, 1f);

        public static readonly IntPtr MagentaColor = CreateGenericRGB(1f, 0f, 1f, 1f);

        public static readonly IntPtr MaroonColor = CreateGenericRGB(0.5019608f, 0f, 0f, 1f);

        public static readonly IntPtr MediumAquamarineColor = CreateGenericRGB(0.4f, 0.8039216f, 0.6666667f, 1f);

        public static readonly IntPtr MediumBlueColor = CreateGenericRGB(0f, 0f, 0.8039216f, 1f);

        public static readonly IntPtr MediumOrchidColor = CreateGenericRGB(0.7294118f, 0.3333333f, 0.827451f, 1f);

        public static readonly IntPtr MediumPurpleColor = CreateGenericRGB(0.5764706f, 0.4392157f, 0.8588235f, 1f);

        public static readonly IntPtr MediumSeaGreenColor = CreateGenericRGB(0.2352941f, 0.7019608f, 0.4431373f, 1f);

        public static readonly IntPtr MediumSlateBlueColor = CreateGenericRGB(0.4823529f, 0.4078431f, 0.9333333f, 1f);

        public static readonly IntPtr MediumSpringGreenColor = CreateGenericRGB(0f, 0.9803922f, 0.6039216f, 1f);

        public static readonly IntPtr MediumTurquoiseColor = CreateGenericRGB(0.282353f, 0.8196079f, 0.8f, 1f);

        public static readonly IntPtr MediumVioletRedColor = CreateGenericRGB(0.7803922f, 0.08235294f, 0.5215687f, 1f);

        public static readonly IntPtr MidnightBlueColor = CreateGenericRGB(0.09803922f, 0.09803922f, 0.4392157f, 1f);

        public static readonly IntPtr MintCreamColor = CreateGenericRGB(0.9607843f, 1f, 0.9803922f, 1f);

        public static readonly IntPtr MistyRoseColor = CreateGenericRGB(1f, 0.8941177f, 0.8823529f, 1f);

        public static readonly IntPtr MoccasinColor = CreateGenericRGB(1f, 0.8941177f, 0.7098039f, 1f);

        public static readonly IntPtr NavajoWhiteColor = CreateGenericRGB(1f, 0.8705882f, 0.6784314f, 1f);

        public static readonly IntPtr NavyColor = CreateGenericRGB(0f, 0f, 0.5019608f, 1f);

        public static readonly IntPtr OldLaceColor = CreateGenericRGB(0.9921569f, 0.9607843f, 0.9019608f, 1f);

        public static readonly IntPtr OliveColor = CreateGenericRGB(0.5019608f, 0.5019608f, 0f, 1f);

        public static readonly IntPtr OliveDrabColor = CreateGenericRGB(0.4196078f, 0.5568628f, 0.1372549f, 1f);

        public static readonly IntPtr OrangeColor = CreateGenericRGB(1f, 0.6470588f, 0f, 1f);

        public static readonly IntPtr OrangeRedColor = CreateGenericRGB(1f, 0.2705882f, 0f, 1f);

        public static readonly IntPtr OrchidColor = CreateGenericRGB(0.854902f, 0.4392157f, 0.8392157f, 1f);

        public static readonly IntPtr PaleGoldenrodColor = CreateGenericRGB(0.9333333f, 0.9098039f, 0.6666667f, 1f);

        public static readonly IntPtr PaleGreenColor = CreateGenericRGB(0.5960785f, 0.9843137f, 0.5960785f, 1f);

        public static readonly IntPtr PaleTurquoiseColor = CreateGenericRGB(0.6862745f, 0.9333333f, 0.9333333f, 1f);

        public static readonly IntPtr PaleVioletRedColor = CreateGenericRGB(0.8588235f, 0.4392157f, 0.5764706f, 1f);

        public static readonly IntPtr PapayaWhipColor = CreateGenericRGB(1f, 0.9372549f, 0.8352941f, 1f);

        public static readonly IntPtr PeachPuffColor = CreateGenericRGB(1f, 0.854902f, 0.7254902f, 1f);

        public static readonly IntPtr PeruColor = CreateGenericRGB(0.8039216f, 0.5215687f, 0.2470588f, 1f);

        public static readonly IntPtr PinkColor = CreateGenericRGB(1f, 0.7529412f, 0.7960784f, 1f);

        public static readonly IntPtr PlumColor = CreateGenericRGB(0.8666667f, 0.627451f, 0.8666667f, 1f);

        public static readonly IntPtr PowderBlueColor = CreateGenericRGB(0.6901961f, 0.8784314f, 0.9019608f, 1f);

        public static readonly IntPtr PurpleColor = CreateGenericRGB(0.5019608f, 0f, 0.5019608f, 1f);

        public static readonly IntPtr RedColor = CreateGenericRGB(1f, 0f, 0f, 1f);

        public static readonly IntPtr RosyBrownColor = CreateGenericRGB(0.7372549f, 0.5607843f, 0.5607843f, 1f);

        public static readonly IntPtr RoyalBlueColor = CreateGenericRGB(0.254902f, 0.4117647f, 0.8823529f, 1f);

        public static readonly IntPtr SaddleBrownColor = CreateGenericRGB(0.5450981f, 0.2705882f, 0.07450981f, 1f);

        public static readonly IntPtr SalmonColor = CreateGenericRGB(0.9803922f, 0.5019608f, 0.4470588f, 1f);

        public static readonly IntPtr SandyBrownColor = CreateGenericRGB(0.9568627f, 0.6431373f, 0.3764706f, 1f);

        public static readonly IntPtr SeaGreenColor = CreateGenericRGB(0.1803922f, 0.5450981f, 0.3411765f, 1f);

        public static readonly IntPtr SeaShellColor = CreateGenericRGB(1f, 0.9607843f, 0.9333333f, 1f);

        public static readonly IntPtr SiennaColor = CreateGenericRGB(0.627451f, 0.3215686f, 0.1764706f, 1f);

        public static readonly IntPtr SilverColor = CreateGenericRGB(0.7529412f, 0.7529412f, 0.7529412f, 1f);

        public static readonly IntPtr SkyBlueColor = CreateGenericRGB(0.5294118f, 0.8078431f, 0.9215686f, 1f);

        public static readonly IntPtr SlateBlueColor = CreateGenericRGB(0.4156863f, 0.3529412f, 0.8039216f, 1f);

        public static readonly IntPtr SlateGrayColor = CreateGenericRGB(0.4392157f, 0.5019608f, 0.5647059f, 1f);

        public static readonly IntPtr SnowColor = CreateGenericRGB(1f, 0.9803922f, 0.9803922f, 1f);

        public static readonly IntPtr SpringGreenColor = CreateGenericRGB(0f, 1f, 0.4980392f, 1f);

        public static readonly IntPtr SteelBlueColor = CreateGenericRGB(0.2745098f, 0.509804f, 0.7058824f, 1f);

        public static readonly IntPtr TanColor = CreateGenericRGB(0.8235294f, 0.7058824f, 0.5490196f, 1f);

        public static readonly IntPtr TealColor = CreateGenericRGB(0f, 0.5019608f, 0.5019608f, 1f);

        public static readonly IntPtr ThistleColor = CreateGenericRGB(0.8470588f, 0.7490196f, 0.8470588f, 1f);

        public static readonly IntPtr TomatoColor = CreateGenericRGB(1f, 0.3882353f, 0.2784314f, 1f);

        public static readonly IntPtr TurquoiseColor = CreateGenericRGB(0.2509804f, 0.8784314f, 0.8156863f, 1f);

        public static readonly IntPtr VioletColor = CreateGenericRGB(0.9333333f, 0.509804f, 0.9333333f, 1f);

        public static readonly IntPtr WheatColor = CreateGenericRGB(0.9607843f, 0.8705882f, 0.7019608f, 1f);

        public static readonly IntPtr WhiteColor = CreateGenericRGB(1f, 1f, 1f, 1f);

        public static readonly IntPtr WhiteSmokeColor = CreateGenericRGB(0.9607843f, 0.9607843f, 0.9607843f, 1f);

        public static readonly IntPtr YellowColor = CreateGenericRGB(1f, 1f, 0f, 1f);

        public static readonly IntPtr YellowGreenColor = CreateGenericRGB(0.6039216f, 0.8039216f, 0.1960784f, 1f);
#endif
    }
}
