//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
    public partial struct CGRect
    {
        public static readonly CGRect CGRectZero = new CGRect();

        public static int CGRectContainsPoint(CGRect rect, CGPoint point)
        {
            return ((point.x >= CGRectGetMinX(rect)) &&
                    (point.x < CGRectGetMaxX(rect)) &&
                    (point.y >= CGRectGetMinY(rect)) &&
                    (point.y < CGRectGetMaxY(rect))) ? 1 : 0;
        }

        public static int CGRectContainsRect(CGRect rect1, CGRect rect2)
        {
            return ((CGRectIsEmpty(rect2) == 0) &&
                    (CGRectGetMinX(rect1) <= CGRectGetMinX((rect2))) &&
                    (CGRectGetMinY(rect1) <= CGRectGetMinY((rect2))) &&
                    (CGRectGetMaxX(rect1) >= CGRectGetMaxX((rect2))) &&
                    (CGRectGetMaxY(rect1) >= CGRectGetMaxY((rect2)))) ? 1 : 0;
        }

        public static void CGRectDivide(CGRect rect, ref CGRect slice, ref CGRect remainder, float amount, CGRectEdge edge)
        {
            if (CGRectIsEmpty(rect) == 1)
            {
                slice = CGRectZero;
                remainder = CGRectZero;
            }

            switch (edge)
            {
                case CGRectEdge.CGRectMinXEdge:
                    {
                        float delta = amount;
                        if (amount > rect.size.width)
                        {
                            delta = rect.size.width;
                        }

                        slice = CGRectMake(rect.origin.x,
                                           rect.origin.y,
                                           delta,
                                           rect.size.height);
                        remainder = CGRectMake(rect.origin.x + delta,
                                               rect.origin.y,
                                               rect.size.width - delta,
                                               rect.size.height);
                    }
                    break;
                case CGRectEdge.CGRectMinYEdge:
                    {
                        float delta = amount;
                        if (amount > rect.size.height)
                        {
                            delta = rect.size.height;
                        }

                        slice = CGRectMake(rect.origin.x,
                                           rect.origin.y,
                                           rect.size.width,
                                           delta);
                        remainder = CGRectMake(rect.origin.x,
                                               rect.origin.y + delta,
                                               rect.size.width,
                                               rect.size.height - delta);
                    }
                    break;
                case CGRectEdge.CGRectMaxXEdge:
                    {
                        float delta = amount;
                        if (amount > rect.size.width)
                        {
                            delta = rect.size.width;
                        }

                        slice = CGRectMake(rect.origin.x + rect.size.width - delta,
                                           rect.origin.y,
                                           delta,
                                           rect.size.height);
                        remainder = CGRectMake(rect.origin.x,
                                               rect.origin.y,
                                               rect.size.width - delta,
                                               rect.size.height);
                    }
                    break;
                case CGRectEdge.CGRectMaxYEdge:
                    {
                        float delta = amount;
                        if (amount > rect.size.height)
                        {
                            delta = rect.size.height;
                        }

                        slice = CGRectMake(rect.origin.x,
                                           rect.origin.y + rect.size.height - delta,
                                           rect.size.width,
                                           delta);
                        remainder = CGRectMake(rect.origin.x,
                                               rect.origin.y,
                                               rect.size.width,
                                               rect.size.height - delta);
                    }
                    break;
                default:
                    throw new ArgumentOutOfRangeException("edge");
            }
        }

        public static int CGRectEqualToRect(CGRect rect1, CGRect rect2)
        {
            return Equals(rect1, rect2) ? 1 : 0;
        }

        public static float CGRectGetHeight(CGRect rect)
        {
            return rect.size.height;
        }

        public static float CGRectGetMaxX(CGRect rect)
        {
            return rect.origin.x + rect.size.width;
        }

        public static float CGRectGetMaxY(CGRect rect)
        {
            return rect.origin.y + rect.size.height;
        }

        public static float CGRectGetMidX(CGRect rect)
        {
            return rect.origin.x + (rect.size.width/2.0f);
        }

        public static float CGRectGetMidY(CGRect rect)
        {
            return rect.origin.y + (rect.size.height/2.0f);
        }

        public static float CGRectGetMinX(CGRect rect)
        {
            return rect.origin.x;
        }

        public static float CGRectGetMinY(CGRect rect)
        {
            return rect.origin.y;
        }

        public static float CGRectGetWidth(CGRect rect)
        {
            return rect.size.width;
        }

        public static CGRect CGRectInset(CGRect rect, float dx, float dy)
        {
            return CGRectMake(rect.origin.x + dx,
                              rect.origin.y + dy,
                              rect.size.width - 2*dx,
                              rect.size.height - 2*dy);
        }

        public static CGRect CGRectIntegral(CGRect rect)
        {
            CGRect result = new CGRect();
            result.origin.x = (float)Math.Floor(rect.origin.x);
            result.origin.y = (float)Math.Floor(rect.origin.y);
            result.size.width = (float)Math.Ceiling(rect.origin.x + rect.size.width) - result.origin.x;
            result.size.height = (float)Math.Ceiling(rect.origin.y + rect.size.height) - result.origin.y;
            return result;
        }

        public static CGRect CGRectIntersection(CGRect rect1, CGRect rect2)
        {
            if (((CGRectGetMaxX(rect1) <= CGRectGetMinX(rect2)) || (CGRectGetMaxX(rect2) <= CGRectGetMinX(rect1))) ||
                ((CGRectGetMaxY(rect1) <= CGRectGetMinY(rect2)) || (CGRectGetMaxY(rect2) <= CGRectGetMinY(rect1))))
            {
                return CGRectZero;
            }

            CGRect result = new CGRect();

            result.origin.x = (CGRectGetMinX(rect1) <= CGRectGetMinX(rect2)) ? CGRectGetMinX(rect2) : CGRectGetMinX(rect1);
            result.origin.y = (CGRectGetMinY(rect1) <= CGRectGetMinY(rect2)) ? CGRectGetMinY(rect2) : CGRectGetMinY(rect1);

            result.size.width = (CGRectGetMaxX(rect1) >= CGRectGetMaxX(rect2)) ? (CGRectGetMaxX(rect2) - result.origin.x) : (CGRectGetMaxX(rect1) - result.origin.x);
            result.size.height = (CGRectGetMaxY(rect1) >= CGRectGetMaxY(rect2)) ? (CGRectGetMaxY(rect2) - result.origin.y) : (CGRectGetMaxY(rect1) - result.origin.y);

            return result;
        }

        public static int CGRectIntersectsRect(CGRect rect1, CGRect rect2)
        {
            return (((CGRectGetMaxX(rect1) <= CGRectGetMinX(rect2)) || (CGRectGetMaxX(rect2) <= CGRectGetMinX(rect1))) ||
                    ((CGRectGetMaxY(rect1) <= CGRectGetMinY(rect2)) || (CGRectGetMaxY(rect2) <= CGRectGetMinY(rect1))))
                       ? 0
                       : 1;
        }

        public static int CGRectIsEmpty(CGRect rect)
        {
            return ((rect.size.width > 0) && (rect.size.height > 0)) ? 0 : 1;
        }

        public static bool CGRectIsInfinite(CGRect rect)
        {
            return false;
        }

        public static int CGRectIsNull(CGRect rect)
        {
            return 0;
        }

        public static CGRect CGRectMake(float x, float y, float width, float height)
        {
            return new CGRect(x, y, width, height);
        }

        public static CGRect CGRectOffset(CGRect rect, float dx, float dy)
        {
            return CGRectMake(rect.origin.x + dx,
                              rect.origin.y + dy,
                              rect.size.width,
                              rect.size.height);
        }

        public static CGRect CGRectStandardize(CGRect rect)
        {
            bool horiz = (rect.size.width > 0);
            bool vert = (rect.size.height > 0);
            float w = horiz ? rect.size.width : -rect.size.width;
            float h = horiz ? rect.size.height : -rect.size.height;
            float x = horiz ? rect.origin.x : rect.origin.x - w;
            float y = vert ? rect.origin.y : rect.origin.y - h;
            return CGRectMake(x, y, w, h);
        }

        public static CGRect CGRectUnion(CGRect r1, CGRect r2)
        {
            if ((CGRectIsEmpty(r1) == 1) && (CGRectIsEmpty(r2) == 2))
            {
                return CGRectZero;
            }
            else if (CGRectIsEmpty(r1) == 1)
            {
                return r2;
            }
            else if (CGRectIsEmpty(r2) == 1)
            {
                return r1;
            }

            CGRect result = CGRectMake(Math.Min(CGRectGetMinX(r1), CGRectGetMinX(r2)),
                                       Math.Min(CGRectGetMinY(r1), CGRectGetMinY(r2)),
                                       Math.Max(CGRectGetMaxX(r1), CGRectGetMaxX(r2)),
                                       Math.Max(CGRectGetMaxY(r1), CGRectGetMaxY(r2)));
            return result;
        }
    }
}
