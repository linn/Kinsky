//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CALayer
    {
        public static readonly NSString kCAOnOrderIn = NSString.NSPinnedString("onOrderIn");

        public static readonly NSString kCAOnOrderOut = NSString.NSPinnedString("onOrderOut");

        public static readonly NSString kCATransition = NSString.NSPinnedString("transition");

        public static readonly NSString kCAGravityCenter = NSString.NSPinnedString("center");

        public static readonly NSString kCAGravityTop = NSString.NSPinnedString("top");

        public static readonly NSString kCAGravityBottom = NSString.NSPinnedString("bottom");

        public static readonly NSString kCAGravityLeft = NSString.NSPinnedString("left");

        public static readonly NSString kCAGravityRight = NSString.NSPinnedString("right");

        public static readonly NSString kCAGravityTopLeft = NSString.NSPinnedString("topLeft");

        public static readonly NSString kCAGravityTopRight = NSString.NSPinnedString("topRight");

        public static readonly NSString kCAGravityBottomLeft = NSString.NSPinnedString("bottomLeft");

        public static readonly NSString kCAGravityBottomRight = NSString.NSPinnedString("bottomRight");

        public static readonly NSString kCAGravityResize = NSString.NSPinnedString("resize");

        public static readonly NSString kCAGravityResizeAspect = NSString.NSPinnedString("resizeAspect");

        public static readonly NSString kCAGravityResizeAspectFill = NSString.NSPinnedString("resizeAspectFill");

        public static readonly NSString kCAFilterLinear = NSString.NSPinnedString("linear");

        public static readonly NSString kCAFilterNearest = NSString.NSPinnedString("nearest");
    }
#endif
}
