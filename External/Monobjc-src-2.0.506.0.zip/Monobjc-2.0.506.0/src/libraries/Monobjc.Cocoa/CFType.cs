﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;

namespace Monobjc.Cocoa
{
    public class CFType
    {
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString CFCopyDescription(IntPtr cf);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString CFCopyTypeIDDescription(uint theType);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices")]
        public static extern Boolean CFEqual(IntPtr cf1, IntPtr cf2);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices")]
        public static extern IntPtr CFGetAllocator(IntPtr cf);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices")]
        public static extern uint CFGetRetainCount(IntPtr cf);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices")]
        public static extern uint CFGetTypeID(IntPtr cf);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices")]
        public static extern uint CFHash(IntPtr cf);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices")]
        public static extern void CFRelease(IntPtr cf);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices")]
        public static extern CFType CFRetain(IntPtr cf);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices")]
        public static extern void CFShow(IntPtr obj);
    }
}
