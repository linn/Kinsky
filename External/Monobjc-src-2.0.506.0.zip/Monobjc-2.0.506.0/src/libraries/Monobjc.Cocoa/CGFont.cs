//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;
using CGContextRef = System.IntPtr;
using CGDataProviderRef = System.IntPtr;
using CGFontRef = System.IntPtr;
using CGFloat = System.Single;
using CGGlyph = System.UInt16;

namespace Monobjc.Cocoa
{
    public class CGFont
    {
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontCanCreatePostScriptSubset")]
        public static extern bool CanCreatePostScriptSubset(CGFontRef font, CGFontPostScriptFormat format);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGFontCopyFullName")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString CopyFullName(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGFontCopyGlyphNameForGlyph")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString CopyGlyphNameForGlyph(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGFontCopyPostScriptName")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString CopyPostScriptName(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGFontCopyTableForTag")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSData>))]
        public static extern NSData CopyTableForTag(CGFontRef font, uint tag);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGFontCopyTableTags")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSArray>))]
        public static extern NSArray CopyTableTags(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGFontCopyVariationAxes")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSArray>))]
        public static extern NSArray CopyVariationAxes(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGFontCopyVariations")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))]
        public static extern NSDictionary CopyVariations(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontCreateCopyWithVariations")]
        public static extern CGFontRef CreateCopyWithVariations(CGFontRef font, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary variations);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGFontCreatePostScriptEncoding")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSData>))]
        public static extern NSData CreatePostScriptEncoding(CGFontRef font, CGGlyph[] encoding);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGFontCreatePostScriptSubset")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSData>))]
        public static extern NSData CreatePostScriptSubset(CGFontRef font, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString subsetName, CGFontPostScriptFormat format, CGGlyph[] glyphs, uint count,
                                                                 CGGlyph[] encoding);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGFontCreateWithDataProvider")]
        public static extern CGFontRef CreateWithDataProvider(CGDataProviderRef provider);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontCreateWithFontName")]
        public static extern CGFontRef CreateWithFontName([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString name);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontCreateWithPlatformFont")]
        public static extern CGFontRef CreateWithPlatformFont(CGContextRef platformFontReference);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetAscent")]
        public static extern int GetAscent(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetCapHeight")]
        public static extern int GetCapHeight(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetDescent")]
        public static extern int GetDescent(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetFontBBox")]
        public static extern CGRect GetFontBBox(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetGlyphAdvances")]
        public static extern bool GetGlyphAdvances(CGFontRef font, CGGlyph[] glyphs, uint count, int[] advances);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetGlyphBBoxes")]
        public static extern bool GetGlyphBBoxes(CGFontRef font, CGGlyph[] glyphs, uint count, CGRect[] bboxes);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetGlyphWithGlyphName")]
        public static extern CGGlyph GetGlyphWithGlyphName(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetItalicAngle")]
        public static extern CGFloat GetItalicAngle(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetLeading")]
        public static extern int GetLeading(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetNumberOfGlyphs")]
        public static extern uint GetNumberOfGlyphs(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetStemV")]
        public static extern CGFloat GetStemV(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetTypeID")]
        public static extern uint GetTypeID();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetUnitsPerEm")]
        public static extern int GetUnitsPerEm(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontGetXHeight")]
        public static extern int GetXHeight(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontRelease")]
        public static extern void Release(CGFontRef font);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGFontRetain")]
        public static extern CGFontRef Retain(CGFontRef font);

        public static readonly NSString kCGFontVariationAxisName = NSString.NSPinnedString("kCGFontVariationAxisName");

        public static readonly NSString kCGFontVariationAxisMinValue = NSString.NSPinnedString("kCGFontVariationAxisMinValue");

        public static readonly NSString kCGFontVariationAxisMaxValue = NSString.NSPinnedString("kCGFontVariationAxisMaxValue");

        public static readonly NSString kCGFontVariationAxisDefaultValue = NSString.NSPinnedString("kCGFontVariationAxisDefaultValue");
    }
}
