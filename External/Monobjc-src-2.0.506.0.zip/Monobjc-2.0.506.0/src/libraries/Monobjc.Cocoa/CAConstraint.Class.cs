//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using CAConstraintAttribute=System.Int32;

namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CAConstraint
    {
        public static CAConstraint ConstraintWithAttributeRelativeToAttribute(CAConstraintAttribute attr, NSString srcLayer, CAConstraintAttribute srcAttr)
        {
            return ObjectiveCRuntime.SendMessage<CAConstraint>(CAConstraintClass, "constraintWithAttribute:relativeTo:attribute:", attr, srcLayer, srcAttr);
        }

        public static CAConstraint ConstraintWithAttributeRelativeToAttributeOffset(CAConstraintAttribute attr, NSString srcLayer, CAConstraintAttribute srcAttr, float offset)
        {
            return ObjectiveCRuntime.SendMessage<CAConstraint>(CAConstraintClass, "constraintWithAttribute:relativeTo:attribute:offset:", attr, srcLayer, srcAttr, offset);
        }

        public static CAConstraint ConstraintWithAttributeRelativeToAttributeScaleOffset(CAConstraintAttribute attr, NSString srcLayer, CAConstraintAttribute srcAttr, float scale, float offset)
        {
            return ObjectiveCRuntime.SendMessage<CAConstraint>(CAConstraintClass, "constraintWithAttribute:relativeTo:attribute:scale:offset:", attr, srcLayer, srcAttr, scale, offset);
        }

        public virtual Id InitWithAttributeRelativeToAttributeScaleOffset(CAConstraintAttribute attr, NSString srcLayer, CAConstraintAttribute srcAttr, float scale, float offset)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithAttribute:relativeTo:attribute:scale:offset:", attr, srcLayer, srcAttr, scale, offset);
        }

#if MACOSX_10_6
        public CAConstraintAttribute Attribute
        {
            get { return ObjectiveCRuntime.SendMessage<CAConstraintAttribute>(this, "attribute"); }
        }
#endif

#if MACOSX_10_6
        public float Offset
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "offset"); }
        }
#endif

#if MACOSX_10_6
        public float Scale
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "scale"); }
        }
#endif

#if MACOSX_10_6
        public CAConstraintAttribute SourceAttribute
        {
            get { return ObjectiveCRuntime.SendMessage<CAConstraintAttribute>(this, "sourceAttribute"); }
        }
#endif

#if MACOSX_10_6
        public NSString SourceName
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "sourceName"); }
        }
#endif
    }
#endif
}
