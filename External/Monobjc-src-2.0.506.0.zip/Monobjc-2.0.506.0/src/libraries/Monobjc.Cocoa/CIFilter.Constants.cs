//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
    public partial class CIFilter
    {
        public static readonly NSString kCIAttributeFilterName = NSString.NSPinnedString("CIAttributeFilterName");

        public static readonly NSString kCIAttributeFilterDisplayName = NSString.NSPinnedString("CIAttributeFilterDisplayName");

        public static readonly NSString kCIAttributeDescription = NSString.NSPinnedString("CIAttributeDescription");

        public static readonly NSString kCIAttributeReferenceDocumentation = NSString.NSPinnedString("CIAttributeReferenceDocumentation");

        public static readonly NSString kCIAttributeFilterCategories = NSString.NSPinnedString("CIAttributeFilterCategories");

        public static readonly NSString kCIAttributeClass = NSString.NSPinnedString("CIAttributeClass");

        public static readonly NSString kCIAttributeType = NSString.NSPinnedString("CIAttributeType");

        public static readonly NSString kCIAttributeMin = NSString.NSPinnedString("CIAttributeMin");

        public static readonly NSString kCIAttributeMax = NSString.NSPinnedString("CIAttributeMax");

        public static readonly NSString kCIAttributeSliderMin = NSString.NSPinnedString("CIAttributeSliderMin");

        public static readonly NSString kCIAttributeSliderMax = NSString.NSPinnedString("CIAttributeSliderMax");

        public static readonly NSString kCIAttributeDefault = NSString.NSPinnedString("CIAttributeDefault");

        public static readonly NSString kCIAttributeIdentity = NSString.NSPinnedString("CIAttributeIdentity");

        public static readonly NSString kCIAttributeName = NSString.NSPinnedString("CIAttributeName");

        public static readonly NSString kCIAttributeDisplayName = NSString.NSPinnedString("CIAttributeDisplayName");

        public static readonly NSString kCIAttributeTypeTime = NSString.NSPinnedString("CIAttributeTypeTime");

        public static readonly NSString kCIAttributeTypeScalar = NSString.NSPinnedString("CIAttributeTypeScalar");

        public static readonly NSString kCIAttributeTypeDistance = NSString.NSPinnedString("CIAttributeTypeDistance");

        public static readonly NSString kCIAttributeTypeAngle = NSString.NSPinnedString("CIAttributeTypeAngle");

        public static readonly NSString kCIAttributeTypeBoolean = NSString.NSPinnedString("CIAttributeTypeBoolean");

        public static readonly NSString kCIAttributeTypeInteger = NSString.NSPinnedString("CIAttributeTypeInteger");

        public static readonly NSString kCIAttributeTypeCount = NSString.NSPinnedString("CIAttributeTypeCount");

        public static readonly NSString kCIAttributeTypePosition = NSString.NSPinnedString("CIAttributeTypePosition");

        public static readonly NSString kCIAttributeTypeOffset = NSString.NSPinnedString("CIAttributeTypeOffset");

        public static readonly NSString kCIAttributeTypePosition3 = NSString.NSPinnedString("CIAttributeTypePosition3");

        public static readonly NSString kCIAttributeTypeRectangle = NSString.NSPinnedString("CIAttributeTypeRectangle");

        public static readonly NSString kCIAttributeTypeOpaqueColor = NSString.NSPinnedString("CIAttributeTypeOpaqueColor");

        public static readonly NSString kCIAttributeTypeGradient = NSString.NSPinnedString("CIAttributeTypeGradient");

        public static readonly NSString kCICategoryDistortionEffect = NSString.NSPinnedString("CICategoryDistortionEffect");

        public static readonly NSString kCICategoryGeometryAdjustment = NSString.NSPinnedString("CICategoryGeometryAdjustment");

        public static readonly NSString kCICategoryCompositeOperation = NSString.NSPinnedString("CICategoryCompositeOperation");

        public static readonly NSString kCICategoryHalftoneEffect = NSString.NSPinnedString("CICategoryHalftoneEffect");

        public static readonly NSString kCICategoryColorAdjustment = NSString.NSPinnedString("CICategoryColorAdjustment");

        public static readonly NSString kCICategoryColorEffect = NSString.NSPinnedString("CICategoryColorEffect");

        public static readonly NSString kCICategoryTransition = NSString.NSPinnedString("CICategoryTransition");

        public static readonly NSString kCICategoryTileEffect = NSString.NSPinnedString("CICategoryTileEffect");

        public static readonly NSString kCICategoryGenerator = NSString.NSPinnedString("CICategoryGenerator");

        public static readonly NSString kCICategoryGradient = NSString.NSPinnedString("CICategoryGradient");

        public static readonly NSString kCICategoryStylize = NSString.NSPinnedString("CICategoryStylize");

        public static readonly NSString kCICategorySharpen = NSString.NSPinnedString("CICategorySharpen");

        public static readonly NSString kCICategoryBlur = NSString.NSPinnedString("CICategoryBlur");

        public static readonly NSString kCICategoryVideo = NSString.NSPinnedString("CICategoryVideo");

        public static readonly NSString kCICategoryStillImage = NSString.NSPinnedString("CICategoryStillImage");

        public static readonly NSString kCICategoryInterlaced = NSString.NSPinnedString("CICategoryInterlaced");

        public static readonly NSString kCICategoryNonSquarePixels = NSString.NSPinnedString("CICategoryNonSquarePixels");

        public static readonly NSString kCICategoryHighDynamicRange = NSString.NSPinnedString("CICategoryHighDynamicRange");

        public static readonly NSString kCICategoryBuiltIn = NSString.NSPinnedString("CICategoryBuiltIn");

        public static readonly NSString kCICategoryFilterGenerator = NSString.NSPinnedString("CICategoryFilterGenerator");

        public static readonly NSString kCIApplyOptionExtent = NSString.NSPinnedString("extent");

        public static readonly NSString kCIApplyOptionDefinition = NSString.NSPinnedString("definition");

        public static readonly NSString kCIApplyOptionUserInfo = NSString.NSPinnedString("user_info");

        public static readonly NSString kCIUIParameterSet = NSString.NSPinnedString("CIUIParameterSet");

        public static readonly NSString kCIUISetBasic = NSString.NSPinnedString("CIUISetBasic");

        public static readonly NSString kCIUISetIntermediate = NSString.NSPinnedString("CIUISetIntermediate");

        public static readonly NSString kCIUISetAdvanced = NSString.NSPinnedString("CIUISetAdvanced");

        public static readonly NSString kCIUISetDevelopment = NSString.NSPinnedString("CIUISetDevelopment");

        public static readonly NSString kCIOutputImageKey = NSString.NSPinnedString("outputImage");

        public static readonly NSString kCIInputBackgroundImageKey = NSString.NSPinnedString("inputBackgroundImage");

        public static readonly NSString kCIInputImageKey = NSString.NSPinnedString("inputImage");

        public static readonly NSString kCIInputTimeKey = NSString.NSPinnedString("inputTime");

        public static readonly NSString kCIInputTransformKey = NSString.NSPinnedString("inputTransform");

        public static readonly NSString kCIInputScaleKey = NSString.NSPinnedString("inputScale");

        public static readonly NSString kCIInputAspectRatioKey = NSString.NSPinnedString("inputAspectRatio");

        public static readonly NSString kCIInputCenterKey = NSString.NSPinnedString("inputCenter");

        public static readonly NSString kCIInputRadiusKey = NSString.NSPinnedString("inputRadius");

        public static readonly NSString kCIInputAngleKey = NSString.NSPinnedString("inputAngle");

        public static readonly NSString kCIInputRefractionKey = NSString.NSPinnedString("inputRefraction");

        public static readonly NSString kCIInputWidthKey = NSString.NSPinnedString("inputWidth");

        public static readonly NSString kCIInputSharpnessKey = NSString.NSPinnedString("inputSharpness");

        public static readonly NSString kCIInputIntensityKey = NSString.NSPinnedString("inputIntensity");

        public static readonly NSString kCIInputEVKey = NSString.NSPinnedString("inputEV");

        public static readonly NSString kCIInputSaturationKey = NSString.NSPinnedString("inputSaturation");

        public static readonly NSString kCIInputColorKey = NSString.NSPinnedString("inputColor");

        public static readonly NSString kCIInputBrightnessKey = NSString.NSPinnedString("inputBrightness");

        public static readonly NSString kCIInputContrastKey = NSString.NSPinnedString("inputContrast");

        public static readonly NSString kCIInputGradientImageKey = NSString.NSPinnedString("inputGradientImage");

        public static readonly NSString kCIInputMaskImageKey = NSString.NSPinnedString("inputMaskImage");

        public static readonly NSString kCIInputShadingImageKey = NSString.NSPinnedString("inputShadingImage");

        public static readonly NSString kCIInputTargetImageKey = NSString.NSPinnedString("inputTargetImage");

        public static readonly NSString kCIInputExtentKey = NSString.NSPinnedString("inputExtent");


        public static readonly NSString kCIInputDecoderVersionKey = NSString.NSPinnedString("inputDecoderVersion");

        public static readonly NSString kCISupportedDecoderVersionsKey = NSString.NSPinnedString("supportedDecoderVersions");

        public static readonly NSString kCIInputBoostKey = NSString.NSPinnedString("inputBoost");

        public static readonly NSString kCIInputNeutralChromaticityXKey = NSString.NSPinnedString("inputNeutralChromaticityX");

        public static readonly NSString kCIInputNeutralChromaticityYKey = NSString.NSPinnedString("inputNeutralChromaticityY");

        public static readonly NSString kCIInputNeutralTemperatureKey = NSString.NSPinnedString("inputNeutralTemperature");

        public static readonly NSString kCIInputNeutralTintKey = NSString.NSPinnedString("inputNeutralTint");

        public static readonly NSString kCIInputScaleFactorKey = NSString.NSPinnedString("inputScaleFactor");

        public static readonly NSString kCIInputAllowDraftModeKey = NSString.NSPinnedString("inputDraftMode");

        public static readonly NSString kCIInputIgnoreImageOrientationKey = NSString.NSPinnedString("inputIgnoreOrientation");

        public static readonly NSString kCIInputImageOrientationKey = NSString.NSPinnedString("inputImageOrientation");

        public static readonly NSString kCIInputEnableSharpeningKey = NSString.NSPinnedString("inputEnableSharpening");

        public static readonly NSString kCIInputEnableChromaticNoiseTrackingKey = NSString.NSPinnedString("inputEnableNoiseTracking");

        public static readonly NSString kCIInputBoostShadowAmountKey = NSString.NSPinnedString("inputBoostShadowAmount");

        public static readonly NSString kCIInputBiasKey = NSString.NSPinnedString("inputBias");
    }
}
