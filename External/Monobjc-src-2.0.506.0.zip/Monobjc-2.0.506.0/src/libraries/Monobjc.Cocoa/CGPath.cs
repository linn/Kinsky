﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;
using CGPathRef=System.IntPtr;
using CGMutablePathRef=System.IntPtr;
using CGFloat = System.Single;

namespace Monobjc.Cocoa
{
    public class CGPath
    {
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathAddArc")]
        public static extern void AddArc(CGMutablePathRef path, ref CGAffineTransform m, CGFloat x, CGFloat y, CGFloat radius, CGFloat startAngle, CGFloat endAngle, bool clockwise);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathAddArcToPoint")]
        public static extern void AddArcToPoint(CGMutablePathRef path, ref CGAffineTransform m, CGFloat x1, CGFloat y1, CGFloat x2, CGFloat y2, CGFloat radius);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathAddCurveToPoint")]
        public static extern void AddCurveToPoint(CGMutablePathRef path, ref CGAffineTransform m, CGFloat cp1x, CGFloat cp1y, CGFloat cp2x, CGFloat cp2y, CGFloat x, CGFloat y);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathAddEllipseInRect")]
        public static extern void AddEllipseInRect(CGMutablePathRef path, ref CGAffineTransform m, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathAddLines")]
        public static extern void AddLines(CGMutablePathRef path, ref CGAffineTransform m, CGPoint[] points, uint count);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathAddLineToPoint")]
        public static extern void AddLineToPoint(CGMutablePathRef path, ref CGAffineTransform m, CGFloat x, CGFloat y);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathAddPath")]
        public static extern void AddPath(CGMutablePathRef path1, ref CGAffineTransform m, CGPathRef path2);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathAddQuadCurveToPoint")]
        public static extern void AddQuadCurveToPoint(CGMutablePathRef path, ref CGAffineTransform m, CGFloat cpx, CGFloat cpy, CGFloat x, CGFloat y);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathAddRect")]
        public static extern void AddRect(CGMutablePathRef path, ref CGAffineTransform m, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathAddRects")]
        public static extern void AddRects(CGMutablePathRef path, ref CGAffineTransform m, CGRect[] rects, uint count);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathApply")]
        public static extern void Apply(CGPathRef path, CGPathRef info, CGPathApplierFunction function);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathCloseSubpath")]
        public static extern void CloseSubpath(CGMutablePathRef path);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathContainsPoint")]
        public static extern bool ContainsPoint(CGPathRef path, ref CGAffineTransform m, CGPoint point, bool eoFill);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathCreateCopy")]
        public static extern CGPathRef CreateCopy(CGPathRef path);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathCreateMutable")]
        public static extern CGMutablePathRef CreateMutable();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathCreateMutableCopy")]
        public static extern CGMutablePathRef CreateMutableCopy(CGPathRef path);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathEqualToPath")]
        public static extern bool EqualToPath(CGPathRef path1, CGPathRef path2);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathGetBoundingBox")]
        public static extern CGRect GetBoundingBox(CGPathRef path);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathGetCurrentPoint")]
        public static extern CGPoint GetCurrentPoint(CGPathRef path);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathGetTypeID")]
        public static extern uint GetTypeID();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathIsEmpty")]
        public static extern bool IsEmpty(CGPathRef path);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathIsRect")]
        public static extern bool IsRect(CGPathRef path, ref CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathMoveToPoint")]
        public static extern void MoveToPoint(CGMutablePathRef path, ref CGAffineTransform m, CGFloat x, CGFloat y);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathRelease")]
        public static extern void Release(CGPathRef path);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGPathRetain")]
        public static extern CGPathRef Retain(CGPathRef path);
    }
}
