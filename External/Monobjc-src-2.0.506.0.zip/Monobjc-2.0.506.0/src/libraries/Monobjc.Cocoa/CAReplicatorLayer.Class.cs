//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using CGColorRef = System.IntPtr;
using CFTimeInterval = System.Double;

namespace Monobjc.Cocoa
{
#if MACOSX_10_6
    partial class CAReplicatorLayer
    {
        public virtual float InstanceAlphaOffset
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "instanceAlphaOffset"); }
            set { ObjectiveCRuntime.SendMessage(this, "setInstanceAlphaOffset:", value); }
        }

        public virtual float InstanceBlueOffset
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "instanceBlueOffset"); }
            set { ObjectiveCRuntime.SendMessage(this, "setInstanceBlueOffset:", value); }
        }

        public virtual CGColorRef InstanceColor
        {
            get { return ObjectiveCRuntime.SendMessage<CGColorRef>(this, "instanceColor"); }
            set { ObjectiveCRuntime.SendMessage(this, "setInstanceColor:", value); }
        }

        public virtual int InstanceCount
        {
            get { return ObjectiveCRuntime.SendMessage<int>(this, "instanceCount"); }
            set { ObjectiveCRuntime.SendMessage(this, "setInstanceCount:", value); }
        }

        public virtual CFTimeInterval InstanceDelay
        {
            get { return ObjectiveCRuntime.SendMessage<CFTimeInterval>(this, "instanceDelay"); }
            set { ObjectiveCRuntime.SendMessage(this, "setInstanceDelay:", value); }
        }

        public virtual float InstanceGreenOffset
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "instanceGreenOffset"); }
            set { ObjectiveCRuntime.SendMessage(this, "setInstanceGreenOffset:", value); }
        }

        public virtual float InstanceRedOffset
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "instanceRedOffset"); }
            set { ObjectiveCRuntime.SendMessage(this, "setInstanceRedOffset:", value); }
        }

        public virtual CATransform3D InstanceTransform
        {
            get { return ObjectiveCRuntime.SendMessage<CATransform3D>(this, "instanceTransform"); }
            set { ObjectiveCRuntime.SendMessage(this, "setInstanceTransform:", value); }
        }

        public virtual bool PreservesDepth
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "preservesDepth"); }
            set { ObjectiveCRuntime.SendMessage(this, "setPreservesDepth:", value); }
        }
    }
#endif
}
