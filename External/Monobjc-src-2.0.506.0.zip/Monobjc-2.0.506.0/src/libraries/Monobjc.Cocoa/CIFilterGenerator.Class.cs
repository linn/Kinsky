﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CIFilterGenerator
    {
        public static CIFilterGenerator FilterGeneratorWithContentsOfURL(NSURL aURL)
        {
            return ObjectiveCRuntime.SendMessage<CIFilterGenerator>(CIFilterGeneratorClass, "filterGeneratorWithContentsOfURL:", aURL);
        }

        public virtual void ConnectObjectWithKeyToObjectWithKey(Id sourceObject, NSString sourceKey, Id targetObject, NSString targetKey)
        {
            ObjectiveCRuntime.SendMessage(this, "connectObject:withKey:toObject:withKey:", sourceObject, sourceKey, targetObject, targetKey);
        }

        public virtual void DisconnectObjectWithKeyToObjectWithKey(Id sourceObject, NSString key, Id targetObject, NSString targetKey)
        {
            ObjectiveCRuntime.SendMessage(this, "disconnectObject:withKey:toObject:withKey:", sourceObject, key, targetObject, targetKey);
        }

        public virtual void ExportKeyFromObjectWithName(NSString key, Id targetObject, NSString exportedKeyName)
        {
            ObjectiveCRuntime.SendMessage(this, "exportKey:fromObject:withName:", key, targetObject, exportedKeyName);
        }

        public virtual Id InitWithContentsOfURL(NSURL aURL)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithContentsOfURL:", aURL);
        }

        public virtual void RegisterFilterName(NSString name)
        {
            ObjectiveCRuntime.SendMessage(this, "registerFilterName:", name);
        }

        public virtual void RemoveExportedKey(NSString exportedKeyName)
        {
            ObjectiveCRuntime.SendMessage(this, "removeExportedKey:", exportedKeyName);
        }

        public virtual void SetAttributesForExportedKey(NSDictionary attributes, NSString key)
        {
            ObjectiveCRuntime.SendMessage(this, "setAttributes:forExportedKey:", attributes, key);
        }

        public virtual bool WriteToURLAtomically(NSURL aURL, bool flag)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "writeToURL:atomically:", aURL, flag);
        }

        public static CIFilterGenerator FilterGenerator
        {
            get { return ObjectiveCRuntime.SendMessage<CIFilterGenerator>(CIFilterGeneratorClass, "filterGenerator"); }
        }

        public virtual NSDictionary ClassAttributes
        {
            get { return ObjectiveCRuntime.SendMessage<NSDictionary>(this, "classAttributes"); }
            set { ObjectiveCRuntime.SendMessage(this, "setClassAttributes:", value); }
        }

        public virtual NSDictionary ExportedKeys
        {
            get { return ObjectiveCRuntime.SendMessage<NSDictionary>(this, "exportedKeys"); }
        }

        public virtual CIFilter Filter
        {
            get { return ObjectiveCRuntime.SendMessage<CIFilter>(this, "filter"); }
        }
    }
#endif
}
