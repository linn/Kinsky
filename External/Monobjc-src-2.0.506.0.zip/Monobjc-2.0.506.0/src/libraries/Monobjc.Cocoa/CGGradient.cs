﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;
using CGColorSpaceRef = System.IntPtr;
using CGGradientRef = System.IntPtr;
using CGFloat = System.Single;

namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public class CGGradient
    {
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGGradientCreateWithColorComponents")]
        public static extern CGGradientRef CreateWithColorComponents(CGColorSpaceRef space, CGFloat[] components, CGFloat[] locations, uint count);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGGradientCreateWithColors")]
        public static extern CGGradientRef CreateWithColors(CGColorSpaceRef space, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSArray>))] NSArray colors, CGFloat[] locations);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGGradientGetTypeID")]
        public static extern uint GetTypeID();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGGradientRelease")]
        public static extern void Release(CGGradientRef gradient);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGGradientRetain")]
        public static extern CGGradientRef Retain(CGGradientRef gradient);
    }
#endif
}
