//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace Monobjc.Cocoa
{
    [StructLayout(LayoutKind.Sequential)]
    public partial struct CGPoint : IEquatable<CGPoint>
    {
        public float x;

        public float y;

        public CGPoint(float x, float y)
        {
            this.x = x;
            this.y = y;
        }

        public override String ToString()
        {
            return String.Format(CultureInfo.CurrentCulture, "CGPoint({0}, {1})", this.x, this.y);
        }

        public static bool operator !=(CGPoint cgPoint1, CGPoint cgPoint2)
        {
            return !cgPoint1.Equals(cgPoint2);
        }

        public static bool operator ==(CGPoint cgPoint1, CGPoint cgPoint2)
        {
            return cgPoint1.Equals(cgPoint2);
        }

        public bool Equals(CGPoint cgPoint)
        {
            return (this.x == cgPoint.x) && (this.y == cgPoint.y);
        }

        public override bool Equals(object obj)
        {
            if (!(obj is CGPoint))
            {
                return false;
            }
            return Equals((CGPoint) obj);
        }

        public override int GetHashCode()
        {
            return this.x.GetHashCode() + 29*this.y.GetHashCode();
        }
    }
}
