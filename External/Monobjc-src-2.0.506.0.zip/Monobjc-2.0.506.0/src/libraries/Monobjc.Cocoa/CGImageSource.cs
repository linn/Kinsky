﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;
using CGDataProviderRef=System.IntPtr;
using CGImageSourceRef=System.IntPtr;
using CGImageRef=System.IntPtr;

namespace Monobjc.Cocoa
{
    public class CGImageSource
    {
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceCopyProperties")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))]
        public static extern NSDictionary CopyProperties(CGImageSourceRef isrc, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary options);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceCopyPropertiesAtIndex")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))]
        public static extern NSDictionary CopyPropertiesAtIndex(CGImageSourceRef isrc, uint index, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary options);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceCopyTypeIdentifiers")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSArray>))]
        public static extern NSArray CopyTypeIdentifiers();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceCreateImageAtIndex")]
        public static extern CGImageRef CreateImageAtIndex(CGImageSourceRef isrc, uint index, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary options);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceCreateIncremental")]
        public static extern CGImageSourceRef CreateIncremental([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary options);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceCreateThumbnailAtIndex")]
        public static extern CGImageRef CreateThumbnailAtIndex(CGImageSourceRef isrc, uint index, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary options);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceCreateWithData")]
        public static extern CGImageSourceRef CreateWithData([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSData>))] NSData data,
                                                                          [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary options);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceCreateWithDataProvider")]
        public static extern CGImageSourceRef CreateWithDataProvider(CGDataProviderRef provider, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary options);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceCreateWithURL")]
        public static extern CGImageSourceRef CreateWithURL([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSURL>))] NSURL url,
                                                                         [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSDictionary>))] NSDictionary options);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceGetCount")]
        public static extern uint GetCount(CGImageSourceRef isrc);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceGetStatus")]
        public static extern CGImageSourceStatus GetStatus(CGImageSourceRef isrc);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceGetStatusAtIndex")]
        public static extern CGImageSourceStatus GetStatusAtIndex(CGImageSourceRef isrc, uint index);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceGetType")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))]
        public static extern NSString GetType(CGImageSourceRef isrc);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceGetTypeID")]
        public static extern uint GetTypeID();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceUpdateData")]
        public static extern void UpdateData(CGImageSourceRef isrc, [MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSData>))] NSData data, bool final);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageSourceUpdateDataProvider")]
        public static extern void UpdateDataProvider(CGImageSourceRef isrc, CGDataProviderRef provider, bool final);

        public static readonly NSString kCGImagePropertyTIFFDictionary = NSString.NSPinnedString("{TIFF}");

        public static readonly NSString kCGImagePropertyGIFDictionary = NSString.NSPinnedString("{GIF}");

        public static readonly NSString kCGImagePropertyJFIFDictionary = NSString.NSPinnedString("{JFIF}");

        public static readonly NSString kCGImagePropertyExifDictionary = NSString.NSPinnedString("{Exif}");

        public static readonly NSString kCGImagePropertyPNGDictionary = NSString.NSPinnedString("{PNG}");

        public static readonly NSString kCGImagePropertyIPTCDictionary = NSString.NSPinnedString("{IPTC}");

        public static readonly NSString kCGImagePropertyGPSDictionary = NSString.NSPinnedString("{GPS}");

        public static readonly NSString kCGImagePropertyRawDictionary = NSString.NSPinnedString("{Raw}");

        public static readonly NSString kCGImagePropertyCIFFDictionary = NSString.NSPinnedString("{CIFF}");

        public static readonly NSString kCGImageProperty8BIMDictionary = NSString.NSPinnedString("{8BIM}");

        public static readonly NSString kCGImageSourceTypeIdentifierHint = NSString.NSPinnedString("kCGImageSourceTypeIdentifierHint");

        public static readonly NSString kCGImageSourceShouldAllowFloat = NSString.NSPinnedString("kCGImageSourceShouldAllowFloat");

        public static readonly NSString kCGImageSourceShouldCache = NSString.NSPinnedString("kCGImageSourceShouldCache");

        public static readonly NSString kCGImageSourceCreateThumbnailFromImageIfAbsent = NSString.NSPinnedString("kCGImageSourceCreateThumbnailFromImageIfAbsent");

        public static readonly NSString kCGImageSourceCreateThumbnailFromImageAlways = NSString.NSPinnedString("kCGImageSourceCreateThumbnailFromImageAlways");

        public static readonly NSString kCGImageSourceThumbnailMaxPixelSize = NSString.NSPinnedString("kCGImageSourceThumbnailMaxPixelSize");

        public static readonly NSString kCGImageSourceCreateThumbnailWithTransform = NSString.NSPinnedString("kCGImageSourceCreateThumbnailWithTransform");

        public static readonly NSString kCGImagePropertyFileSize = NSString.NSPinnedString("FileSize");

        public static readonly NSString kCGImagePropertyDPIHeight = NSString.NSPinnedString("DPIHeight");

        public static readonly NSString kCGImagePropertyDPIWidth = NSString.NSPinnedString("DPIWidth");

        public static readonly NSString kCGImagePropertyPixelWidth = NSString.NSPinnedString("PixelWidth");

        public static readonly NSString kCGImagePropertyPixelHeight = NSString.NSPinnedString("PixelHeight");

        public static readonly NSString kCGImagePropertyDepth = NSString.NSPinnedString("Depth");

        public static readonly NSString kCGImagePropertyOrientation = NSString.NSPinnedString("Orientation");

        public static readonly NSString kCGImagePropertyIsFloat = NSString.NSPinnedString("IsFloat");

        public static readonly NSString kCGImagePropertyIsIndexed = NSString.NSPinnedString("IsIndexed");

        public static readonly NSString kCGImagePropertyHasAlpha = NSString.NSPinnedString("HasAlpha");

        public static readonly NSString kCGImagePropertyColorModel = NSString.NSPinnedString("ColorModel");

        public static readonly NSString kCGImagePropertyProfileName = NSString.NSPinnedString("ProfileName");

        public static readonly NSString kCGImagePropertyColorModelRGB = NSString.NSPinnedString("RGB");

        public static readonly NSString kCGImagePropertyColorModelGray = NSString.NSPinnedString("Gray");

        public static readonly NSString kCGImagePropertyColorModelCMYK = NSString.NSPinnedString("CMYK");

        public static readonly NSString kCGImagePropertyColorModelLab = NSString.NSPinnedString("Lab");

        public static readonly NSString kCGImagePropertyExifExposureTime = NSString.NSPinnedString("ExposureTime");

        public static readonly NSString kCGImagePropertyExifFNumber = NSString.NSPinnedString("FNumber");

        public static readonly NSString kCGImagePropertyExifExposureProgram = NSString.NSPinnedString("ExposureProgram");

        public static readonly NSString kCGImagePropertyExifSpectralSensitivity = NSString.NSPinnedString("SpectralSensitivity");

        public static readonly NSString kCGImagePropertyExifISOSpeedRatings = NSString.NSPinnedString("ISOSpeedRatings");

        public static readonly NSString kCGImagePropertyExifOECF = NSString.NSPinnedString("OECF");

        public static readonly NSString kCGImagePropertyExifVersion = NSString.NSPinnedString("ExifVersion");

        public static readonly NSString kCGImagePropertyExifDateTimeOriginal = NSString.NSPinnedString("DateTimeOriginal");

        public static readonly NSString kCGImagePropertyExifDateTimeDigitized = NSString.NSPinnedString("DateTimeDigitized");

        public static readonly NSString kCGImagePropertyExifComponentsConfiguration = NSString.NSPinnedString("ComponentsConfiguration");

        public static readonly NSString kCGImagePropertyExifCompressedBitsPerPixel = NSString.NSPinnedString("CompressedBitsPerPixel");

        public static readonly NSString kCGImagePropertyExifShutterSpeedValue = NSString.NSPinnedString("ShutterSpeedValue");

        public static readonly NSString kCGImagePropertyExifApertureValue = NSString.NSPinnedString("ApertureValue");

        public static readonly NSString kCGImagePropertyExifBrightnessValue = NSString.NSPinnedString("BrightnessValue");

        public static readonly NSString kCGImagePropertyExifExposureBiasValue = NSString.NSPinnedString("ExposureBiasValue");

        public static readonly NSString kCGImagePropertyExifMaxApertureValue = NSString.NSPinnedString("MaxApertureValue");

        public static readonly NSString kCGImagePropertyExifSubjectDistance = NSString.NSPinnedString("SubjectDistance");

        public static readonly NSString kCGImagePropertyExifMeteringMode = NSString.NSPinnedString("MeteringMode");

        public static readonly NSString kCGImagePropertyExifLightSource = NSString.NSPinnedString("LightSource");

        public static readonly NSString kCGImagePropertyExifFlash = NSString.NSPinnedString("Flash");

        public static readonly NSString kCGImagePropertyExifFocalLength = NSString.NSPinnedString("FocalLength");

        public static readonly NSString kCGImagePropertyExifSubjectArea = NSString.NSPinnedString("SubjectArea");

        public static readonly NSString kCGImagePropertyExifMakerNote = NSString.NSPinnedString("MakerNote");

        public static readonly NSString kCGImagePropertyExifUserComment = NSString.NSPinnedString("UserComment");

        public static readonly NSString kCGImagePropertyExifSubsecTime = NSString.NSPinnedString("SubsecTime");

        public static readonly NSString kCGImagePropertyExifSubsecTimeOrginal = NSString.NSPinnedString("SubsecTimeOriginal");

        public static readonly NSString kCGImagePropertyExifSubsecTimeDigitized = NSString.NSPinnedString("SubsecTimeDigitized");

        public static readonly NSString kCGImagePropertyExifFlashPixVersion = NSString.NSPinnedString("FlashPixVersion");

        public static readonly NSString kCGImagePropertyExifColorSpace = NSString.NSPinnedString("ColorSpace");

        public static readonly NSString kCGImagePropertyExifPixelXDimension = NSString.NSPinnedString("PixelXDimension");

        public static readonly NSString kCGImagePropertyExifPixelYDimension = NSString.NSPinnedString("PixelYDimension");

        public static readonly NSString kCGImagePropertyExifRelatedSoundFile = NSString.NSPinnedString("RelatedSoundFile");

        public static readonly NSString kCGImagePropertyExifFlashEnergy = NSString.NSPinnedString("FlashEnergy");

        public static readonly NSString kCGImagePropertyExifSpatialFrequencyResponse = NSString.NSPinnedString("SpatialFrequencyResponse");

        public static readonly NSString kCGImagePropertyExifFocalPlaneXResolution = NSString.NSPinnedString("FocalPlaneXResolution");

        public static readonly NSString kCGImagePropertyExifFocalPlaneYResolution = NSString.NSPinnedString("FocalPlaneYResolution");

        public static readonly NSString kCGImagePropertyExifFocalPlaneResolutionUnit = NSString.NSPinnedString("FocalPlaneResolutionUnit");

        public static readonly NSString kCGImagePropertyExifSubjectLocation = NSString.NSPinnedString("SubjectLocation");

        public static readonly NSString kCGImagePropertyExifExposureIndex = NSString.NSPinnedString("ExposureIndex");

        public static readonly NSString kCGImagePropertyExifSensingMethod = NSString.NSPinnedString("SensingMethod");

        public static readonly NSString kCGImagePropertyExifFileSource = NSString.NSPinnedString("FileSource");

        public static readonly NSString kCGImagePropertyExifSceneType = NSString.NSPinnedString("SceneType");

        public static readonly NSString kCGImagePropertyExifCFAPattern = NSString.NSPinnedString("CFAPattern");

        public static readonly NSString kCGImagePropertyExifCustomRendered = NSString.NSPinnedString("CustomRendered");

        public static readonly NSString kCGImagePropertyExifExposureMode = NSString.NSPinnedString("ExposureMode");

        public static readonly NSString kCGImagePropertyExifWhiteBalance = NSString.NSPinnedString("WhiteBalance");

        public static readonly NSString kCGImagePropertyExifDigitalZoomRatio = NSString.NSPinnedString("DigitalZoomRatio");

        public static readonly NSString kCGImagePropertyExifFocalLenIn35mmFilm = NSString.NSPinnedString("FocalLenIn35mmFilm");

        public static readonly NSString kCGImagePropertyExifSceneCaptureType = NSString.NSPinnedString("SceneCaptureType");

        public static readonly NSString kCGImagePropertyExifGainControl = NSString.NSPinnedString("GainControl");

        public static readonly NSString kCGImagePropertyExifContrast = NSString.NSPinnedString("Contrast");

        public static readonly NSString kCGImagePropertyExifSaturation = NSString.NSPinnedString("Saturation");

        public static readonly NSString kCGImagePropertyExifSharpness = NSString.NSPinnedString("Sharpness");

        public static readonly NSString kCGImagePropertyExifDeviceSettingDescription = NSString.NSPinnedString("DeviceSettingDescription");

        public static readonly NSString kCGImagePropertyExifSubjectDistRange = NSString.NSPinnedString("SubjectDistRange");

        public static readonly NSString kCGImagePropertyExifImageUniqueID = NSString.NSPinnedString("ImageUniqueID");

        public static readonly NSString kCGImagePropertyExifGamma = NSString.NSPinnedString("Gamma");

        public static readonly NSString kCGImagePropertyGIFLoopCount = NSString.NSPinnedString("LoopCount");

        public static readonly NSString kCGImagePropertyGIFDelayTime = NSString.NSPinnedString("DelayTime");

        public static readonly NSString kCGImagePropertyGIFImageColorMap = NSString.NSPinnedString("ImageColorMap");

        public static readonly NSString kCGImagePropertyGIFHasGlobalColorMap = NSString.NSPinnedString("HasGlobalColorMap");

        public static readonly NSString kCGImagePropertyGPSVersion = NSString.NSPinnedString("GPSVersion");

        public static readonly NSString kCGImagePropertyGPSLatitudeRef = NSString.NSPinnedString("LatitudeRef");

        public static readonly NSString kCGImagePropertyGPSLatitude = NSString.NSPinnedString("Latitude");

        public static readonly NSString kCGImagePropertyGPSLongitudeRef = NSString.NSPinnedString("LongitudeRef");

        public static readonly NSString kCGImagePropertyGPSLongitude = NSString.NSPinnedString("Longitude");

        public static readonly NSString kCGImagePropertyGPSAltitudeRef = NSString.NSPinnedString("AltitudeRef");

        public static readonly NSString kCGImagePropertyGPSAltitude = NSString.NSPinnedString("Altitude");

        public static readonly NSString kCGImagePropertyGPSTimeStamp = NSString.NSPinnedString("TimeStamp");

        public static readonly NSString kCGImagePropertyGPSSatellites = NSString.NSPinnedString("Satellites");

        public static readonly NSString kCGImagePropertyGPSStatus = NSString.NSPinnedString("Status");

        public static readonly NSString kCGImagePropertyGPSMeasureMode = NSString.NSPinnedString("MeasureMode");

        public static readonly NSString kCGImagePropertyGPSDOP = NSString.NSPinnedString("DOP");

        public static readonly NSString kCGImagePropertyGPSSpeedRef = NSString.NSPinnedString("SpeedRef");

        public static readonly NSString kCGImagePropertyGPSSpeed = NSString.NSPinnedString("Speed");

        public static readonly NSString kCGImagePropertyGPSTrackRef = NSString.NSPinnedString("TrackRef");

        public static readonly NSString kCGImagePropertyGPSTrack = NSString.NSPinnedString("Track");

        public static readonly NSString kCGImagePropertyGPSImgDirectionRef = NSString.NSPinnedString("ImgDirectionRef");

        public static readonly NSString kCGImagePropertyGPSImgDirection = NSString.NSPinnedString("ImgDirection");

        public static readonly NSString kCGImagePropertyGPSMapDatum = NSString.NSPinnedString("MapDatum");

        public static readonly NSString kCGImagePropertyGPSDestLatitudeRef = NSString.NSPinnedString("DestLatitudeRef");

        public static readonly NSString kCGImagePropertyGPSDestLatitude = NSString.NSPinnedString("DestLatitude");

        public static readonly NSString kCGImagePropertyGPSDestLongitudeRef = NSString.NSPinnedString("DestLongitudeRef");

        public static readonly NSString kCGImagePropertyGPSDestLongitude = NSString.NSPinnedString("DestLongitude");

        public static readonly NSString kCGImagePropertyGPSDestBearingRef = NSString.NSPinnedString("DestBearingRef");

        public static readonly NSString kCGImagePropertyGPSDestBearing = NSString.NSPinnedString("DestBearing");

        public static readonly NSString kCGImagePropertyGPSDestDistanceRef = NSString.NSPinnedString("DestDistanceRef");

        public static readonly NSString kCGImagePropertyGPSDestDistance = NSString.NSPinnedString("DestDistance");

        public static readonly NSString kCGImagePropertyGPSProcessingMethod = NSString.NSPinnedString("ProcessingMethod");

        public static readonly NSString kCGImagePropertyGPSAreaInformation = NSString.NSPinnedString("AreaInformation");

        public static readonly NSString kCGImagePropertyGPSDateStamp = NSString.NSPinnedString("DateStamp");

        public static readonly NSString kCGImagePropertyGPSDifferental = NSString.NSPinnedString("Differential");

        public static readonly NSString kCGImagePropertyIPTCObjectTypeReference = NSString.NSPinnedString("ObjectTypeReference");

        public static readonly NSString kCGImagePropertyIPTCObjectAttributeReference = NSString.NSPinnedString("ObjectAttributeReference");

        public static readonly NSString kCGImagePropertyIPTCObjectName = NSString.NSPinnedString("ObjectName");

        public static readonly NSString kCGImagePropertyIPTCEditStatus = NSString.NSPinnedString("EditStatus");

        public static readonly NSString kCGImagePropertyIPTCEditorialUpdate = NSString.NSPinnedString("EditorialUpdate");

        public static readonly NSString kCGImagePropertyIPTCUrgency = NSString.NSPinnedString("Urgency");

        public static readonly NSString kCGImagePropertyIPTCSubjectReference = NSString.NSPinnedString("SubjectReference");

        public static readonly NSString kCGImagePropertyIPTCCategory = NSString.NSPinnedString("Category");

        public static readonly NSString kCGImagePropertyIPTCSupplementalCategory = NSString.NSPinnedString("SupplementalCategory");

        public static readonly NSString kCGImagePropertyIPTCFixtureIdentifier = NSString.NSPinnedString("FixtureIdentifier");

        public static readonly NSString kCGImagePropertyIPTCKeywords = NSString.NSPinnedString("Keywords");

        public static readonly NSString kCGImagePropertyIPTCContentLocationCode = NSString.NSPinnedString("ContentLocationCode");

        public static readonly NSString kCGImagePropertyIPTCContentLocationName = NSString.NSPinnedString("ContentLocationName");

        public static readonly NSString kCGImagePropertyIPTCReleaseDate = NSString.NSPinnedString("ReleaseDate");

        public static readonly NSString kCGImagePropertyIPTCReleaseTime = NSString.NSPinnedString("ReleaseTime");

        public static readonly NSString kCGImagePropertyIPTCExpirationDate = NSString.NSPinnedString("ExpirationDate");

        public static readonly NSString kCGImagePropertyIPTCExpirationTime = NSString.NSPinnedString("ExpirationTime");

        public static readonly NSString kCGImagePropertyIPTCSpecialInstructions = NSString.NSPinnedString("SpecialInstructions");

        public static readonly NSString kCGImagePropertyIPTCActionAdvised = NSString.NSPinnedString("ActionAdvised");

        public static readonly NSString kCGImagePropertyIPTCReferenceService = NSString.NSPinnedString("ReferenceService");

        public static readonly NSString kCGImagePropertyIPTCReferenceDate = NSString.NSPinnedString("ReferenceDate");

        public static readonly NSString kCGImagePropertyIPTCReferenceNumber = NSString.NSPinnedString("ReferenceNumber");

        public static readonly NSString kCGImagePropertyIPTCDateCreated = NSString.NSPinnedString("DateCreated");

        public static readonly NSString kCGImagePropertyIPTCTimeCreated = NSString.NSPinnedString("TimeCreated");

        public static readonly NSString kCGImagePropertyIPTCDigitalCreationDate = NSString.NSPinnedString("DigitalCreationDate");

        public static readonly NSString kCGImagePropertyIPTCDigitalCreationTime = NSString.NSPinnedString("DigitalCreationTime");

        public static readonly NSString kCGImagePropertyIPTCOriginatingProgram = NSString.NSPinnedString("OriginatingProgram");

        public static readonly NSString kCGImagePropertyIPTCProgramVersion = NSString.NSPinnedString("ProgramVersion");

        public static readonly NSString kCGImagePropertyIPTCObjectCycle = NSString.NSPinnedString("ObjectCycle");

        public static readonly NSString kCGImagePropertyIPTCByline = NSString.NSPinnedString("Byline");

        public static readonly NSString kCGImagePropertyIPTCBylineTitle = NSString.NSPinnedString("BylineTitle");

        public static readonly NSString kCGImagePropertyIPTCCity = NSString.NSPinnedString("City");

        public static readonly NSString kCGImagePropertyIPTCSubLocation = NSString.NSPinnedString("SubLocation");

        public static readonly NSString kCGImagePropertyIPTCProvinceState = NSString.NSPinnedString("Province/State");

        public static readonly NSString kCGImagePropertyIPTCCountryPrimaryLocationCode = NSString.NSPinnedString("Country/PrimaryLocationCode");

        public static readonly NSString kCGImagePropertyIPTCCountryPrimaryLocationName = NSString.NSPinnedString("Country/PrimaryLocationName");

        public static readonly NSString kCGImagePropertyIPTCOriginalTransmissionReference = NSString.NSPinnedString("OriginalTransmissionReference");

        public static readonly NSString kCGImagePropertyIPTCHeadline = NSString.NSPinnedString("Headline");

        public static readonly NSString kCGImagePropertyIPTCCredit = NSString.NSPinnedString("Credit");

        public static readonly NSString kCGImagePropertyIPTCSource = NSString.NSPinnedString("Source");

        public static readonly NSString kCGImagePropertyIPTCCopyrightNotice = NSString.NSPinnedString("CopyrightNotice");

        public static readonly NSString kCGImagePropertyIPTCContact = NSString.NSPinnedString("Contact");

        public static readonly NSString kCGImagePropertyIPTCCaptionAbstract = NSString.NSPinnedString("Caption/Abstract");

        public static readonly NSString kCGImagePropertyIPTCWriterEditor = NSString.NSPinnedString("Writer/Editor");

        public static readonly NSString kCGImagePropertyIPTCImageType = NSString.NSPinnedString("ImageType");

        public static readonly NSString kCGImagePropertyIPTCImageOrientation = NSString.NSPinnedString("ImageOrientation");

        public static readonly NSString kCGImagePropertyIPTCLanguageIdentifier = NSString.NSPinnedString("LanguageIdentifier");

        public static readonly NSString kCGImagePropertyIPTCStarRating = NSString.NSPinnedString("StarRating");

        public static readonly NSString kCGImagePropertyJFIFVersion = NSString.NSPinnedString("JFIFVersion");

        public static readonly NSString kCGImagePropertyJFIFXDensity = NSString.NSPinnedString("XDensity");

        public static readonly NSString kCGImagePropertyJFIFYDensity = NSString.NSPinnedString("YDensity");

        public static readonly NSString kCGImagePropertyJFIFDensityUnit = NSString.NSPinnedString("DensityUnit");

        public static readonly NSString kCGImagePropertyJFIFIsProgressive = NSString.NSPinnedString("IsProgressive");

        public static readonly NSString kCGImagePropertyPNGGamma = NSString.NSPinnedString("Gamma");

        public static readonly NSString kCGImagePropertyPNGInterlaceType = NSString.NSPinnedString("InterlaceType");

        public static readonly NSString kCGImagePropertyPNGXPixelsPerMeter = NSString.NSPinnedString("XPixelsPerMeter");

        public static readonly NSString kCGImagePropertyPNGYPixelsPerMeter = NSString.NSPinnedString("YPixelsPerMeter");

        public static readonly NSString kCGImagePropertyPNGsRGBIntent = NSString.NSPinnedString("sRGBIntent");

        public static readonly NSString kCGImagePropertyPNGChromaticities = NSString.NSPinnedString("Chromaticities");

        public static readonly NSString kCGImagePropertyTIFFCompression = NSString.NSPinnedString("Compression");

        public static readonly NSString kCGImagePropertyTIFFPhotometricInterpretation = NSString.NSPinnedString("PhotometricInterpretation");

        public static readonly NSString kCGImagePropertyTIFFDocumentName = NSString.NSPinnedString("DocumentName");

        public static readonly NSString kCGImagePropertyTIFFImageDescription = NSString.NSPinnedString("ImageDescription");

        public static readonly NSString kCGImagePropertyTIFFMake = NSString.NSPinnedString("Make");

        public static readonly NSString kCGImagePropertyTIFFModel = NSString.NSPinnedString("Model");

        public static readonly NSString kCGImagePropertyTIFFOrientation = NSString.NSPinnedString("Orientation");

        public static readonly NSString kCGImagePropertyTIFFXResolution = NSString.NSPinnedString("XResolution");

        public static readonly NSString kCGImagePropertyTIFFYResolution = NSString.NSPinnedString("YResolution");

        public static readonly NSString kCGImagePropertyTIFFResolutionUnit = NSString.NSPinnedString("ResolutionUnit");

        public static readonly NSString kCGImagePropertyTIFFSoftware = NSString.NSPinnedString("Software");

        public static readonly NSString kCGImagePropertyTIFFTransferFunction = NSString.NSPinnedString("TransferFunction");

        public static readonly NSString kCGImagePropertyTIFFDateTime = NSString.NSPinnedString("DateTime");

        public static readonly NSString kCGImagePropertyTIFFArtist = NSString.NSPinnedString("Artist");

        public static readonly NSString kCGImagePropertyTIFFHostComputer = NSString.NSPinnedString("HostComputer");

        public static readonly NSString kCGImagePropertyTIFFCopyright = NSString.NSPinnedString("Copyright");

        public static readonly NSString kCGImagePropertyTIFFWhitePoint = NSString.NSPinnedString("WhitePoint");

        public static readonly NSString kCGImagePropertyTIFFPrimaryChromaticities = NSString.NSPinnedString("PrimaryChromaticities");
    }
}
