//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
    public partial class CIFilter
    {
        public static NSArray FilterNamesInCategories(NSArray categories)
        {
            return ObjectiveCRuntime.SendMessage<NSArray>(CIFilterClass, "filterNamesInCategories:", categories);
        }

        public static NSArray FilterNamesInCategory(NSString category)
        {
            return ObjectiveCRuntime.SendMessage<NSArray>(CIFilterClass, "filterNamesInCategory:", category);
        }

#if MACOSX_10_5
        public static CIFilter FilterWithImageDataOptions(NSData data, NSDictionary options)
        {
            return ObjectiveCRuntime.SendMessage<CIFilter>(CIFilterClass, "filterWithImageData:options:", data, options);
        }
#endif

#if MACOSX_10_5
        public static CIFilter FilterWithImageURLOptions(NSURL url, NSDictionary options)
        {
            return ObjectiveCRuntime.SendMessage<CIFilter>(CIFilterClass, "filterWithImageURL:options:", url, options);
        }
#endif

        public static CIFilter FilterWithName(NSString name)
        {
            return ObjectiveCRuntime.SendMessage<CIFilter>(CIFilterClass, "filterWithName:", name);
        }

        public static CIFilter FilterWithNameKeysAndValues(NSString name, params Object[] values)
        {
            return ObjectiveCRuntime.SendMessageVarArgs<CIFilter>(CIFilterClass, "filterWithName:keysAndValues:", name, values);
        }

#if MACOSX_10_5
        public static NSString LocalizedDescriptionForFilterName(NSString filterName)
        {
            return ObjectiveCRuntime.SendMessage<NSString>(CIFilterClass, "localizedDescriptionForFilterName:", filterName);
        }
#endif

        public static NSString LocalizedNameForCategory(NSString category)
        {
            return ObjectiveCRuntime.SendMessage<NSString>(CIFilterClass, "localizedNameForCategory:", category);
        }

        public static NSString LocalizedNameForFilterName(NSString filterName)
        {
            return ObjectiveCRuntime.SendMessage<NSString>(CIFilterClass, "localizedNameForFilterName:", filterName);
        }

#if MACOSX_10_5
        public static NSURL LocalizedReferenceDocumentationForFilterName(NSString filterName)
        {
            return ObjectiveCRuntime.SendMessage<NSURL>(CIFilterClass, "localizedReferenceDocumentationForFilterName:", filterName);
        }
#endif

        public static void RegisterFilterNameConstructorClassAttributes(NSString name, Id anObject, NSDictionary attributes)
        {
            ObjectiveCRuntime.SendMessage(CIFilterClass, "registerFilterName:constructor:classAttributes:", name, anObject, attributes);
        }

        public virtual CIImage Apply(CIKernel k, params Object[] values)
        {
            return ObjectiveCRuntime.SendMessageVarArgs<CIImage>(this, "apply:", k, values);
        }

        public virtual CIImage ApplyArgumentsOptions(CIKernel k, NSArray args, NSDictionary dict)
        {
            return ObjectiveCRuntime.SendMessage<CIImage>(this, "apply:arguments:options:", k, args, dict);
        }

        public virtual void SetDefaults()
        {
            ObjectiveCRuntime.SendMessage(this, "setDefaults");
        }

        public virtual NSDictionary Attributes
        {
            get { return ObjectiveCRuntime.SendMessage<NSDictionary>(this, "attributes"); }
        }

        public virtual NSArray InputKeys
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "inputKeys"); }
        }

        public virtual NSArray OutputKeys
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "outputKeys"); }
        }
    }
}
