//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CALayer
    {
        public delegate ICAAction ActionForLayerForKeyEventHandler(CALayer layer, NSString key);

        public delegate void DisplayLayerEventHandler(CALayer layer);

        public delegate void DrawLayerInContextEventHandler(CALayer layer, IntPtr ctx);

        public void SetDelegate(Action<CALayerEventDispatcher> assignment)
        {
            CALayerEventDispatcher @delegate = this.Delegate.SafeCastAs<CALayerEventDispatcher>();
            if (@delegate != null)
            {
                @delegate.Release();
                this.Delegate = null;
            }

            if (assignment != null)
            {
                @delegate = new CALayerEventDispatcher();
                assignment(@delegate);
                this.Delegate = @delegate;
            }
        }

        [ObjectiveCClass]
        public class CALayerEventDispatcher : NSObject
        {
            public static readonly Class CALayerEventDispatcherClass = Class.GetClassFromType(typeof (CALayerEventDispatcher));

            public CALayerEventDispatcher() {}

            public CALayerEventDispatcher(IntPtr nativePointer)
                : base(nativePointer) {}

            [ObjectiveCMessage("respondsToSelector:")]
            public override bool RespondsToSelector(IntPtr aSelector)
            {
                String message = ObjectiveCRuntime.Selector(aSelector);
                switch (message)
                {
                    case "actionForLayer:forKey:":
                        return (this.ActionForLayerForKey != null);
                    case "displayLayer:":
                        return (this.DisplayLayer != null);
                    case "drawLayer:inContext:":
                        return (this.DrawLayerInContext != null);
                }
                return this.SendMessageSuper<bool>(CALayerEventDispatcherClass, "respondsToSelector:", aSelector);
            }

            public event ActionForLayerForKeyEventHandler ActionForLayerForKey;

            public event DisplayLayerEventHandler DisplayLayer;

            public event DrawLayerInContextEventHandler DrawLayerInContext;

            [ObjectiveCMessage("actionForLayer:forKey:")]
            public ICAAction ActionForLayerForKeyMessage(CALayer layer, NSString key)
            {
                ICAAction result = null;
                if (this.ActionForLayerForKey != null)
                {
                    result = this.ActionForLayerForKey(layer, key);
                }
                return result;
            }

            [ObjectiveCMessage("displayLayer:")]
            public void DisplayLayerMessage(CALayer layer)
            {
                if (this.DisplayLayer != null)
                {
                    this.DisplayLayer(layer);
                }
            }

            [ObjectiveCMessage("drawLayer:inContext:")]
            public void DrawLayerInContextMessage(CALayer layer, IntPtr ctx)
            {
                if (this.DrawLayerInContext != null)
                {
                    this.DrawLayerInContext(layer, ctx);
                }
            }

            [ObjectiveCMessage("dealloc", SynchronizeFields = false)]
            public void Dealloc()
            {
                if (this.ActionForLayerForKey != null)
                {
                    foreach (ActionForLayerForKeyEventHandler handler in this.ActionForLayerForKey.GetInvocationList())
                    {
                        this.ActionForLayerForKey -= handler;
                    }
                }
                if (this.DisplayLayer != null)
                {
                    foreach (DisplayLayerEventHandler handler in this.DisplayLayer.GetInvocationList())
                    {
                        this.DisplayLayer -= handler;
                    }
                }
                if (this.DrawLayerInContext != null)
                {
                    foreach (DrawLayerInContextEventHandler handler in this.DrawLayerInContext.GetInvocationList())
                    {
                        this.DrawLayerInContext -= handler;
                    }
                }

                this.SendMessageSuper(CALayerEventDispatcherClass, "dealloc");
            }
        }
    }
#endif
}
