//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;

namespace Monobjc.Cocoa
{
    [StructLayout(LayoutKind.Sequential)]
    public partial struct CGAffineTransform : IEquatable<CGAffineTransform>
    {
        public float a;

        public float b;

        public float c;

        public float d;

        public float tx;

        public float ty;

        public CGAffineTransform(float a, float b, float c, float d, float tx, float ty)
        {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.tx = tx;
            this.ty = ty;
        }

        public static bool operator !=(CGAffineTransform cgAffineTransform1, CGAffineTransform cgAffineTransform2)
        {
            return !cgAffineTransform1.Equals(cgAffineTransform2);
        }

        public static bool operator ==(CGAffineTransform cgAffineTransform1, CGAffineTransform cgAffineTransform2)
        {
            return cgAffineTransform1.Equals(cgAffineTransform2);
        }

        public bool Equals(CGAffineTransform cgAffineTransform)
        {
            if (this.a != cgAffineTransform.a)
            {
                return false;
            }
            if (this.b != cgAffineTransform.b)
            {
                return false;
            }
            if (this.c != cgAffineTransform.c)
            {
                return false;
            }
            if (this.d != cgAffineTransform.d)
            {
                return false;
            }
            if (this.tx != cgAffineTransform.tx)
            {
                return false;
            }
            if (this.ty != cgAffineTransform.ty)
            {
                return false;
            }
            return true;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is CGAffineTransform))
            {
                return false;
            }
            return Equals((CGAffineTransform) obj);
        }

        public override int GetHashCode()
        {
            int result = this.a.GetHashCode();
            result = 29*result + this.b.GetHashCode();
            result = 29*result + this.c.GetHashCode();
            result = 29*result + this.d.GetHashCode();
            result = 29*result + this.tx.GetHashCode();
            result = 29*result + this.ty.GetHashCode();
            return result;
        }
    }
}
