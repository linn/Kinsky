//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;
using CGColorRef = System.IntPtr;
using CGColorSpaceRef = System.IntPtr;
using CGPatternRef = System.IntPtr;
using CGFloat = System.Single;

namespace Monobjc.Cocoa
{
    public partial class CGColor
    {
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorCreate")]
        public static extern CGColorRef Create(CGColorSpaceRef colorspace, CGFloat[] components);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorCreateCopy")]
        public static extern CGColorRef CreateCopy(CGColorRef color);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorCreateCopyWithAlpha")]
        public static extern CGColorRef CreateCopyWithAlpha(CGColorRef color, CGFloat alpha);

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorCreateGenericCMYK")]
        public static extern CGColorRef CreateGenericCMYK(CGFloat cyan, CGFloat magenta, CGFloat yellow, CGFloat black, CGFloat alpha);
#endif

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorCreateGenericGray")]
        public static extern CGColorRef CreateGenericGray(CGFloat gray, CGFloat alpha);
#endif

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorCreateGenericRGB")]
        public static extern CGColorRef CreateGenericRGB(CGFloat red, CGFloat green, CGFloat blue, CGFloat alpha);
#endif

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorCreateWithPattern")]
        public static extern CGColorRef CreateWithPattern(CGColorSpaceRef colorspace, CGPatternRef pattern, CGFloat[] components);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorEqualToColor")]
        public static extern bool EqualToColor(CGColorRef color1, CGColorRef color2);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorGetAlpha")]
        public static extern CGFloat GetAlpha(CGColorRef color);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorGetColorSpace")]
        public static extern CGColorSpaceRef GetColorSpace(CGColorRef color);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices")]
        public static extern CGFloat[] CGColorGetComponents(CGColorRef color);

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorGetConstantColor")]
        public static extern CGColorRef GetConstantColor([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString colorName);
#endif

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorGetNumberOfComponents")]
        public static extern uint GetNumberOfComponents(CGColorRef color);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorGetPattern")]
        public static extern CGPatternRef GetPattern(CGColorRef color);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorGetTypeID")]
        public static extern uint GetTypeID();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorRelease")]
        public static extern void Release(CGColorRef color);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorRetain")]
        public static extern CGColorRef Retain(CGColorRef color);

        public static readonly NSString kCGColorWhite = NSString.NSPinnedString("kCGColorWhite");

        public static readonly NSString kCGColorBlack = NSString.NSPinnedString("kCGColorBlack");

        public static readonly NSString kCGColorClear = NSString.NSPinnedString("kCGColorClear");
    }
}
