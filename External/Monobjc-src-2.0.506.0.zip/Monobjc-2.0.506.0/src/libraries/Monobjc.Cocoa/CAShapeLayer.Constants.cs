//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
#if MACOSX_10_6
    partial class CAShapeLayer
    {
        public static readonly NSString kCAFillRuleNonZero = NSString.NSPinnedString("non-zero");

        public static readonly NSString kCAFillRuleEvenOdd = NSString.NSPinnedString("even-odd");

        public static readonly NSString kCALineJoinMiter = NSString.NSPinnedString("miter");

        public static readonly NSString kCALineJoinRound = NSString.NSPinnedString("round");

        public static readonly NSString kCALineJoinBevel = NSString.NSPinnedString("bevel");

        public static readonly NSString kCALineCapButt = NSString.NSPinnedString("butt");

        public static readonly NSString kCALineCapRound = NSString.NSPinnedString("round");

        public static readonly NSString kCALineCapSquare = NSString.NSPinnedString("square");
    }
#endif
}
