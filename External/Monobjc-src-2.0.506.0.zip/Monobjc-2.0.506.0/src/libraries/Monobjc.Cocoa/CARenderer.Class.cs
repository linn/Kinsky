//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CARenderer
    {
        public static CARenderer Bounds(IntPtr ctx, NSDictionary dict)
        {
            return ObjectiveCRuntime.SendMessage<CARenderer>(CARendererClass, "bounds", ctx, dict);
        }

        public static CARenderer Layer(IntPtr ctx, NSDictionary dict)
        {
            return ObjectiveCRuntime.SendMessage<CARenderer>(CARendererClass, "layer", ctx, dict);
        }

        public static CARenderer RendererWithCGLContextOptions(IntPtr ctx, NSDictionary dict)
        {
            return ObjectiveCRuntime.SendMessage<CARenderer>(CARendererClass, "rendererWithCGLContext:options:", ctx, dict);
        }

        public virtual void AddUpdateRect(CGRect aRect)
        {
            ObjectiveCRuntime.SendMessage(this, "addUpdateRect:", aRect);
        }

        public virtual void BeginFrameAtTimeTimeStamp(double timeInterval, CVTimeStamp timeStamp)
        {
            ObjectiveCRuntime.SendMessage(this, "beginFrameAtTime:timeStamp:", timeInterval, timeStamp);
        }

        public virtual void EndFrame()
        {
            ObjectiveCRuntime.SendMessage(this, "endFrame");
        }

        public virtual void Render()
        {
            ObjectiveCRuntime.SendMessage(this, "render");
        }

        public virtual double NextFrameTime
        {
            get { return ObjectiveCRuntime.SendMessage<double>(this, "nextFrameTime"); }
        }

        public virtual CGRect UpdateBounds
        {
            get { return ObjectiveCRuntime.SendMessage<CGRect>(this, "updateBounds"); }
        }
    }
#endif
}
