//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using CGColorRef = System.IntPtr;

namespace Monobjc.Cocoa
{
#if MACOSX_10_6
    partial class CAEmitterCell
    {
        public virtual float AlphaRange
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "alphaRange"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAlphaRange:", value); }
        }

        public virtual float AlphaSpeed
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "alphaSpeed"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAlphaSpeed:", value); }
        }

        public virtual float BirthRate
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "birthRate"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBirthRate:", value); }
        }

        public virtual float BlueRange
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "blueRange"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBlueRange:", value); }
        }

        public virtual float BlueSpeed
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "blueSpeed"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBlueSpeed:", value); }
        }

        public virtual CGColorRef Color
        {
            get { return ObjectiveCRuntime.SendMessage<CGColorRef>(this, "color"); }
            set { ObjectiveCRuntime.SendMessage(this, "setColor:", value); }
        }

        public virtual Id Contents
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "contents"); }
            set { ObjectiveCRuntime.SendMessage(this, "setContents:", value); }
        }

        public virtual CGRect ContentsRect
        {
            get { return ObjectiveCRuntime.SendMessage<CGRect>(this, "contentsRect"); }
            set { ObjectiveCRuntime.SendMessage(this, "setContentsRect:", value); }
        }

        public virtual float EmissionLatitude
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "emissionLatitude"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEmissionLatitude:", value); }
        }

        public virtual float EmissionLongitude
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "emissionLongitude"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEmissionLongitude:", value); }
        }

        public virtual float EmissionRange
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "emissionRange"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEmissionRange:", value); }
        }

        public virtual NSArray EmitterCells
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "emitterCells"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEmitterCells:", value); }
        }

        public virtual bool IsEnabled
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "isEnabled"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEnabled:", value); }
        }

        public virtual float GreenRange
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "greenRange"); }
            set { ObjectiveCRuntime.SendMessage(this, "setGreenRange:", value); }
        }

        public virtual float GreenSpeed
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "greenSpeed"); }
            set { ObjectiveCRuntime.SendMessage(this, "setGreenSpeed:", value); }
        }

        public virtual float Lifetime
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "lifetime"); }
            set { ObjectiveCRuntime.SendMessage(this, "setLifetime:", value); }
        }

        public virtual float LifetimeRange
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "lifetimeRange"); }
            set { ObjectiveCRuntime.SendMessage(this, "setLifetimeRange:", value); }
        }

        public virtual NSString MagnificationFilter
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "magnificationFilter"); }
            set { ObjectiveCRuntime.SendMessage(this, "setMagnificationFilter:", value); }
        }

        public virtual NSString MinificationFilter
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "minificationFilter"); }
            set { ObjectiveCRuntime.SendMessage(this, "setMinificationFilter:", value); }
        }

        public virtual float MinificationFilterBias
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "minificationFilterBias"); }
            set { ObjectiveCRuntime.SendMessage(this, "setMinificationFilterBias:", value); }
        }

        public virtual NSString Name
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "name"); }
            set { ObjectiveCRuntime.SendMessage(this, "setName:", value); }
        }

        public virtual float RedRange
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "redRange"); }
            set { ObjectiveCRuntime.SendMessage(this, "setRedRange:", value); }
        }

        public virtual float RedSpeed
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "redSpeed"); }
            set { ObjectiveCRuntime.SendMessage(this, "setRedSpeed:", value); }
        }

        public virtual float Scale
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "scale"); }
            set { ObjectiveCRuntime.SendMessage(this, "setScale:", value); }
        }

        public virtual float ScaleRange
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "scaleRange"); }
            set { ObjectiveCRuntime.SendMessage(this, "setScaleRange:", value); }
        }

        public virtual float ScaleSpeed
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "scaleSpeed"); }
            set { ObjectiveCRuntime.SendMessage(this, "setScaleSpeed:", value); }
        }

        public virtual float Spin
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "spin"); }
            set { ObjectiveCRuntime.SendMessage(this, "setSpin:", value); }
        }

        public virtual float SpinRange
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "spinRange"); }
            set { ObjectiveCRuntime.SendMessage(this, "setSpinRange:", value); }
        }

        public virtual NSDictionary Style
        {
            get { return ObjectiveCRuntime.SendMessage<NSDictionary>(this, "style"); }
            set { ObjectiveCRuntime.SendMessage(this, "setStyle:", value); }
        }

        public virtual float Velocity
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "velocity"); }
            set { ObjectiveCRuntime.SendMessage(this, "setVelocity:", value); }
        }

        public virtual float VelocityRange
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "velocityRange"); }
            set { ObjectiveCRuntime.SendMessage(this, "setVelocityRange:", value); }
        }

        public virtual float XAcceleration
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "xAcceleration"); }
            set { ObjectiveCRuntime.SendMessage(this, "setXAcceleration:", value); }
        }

        public virtual float YAcceleration
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "yAcceleration"); }
            set { ObjectiveCRuntime.SendMessage(this, "setYAcceleration:", value); }
        }

        public virtual float ZAcceleration
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "zAcceleration"); }
            set { ObjectiveCRuntime.SendMessage(this, "setZAcceleration:", value); }
        }

        public static Id EmitterCell
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(CAEmitterCellClass, "emitterCell"); }
        }

        public static Id DefaultValueForKey(NSString key)
        {
            return ObjectiveCRuntime.SendMessage<Id>(CAEmitterCellClass, "defaultValueForKey:", key);
        }

        public bool ShouldArchiveValueForKey(NSString key)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "shouldArchiveValueForKey:", key);
        }
    }
#endif   
}
