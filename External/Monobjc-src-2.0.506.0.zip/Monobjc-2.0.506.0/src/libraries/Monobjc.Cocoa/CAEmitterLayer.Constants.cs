//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
#if MACOSX_10_6
    partial class CAEmitterLayer
    {
        public static readonly NSString kCAEmitterLayerCircle = NSString.NSPinnedString("circle");

        public static readonly NSString kCAEmitterLayerCuboid = NSString.NSPinnedString("cuboid");

        public static readonly NSString kCAEmitterLayerLine = NSString.NSPinnedString("line");

        public static readonly NSString kCAEmitterLayerPoint = NSString.NSPinnedString("point");

        public static readonly NSString kCAEmitterLayerRectangle = NSString.NSPinnedString("rectangle");

        public static readonly NSString kCAEmitterLayerSphere = NSString.NSPinnedString("sphere");

        public static readonly NSString kCAEmitterLayerPoints = NSString.NSPinnedString("points");

        public static readonly NSString kCAEmitterLayerOutline = NSString.NSPinnedString("outline");

        public static readonly NSString kCAEmitterLayerSurface = NSString.NSPinnedString("surface");

        public static readonly NSString kCAEmitterLayerVolume = NSString.NSPinnedString("volume");

        public static readonly NSString kCAEmitterLayerUnordered = NSString.NSPinnedString("unordered");

        public static readonly NSString kCAEmitterLayerOldestFirst = NSString.NSPinnedString("oldestFirst");

        public static readonly NSString kCAEmitterLayerOldestLast = NSString.NSPinnedString("oldestLast");

        public static readonly NSString kCAEmitterLayerBackToFront = NSString.NSPinnedString("backToFront");

        public static readonly NSString kCAEmitterLayerAdditive = NSString.NSPinnedString("additive");
    }
#endif
}
