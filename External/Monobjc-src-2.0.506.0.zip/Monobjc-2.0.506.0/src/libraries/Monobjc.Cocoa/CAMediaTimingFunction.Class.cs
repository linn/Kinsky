//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;

namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CAMediaTimingFunction
    {
        public static CAMediaTimingFunction FunctionWithControlPoints(float c1x, float c1y, float c2x, float c2y)
        {
            return ObjectiveCRuntime.SendMessage<CAMediaTimingFunction>(CAMediaTimingFunctionClass, "functionWithControlPoints::::", c1x, c1y, c2x, c2y);
        }

        public static CAMediaTimingFunction FunctionWithName(NSString name)
        {
            return ObjectiveCRuntime.SendMessage<CAMediaTimingFunction>(CAMediaTimingFunctionClass, "functionWithName:", name);
        }

        public virtual void GetControlPointAtIndexValues(uint index, [In, Out] float[] ptr)
        {
            ObjectiveCRuntime.SendMessage(this, "getControlPointAtIndex:values:", index, ptr);
        }

        public virtual Id InitWithControlPoints(float c1x, float c1y, float c2x, float c2y)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithControlPoints::::", c1x, c1y, c2x, c2y);
        }
    }
#endif
}
