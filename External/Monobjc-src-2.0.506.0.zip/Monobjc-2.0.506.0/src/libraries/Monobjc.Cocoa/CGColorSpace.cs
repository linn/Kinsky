//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;
using CGColorSpaceRef = System.IntPtr;
using CGDataProviderRef = System.IntPtr;
using CGFloat = System.Single;

namespace Monobjc.Cocoa
{
    public class CGColorSpace
    {
#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGColorSpaceCopyICCProfile")]
        [return : MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSData>))]
        public static extern NSData CopyICCProfile(CGColorSpaceRef space);
#endif

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceCreateCalibratedGray")]
        public static extern CGColorSpaceRef CreateCalibratedGray(CGFloat[] whitePoint, CGFloat[] blackPoint, CGFloat gamma);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceCreateCalibratedRGB")]
        public static extern CGColorSpaceRef CreateCalibratedRGB(CGFloat[] whitePoint, CGFloat[] blackPoint, CGFloat[] gamma, CGFloat[] matrix);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceCreateDeviceCMYK")]
        public static extern CGColorSpaceRef CreateDeviceCMYK();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceCreateDeviceGray")]
        public static extern CGColorSpaceRef CreateDeviceGray();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceCreateDeviceRGB")]
        public static extern CGColorSpaceRef CreateDeviceRGB();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceCreateICCBased")]
        public static extern CGColorSpaceRef CreateICCBased(uint nComponents, CGFloat[] range, CGDataProviderRef profile, CGColorSpaceRef alternate);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceCreateIndexed")]
        public static extern CGColorSpaceRef CreateIndexed(CGColorSpaceRef baseSpace, uint lastIndex, CGColorSpaceRef colorTable);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceCreateLab")]
        public static extern CGColorSpaceRef CreateLab(CGFloat[] whitePoint, CGFloat[] blackPoint, CGFloat[] range);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceCreatePattern")]
        public static extern CGColorSpaceRef CreatePattern(CGColorSpaceRef baseSpace);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceCreateWithName")]
        public static extern CGColorSpaceRef CreateWithName([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSString>))] NSString name);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceCreateWithPlatformColorSpace")]
        public static extern CGColorSpaceRef CreateWithPlatformColorSpace(CGColorSpaceRef platformColorSpaceReference);

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceGetBaseColorSpace")]
        public static extern CGColorSpaceRef GetBaseColorSpace(CGColorSpaceRef space);
#endif

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceGetColorTable")]
        public static extern void GetColorTable(CGColorSpaceRef space, CGColorSpaceRef table);
#endif

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceGetColorTableCount")]
        public static extern uint GetColorTableCount(CGColorSpaceRef space);
#endif

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceGetModel")]
        public static extern CGColorSpaceModel GetModel(CGColorSpaceRef space);
#endif

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceGetNumberOfComponents")]
        public static extern uint GetNumberOfComponents(CGColorSpaceRef cs);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceGetTypeID")]
        public static extern uint GetTypeID();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceRelease")]
        public static extern void Release(CGColorSpaceRef cs);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGColorSpaceRetain")]
        public static extern CGColorSpaceRef Retain(CGColorSpaceRef cs);

        public static readonly NSString kCGColorSpaceGenericGray = NSString.NSPinnedString("kCGColorSpaceGenericGray");

        public static readonly NSString kCGColorSpaceGenericRGB = NSString.NSPinnedString("kCGColorSpaceGenericRGB");

        public static readonly NSString kCGColorSpaceGenericCMYK = NSString.NSPinnedString("kCGColorSpaceGenericCMYK");

#if MACOSX_10_5
        public static readonly NSString kCGColorSpaceGenericRGBLinear = NSString.NSPinnedString("kCGColorSpaceGenericRGBLinear");
#endif

#if MACOSX_10_5
        public static readonly NSString kCGColorSpaceAdobeRGB1998 = NSString.NSPinnedString("kCGColorSpaceAdobeRGB1998");
#endif

#if MACOSX_10_5
        public static readonly NSString kCGColorSpaceSRGB = NSString.NSPinnedString("kCGColorSpaceSRGB");
#endif
    }
}
