//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
    public partial struct CGSize
    {
        public static readonly CGSize CGSizeZero = new CGSize();

        public static int CGSizeEqualToSize(CGSize size1, CGSize size2)
        {
            return Equals(size1, size2) ? 1 : 0;
        }

        public static CGSize CGSizeMake(float width, float height)
        {
            return new CGSize(width, height);
        }
    }
}
