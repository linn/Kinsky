//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CALayer
    {
        public virtual NSDictionary Actions
        {
            get { return ObjectiveCRuntime.SendMessage<NSDictionary>(this, "actions"); }
            set { ObjectiveCRuntime.SendMessage(this, "setActions:", value); }
        }

#if MACOSX_10_6
        public virtual float AnchorPointZ
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "anchorPointZ"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAnchorPointZ:", value); }
        }
#endif

        public virtual CGPoint AnchorPoint
        {
            get { return ObjectiveCRuntime.SendMessage<CGPoint>(this, "anchorPoint"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAnchorPoint:", value); }
        }

        public virtual CAAutoresizingMask AutoresizingMask
        {
            get { return ObjectiveCRuntime.SendMessage<CAAutoresizingMask>(this, "autoresizingMask"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAutoresizingMask:", value); }
        }

        public virtual IntPtr BackgroundColor
        {
            get { return ObjectiveCRuntime.SendMessage<IntPtr>(this, "backgroundColor"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBackgroundColor:", value); }
        }

        public virtual NSArray BackgroundFilters
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "backgroundFilters"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBackgroundFilters:", value); }
        }

        public virtual IntPtr BorderColor
        {
            get { return ObjectiveCRuntime.SendMessage<IntPtr>(this, "borderColor"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBorderColor:", value); }
        }

        public virtual float BorderWidth
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "borderWidth"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBorderWidth:", value); }
        }

        public virtual CGRect Bounds
        {
            get { return ObjectiveCRuntime.SendMessage<CGRect>(this, "bounds"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBounds:", value); }
        }

        public virtual CIFilter CompositingFilter
        {
            get { return ObjectiveCRuntime.SendMessage<CIFilter>(this, "compositingFilter"); }
            set { ObjectiveCRuntime.SendMessage(this, "setCompositingFilter:", value); }
        }

        public virtual NSArray Constraints
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "constraints"); }
            set { ObjectiveCRuntime.SendMessage(this, "setConstraints:", value); }
        }

        public virtual Id Contents
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "contents"); }
            set { ObjectiveCRuntime.SendMessage(this, "setContents:", value); }
        }

#if MACOSX_10_6
        public virtual CGRect ContentsCenter
        {
            get { return ObjectiveCRuntime.SendMessage<CGRect>(this, "contentsCenter"); }
            set { ObjectiveCRuntime.SendMessage(this, "setContentsCenter:", value); }
        }
#endif
    
        public virtual NSString ContentsGravity
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "contentsGravity"); }
            set { ObjectiveCRuntime.SendMessage(this, "setContentsGravity:", value); }
        }

        public virtual CGRect ContentsRect
        {
            get { return ObjectiveCRuntime.SendMessage<CGRect>(this, "contentsRect"); }
            set { ObjectiveCRuntime.SendMessage(this, "setContentsRect:", value); }
        }

        public virtual float CornerRadius
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "cornerRadius"); }
            set { ObjectiveCRuntime.SendMessage(this, "setCornerRadius:", value); }
        }

        public virtual Id Delegate
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "delegate"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDelegate:", value); }
        }

        public virtual bool DoubleSided
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "doubleSided"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDoubleSided:", value); }
        }

        public virtual CAEdgeAntialiasingMask EdgeAntialiasingMask
        {
            get { return ObjectiveCRuntime.SendMessage<CAEdgeAntialiasingMask>(this, "edgeAntialiasingMask"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEdgeAntialiasingMask:", value); }
        }

        public virtual NSArray Filters
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "filters"); }
            set { ObjectiveCRuntime.SendMessage(this, "setFilters:", value); }
        }

        public virtual CGRect Frame
        {
            get { return ObjectiveCRuntime.SendMessage<CGRect>(this, "frame"); }
            set { ObjectiveCRuntime.SendMessage(this, "setFrame:", value); }
        }

#if MACOSX_10_6
        public virtual bool GeometryFlipped
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "isGeometryFlipped"); }
            set { ObjectiveCRuntime.SendMessage(this, "setGeometryFlipped:", value); }
        }
#endif

        public virtual bool Hidden
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "hidden"); }
            set { ObjectiveCRuntime.SendMessage(this, "setHidden:", value); }
        }

        public virtual Id LayoutManager
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "layoutManager"); }
            set { ObjectiveCRuntime.SendMessage(this, "setLayoutManager:", value); }
        }

        public virtual NSString MagnificationFilter
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "magnificationFilter"); }
            set { ObjectiveCRuntime.SendMessage(this, "setMagnificationFilter:", value); }
        }

        public virtual CALayer Mask
        {
            get { return ObjectiveCRuntime.SendMessage<CALayer>(this, "mask"); }
            set { ObjectiveCRuntime.SendMessage(this, "setMask:", value); }
        }

        public virtual bool MasksToBounds
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "masksToBounds"); }
            set { ObjectiveCRuntime.SendMessage(this, "setMasksToBounds:", value); }
        }

        public virtual NSString MinificationFilter
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "minificationFilter"); }
            set { ObjectiveCRuntime.SendMessage(this, "setMinificationFilter:", value); }
        }

#if MACOSX_10_6
        public virtual float MinificationFilterBias
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "minificationFilterBias"); }
            set { ObjectiveCRuntime.SendMessage(this, "setMinificationFilterBias:", value); }
        }
#endif

        public virtual NSString Name
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "name"); }
            set { ObjectiveCRuntime.SendMessage(this, "setName:", value); }
        }

        public virtual bool NeedsDisplayOnBoundsChange
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "needsDisplayOnBoundsChange"); }
            set { ObjectiveCRuntime.SendMessage(this, "setNeedsDisplayOnBoundsChange:", value); }
        }

        public virtual float Opacity
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "opacity"); }
            set { ObjectiveCRuntime.SendMessage(this, "setOpacity:", value); }
        }

        public virtual bool Opaque
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "opaque"); }
            set { ObjectiveCRuntime.SendMessage(this, "setOpaque:", value); }
        }

        public virtual CGPoint Position
        {
            get { return ObjectiveCRuntime.SendMessage<CGPoint>(this, "position"); }
            set { ObjectiveCRuntime.SendMessage(this, "setPosition:", value); }
        }

        public virtual IntPtr ShadowColor
        {
            get { return ObjectiveCRuntime.SendMessage<IntPtr>(this, "shadowColor"); }
            set { ObjectiveCRuntime.SendMessage(this, "setShadowColor:", value); }
        }

        public virtual CGSize ShadowOffset
        {
            get { return ObjectiveCRuntime.SendMessage<CGSize>(this, "shadowOffset"); }
            set { ObjectiveCRuntime.SendMessage(this, "setShadowOffset:", value); }
        }

        public virtual float ShadowOpacity
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "shadowOpacity"); }
            set { ObjectiveCRuntime.SendMessage(this, "setShadowOpacity:", value); }
        }

        public virtual float ShadowRadius
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "shadowRadius"); }
            set { ObjectiveCRuntime.SendMessage(this, "setShadowRadius:", value); }
        }

        public virtual NSDictionary Style
        {
            get { return ObjectiveCRuntime.SendMessage<NSDictionary>(this, "style"); }
            set { ObjectiveCRuntime.SendMessage(this, "setStyle:", value); }
        }

        public virtual NSArray Sublayers
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "sublayers"); }
            set { ObjectiveCRuntime.SendMessage(this, "setSublayerTransform:", value); }
        }

        public virtual CATransform3D SublayerTransform
        {
            get { return ObjectiveCRuntime.SendMessage<CATransform3D>(CALayerClass, "sublayerTransform"); }
            set { ObjectiveCRuntime.SendMessage(this, "setSublayerTransform:", value); }
        }

        public virtual CALayer Superlayer
        {
            get { return ObjectiveCRuntime.SendMessage<CALayer>(CALayerClass, "superlayer"); }
        }

        public virtual CATransform3D Transform
        {
            get { return ObjectiveCRuntime.SendMessage<CATransform3D>(CALayerClass, "transform"); }
            set { ObjectiveCRuntime.SendMessage(this, "setTransform:", value); }
        }

        public virtual CGRect VisibleRect
        {
            get { return ObjectiveCRuntime.SendMessage<CGRect>(CALayerClass, "visibleRect"); }
        }

        public virtual float ZPosition
        {
            get { return ObjectiveCRuntime.SendMessage<float>(CALayerClass, "zPosition"); }
            set { ObjectiveCRuntime.SendMessage(this, "setZPosition:", value); }
        }

        public static ICAAction DefaultActionForKey(NSString aKey)
        {
            return ObjectiveCRuntime.SendMessage<ICAAction>(CALayerClass, "defaultActionForKey:", aKey);
        }

        public static Id DefaultValueForKey(NSString key)
        {
            return ObjectiveCRuntime.SendMessage<Id>(CALayerClass, "defaultValueForKey:", key);
        }

#if MACOSX_10_6
        public virtual bool NeedsDisplay
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "needsDisplay"); }
        }
#endif

#if MACOSX_10_6
        public static Id NeedsDisplayForKey(NSString key)
        {
            return ObjectiveCRuntime.SendMessage<Id>(CALayerClass, "needsDisplayForKey:", key);
        }
#endif

#if MACOSX_10_6
        public virtual bool NeedsLayout
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "needsLayout"); }
        }
#endif

        public virtual ICAAction ActionForKey(NSString aKey)
        {
            return ObjectiveCRuntime.SendMessage<ICAAction>(this, "actionForKey:", aKey);
        }

        public virtual void AddAnimationForKey(CAAnimation anim, NSString key)
        {
            ObjectiveCRuntime.SendMessage(this, "addAnimation:forKey:", anim, key);
        }

        public virtual void AddConstraint(CAConstraint aConstraint)
        {
            ObjectiveCRuntime.SendMessage(this, "addConstraint:", aConstraint);
        }

        public virtual void AddSublayer(CALayer aLayer)
        {
            ObjectiveCRuntime.SendMessage(this, "addSublayer:", aLayer);
        }

        public virtual CAAnimation AnimationForKey(NSString key)
        {
            return ObjectiveCRuntime.SendMessage<CAAnimation>(this, "animationForKey:", key);
        }

#if MACOSX_10_6
        public virtual NSArray AnimationKeys
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "animationKeys"); }
        }
#endif

        public virtual bool ContainsPoint(CGPoint thePoint)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "containsPoint:", thePoint);
        }

#if MACOSX_10_6
        public virtual bool ContentsAreFlipped
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "contentsAreFlipped"); }
        }
#endif

        public virtual CGPoint ConvertPointFromLayer(CGPoint aPoint, CALayer layer)
        {
            return ObjectiveCRuntime.SendMessage<CGPoint>(this, "convertPoint:fromLayer:", aPoint, layer);
        }

        public virtual CGPoint ConvertPointToLayer(CGPoint aPoint, CALayer layer)
        {
            return ObjectiveCRuntime.SendMessage<CGPoint>(this, "convertPoint:toLayer:", aPoint, layer);
        }

        public virtual CGRect ConvertRectFromLayer(CGRect aRect, CALayer layer)
        {
            return ObjectiveCRuntime.SendMessage<CGRect>(this, "convertRect:fromLayer:", aRect, layer);
        }

        public virtual CGRect ConvertRectToLayer(CGRect aRect, CALayer layer)
        {
            return ObjectiveCRuntime.SendMessage<CGRect>(this, "convertRect:toLayer:", aRect, layer);
        }

        public virtual double ConvertTimeFromLayer(double timeInterval, CALayer layer)
        {
            return ObjectiveCRuntime.SendMessage<double>(this, "convertTime:fromLayer:", timeInterval, layer);
        }

        public virtual double ConvertTimeToLayer(double timeInterval, CALayer layer)
        {
            return ObjectiveCRuntime.SendMessage<double>(this, "convertTime:toLayer:", timeInterval, layer);
        }

        public virtual void Display()
        {
            ObjectiveCRuntime.SendMessage(this, "display");
        }

#if MACOSX_10_6
        public virtual void DisplayIfNeeded()
        {
            ObjectiveCRuntime.SendMessage(this, "displayIfNeeded");
        }
#endif

        public virtual void DrawInContext(IntPtr ctx)
        {
            ObjectiveCRuntime.SendMessage(this, "drawInContext:", ctx);
        }

        public virtual CALayer HitTest(CGPoint thePoint)
        {
            return ObjectiveCRuntime.SendMessage<CALayer>(this, "hitTest:", thePoint);
        }

        public virtual Id InitWithLayer(Id layer)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithLayer:", layer);
        }

        public virtual void InsertSublayerAbove(CALayer aLayer, CALayer siblingLayer)
        {
            ObjectiveCRuntime.SendMessage(this, "insertSublayer:above:", aLayer, siblingLayer);
        }

        public virtual void InsertSublayerAtIndex(CALayer aLayer, uint index)
        {
            ObjectiveCRuntime.SendMessage(this, "insertSublayer:atIndex:", aLayer, index);
        }

        public virtual void InsertSublayerBelow(CALayer aLayer, CALayer sublayer)
        {
            ObjectiveCRuntime.SendMessage(this, "insertSublayer:below:", aLayer, sublayer);
        }

        public virtual void LayoutIfNeeded()
        {
            ObjectiveCRuntime.SendMessage(this, "layoutIfNeeded");
        }

        public virtual void LayoutSublayers()
        {
            ObjectiveCRuntime.SendMessage(this, "layoutSublayers");
        }

        public virtual void RemoveAllAnimations()
        {
            ObjectiveCRuntime.SendMessage(this, "removeAllAnimations");
        }

        public virtual void RemoveAnimationForKey(NSString key)
        {
            ObjectiveCRuntime.SendMessage(this, "removeAnimationForKey:", key);
        }

        public virtual void RemoveFromSuperlayer()
        {
            ObjectiveCRuntime.SendMessage(this, "removeFromSuperlayer");
        }

        public virtual void RenderInContext(IntPtr ctx)
        {
            ObjectiveCRuntime.SendMessage(this, "renderInContext:", ctx);
        }

        public virtual void ReplaceSublayerWith(CALayer oldLayer, CALayer newLayer)
        {
            ObjectiveCRuntime.SendMessage(this, "replaceSublayer:with:", oldLayer, newLayer);
        }

        public virtual void ResizeSublayersWithOldSize(CGSize size)
        {
            ObjectiveCRuntime.SendMessage(this, "resizeSublayersWithOldSize:", size);
        }

        public virtual void ResizeWithOldSuperlayerSize(CGSize size)
        {
            ObjectiveCRuntime.SendMessage(this, "resizeWithOldSuperlayerSize:", size);
        }

        public virtual void ScrollPoint(CGPoint thePoint)
        {
            ObjectiveCRuntime.SendMessage(this, "scrollPoint:", thePoint);
        }

        public virtual void ScrollRectToVisible(CGRect theRect)
        {
            ObjectiveCRuntime.SendMessage(this, "scrollRectToVisible:", theRect);
        }

        public virtual void SetNeedsDisplay()
        {
            ObjectiveCRuntime.SendMessage(this, "setNeedsDisplay");
        }

        public virtual void SetNeedsDisplayInRect(CGRect theRect)
        {
            ObjectiveCRuntime.SendMessage(this, "setNeedsDisplayInRect:", theRect);
        }

        public virtual void SetNeedsLayout()
        {
            ObjectiveCRuntime.SendMessage(this, "setNeedsLayout");
        }

        public virtual bool ShouldArchiveValueForKey(NSString key)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "shouldArchiveValueForKey:", key);
        }

        public static CALayer Layer
        {
            get { return ObjectiveCRuntime.SendMessage<CALayer>(CALayerClass, "layer"); }
        }

        public virtual CGAffineTransform AffineTransform
        {
            get { return ObjectiveCRuntime.SendMessage<CGAffineTransform>(this, "affineTransform"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAffineTransform:", value); }
        }

        public virtual bool IsDoubleSided
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "isDoubleSided"); }
        }

        public virtual bool IsHidden
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "isHidden"); }
        }

        public virtual bool IsOpaque
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "isOpaque"); }
        }

        public virtual Id ModelLayer
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "modelLayer"); }
        }

        public virtual CGSize PreferredFrameSize
        {
            get { return ObjectiveCRuntime.SendMessage<CGSize>(this, "preferredFrameSize"); }
        }

        public virtual Id PresentationLayer
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "presentationLayer"); }
        }
    }
#endif
}
