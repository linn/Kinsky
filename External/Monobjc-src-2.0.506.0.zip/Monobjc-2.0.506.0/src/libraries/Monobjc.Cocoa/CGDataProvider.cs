﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;
using CGDataProviderRef=System.IntPtr;

namespace Monobjc.Cocoa
{
    public class CGDataProvider
    {
#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataProviderCreateDirect")]
        public static extern CGDataProviderRef CreateDirect(CGDataProviderRef info, uint size, ref CGDataProviderDirectCallbacks callbacks);
#endif

#if MACOSX_10_5
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataProviderCreateSequential")]
        public static extern CGDataProviderRef CreateSequential(CGDataProviderRef info, ref CGDataProviderSequentialCallbacks callbacks);
#endif

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataProviderCreateWithCFData")]
        public static extern CGDataProviderRef CreateWithCFData([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSData>))] NSData data);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataProviderCreateWithData")]
        public static extern CGDataProviderRef CreateWithData(CGDataProviderRef info, CGDataProviderRef data, uint size, CGDataProviderReleaseDataCallback releaseData);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataProviderCreateWithURL")]
        public static extern CGDataProviderRef CreateWithURL([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSURL>))] NSURL url);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataProviderGetTypeID")]
        public static extern uint GetTypeID();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataProviderRelease")]
        public static extern void Release(CGDataProviderRef provider);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataProviderRetain")]
        public static extern CGDataProviderRef Retain(CGDataProviderRef provider);
    }
}
