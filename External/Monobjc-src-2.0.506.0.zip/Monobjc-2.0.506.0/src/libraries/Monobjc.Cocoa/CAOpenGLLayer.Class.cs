﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CAOpenGLLayer
    {
        public virtual bool Asynchronous(IntPtr glContext, IntPtr pixelFormat, double timeInterval, CVTimeStamp timeStamp)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "asynchronous", glContext, pixelFormat, timeInterval, timeStamp);
        }

        public virtual bool CanDrawInCGLContextPixelFormatForLayerTimeDisplayTime(IntPtr glContext, IntPtr pixelFormat, double timeInterval, CVTimeStamp timeStamp)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "canDrawInCGLContext:pixelFormat:forLayerTime:displayTime:", glContext, pixelFormat, timeInterval, timeStamp);
        }

        public virtual IntPtr CopyCGLContextForPixelFormat(IntPtr pixelFormat)
        {
            return ObjectiveCRuntime.SendMessage<IntPtr>(this, "copyCGLContextForPixelFormat:", pixelFormat);
        }

        public virtual IntPtr CopyCGLPixelFormatForDisplayMask(uint mask)
        {
            return ObjectiveCRuntime.SendMessage<IntPtr>(this, "copyCGLPixelFormatForDisplayMask:", mask);
        }

        public virtual void DrawInCGLContextPixelFormatForLayerTimeDisplayTime(IntPtr glContext, IntPtr pixelFormat, double timeInterval, CVTimeStamp timeStamp)
        {
            ObjectiveCRuntime.SendMessage(this, "drawInCGLContext:pixelFormat:forLayerTime:displayTime:", glContext, pixelFormat, timeInterval, timeStamp);
        }

        public virtual void ReleaseCGLContext(IntPtr glContext)
        {
            ObjectiveCRuntime.SendMessage(this, "releaseCGLContext:", glContext);
        }

        public virtual void ReleaseCGLPixelFormat(IntPtr pixelFormat)
        {
            ObjectiveCRuntime.SendMessage(this, "releaseCGLPixelFormat:", pixelFormat);
        }

        public virtual bool IsAsynchronous
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "isAsynchronous"); }
        }
    }
#endif
}
