﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;
using CGDataConsumerRef=System.IntPtr;

namespace Monobjc.Cocoa
{
    public class CGDataConsumer
    {
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataConsumerCreate")]
        public static extern CGDataConsumerRef Create(CGDataConsumerRef info, ref CGDataConsumerCallbacks callbacks);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataConsumerCreateWithCFData")]
        public static extern CGDataConsumerRef CreateWithCFData([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSMutableData>))] NSMutableData data);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataConsumerCreateWithURL")]
        public static extern CGDataConsumerRef CreateWithURL([MarshalAs(UnmanagedType.CustomMarshaler, MarshalTypeRef = typeof (IdMarshaler<NSURL>))] NSURL url);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataConsumerGetTypeID")]
        public static extern uint GetTypeID();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataConsumerRelease")]
        public static extern void Release(CGDataConsumerRef consumer);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGDataConsumerRetain")]
        public static extern CGDataConsumerRef Retain(CGDataConsumerRef consumer);
    }
}
