//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
#if MACOSX_10_6
    partial class CAEmitterLayer
    {
        public virtual float BirthRate
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "birthRate"); }
            set { ObjectiveCRuntime.SendMessage(this, "setBirthRate:", value); }
        }

        public virtual NSArray EmitterCells
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "emitterCells"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEmitterCells:", value); }
        }

        public virtual float EmitterDepth
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "emitterDepth"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEmitterDepth:", value); }
        }

        public virtual NSString EmitterMode
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "emitterMode"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEmitterMode:", value); }
        }

        public virtual CGPoint EmitterPosition
        {
            get { return ObjectiveCRuntime.SendMessage<CGPoint>(this, "emitterPosition"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEmitterPosition:", value); }
        }

        public virtual NSString EmitterShape
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "emitterShape"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEmitterShape:", value); }
        }

        public virtual CGSize EmitterSize
        {
            get { return ObjectiveCRuntime.SendMessage<CGSize>(this, "emitterSize"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEmitterSize:", value); }
        }

        public virtual float EmitterZPosition
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "emitterZPosition"); }
            set { ObjectiveCRuntime.SendMessage(this, "setEmitterZPosition:", value); }
        }

        public virtual float Lifetime
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "lifetime"); }
            set { ObjectiveCRuntime.SendMessage(this, "setLifetime:", value); }
        }

        public virtual bool PreservesDepth
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "preservesDepth"); }
            set { ObjectiveCRuntime.SendMessage(this, "setPreservesDepth:", value); }
        }

        public virtual NSString RenderMode
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "renderMode"); }
            set { ObjectiveCRuntime.SendMessage(this, "setRenderMode:", value); }
        }

        public virtual float Scale
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "scale"); }
            set { ObjectiveCRuntime.SendMessage(this, "setScale:", value); }
        }

        public virtual UInt32 Seed
        {
            get { return ObjectiveCRuntime.SendMessage<UInt32>(this, "seed"); }
            set { ObjectiveCRuntime.SendMessage(this, "setSeed:", value); }
        }

        public virtual float Spin
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "spin"); }
            set { ObjectiveCRuntime.SendMessage(this, "setSpin:", value); }
        }

        public virtual float Velocity
        {
            get { return ObjectiveCRuntime.SendMessage<float>(this, "velocity"); }
            set { ObjectiveCRuntime.SendMessage(this, "setVelocity:", value); }
        }
    }
#endif
}
