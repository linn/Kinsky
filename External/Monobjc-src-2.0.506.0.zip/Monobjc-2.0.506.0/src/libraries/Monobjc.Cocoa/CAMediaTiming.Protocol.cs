//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    [ObjectiveCProtocol("CAMediaTiming")]
    public interface ICAMediaTiming : IManagedWrapper
    {
        bool Autoreverses { [ObjectiveCMessage("autoreverses")]
        get; [ObjectiveCMessage("setAutoreverses:")]
        set; }

        double BeginTime { [ObjectiveCMessage("beginTime")]
        get; [ObjectiveCMessage("setBeginTime:")]
        set; }

        double Duration { [ObjectiveCMessage("duration")]
        get; [ObjectiveCMessage("setDuration:")]
        set; }

        NSString FillMode { [ObjectiveCMessage("fillMode")]
        get; [ObjectiveCMessage("setFillMode:")]
        set; }

        float RepeatCount { [ObjectiveCMessage("repeatCount")]
        get; [ObjectiveCMessage("setRepeatCount:")]
        set; }

        double RepeatDuration { [ObjectiveCMessage("repeatDuration")]
        get; [ObjectiveCMessage("setRepeatDuration:")]
        set; }

        float Speed { [ObjectiveCMessage("speed")]
        get; [ObjectiveCMessage("setSpeed:")]
        set; }

        double TimeOffset { [ObjectiveCMessage("timeOffset")]
        get; [ObjectiveCMessage("setTimeOffset:")]
        set; }
    }
#endif
}
