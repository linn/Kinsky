//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Runtime.InteropServices;
using CGImageRef = System.IntPtr;
using CGDataProviderRef = System.IntPtr;
using CGColorSpaceRef = System.IntPtr;
using CGFloat = System.Single;

namespace Monobjc.Cocoa
{
    public class CGImage
    {
        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageCreate")]
        public static extern CGImageRef Create(uint width, uint height, uint bitsPerComponent, uint bitsPerPixel, uint bytesPerRow, CGColorSpaceRef colorspace, CGBitmapInfo bitmapInfo, CGDataProviderRef provider, CGFloat[] decode,
                                                      bool shouldInterpolate, CGColorRenderingIntent intent);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageCreateCopy")]
        public static extern CGImageRef CreateCopy(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageCreateCopyWithColorSpace")]
        public static extern CGImageRef CreateCopyWithColorSpace(CGImageRef image, CGColorSpaceRef colorspace);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageCreateWithImageInRect")]
        public static extern CGImageRef CreateWithImageInRect(CGImageRef image, CGRect rect);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageCreateWithJPEGDataProvider")]
        public static extern CGImageRef CreateWithJPEGDataProvider(CGDataProviderRef source, CGFloat[] decode, bool shouldInterpolate, CGColorRenderingIntent intent);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageCreateWithMask")]
        public static extern CGImageRef CreateWithMask(CGImageRef image, CGImageRef mask);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageCreateWithMaskingColors")]
        public static extern CGImageRef CreateWithMaskingColors(CGImageRef image, CGFloat[] components);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageCreateWithPNGDataProvider")]
        public static extern CGImageRef CreateWithPNGDataProvider(CGDataProviderRef source, CGFloat[] decode, bool shouldInterpolate, CGColorRenderingIntent intent);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetAlphaInfo")]
        public static extern CGImageAlphaInfo GetAlphaInfo(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetBitmapInfo")]
        public static extern CGBitmapInfo GetBitmapInfo(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetBitsPerComponent")]
        public static extern uint GetBitsPerComponent(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetBitsPerPixel")]
        public static extern uint GetBitsPerPixel(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetBytesPerRow")]
        public static extern uint GetBytesPerRow(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetColorSpace")]
        public static extern CGColorSpaceRef GetColorSpace(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetDataProvider")]
        public static extern CGDataProviderRef GetDataProvider(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint = "CGImageGetDecode")]
        public static extern CGFloat[] GetDecode(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetHeight")]
        public static extern uint GetHeight(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetRenderingIntent")]
        public static extern CGColorRenderingIntent GetRenderingIntent(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetShouldInterpolate")]
        public static extern bool GetShouldInterpolate(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetTypeID")]
        public static extern uint GetTypeID();

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageGetWidth")]
        public static extern uint GetWidth(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageIsMask")]
        public static extern bool IsMask(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageMaskCreate")]
        public static extern CGImageRef MaskCreate(uint width, uint height, uint bitsPerComponent, uint bitsPerPixel, uint bytesPerRow, CGDataProviderRef provider, CGFloat[] decode, bool shouldInterpolate);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageRelease")]
        public static extern void Release(CGImageRef image);

        [DllImport("/System/Libraries/Frameworks/ApplicationServices.framework/ApplicationServices", EntryPoint="CGImageRetain")]
        public static extern CGImageRef Retain(CGImageRef image);
    }
}
