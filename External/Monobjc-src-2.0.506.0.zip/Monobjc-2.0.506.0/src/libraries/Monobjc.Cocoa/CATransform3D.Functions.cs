//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial struct CATransform3D
    {
        public static CATransform3D Concat(CATransform3D a, CATransform3D b)
        {
            // TODO: Check matrices at http://www.devmaster.net/wiki/Transformation_matrices
            return new CATransform3D(a.m11 * b.m11 + a.m12 * b.m21 + a.m13 * b.m31 + a.m14 * b.m41,
                                     a.m11 * b.m12 + a.m12 * b.m22 + a.m13 * b.m32 + a.m14 * b.m42,
                                     a.m11 * b.m13 + a.m12 * b.m23 + a.m13 * b.m33 + a.m14 * b.m43,
                                     a.m11 * b.m14 + a.m12 * b.m24 + a.m13 * b.m34 + a.m14 * b.m44,

                                     a.m21 * b.m11 + a.m22 * b.m21 + a.m23 * b.m31 + a.m24 * b.m41,
                                     a.m21 * b.m12 + a.m22 * b.m22 + a.m23 * b.m32 + a.m24 * b.m42,
                                     a.m21 * b.m13 + a.m22 * b.m23 + a.m23 * b.m33 + a.m24 * b.m43,
                                     a.m21 * b.m14 + a.m22 * b.m24 + a.m23 * b.m34 + a.m24 * b.m44,

                                     a.m31 * b.m11 + a.m32 * b.m21 + a.m33 * b.m31 + a.m34 * b.m41,
                                     a.m31 * b.m12 + a.m32 * b.m22 + a.m33 * b.m32 + a.m34 * b.m42,
                                     a.m31 * b.m13 + a.m32 * b.m23 + a.m33 * b.m33 + a.m34 * b.m43,
                                     a.m31 * b.m14 + a.m32 * b.m24 + a.m33 * b.m34 + a.m34 * b.m44,

                                     a.m41 * b.m11 + a.m42 * b.m21 + a.m43 * b.m31 + a.m44 * b.m41,
                                     a.m41 * b.m12 + a.m42 * b.m22 + a.m43 * b.m32 + a.m44 * b.m42,
                                     a.m41 * b.m13 + a.m42 * b.m23 + a.m43 * b.m33 + a.m44 * b.m43,
                                     a.m41 * b.m14 + a.m42 * b.m24 + a.m43 * b.m34 + a.m44 * b.m44);
        }

        public static bool EqualToTransform(CATransform3D a, CATransform3D b)
        {
            return Equals(a, b);
        }

        public static CGAffineTransform CATransform3DGetAffineTransform(CATransform3D t)
        {
            // TODO : To implement
            throw new NotImplementedException();
        }

        public static CATransform3D Invert(CATransform3D t)
        {
            // TODO : To implement
            throw new NotImplementedException();
        }

        public static bool IsAffine(CATransform3D t)
        {
            // TODO : To implement
            throw new NotImplementedException();
        }

        public static bool IsIdentity(CATransform3D t)
        {
            return EqualToTransform(t, Identity);
        }

        public static CATransform3D Make(CGAffineTransform m)
        {
            // TODO : To implement
            throw new NotImplementedException();
        }

        public static CATransform3D MakeRotation(float angle, float x, float y, float z)
        {
            // TODO: Check matrices at http://www.devmaster.net/wiki/Transformation_matrices
            float oneMinusCos = (float) (1.0d - Math.Cos(angle));
            float sin = (float) Math.Sin(angle);
            float x2 = x*x;
            float y2 = y*y;
            float z2 = z*z;

            return new CATransform3D(1.0f + oneMinusCos*(x2 - 1), oneMinusCos*x*y + z*sin, oneMinusCos*x*z - y*sin, 0,
                                     oneMinusCos*x*y - z*sin, 1.0f + oneMinusCos*(y2 - 1.0f), oneMinusCos*y*z - x*sin, 0,
                                     oneMinusCos*x*z + y*sin, oneMinusCos*y*z - x*sin, 1.0f + oneMinusCos*(z2 - 1.0f), 0,
                                     0, 0, 0, 1.0f);
        }

        public static CATransform3D MakeScale(float sx, float sy, float sz)
        {
            // TODO: Check matrices at http://www.devmaster.net/wiki/Transformation_matrices
            return new CATransform3D(sx, 0.0f, 0.0f, 0.0f,
                                     0.0f, sy, 0.0f, 0.0f,
                                     0.0f, 0.0f, sz, 0.0f,
                                     0.0f, 0.0f, 0.0f, 1.0f);
        }

        public static CATransform3D MakeTranslation(float tx, float ty, float tz)
        {
            // TODO: Check matrices at http://www.devmaster.net/wiki/Transformation_matrices
            return new CATransform3D(1.0f, 0.0f, 0.0f, 0.0f,
                                     0.0f, 1.0f, 0.0f, 0.0f,
                                     0.0f, 0.0f, 1.0f, 0.0f,
                                     tx, ty, tz, 1.0f);
        }

        public static CATransform3D Rotate(CATransform3D t, float angle, float x, float y, float z)
        {
            CATransform3D rotation = MakeRotation(angle, x, y, z);
            return Concat(t, rotation);
        }

        public static CATransform3D Scale(CATransform3D t, float sx, float sy, float sz)
        {
            // TODO: Check matrices at http://www.devmaster.net/wiki/Transformation_matrices
            return new CATransform3D(t.m11 * sx, t.m12 * sy, t.m13 * sz, t.m14,
                                     t.m21 * sx, t.m22 * sy, t.m23 * sz, t.m24,
                                     t.m31 * sx, t.m32 * sy, t.m33 * sz, t.m34,
                                     t.m41 * sx, t.m42 * sy, t.m43 * sz, t.m44);
        }

        public static CATransform3D Translate(CATransform3D t, float tx, float ty, float tz)
        {
            // TODO: Check matrices at http://www.devmaster.net/wiki/Transformation_matrices
            return new CATransform3D(t.m11 + t.m14*tx, t.m12 + t.m14*ty, t.m13 + t.m14*tz, t.m14,
                                     t.m21 + t.m24*tx, t.m22 + t.m24*ty, t.m23 + t.m24*tz, t.m24,
                                     t.m31 + t.m34*tx, t.m32 + t.m34*ty, t.m33 + t.m34*tz, t.m34,
                                     t.m41 + t.m44*tx, t.m42 + t.m44*ty, t.m43 + t.m44*tz, t.m44);
        }
    }
#endif
}
