//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using System.Runtime.InteropServices;

namespace Monobjc.Cocoa
{
    [StructLayout(LayoutKind.Sequential)]
    public partial struct CGSize : IEquatable<CGSize>
    {
        public float width;

        public float height;

        public CGSize(float width, float height)
        {
            this.width = width;
            this.height = height;
        }

        public override String ToString()
        {
            return String.Format(CultureInfo.CurrentCulture, "CGSize({0}, {1})", this.width, this.height);
        }

        public static bool operator !=(CGSize cgSize1, CGSize cgSize2)
        {
            return !cgSize1.Equals(cgSize2);
        }

        public static bool operator ==(CGSize cgSize1, CGSize cgSize2)
        {
            return cgSize1.Equals(cgSize2);
        }

        public bool Equals(CGSize cgSize)
        {
            return (this.width == cgSize.width) && (this.height == cgSize.height);
        }

        public override bool Equals(object obj)
        {
            if (!(obj is CGSize))
            {
                return false;
            }
            return Equals((CGSize) obj);
        }

        public override int GetHashCode()
        {
            return this.width.GetHashCode() + 29*this.height.GetHashCode();
        }
    }
}
