//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CAAnimation
    {
        public delegate void AnimationDidStartEventHandler(CAAnimation theAnimation);

        public delegate void AnimationDidStopFinishedEventHandler(CAAnimation theAnimation, bool flag);

        public void SetDelegate(Action<CAAnimationEventDispatcher> assignment)
        {
            CAAnimationEventDispatcher @delegate = this.Delegate.SafeCastAs<CAAnimationEventDispatcher>();
            if (@delegate != null)
            {
                @delegate.Release();
                this.Delegate = null;
            }

            if (assignment != null)
            {
                @delegate = new CAAnimationEventDispatcher();
                assignment(@delegate);
                this.Delegate = @delegate;
            }
        }

        [ObjectiveCClass]
        public class CAAnimationEventDispatcher : NSObject
        {
            public static readonly Class CAAnimationEventDispatcherClass = Class.GetClassFromType(typeof (CAAnimationEventDispatcher));

            public CAAnimationEventDispatcher() {}

            public CAAnimationEventDispatcher(IntPtr nativePointer)
                : base(nativePointer) {}

            [ObjectiveCMessage("respondsToSelector:")]
            public override bool RespondsToSelector(IntPtr aSelector)
            {
                String message = ObjectiveCRuntime.Selector(aSelector);
                switch (message)
                {
                    case "animationDidStart:":
                        return (this.AnimationDidStart != null);
                    case "animationDidStop:finished:":
                        return (this.AnimationDidStopFinished != null);
                }
                return this.SendMessageSuper<bool>(CAAnimationEventDispatcherClass, "respondsToSelector:", aSelector);
            }

            public event AnimationDidStartEventHandler AnimationDidStart;

            public event AnimationDidStopFinishedEventHandler AnimationDidStopFinished;

            [ObjectiveCMessage("animationDidStart:")]
            public void AnimationDidStartMessage(CAAnimation theAnimation)
            {
                if (this.AnimationDidStart != null)
                {
                    this.AnimationDidStart(theAnimation);
                }
            }

            [ObjectiveCMessage("animationDidStop:finished:")]
            public void AnimationDidStopFinishedMessage(CAAnimation theAnimation, bool flag)
            {
                if (this.AnimationDidStopFinished != null)
                {
                    this.AnimationDidStopFinished(theAnimation, flag);
                }
            }

            [ObjectiveCMessage("dealloc", SynchronizeFields = false)]
            public void Dealloc()
            {
                if (this.AnimationDidStart != null)
                {
                    foreach (AnimationDidStartEventHandler handler in this.AnimationDidStart.GetInvocationList())
                    {
                        this.AnimationDidStart -= handler;
                    }
                }
                if (this.AnimationDidStopFinished != null)
                {
                    foreach (AnimationDidStopFinishedEventHandler handler in this.AnimationDidStopFinished.GetInvocationList())
                    {
                        this.AnimationDidStopFinished -= handler;
                    }
                }

                this.SendMessageSuper(CAAnimationEventDispatcherClass, "dealloc");
            }
        }
    }
#endif
}
