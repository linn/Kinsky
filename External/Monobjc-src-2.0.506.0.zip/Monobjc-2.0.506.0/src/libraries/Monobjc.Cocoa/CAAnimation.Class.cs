//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
#if MACOSX_10_5
    public partial class CAAnimation
    {
        public static Id DefaultValueForKey(NSString key)
        {
            return ObjectiveCRuntime.SendMessage<Id>(CAAnimationClass, "defaultValueForKey:", key);
        }

        public virtual bool ShouldArchiveValueForKey(NSString key)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "shouldArchiveValueForKey:", key);
        }

        public virtual Id Delegate
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "delegate"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDelegate:", value); }
        }

        public virtual bool RemovedOnCompletion
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "removedOnCompletion"); }
            set { ObjectiveCRuntime.SendMessage(this, "setRemovedOnCompletion:", value); }
        }

        public virtual CAMediaTimingFunction TimingFunction
        {
            get { return ObjectiveCRuntime.SendMessage<CAMediaTimingFunction>(this, "timingFunction"); }
            set { ObjectiveCRuntime.SendMessage(this, "setTimingFunction:", value); }
        }

        public static CAAnimation Animation
        {
            get { return ObjectiveCRuntime.SendMessage<CAAnimation>(CAAnimationClass, "animation"); }
        }

        public virtual bool IsRemovedOnCompletion
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "isRemovedOnCompletion"); }
        }
    }
#endif
}
