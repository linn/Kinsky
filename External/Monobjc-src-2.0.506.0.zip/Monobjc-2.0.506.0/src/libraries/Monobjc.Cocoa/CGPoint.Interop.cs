//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Cocoa
{
    public partial struct CGPoint
    {
        public static CGPoint Add(CGPoint cgPoint, CGSize cgSize)
        {
            return new CGPoint(cgPoint.x + cgSize.width, cgPoint.y + cgSize.height);
        }

        public static CGPoint Substract(CGPoint cgPoint, CGSize cgSize)
        {
            return new CGPoint(cgPoint.x - cgSize.width, cgPoint.y - cgSize.height);
        }

        public static CGSize Substract(CGPoint cgPoint1, CGPoint cgPoint2)
        {
            return new CGSize(Math.Abs(cgPoint2.x - cgPoint1.x), Math.Abs(cgPoint2.y - cgPoint1.y));
        }

        public static CGPoint operator +(CGPoint cgPoint, CGSize cgSize)
        {
            return Add(cgPoint, cgSize);
        }

        public static CGPoint operator -(CGPoint cgPoint, CGSize cgSize)
        {
            return Substract(cgPoint, cgSize);
        }

        public static CGSize operator -(CGPoint cgPoint1, CGPoint cgPoint2)
        {
            return Substract(cgPoint1, cgPoint2);
        }
    }
}
