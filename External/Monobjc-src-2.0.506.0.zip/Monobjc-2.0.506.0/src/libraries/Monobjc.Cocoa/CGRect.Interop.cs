//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Cocoa
{
    public partial struct CGRect
    {
        public int ContainsRect(CGRect aRect)
        {
            return CGRectContainsRect(this, aRect);
        }

        public void DivideRect(ref CGRect slice,
                               ref CGRect remainder,
                               float amount,
                               CGRectEdge edge)
        {
            CGRectDivide(this, ref slice, ref remainder, amount, edge);
        }

        public float Height
        {
            get { return CGRectGetHeight(this); }
        }

        public CGRect InsetRect(float dX, float dY)
        {
            return CGRectInset(this, dX, dY);
        }

        public CGRect IntegralRect()
        {
            return CGRectIntegral(this);
        }

        public CGRect IntersectionRect(CGRect aRect)
        {
            return CGRectIntersection(this, aRect);
        }

        public int IntersectsRect(CGRect aRect)
        {
            return CGRectIntersectsRect(this, aRect);
        }

        public int IsEmptyRect
        {
            get { return CGRectIsEmpty(this); }
        }

        public float MaxX
        {
            get { return CGRectGetMaxX(this); }
        }

        public float MaxY
        {
            get { return CGRectGetMaxY(this); }
        }

        public float MidX
        {
            get { return CGRectGetMidX(this); }
        }

        public float MidY
        {
            get { return CGRectGetMidY(this); }
        }

        public float MinX
        {
            get { return CGRectGetMinX(this); }
        }

        public float MinY
        {
            get { return CGRectGetMinY(this); }
        }

        public CGRect OffsetRect(float dX, float dY)
        {
            return CGRectOffset(this, dX, dY);
        }

        public int PointInRect(CGPoint aPoint)
        {
            return CGRectContainsPoint(this, aPoint);
        }

        public CGRect UnionRect(CGRect aRect)
        {
            return CGRectUnion(this, aRect);
        }

        public float Width
        {
            get { return CGRectGetWidth(this); }
        }
    }
}
