//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using Monobjc.Properties;

namespace Monobjc
{
    partial class Class
    {
        /// <summary>
        /// Maps the given class using the type, the classname and the instance.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="className">Name of the class.</param>
        /// <param name="classInstance">The class instance.</param>
        /// <exception cref="ObjectiveCException">The mapping is not possible because the type or the classname are already registered</exception>
        [MethodImpl(MethodImplOptions.Synchronized)]
        internal static void MapClass(Type type, String className, Class classInstance)
        {
            if (classMappingByName.ContainsKey(className))
            {
                throw new ObjectiveCException(String.Format(CultureInfo.CurrentCulture, Resources.CannotMapTheSameClassTwice, className));
            }
            classMappingByName.Add(className, type);

            if (classMappingByType.ContainsKey(type))
            {
                throw new ObjectiveCException(String.Format(CultureInfo.CurrentCulture, Resources.CannotMapTheSameClassTwice, type.FullName));
            }
            classMappingByType.Add(type, classInstance);
        }

        /// <summary>
        /// Gets the class by its type.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>An <see cref="Class"/> instance if found.</returns>
        [MethodImpl(MethodImplOptions.Synchronized)]
        internal static Class GetClass(Type type)
        {
            if (classMappingByType.ContainsKey(type))
            {
                return classMappingByType[type];
            }
            return null;
        }

        /// <summary>
        /// Gets the class by its name.
        /// </summary>
        /// <param name="className">Name of the class.</param>
        /// <returns>An <see cref="Class"/> instance if found.</returns>
        [MethodImpl(MethodImplOptions.Synchronized)]
        internal static Type GetClass(String className)
        {
            if (classMappingByName.ContainsKey(className))
            {
                return classMappingByName[className];
            }
            return null;
        }
    }
}