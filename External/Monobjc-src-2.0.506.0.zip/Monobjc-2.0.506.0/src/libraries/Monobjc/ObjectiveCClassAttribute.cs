//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using Monobjc.Properties;

namespace Monobjc
{
    /// <summary>
    /// <para>Allows a .NET class to be registered within the Objective-C runtime.</para>
    /// <para>All the ascendant classes in the inheritance hierarchy must have a <see cref="ObjectiveCClassAttribute"/> attribute,
    /// otherwise the runtime will not be able to use it.</para>
    /// </summary>
    /// 
    /// <example>
    /// <para>The following example shows how to use the <see cref="ObjectiveCClassAttribute"/> attribute.</para>
    /// <para>The type <c>MyOwnType1</c> will be registered with the "MyOwnType1" name.
    /// <code>
    /// [ObjectiveCClass]
    /// public class MyOwnType1 : NSObject
    /// {
    ///     ...
    /// }
    /// </code>
    /// </para>
    /// <para>The type <c>MyOwnType2</c> will be registered with the "Type2" name.
    /// <code>
    /// [ObjectiveCClass("Type2")]
    /// public class MyOwnType2 : NSObject
    /// {
    ///     ...
    /// }
    /// </code>
    /// </para>
    /// </example>
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class ObjectiveCClassAttribute : Attribute
    {
        private readonly String name;
        private String interceptCallsFor;

        /// <summary>
        /// <para>Initializes a new instance of the <see cref="ObjectiveCClassAttribute"/> class.</para>
        /// <para>The name that will be used to register the tagged type will be its short name, i.e. "MyType"
        /// if the type is "Foo.Bar.MyType".</para>
        /// </summary>
        public ObjectiveCClassAttribute()
        {
            this.name = String.Empty;
            this.InterceptCallsFor = String.Empty;
        }

        /// <summary>
        /// <para>Initializes a new instance of the <see cref="ObjectiveCClassAttribute"/> class.</para>
        /// <para>Note: the name MUST be an ANSI identifier.</para>
        /// </summary>
        /// <param name="name">The name that will be used to register the tagged type.</param>
        public ObjectiveCClassAttribute(String name)
        {
            this.name = name;
            this.InterceptCallsFor = String.Empty;
        }

        /// <summary>
        /// <para>Gets the name to use when registering this class in the Objective-C runtime.</para>
        /// </summary>
        /// <value>The name to use.</value>
        public String Name
        {
            get { return this.name; }
        }

        /// <summary>
        /// <para>Gets or sets the name of the class whose methods will be intercetped by this class.</para>
        /// <para>The Objective-C runtime allows method replacement. It is useful to introduce
        /// a new behaviour wihtin a class hierarchy or to intercept messages.</para>
        /// <para>Note: the name MUST be an ANSI identifier.</para>
        /// </summary>
        /// <value>The name of the recplaced class.</value>
        public String InterceptCallsFor
        {
            get { return this.interceptCallsFor; }
            set { this.interceptCallsFor = value; }
        }

        /// <summary>
        /// <para>Gets a value indicating whether the exported type is an imposter (<see cref="InterceptCallsFor"/> property).</para>
        /// </summary>
        /// <value><c>true</c> if the exported type is an interceptor; otherwise, <c>false</c>.</value>
        public bool Interceptor
        {
            get { return !String.IsNullOrEmpty(this.interceptCallsFor); }
        }

        /// <summary>
        /// <para>Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.</para>
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override String ToString()
        {
            return String.Format(CultureInfo.CurrentCulture,
                                 Resources.ObjectiveCClassString,
                                 this.Name,
                                 this.InterceptCallsFor);
        }
    }
}