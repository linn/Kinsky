//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;

namespace Monobjc
{
    public partial class ObjectiveCRuntime
    {
        /// <summary>
        /// Returns the selector from the message name.
        /// </summary>
        /// <param name="selectorName">The selectorName.</param>
        /// <returns>A pointer to a selector</returns>
        public static IntPtr Selector(String selectorName)
        {
            return SafeNativeMethods.sel_registerName(selectorName);
        }

        /// <summary>
        /// Returns the message name from the selector.
        /// </summary>
        /// <param name="selector">The selector.</param>
        /// <returns>A pointer to a selector</returns>
        public static String Selector(IntPtr selector)
        {
            return Marshal.PtrToStringAnsi(SafeNativeMethods.sel_getName(selector));
        }

        /// <summary>
        /// Log to ouptut the details of a message sending.
        /// </summary>
        private static void LogSendMessage(String message, IManagedWrapper receiver, String selector)
        {
            Logger.Trace("ObjectiveCRuntime", message + " '" + selector + "' to 0x" + receiver.NativePointer.ToString("x"));
        }
    }
}