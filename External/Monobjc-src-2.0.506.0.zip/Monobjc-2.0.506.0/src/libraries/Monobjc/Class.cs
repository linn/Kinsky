//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Globalization;
using Monobjc.Properties;
using Monobjc.Runtime;
using Monobjc.Utils;

namespace Monobjc
{
    /// <summary>
    /// Represents a managed wrapper around an Objective-C Class definition.
    /// </summary>
    public sealed partial class Class : Id
    {
        private static readonly IDictionary<string, Type> classMappingByName = new Dictionary<String, Type>(512);
        private static readonly IDictionary<Type, Class> classMappingByType = new Dictionary<Type, Class>(512);

        private String name;
        private Class superClass;

        /// <summary>
        /// Initializes a new instance of the <see cref="Class"/> class.
        /// </summary>
        public Class() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="Class"/> class.
        /// </summary>
        /// <param name="value">The native pointer.</param>
        /// <exception cref="ArgumentNullException">If the pointer is null</exception>
        public Class(IntPtr value)
        {
            if (value == IntPtr.Zero)
            {
                throw new ArgumentNullException("value", Resources.ClassPointerCannotBeSetToZero);
            }
            this.NativePointer = value;
        }

        /// <summary>
        /// Gets the class from object.
        /// </summary>
        /// <param name="obj">The obj.</param>
        /// <returns>The corresponding class</returns>
        /// <exception cref="ArgumentNullException">If the object is null</exception>
        public static Class GetClassFromObject(Id obj)
        {
            if (obj == null)
            {
                throw new ArgumentNullException("obj");
            }
            return GetClassFromType(obj.GetType());
        }

        /// <summary>
        /// Gets the type of the class from.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>The corresponding class</returns>
        /// <exception cref="ArgumentNullException">If the type is null</exception>
        public static Class GetClassFromType(Type type)
        {
            if (type == null)
            {
                throw new ArgumentNullException("type");
            }
            return GetClass(type);
        }

        /// <summary>
        /// Gets the name of the class from.
        /// </summary>
        /// <param name="className">Name of the class.</param>
        /// <returns>The corresponding class</returns>
        /// <exception cref="ArgumentNullException">If the class name is null or empty</exception>
        public static Class GetClassFromName(String className)
        {
            if (String.IsNullOrEmpty(className))
            {
                throw new ArgumentNullException("className");
            }
            Type type = GetClass(className);
            if (type != null)
            {
                return GetClass(type);
            }
            return null;
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override String ToString()
        {
            return this.Name;
        }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        public String Name
        {
            get
            {
                if (this.name == null)
                {
                    this.name = RuntimeBridge.Current.GetClassName(this.NativePointer);
                }
                return this.name;
            }
        }

        /// <summary>
        /// Returns the managed wrapper of the super class for this instance.
        /// </summary>
        public Class SuperClass
        {
            get
            {
                if (this.superClass == null)
                {
                    IntPtr superPointer = RuntimeBridge.Current.GetSuperClass(this.NativePointer);
                    if (superPointer != IntPtr.Zero)
                    {
                        this.superClass = new Class(superPointer);
                    }
                }
                return this.superClass;
            }
        }

        /// <summary>
        /// Dumps the class mappings of the currently registered clases. Use for debugging purpose only.
        /// </summary>
        internal static void DumpClasses()
        {
            if (Logger.DebugEnabled)
            {
                Logger.Debug("Class", "Class Mappings");
                Logger.Debug("Class", "--------------");

                // Retrieve the type list and sort it
                List<Type> keys = new List<Type>(classMappingByType.Keys);
                keys.Sort(new TypeComparer());
                // Print each type with its mapping and its superclass
                foreach (Type key in keys)
                {
                    Logger.Debug("Class", String.Format(CultureInfo.CurrentCulture, "\t{1} ({2}) => {0}", key, classMappingByType[key].Name, classMappingByType[key].SuperClass));
                }

                Logger.Debug("Class", "--------------");
            }
        }
    }
}