//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Text;
using Monobjc.Properties;
using Monobjc.Runtime;
using Monobjc.Utils;

namespace Monobjc
{
    public partial class ObjectiveCRuntime
    {
        /// <summary>
        /// Maps the specified native pointer to the given managed instance.
        /// </summary>
        /// <param name="value">The native pointer.</param>
        /// <param name="instance">The managed instance.</param>
        /// <returns>A pointer to the instance.</returns>
        public static IntPtr MapInstance(IntPtr value, Id instance)
        {
            if (instance == null)
            {
                throw new ArgumentNullException("instance");
            }

            if (value != IntPtr.Zero)
            {
                lock (instances)
                {
                    instances[value] = instance;
#if !MANAGED_SWIZZLING
                    RuntimeBridge.Current.AddObject(value);
#endif
                }
            }

            return value;
        }

#if !MANAGED_SWIZZLING
        /// <summary>
        /// Removes the specified native pointer.
        /// </summary>
        /// <param name="target">The native pointer.</param>
        public static void RemoveInstance(IntPtr target)
        {
            lock (instances)
            {
				try
				{
					instances.Remove(target);
				}
				catch { }
            }
        }
#endif

        /// <summary>
        /// Removes the specified native pointer.
        /// </summary>
        /// <param name="instance">The managed instance.</param>
        public static void RemoveInstance(Id instance)
        {
            if (instance == null)
            {
                throw new ArgumentNullException("instance");
            }

            if (instance.NativePointer != IntPtr.Zero)
            {
                lock (instances)
                {
                    instances.Remove(instance.NativePointer);
                }
            }
        }

        /// <summary>
        /// Gets the instance related to the native pointer.
        /// </summary>
        /// <typeparam name="TClass">The type of the instance.</typeparam>
        /// <param name="value">The native pointer.</param>
        /// <returns>
        /// A cached or created instance of the given type. If the pointer is null, then a null is returned.
        /// </returns>
        /// <exception cref="ObjectiveCClassCastException">If an error occured during the cast</exception>
        public static TClass GetInstance<TClass>(IntPtr value) where TClass : class, IManagedWrapper
        {
            return GetInstance<TClass>(value, false);
        }

        /// <summary>
        /// Gets the instance related to the native pointer.
        /// </summary>
        /// <typeparam name="TClass">The type of the instance.</typeparam>
        /// <param name="value">The native pointer.</param>
        /// <param name="canFail">if set to <c>true</c>, then the retrieval can fail.</param>
        /// <returns>
        /// A cached or created instance of the given type. If the pointer is null, then a null is returned.
        /// </returns>
        /// <exception cref="ObjectiveCClassCastException">If an error occured during the cast</exception>
        public static TClass GetInstance<TClass>(IntPtr value, bool canFail) where TClass : class, IManagedWrapper
        {
            TClass result = default(TClass);
            Type targetType = typeof (TClass);

            if (value != IntPtr.Zero)
            {
                if (targetType.IsClass)
                {
                    // ================================================================================
                    // Return a managed wrapper created or taken from the cache
                    // ================================================================================
                    lock (instances)
                    {
                        // Check to see if instance is already in the cache
                        if (instances.ContainsKey(value))
                        {
                            // If so, we check that the existing wrapper can be use directly
                            Id instance = instances[value];
                            result = instance as TClass;

                            // If no match, try to see if there is an inheritance relationship
                            if (result == default(TClass))
                            {
                                Class cls = Class.GetClassFromType(typeof (TClass));
                                bool kindOf = isKindOfClass(value, Selector("isKindOfClass:"), cls.NativePointer);

                                // If it is not a subclass, maybe something is wrong...
                                if (!kindOf)
                                {
                                    if (canFail)
                                    {
                                        goto bail;
                                    }

                                    // Dump out the class hierarchy
                                    StringBuilder builder = new StringBuilder();
                                    Class c = instance.Class;
                                    do
                                    {
                                        builder.Append(" -> " + c);
                                        c = c.SuperClass;
                                    }
                                    while (c != null);

                                    Logger.Warn("ObjectiveCRuntime", String.Format(CultureInfo.CurrentCulture, Resources.CannotSafelyCastObject, instance.Class, targetType.FullName, builder));
                                    //throw new ObjectiveCClassCastException(String.Format(CultureInfo.CurrentCulture, Resources.CannotSafelyCastObject, instance.Class, targetType.FullName, builder));
                                }
                            }
                        }

                        if (result == default(TClass))
                        {
                            // Create a new wrapper instance (it will place itself in the instance cache)
                            result = Creator<TClass>.CreateInstance(value);
                            if (result == default(TClass))
                            {
                                if (canFail)
                                {
                                    goto bail;
                                }
                                throw new ObjectiveCClassCastException(String.Format(CultureInfo.CurrentCulture, Resources.CannotCreateInstance, typeof (TClass)));
                            }
                        }
                    }
                }
                else
                {
                    // ================================================================================
                    // Return a managed wrapper that implements the interface
                    // ================================================================================

                    // Get the wrapper type for the given interface
                    Type wrapperType = wrapperProvider.GetWrapper<TClass>();

                    // Create an instance
                    Id proxy = Activator.CreateInstance(wrapperType, new Object[] {value}) as Id;
                    if (proxy == null)
                    {
                        if (canFail)
                        {
                            goto bail;
                        }
                        throw new ObjectiveCClassCastException(String.Format(CultureInfo.CurrentCulture, Resources.CannotCreateInstance, typeof (TClass)));
                    }

                    // Check for conformance
                    result = proxy as TClass;
                    if (result == null)
                    {
                        if (canFail)
                        {
                            goto bail;
                        }
                        throw new ObjectiveCClassCastException(String.Format(CultureInfo.CurrentCulture, Resources.CannotCreateInstance, typeof (TClass)));
                    }
                }
            }

            bail:
            return result;
        }

        /// <summary>
        /// Casts the instance to a given type.
        /// </summary>
        /// <typeparam name="TClass">The type of the instance.</typeparam>
        /// <param name="instance">The instance to cast.</param>
        /// <returns>An instance of the given type.</returns>
        /// <exception cref="ObjectiveCClassCastException">If an error occured during the cast</exception>
        public static TClass CastTo<TClass>(Id instance) where TClass : class, IManagedWrapper
        {
            TClass result = default(TClass);

            if (instance != null)
            {
                result = GetInstance<TClass>(instance.NativePointer, false);
            }

            return result;
        }

        /// <summary>
        /// Try to cast the instance to a given type.
        /// </summary>
        /// <typeparam name="TClass">The type of the instance.</typeparam>
        /// <param name="instance">The instance to cast.</param>
        /// <returns>An instance of the given type or null if the cast fails.</returns>
        public static TClass CastAs<TClass>(Id instance) where TClass : class, IManagedWrapper
        {
            TClass result = default(TClass);

            if (instance != null)
            {
                result = GetInstance<TClass>(instance.NativePointer, true);
            }

            return result;
        }

#if MANAGED_SWIZZLING
        /// <summary>
        /// <para>Gets the base implementation pointer for a given class and a selector.</para>
        /// <para>The returned pointer is the original pointer, which allows a replacement
        /// method to make call to the replaced method.</para>
        /// </summary>
        /// <param name="className">Name of the class to search.</param>
        /// <param name="selector">The selector of the method.</param>
        /// <returns>The native pointer of the implementation</returns>
        public static IntPtr GetBaseImplementationPointer(String className, String selector)
        {
            return RuntimeBridge.Current.GetBaseImplementationPointer(className, selector);
        }
#endif

        /// <summary>
        /// Show statistics about the Managed/Native mappings. Use for debugging purpose only.
        /// </summary>
        public static void DumpCache()
        {
            lock (instances)
            {
                if (Logger.DebugEnabled)
                {
                    Logger.Debug("ObjectiveCRuntime", "-------------");
                    Logger.Debug("ObjectiveCRuntime", "Cache Instance Count: " + instances.Count);
                    Logger.Debug("ObjectiveCRuntime", "-------------");
                    Logger.Debug("ObjectiveCRuntime", "Cache Repartition");
                    Logger.Debug("ObjectiveCRuntime", "-------------");
                    IDictionary<Type, int> counts = new SortedDictionary<Type, int>(new TypeComparer());
                    foreach (KeyValuePair<IntPtr, Id> pair in instances)
                    {
                        Type type = pair.Value.GetType();
                        int count = 0;
                        if (counts.ContainsKey(type))
                        {
                            count = counts[type];
                        }
                        counts[type] = ++count;
                    }
                    foreach (KeyValuePair<Type, int> pair in counts)
                    {
                        Logger.Debug("ObjectiveCRuntime", String.Format(CultureInfo.CurrentCulture, "\t{0} = {1}", pair.Key.Name, pair.Value));
                    }
                    Logger.Debug("ObjectiveCRuntime", "-------------");
                }

                if (Logger.TraceEnabled)
                {
                    Logger.Trace("ObjectiveCRuntime", "Cache Details");
                    Logger.Trace("ObjectiveCRuntime", "-------------");
                    List<IntPtr> pointers = new List<IntPtr>(instances.Keys);
                    pointers.Sort((p1, p2) => p1.ToInt64().CompareTo(p2.ToInt64()));
                    foreach (IntPtr pointer in pointers)
                    {
                        Type cls = instances[pointer].GetType();
                        Logger.Trace("ObjectiveCRuntime", String.Format(CultureInfo.CurrentCulture, "\t0x{0} = {1}", pointer.ToString("x"), cls));
                    }
                    Logger.Trace("ObjectiveCRuntime", "-------------");
                }
            }
        }

        /// <summary>
        /// Specific message used when testing for class equivalence.
        /// </summary>
        [DllImport("libobjc", EntryPoint = "objc_msgSend", CharSet = CharSet.Ansi, BestFitMapping = false, ThrowOnUnmappableChar = true)]
        private static extern bool isKindOfClass(IntPtr theReceiver, IntPtr theSelector, IntPtr parameter);

        /// <summary>
        /// Delegate to construct new instance of <see cref="IManagedWrapper"/> implementation.
        /// </summary>
        private delegate TType DynamicCreateInvoker<TType>(IntPtr value);

        /// <summary>
        /// Factory class to create generic instance with non-default constructors.
        /// </summary>
        /// <typeparam name="TType">The parametric type</typeparam>
        private static class Creator<TType>
        {
            private static readonly Type[] PARAMETER_TYPES = new[] {typeof (IntPtr)};
            private static readonly DynamicCreateInvoker<TType> INVOKER = CreateInvoker();

            /// <summary>
            /// Creates a generic instance of the parametric type.
            /// </summary>
            /// <param name="value">The value.</param>
            /// <returns></returns>
            public static TType CreateInstance(IntPtr value)
            {
                return INVOKER(value);
            }

            /// <summary>
            /// Creates the invoker.
            /// </summary>
            private static DynamicCreateInvoker<TType> CreateInvoker()
            {
                Type type = typeof (TType);
                ConstructorInfo constructorInfo = type.GetConstructor(PARAMETER_TYPES);
                DynamicMethod dynamicMethod = new DynamicMethod("CreateInstance", type, PARAMETER_TYPES, type, true);
                ILGenerator generator = dynamicMethod.GetILGenerator();
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Newobj, constructorInfo);
                generator.Emit(OpCodes.Ret);
                return (DynamicCreateInvoker<TType>) dynamicMethod.CreateDelegate(typeof (DynamicCreateInvoker<TType>));
            }
        }
    }
}