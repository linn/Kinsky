//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.Serialization;

namespace Monobjc
{
    /// <summary>
    /// Exception raised if a dynamic class cast failed.
    /// </summary>
    [Serializable]
    public class ObjectiveCClassCastException : ObjectiveCException
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ObjectiveCClassCastException"/> class.
        /// </summary>
        public ObjectiveCClassCastException() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="ObjectiveCClassCastException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        public ObjectiveCClassCastException(String message)
            : base(message) {}

        /// <summary>
        /// Initializes a new instance of the <see cref="ObjectiveCClassCastException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="innerException">The inner exception.</param>
        public ObjectiveCClassCastException(String message, Exception innerException)
            : base(message, innerException) {}

        /// <summary>
        /// Initializes a new instance of the <see cref="ObjectiveCClassCastException"/> class.
        /// </summary>
        /// <param name="info">The <see cref="T:System.Runtime.Serialization.SerializationInfo"></see> that holds the serialized object data about the exception being thrown.</param>
        /// <param name="context">The <see cref="T:System.Runtime.Serialization.StreamingContext"></see> that contains contextual information about the source or destination.</param>
        /// <exception cref="T:System.Runtime.Serialization.SerializationException">The class name is null or <see cref="P:System.Exception.HResult"></see> is zero (0). </exception>
        /// <exception cref="T:System.ArgumentNullException">The info parameter is null. </exception>
        protected ObjectiveCClassCastException(SerializationInfo info, StreamingContext context)
            : base(info, context) {}
    }
}