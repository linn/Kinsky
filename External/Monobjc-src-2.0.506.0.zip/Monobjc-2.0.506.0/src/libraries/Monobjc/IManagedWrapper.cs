//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc
{
    /// <summary>
    /// Interface to identity classes or interfaces that can act as a managed wrapper.
    /// </summary>
    public partial interface IManagedWrapper
    {
        /// <summary>
        /// Cast the current instance to the given type. The cast is dynamically tested for safety.
        /// </summary>
        /// <typeparam name="TInstance">The type of the instance.</typeparam>
        /// <returns>The cast instance</returns>
        /// <exception cref="ObjectiveCClassCastException">If an error occured during the cast</exception>
        TInstance CastTo<TInstance>() where TInstance : class, IManagedWrapper;

        /// <summary>
        /// Try to cast the current instance to the given type. The cast is dynamically tested for safety.
        /// </summary>
        /// <typeparam name="TInstance">The type of the instance.</typeparam>
        /// <returns>The cast instance or null if the cast is not valid</returns>
        TInstance CastAs<TInstance>() where TInstance : class, IManagedWrapper;

        /// <summary>
        /// <para>Gets the underlying native pointer.</para>
        /// </summary>
        /// <value>The native pointer.</value>
        IntPtr NativePointer { get; }
    }
}