//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using System.Reflection;

namespace Monobjc.Utils
{
    /// <summary>
    /// Subclass of <see cref="Binder"/> used to select or not generic methods when a name collision is possible. Other selection or bind calls are ignored.
    /// </summary>
    internal class CustomMethodBinder : Binder
    {
        private readonly bool returnGeneric;

        public CustomMethodBinder(bool generic)
        {
            this.returnGeneric = generic;
        }

        /// <summary>
        /// Selects a method to invoke from the given set of methods, based on the actual arguments.
        /// </summary>
        /// <param name="bindingAttr">One of the <see cref="T:System.Reflection.BindingFlags"></see> enumerators.</param>
        /// <param name="match">The set of methods Reflection has determined to be a possible match, typically because they have the correct member name.</param>
        /// <param name="args">The actual arguments passed in. Both the types and values of the arguments can be changed.</param>
        /// <param name="modifiers">An array of parameter modifiers that enable binding to work with parameter signatures in which the types have been modified.</param>
        /// <param name="culture">An instance of <see cref="T:System.Globalization.CultureInfo"></see> used to control the coercion of data types. If culture is null, the <see cref="T:System.Globalization.CultureInfo"></see> for the current thread is used.For example, this parameter is necessary to convert a String that represents 1000 to a Double value, since 1000 is represented differently by different cultures.</param>
        /// <param name="names">The method name or names.</param>
        /// <param name="state">A binder-provided object that keeps track of argument reordering. The state parameter is a cookie that was passed to BindToMethod and represents an opaque object. The binder creates this object, and the binder is the sole consumer of this object. If state is not null when BindToMethod returns, the runtime calls <see cref="M:System.Reflection.Binder.ReorderArgumentArray(System.Object[]@,System.Object)"></see>.</param>
        /// <returns>
        /// A <see cref="T:System.Reflection.MethodBase"></see> object containing the matching method.
        /// </returns>
        public override MethodBase BindToMethod(BindingFlags bindingAttr, MethodBase[] match, ref object[] args, ParameterModifier[] modifiers, CultureInfo culture, string[] names, out object state)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Selects a field from the given set of fields, based on the specified criteria.
        /// </summary>
        /// <param name="bindingAttr">One of the <see cref="T:System.Reflection.BindingFlags"></see> enumerators.</param>
        /// <param name="match">The set of fields Reflection has determined to be a possible match, typically because they have the correct member name.</param>
        /// <param name="value">The field value used to locate a matching field.</param>
        /// <param name="culture">An instance of <see cref="T:System.Globalization.CultureInfo"></see> used to control the coercion of data types. If culture is null, the <see cref="T:System.Globalization.CultureInfo"></see> for the current thread is used.For example, this parameter is necessary to convert a String that represents 1000 to a Double value, since 1000 is represented differently by different cultures.</param>
        /// <returns>
        /// A <see cref="T:System.Reflection.FieldInfo"></see> object containing the matching field.
        /// </returns>
        public override FieldInfo BindToField(BindingFlags bindingAttr, FieldInfo[] match, object value, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Selects a method from the given set of methods, based on the argument type.
        /// </summary>
        /// <param name="bindingAttr">One of the <see cref="T:System.Reflection.BindingFlags"></see> enumerators.</param>
        /// <param name="match">The set of methods Reflection has determined to be a possible match, typically because they have the correct member name.</param>
        /// <param name="types">The values used to locate a matching method.</param>
        /// <param name="modifiers">An array of parameter modifiers that enable binding to work with parameter signatures in which the types have been modified.</param>
        /// <returns>
        /// A <see cref="T:System.Reflection.MethodBase"></see> object containing the matching method, if found; otherwise, null.
        /// </returns>
        public override MethodBase SelectMethod(BindingFlags bindingAttr, MethodBase[] match, Type[] types, ParameterModifier[] modifiers)
        {
            if (Logger.DebugEnabled)
            {
                Logger.Debug("CustomMethodBinder", String.Format("Searching for{0} method with {1} arguments",
                                                                 (this.returnGeneric ? " generic" : String.Empty),
                                                                 types.Length));
                foreach (MethodBase methodBase in match)
                {
                    Logger.Debug("CustomMethodBinder", "Candidate method is " + methodBase);
                }
            }
            foreach (MethodBase methodBase in match)
            {
                if ((types.Length == methodBase.GetParameters().Length) &&
                    (!this.returnGeneric ^ methodBase.IsGenericMethod))
                {
                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("CustomMethodBinder", "=> Matching method is " + methodBase);
                    }
                    return methodBase;
                }
            }
            return null;
        }

        /// <summary>
        /// Selects a property from the given set of properties, based on the specified criteria.
        /// </summary>
        /// <param name="bindingAttr">One of the <see cref="T:System.Reflection.BindingFlags"></see> enumerators.</param>
        /// <param name="match">The set of properties Reflection has determined to be a possible match, typically because they have the correct member name.</param>
        /// <param name="returnType">The return value the matching property must have.</param>
        /// <param name="indexes">The index types of the property being searched for. Used for index properties such as the indexer for a class.</param>
        /// <param name="modifiers">An array of parameter modifiers that enable binding to work with parameter signatures in which the types have been modified.</param>
        /// <returns>
        /// A <see cref="T:System.Reflection.PropertyInfo"></see> object containing the matching property.
        /// </returns>
        public override PropertyInfo SelectProperty(BindingFlags bindingAttr, PropertyInfo[] match, Type returnType, Type[] indexes, ParameterModifier[] modifiers)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Changes the type of the given Object to the given Type.
        /// </summary>
        /// <param name="value">The value to change into a new Type.</param>
        /// <param name="type">The new Type that value will become.</param>
        /// <param name="culture">An instance of <see cref="T:System.Globalization.CultureInfo"></see> used to control the coercion of data types. If culture is null, the <see cref="T:System.Globalization.CultureInfo"></see> for the current thread is used.For example, this parameter is necessary to convert a String that represents 1000 to a Double value, since 1000 is represented differently by different cultures.</param>
        /// <returns>
        /// An Object containing the given value as the new type.
        /// </returns>
        public override object ChangeType(object value, Type type, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Upon returning from <see cref="M:System.Reflection.Binder.BindToMethod(System.Reflection.BindingFlags,System.Reflection.MethodBase[],System.Object[]@,System.Reflection.ParameterModifier[],System.Globalization.CultureInfo,System.String[],System.Object@)"></see>, restores the args argument to what it was when it came from BindToMethod.
        /// </summary>
        /// <param name="args">The actual arguments passed in. Both the types and values of the arguments can be changed.</param>
        /// <param name="state">A binder-provided object that keeps track of argument reordering.</param>
        public override void ReorderArgumentArray(ref object[] args, object state)
        {
            throw new NotImplementedException();
        }
    }
}