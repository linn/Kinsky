//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Monobjc Bridge - Core Library")]
[assembly: AssemblyDescription("Monobjc Bridge Core Library")]
[assembly: AssemblyCompany("Monobjc Project")]
[assembly: AssemblyProduct("Monobjc Bridge Project")]
[assembly: AssemblyCopyright("Copyright � Monobjc Project 2007-2009 - Licensed under Lesser General Public License")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: ComVisible(false)]
[assembly: Guid("0315fc87-e820-485f-814d-7bd6e75b37ad")]
[assembly:
    InternalsVisibleTo(
        "NAnt.MonobjcTasks, PublicKey=002400000480000014010000060200000024000052534131000800000100010029ff8b97e0f14f02795956038102e307e09657b621712cf57a52af6f2517b17200da6c9367bca0c7aee33395de9a1e5b896122c7e7b698d399ae71fea931a30d4632968a7dd6b8044314207cfeabc8d929616c438758957e91adbe09199975eff73ce4e3a4ed6e97f7813578d007477fb42175f0a3f63597dd9d1cc59e136bb0cc8a14eca9c20d92c9743f0dc6f2e87f27b4c787008b2f721a6fef34445986995d873b08ff017d6bccef27ffd391a2d2699ed6c22ac1a72180e93a88a9068533145786511cc92fa914e97b014ed32df711ad23128b4287729911ba8d012490db356961d4dc5fd9d0517e6d6c20e379557803f45bb22ba16a19c746a4d5485dd1"
        )]
[assembly: AssemblyVersion("2.0.0.0")]