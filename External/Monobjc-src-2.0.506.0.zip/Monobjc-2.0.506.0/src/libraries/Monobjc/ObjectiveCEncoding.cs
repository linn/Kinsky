//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

namespace Monobjc
{
    /// <summary>
    /// <para>Utility class to handle encoding of types and methods. </para>
    /// </summary>
    public static class ObjectiveCEncoding
    {
        private const String ARRAY_PATTERN = "^{0}";
        private const String COLON = ":";
        private const String ENCODING_OFFSET = "{0}{1}";
        private const String INIT = "init";
        private const String STRUCT_END = "}";
        private const String STRUCT_START = "{{{0}=";
        private const String WITH = "With";

        private static readonly String SIGNATURE_PREFIX = String.Format(CultureInfo.CurrentCulture, "@0:{0}", IntPtr.Size);

        private static readonly IDictionary<Type, String> encodings = InitializeEncodings();
        private static readonly IDictionary<Type, int> sizes = InitializeSizes();
        private static readonly IDictionary<Type, int> alignements = InitializeAlignements();

        /// <summary>
        /// <para>Gets the selector for the given method or constructor.</para>
        /// <para>The selector for a method is build with the following rules:
        /// <list type="bullet">
        /// <item>Selector begins with the method name</item>
        /// <item>The first parameter if present is appended by its name with the "With" prefix</item>
        /// <item>The other parameters if present are appended by their names</item>
        /// </list>
        /// </para>
        /// <para>Here are some examples of result:
        /// <list type="table">
        /// <listheader>
        ///  <term>Method</term>
        ///  <description>Corresponding selector</description>
        ///  </listheader>
        /// <item>
        /// <term>public void DoThis()</term>
        /// <description>DoThis</description>
        /// </item>
        /// <item>
        /// <term>public void DoThis(int value)</term>
        /// <description>DoThisWithValue:</description>
        /// </item>
        /// <item>
        /// <term>public void DoThis(NSString str, int val)</term>
        /// <description>DoThisWithStr:val:</description>
        /// </item>
        /// </list>
        /// </para>
        /// <para>The selector for a constructor is build with the following rules:
        /// <list type="bullet">
        /// <item>Selector begins with "Init"</item>
        /// <item>The first parameter if present is appended by its name with the "With" prefix</item>
        /// <item>The other parameters if present are appended by their names</item>
        /// </list>
        /// </para>
        /// <para>Here are some examples of result:
        /// <list type="table">
        /// <listheader>
        /// <term>Constructor</term>
        /// <description>Corresponding selector</description>
        /// </listheader>
        /// <item>
        /// <term>public TestClass()</term>
        /// <description>Init</description>
        /// </item>
        /// <item>
        /// <term>public TestClass(int value)</term>
        /// <description>InitWithValue:</description>
        /// </item>
        /// <item>
        /// <term>public TestClass(NSString str, int val)</term>
        /// <description>InitWithStr:Val:</description>
        /// </item>
        /// </list>
        /// </para>
        /// </summary>
        /// <param name="methodBase">The method base.</param>
        /// <returns>
        /// A selector compliant with Objective-C messaging.
        /// </returns>
        public static String GetSelector(MethodBase methodBase)
        {
            if (methodBase == null)
            {
                throw new ArgumentNullException("methodBase");
            }

            StringBuilder builder = new StringBuilder();
            ParameterInfo[] parameters = methodBase.GetParameters();

            // Add name
            if (methodBase.IsConstructor)
            {
                builder.Append(INIT);
            }
            else
            {
                builder.Append(methodBase.Name);
            }

            for (int i = 0; i < parameters.Length; i++)
            {
                String name = parameters[i].Name;

                // If first parameter, use "With" prefix
                if (i == 0)
                {
                    builder.Append(WITH);
                    builder.Append(name.Substring(0, 1).ToUpperInvariant());
                    if (name.Length > 1)
                    {
                        builder.Append(name.Substring(1));
                    }
                }
                else
                {
                    builder.Append(name);
                }

                builder.Append(COLON);
            }

            return builder.ToString();
        }

        /// <summary>
        /// <para>Gets the signature for the given method or constructor.</para>
        /// <para>Constructors are considered as static method returning the declaring type.</para>
        /// <para>Here are some examples of result for methods:
        /// <list type="table">
        /// <listheader>
        /// <term>Method</term>
        /// <description>Corresponding signature (on IA32 architecture)</description>
        /// </listheader>
        /// <item>
        /// <term>public void DoThis()</term>
        /// <description>v8@0:4</description>
        /// </item>
        /// <item>
        /// <term>public void DoThis(int value)</term>
        /// <description>v12@0:4i8</description>
        /// </item>
        /// <item>
        /// <term>public void DoThis(NSString str, int val)</term>
        /// <description>v16@0:4@8i12</description>
        /// </item>
        /// </list>
        /// </para>
        /// <para>Here are some examples of result for constructor:
        /// <list type="table">
        /// <listheader>
        /// <term>Constructor</term>
        /// <description>Corresponding signature (on IA32 architecture)</description>
        /// </listheader>
        /// <item>
        /// <term>public TestClass()</term>
        /// <description>@8@0:4</description>
        /// </item>
        /// <item>
        /// <term>public TestClass(int value)</term>
        /// <description>@12@0:4i8</description>
        /// </item>
        /// <item>
        /// <term>public TestClass(NSString str, int val)</term>
        /// <description>@16@0:4@8i12</description>
        /// </item>
        /// </list>
        /// </para>
        /// </summary>
        /// <param name="methodBase">The method base.</param>
        /// <returns>
        /// A signature compliant with Objective-C messaging.
        /// </returns>
        public static String GetSignature(MethodBase methodBase)
        {
            if (methodBase == null)
            {
                throw new ArgumentNullException("methodBase");
            }

            StringBuilder builder = new StringBuilder();
            ParameterInfo[] parameters = methodBase.GetParameters();
            Type returnType = methodBase.IsConstructor ? methodBase.DeclaringType : ((MethodInfo) methodBase).ReturnType;

            // Add common prefix
            builder.Append(SIGNATURE_PREFIX);
            // Add self and SEL offsets
            int offset = IntPtr.Size*2;

            for (int i = 0; i < parameters.Length; i++)
            {
                Type type = parameters[i].ParameterType;
                builder.AppendFormat(CultureInfo.CurrentCulture, ENCODING_OFFSET, GetTypeEncoding(type), offset);
                // Add type size to offset 
                offset += GetTypeSize(type);
            }

            // Compute the return type encoding and offset
            String returnEncoding = String.Format(CultureInfo.CurrentCulture, ENCODING_OFFSET, GetTypeEncoding(returnType), offset);
            builder.Insert(0, returnEncoding);

            return builder.ToString();
        }

        /// <summary>
        /// <para>Return the Objective-C encoding used to build selector signature.</para>
        /// <para>Here are some examples of encoding:
        /// <list type="table">
        /// <listheader>
        /// <term>Type</term>
        /// <description>Corresponding encoding</description>
        /// </listheader>
        /// <item>
        /// <term>void</term>
        /// <description>v</description>
        /// </item>
        /// <item>
        /// <term>int or Int32</term>
        /// <description>i</description>
        /// </item>
        /// <item>
        /// <term>NSString</term>
        /// <description>@</description>
        /// </item>
        /// <item>
        /// <term>int[]</term>
        /// <description>^i</description>
        /// </item>
        /// <item>
        /// <term>NSRect</term>
        /// <description>{NSRect={NSPoint=ff}{NSSize=ff}}</description>
        /// </item>
        /// </list>
        /// </para>
        /// <para>For a full list of the encoding, refer to http://developer.apple.com/documentation/Cocoa/Conceptual/ObjectiveC/Articles/chapter_5_section_7.html</para>
        /// </summary>
        /// <param name="type">The type to encode.</param>
        /// <returns>The encoding representation</returns>
        public static String GetTypeEncoding(Type type)
        {
            if (type == null)
            {
                throw new ArgumentNullException("type");
            }

            // Check that type is a simple one
            if (encodings.ContainsKey(type))
            {
                return encodings[type];
            }

            // Arrays (only variable length)
            if (type.IsArray)
            {
                return String.Format(CultureInfo.CurrentCulture, ARRAY_PATTERN, GetTypeEncoding(type.GetElementType()));
            }

            // Get underlying type of Enum
            if (type.IsEnum)
            {
                return GetTypeEncoding(Enum.GetUnderlyingType(type));
            }

            // Structure
            if (type.IsValueType && !type.Namespace.Equals("System"))
            {
                StringBuilder builder = new StringBuilder();
                builder.AppendFormat(CultureInfo.CurrentCulture, STRUCT_START, type.Name);
                foreach (FieldInfo fieldInfo in type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                {
                    builder.Append(GetTypeEncoding(fieldInfo.FieldType));
                }
                builder.Append(STRUCT_END);
                return builder.ToString();
            }

            // Climb up the hierarchy until a valid type is found
            Type baseType = type.BaseType;
            while (baseType != null)
            {
                if (encodings.ContainsKey(baseType))
                {
                    return encodings[baseType];
                }
                baseType = baseType.BaseType;
            }

            return null;
        }

        /// <summary>
        /// <para>Return the native type size used to build selector signature. The value represents the size to use when the type is placed on the parameter stack.</para>
        /// <para>Here are some examples of sizes:
        /// <list type="table">
        /// <listheader>
        /// <term>Type</term>
        /// <description>Corresponding size (on IA32 architecture)</description>
        /// </listheader>
        /// <item>
        /// <term>bool or Boolean</term>
        /// <description>1</description>
        /// </item>
        /// <item>
        /// <term>int or Int32</term>
        /// <description>4</description>
        /// </item>
        /// <item>
        /// <term>NSString</term>
        /// <description>4</description>
        /// </item>
        /// <item>
        /// <term>NSRect</term>
        /// <description>16</description>
        /// </item>
        /// </list>
        /// </para>
        /// </summary>
        /// <para>Of course, the size value is platform dependant.</para>
        /// <param name="type">The type to measure.</param>
        /// <returns>The size value</returns>
        public static int GetTypeSize(Type type)
        {
            if (type == null)
            {
                throw new ArgumentNullException("type");
            }

            // Check that type is a simple one
            if (sizes.ContainsKey(type))
            {
                return sizes[type];
            }

            // Arrays (only variable length)
            if (type.IsArray)
            {
                return sizes[typeof (IntPtr)];
            }

            // Get underlying type of Enum
            if (type.IsEnum)
            {
                return GetTypeSize(Enum.GetUnderlyingType(type));
            }

            // Structure
            if (type.IsValueType && !type.Namespace.Equals("System"))
            {
                int size = 0;
                foreach (FieldInfo fieldInfo in type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                {
                    size += GetTypeSize(fieldInfo.FieldType);
                }
                return size;
            }

            // Climb up the hierarchy until a valid type is found
            Type baseType = type.BaseType;
            while (baseType != null)
            {
                if (sizes.ContainsKey(baseType))
                {
                    return sizes[baseType];
                }
                baseType = baseType.BaseType;
            }

            return -1;
        }

        /// <summary>
        /// <para>Return the native alignment used when adding an instance variable. The value represents the recommended alignment to use when the type is stored in the memory.</para>
        /// <para>Here are some examples of sizes:
        /// <list type="table">
        /// <listheader>
        /// <term>Type</term>
        /// <description>Corresponding alignment (on IA32 architecture)</description>
        /// </listheader>
        /// <item>
        /// <term>bool or Boolean</term>
        /// <description>1</description>
        /// </item>
        /// <item>
        /// <term>int or Int32</term>
        /// <description>4</description>
        /// </item>
        /// <item>
        /// <term>NSString</term>
        /// <description>4</description>
        /// </item>
        /// <item>
        /// <term>NSRect</term>
        /// <description>16</description>
        /// </item>
        /// </list>
        /// </para>
        /// </summary>
        /// <para>Of course, the alignment value is platform dependant.</para>
        /// <param name="type">The type to align.</param>
        /// <returns>The alignment value</returns>
        public static int GetTypeAlignment(Type type)
        {
            if (type == null)
            {
                throw new ArgumentNullException("type");
            }

            // Check that type is a simple one
            if (alignements.ContainsKey(type))
            {
                return alignements[type];
            }

            // Arrays (only variable length)
            if (type.IsArray)
            {
                return alignements[typeof (IntPtr)];
            }

            // Get underlying type of Enum
            if (type.IsEnum)
            {
                return GetTypeAlignment(Enum.GetUnderlyingType(type));
            }

            // Structure
            if (type.IsValueType && !type.Namespace.Equals("System"))
            {
                int alignment = 0;
                foreach (FieldInfo fieldInfo in type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                {
                    alignment = GetTypeAlignment(fieldInfo.FieldType);
                    break;
                }
                return alignment;
            }

            // Climb up the hierarchy until a valid type is found
            Type baseType = type.BaseType;
            while (baseType != null)
            {
                if (alignements.ContainsKey(baseType))
                {
                    return alignements[baseType];
                }
                baseType = baseType.BaseType;
            }

            return -1;
        }

        /// <summary>
        /// Initialize the encoding strings for base types.
        /// </summary>
        private static IDictionary<Type, String> InitializeEncodings()
        {
            IDictionary<Type, String> map = new Dictionary<Type, String>();

            map.Add(typeof (bool), "c"); // 1 byte storage, 4 byte on the stack
            map.Add(typeof (sbyte), "c"); // 1 byte storage (eq. C char)
            map.Add(typeof (byte), "C"); // 1 byte storage (eq. C unsigned char)

            map.Add(typeof (char), "S"); // unichar

            map.Add(typeof (short), "s");
            map.Add(typeof (int), "i");
            map.Add(typeof (long), "q");

            map.Add(typeof (ushort), "S");
            map.Add(typeof (uint), "I");
            map.Add(typeof (ulong), "Q");

            map.Add(typeof (float), "f");
            map.Add(typeof (double), "d");

            map.Add(typeof (void), "v");

            map.Add(typeof (String), "*");
            map.Add(typeof (Class), "#");
            map.Add(typeof (Id), "@");

            map.Add(typeof (IntPtr), "^");
            map.Add(typeof (Delegate), "?");

            return map;
        }

        /// <summary>
        /// Initialize the sizes for base types.
        /// </summary>
        private static IDictionary<Type, int> InitializeSizes()
        {
            IDictionary<Type, int> map = new Dictionary<Type, int>();

            map.Add(typeof (bool), Marshal.SizeOf(typeof (bool))); // 4 byte on the stack
            map.Add(typeof (sbyte), Marshal.SizeOf(typeof (sbyte))); // 1 byte storage (eq. C char)
            map.Add(typeof (byte), Marshal.SizeOf(typeof (byte))); // 1 byte storage (eq. C unsigned char)

            map.Add(typeof (char), Marshal.SizeOf(typeof (ushort))); // unichar

            map.Add(typeof (short), Marshal.SizeOf(typeof (short)));
            map.Add(typeof (int), Marshal.SizeOf(typeof (int)));
            map.Add(typeof (long), Marshal.SizeOf(typeof (long)));

            map.Add(typeof (ushort), Marshal.SizeOf(typeof (ushort)));
            map.Add(typeof (uint), Marshal.SizeOf(typeof (uint)));
            map.Add(typeof (ulong), Marshal.SizeOf(typeof (ulong)));

            map.Add(typeof (float), Marshal.SizeOf(typeof (float)));
            map.Add(typeof (double), Marshal.SizeOf(typeof (double)));

            map.Add(typeof (void), 1);

            map.Add(typeof (String), IntPtr.Size);
            map.Add(typeof (Class), IntPtr.Size);
            map.Add(typeof (Id), IntPtr.Size);

            map.Add(typeof (IntPtr), IntPtr.Size);
            map.Add(typeof (Delegate), IntPtr.Size);

            return map;
        }

        /// <summary>
        /// Initialize the alignements for base types.
        /// TODO : Compute alignement according to the platform.
        /// </summary>
        private static IDictionary<Type, int> InitializeAlignements()
        {
            IDictionary<Type, int> map = new Dictionary<Type, int>();

            map.Add(typeof (bool), Marshal.SizeOf(typeof (bool))); // 4 byte on the stack
            map.Add(typeof (sbyte), Marshal.SizeOf(typeof (sbyte))); // 4 byte on the stack
            map.Add(typeof (byte), Marshal.SizeOf(typeof (byte))); // 4 byte on the stack

            map.Add(typeof (char), Marshal.SizeOf(typeof (ushort))); // unichar

            map.Add(typeof (short), Marshal.SizeOf(typeof (short)));
            map.Add(typeof (int), Marshal.SizeOf(typeof (int)));
            map.Add(typeof (long), Marshal.SizeOf(typeof (long)));

            map.Add(typeof (ushort), Marshal.SizeOf(typeof (ushort)));
            map.Add(typeof (uint), Marshal.SizeOf(typeof (uint)));
            map.Add(typeof (ulong), Marshal.SizeOf(typeof (ulong)));

            map.Add(typeof (float), Marshal.SizeOf(typeof (float)));
            map.Add(typeof (double), Marshal.SizeOf(typeof (double)));

            map.Add(typeof (void), 1);

            map.Add(typeof (String), IntPtr.Size);
            map.Add(typeof (Class), IntPtr.Size);
            map.Add(typeof (Id), IntPtr.Size);

            map.Add(typeof (IntPtr), IntPtr.Size);
            map.Add(typeof (Delegate), IntPtr.Size);

            return map;
        }
    }
}