//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc
{
    /// <summary>
    /// <para>Flags to specify when the loaded image�s external symbols are bound to their definitions in dependent libraries (lazy or at load time) and the visibility of the image�s exported symbols (global or local). The value of this parameter is made up by ORing one binding behavior value with one visibility specification value.</para>
    /// </summary>
    [Flags]
    public enum RuntimeLoadingOptions
    {
        /// <summary>
        /// Each external symbol reference is bound the first time it�s used.
        /// </summary>
        Lazy = 0x01,
        /// <summary>
        /// All external symbol references are bound immediately.
        /// </summary>
        Now = 0x02,
        /// <summary>
        /// The loaded image�s exported symbols are available to any images that use a flat namespace or to calls to dlsym when using a special handle (see dlsym for details).
        /// </summary>
        Global = 0x04,
        /// <summary>
        /// The loaded image�s exported symbols are generally hidden. They are available only to dlsym invocations that use the handle returned by this function.
        /// </summary>
        Local = 0x08
    }
}