//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using Monobjc.Properties;

namespace Monobjc
{
    /// <summary>
    /// <para>Allows a constructor or a method to be exported as part of a native class within the Objective-C runtime.</para>
    /// <para>When the tagged type (with the <see cref="ObjectiveCClassAttribute"/>) is registered in the Objective-C
    /// runtime, all the tagged constructors and methods will be exported, which means they will be callable from
    /// native classes or instances.</para>
    /// </summary>
    /// 
    /// <example>
    /// <para>The following example shows how to use the <see cref="ObjectiveCMessageAttribute"/> attribute.</para>
    /// <code>
    /// [ObjectiveCClass]
    /// public class MyOwnType1 : NSObject
    /// {
    ///     [ObjectiveCMessage]
    ///     public ObjectiveCMessageAttribute(int a, int b)
    ///     {
    ///         ...
    ///     }
    /// 
    ///     [ObjectiveCMessage]
    ///     public int DoThis(bool value)
    ///     {
    ///         ...
    ///     }
    /// 
    ///     [ObjectiveCMessage("doSomeDummyThing:")]
    ///     public void DoDummy(String str)
    ///     {
    ///         ...
    ///     }
    ///     ...
    /// }
    /// </code>
    /// </example>
    [AttributeUsage(AttributeTargets.Constructor | AttributeTargets.Method)]
    public sealed class ObjectiveCMessageAttribute : Attribute
    {
        private readonly String selector;
        private bool synchronizeFields = true;

        /// <summary>
        /// <para>Initializes a new instance of the <see cref="ObjectiveCMessageAttribute"/> class.</para>
        /// </summary>
        public ObjectiveCMessageAttribute()
        {
            this.selector = String.Empty;
        }

        /// <summary>
        /// <para>Initializes a new instance of the <see cref="ObjectiveCMessageAttribute"/> class.</para>
        /// <para>Note: the selector MUST be an ANSI identifier.</para>
        /// </summary>
        /// <param name="selector">The selector to use.</param>
        public ObjectiveCMessageAttribute(String selector)
        {
            this.selector = selector;
        }

        /// <summary>
        /// <para>Gets the selector.</para>
        /// <para>Use the given selector when exporting the constructor or the method in the Objective-C runtime. The
        /// selector must conforms to the rules defined in the "The Objective-C Programming Language" and implemented by
        /// <see cref="ObjectiveCEncoding"/>.</para>
        /// </summary>
        /// <value>The selector to use.</value>
        public String Selector
        {
            get { return this.selector; }
        }

        /// <summary>
        /// <para>Gets or sets the signature.</para>
        /// <para>Use the given signature when exporting the constructor or the method in the Objective-C runtime. The
        /// signature must conforms to the type encoding defined in the "The Objective-C Programming Language" and
        /// implemented by <see cref="ObjectiveCEncoding"/>.</para>
        /// </summary>
        /// <value>The signature to use.</value>
        public string Signature { get; set; }

        /// <summary>
        /// <para>Gets or sets a value indicating whether to synchronize fields.</para>
        /// <para>When <c>true</c>, declared fields will be populated from their native counterpart before the
        /// method call, and will be exported to their native counterpart after the method call. See the
        /// <see cref="ObjectiveCFieldAttribute"/> to know about field export.</para>
        /// </summary>
        /// <value><c>true</c> if synchronization of fields has to be performed; otherwise, <c>false</c>.</value>
        public bool SynchronizeFields
        {
            get { return this.synchronizeFields; }
            set { this.synchronizeFields = value; }
        }

        /// <summary>
        /// <para>Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.</para>
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override String ToString()
        {
            return String.Format(CultureInfo.CurrentCulture,
                                 Resources.ObjectiveCMessageString,
                                 this.Selector,
                                 this.Signature,
                                 this.SynchronizeFields);
        }
    }
}