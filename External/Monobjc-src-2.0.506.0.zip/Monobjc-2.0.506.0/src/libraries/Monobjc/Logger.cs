//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc
{
    /// <summary>
    /// <para>Very basic logger that handles four levels of log.</para>
    /// <para>The levels are set through an environment variable <c>MONOBJC_DEBUG</c>. Output logs are printed in a Terminal console.</para>
    /// <para>The levels are :</para>
    /// <list type="table">
    /// <listheader>
    /// <term>Level</term><description>Associated Output</description>
    /// </listheader>
    /// <item>
    /// <term>TRACE (MONOBJC_DEBUG = 4)</term><description>Very low-level log (message passing, exhaustive cache content). Beware that this level will REALLY slow down the execution.</description>
    /// </item>
    /// <item>
    /// <term>DEBUG (MONOBJC_DEBUG &gt;= 3)</term><description>Low-level log (class registration, proxy creation, messaging, etc.). Beware that this level will slow down the execution.</description>
    /// </item>
    /// <item>
    /// <term>INFO (MONOBJC_DEBUG &gt;= 2)</term><description>Output informationnal log (bridge starting, architectre and runtime selection, statistics, etc.). Beware that this level may slow down the execution.</description>
    /// </item>
    /// <item>
    /// <term>WARN (MONOBJC_DEBUG &gt;= 1)</term><description>Output warning log. There is no noticeable impact</description>
    /// </item>
    /// <item>
    /// <term>ERROR (MONOBJC_DEBUG &gt;= 0 or not set)</term><description>Output error log. There is no noticeable impact</description>
    /// </item>
    /// </list>
    /// </summary>
    public static class Logger
    {
        private static readonly bool TRACE;
        private static readonly bool DEBUG;
        private static readonly bool INFO;
        private static readonly bool WARN;
        private const String FORMAT = "{0} [{1}] {2} - {3}";

        /// <summary>
        /// Initializes this instance.
        /// </summary>
        static Logger()
        {
            String debug = Environment.GetEnvironmentVariable("MONOBJC_DEBUG");
            int level;
            if (Int32.TryParse(debug, out level))
            {
                switch (level)
                {
                    case 4:
                        WARN = INFO = DEBUG = TRACE = true;
                        break;
                    case 3:
                        WARN = INFO = DEBUG = true;
                        break;
                    case 2:
                        WARN = INFO = true;
                        break;
                    case 1:
                        WARN = true;
                        break;
                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// Gets a value indicating whether trace level is enabled.
        /// </summary>
        /// <value><c>true</c> if trace is enabled; otherwise, <c>false</c>.</value>
        public static bool TraceEnabled
        {
            get { return TRACE; }
        }

        /// <summary>
        /// Gets a value indicating whether debug level is enabled.
        /// </summary>
        /// <value><c>true</c> if debug is enabled; otherwise, <c>false</c>.</value>
        public static bool DebugEnabled
        {
            get { return DEBUG; }
        }

        /// <summary>
        /// Gets a value indicating whether info level is enabled.
        /// </summary>
        /// <value><c>true</c> if info level enabled; otherwise, <c>false</c>.</value>
        public static bool InfoEnabled
        {
            get { return INFO; }
        }

        /// <summary>
        /// Gets a value indicating whether warn level is enabled.
        /// </summary>
        /// <value><c>true</c> if warn level enabled; otherwise, <c>false</c>.</value>
        public static bool WarnEnabled
        {
            get { return WARN; }
        }

        /// <summary>
        /// Outputs a TRACE log.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="message">The message.</param>
        public static void Trace(String source, String message)
        {
            if (TRACE)
            {
                Console.WriteLine(FORMAT, DateTime.Now.Ticks, "TRACE", source, message);
            }
        }

        /// <summary>
        /// Outputs a DEBUG log.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="message">The message.</param>
        public static void Debug(String source, String message)
        {
            if (DEBUG)
            {
                Console.WriteLine(FORMAT, DateTime.Now.Ticks, "DEBUG", source, message);
            }
        }

        /// <summary>
        /// Outputs an INFO log.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="message">The message.</param>
        public static void Info(String source, String message)
        {
            if (INFO)
            {
                Console.WriteLine(FORMAT, DateTime.Now.Ticks, "INFO ", source, message);
            }
        }

        /// <summary>
        /// Outputs a WARN log.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="message">The message.</param>
        public static void Warn(String source, String message)
        {
            if (WARN)
            {
                Console.WriteLine(FORMAT, DateTime.Now.Ticks, "WARN ", source, message);
            }
        }

        /// <summary>
        /// Outputs an ERROR log.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="message">The message.</param>
        public static void Error(String source, String message)
        {
            Console.WriteLine(FORMAT, DateTime.Now.Ticks, "ERROR", source, message);
        }
    }
}