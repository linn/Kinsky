//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using Monobjc.Bridge;
using Monobjc.Bridge.Generators;
using Monobjc.Properties;

namespace Monobjc
{
    /// <summary>
    /// <para>Entry point of the .NET/Objective-C bridge.</para>
    /// <para>The runtime is responsible for:
    /// <list type="bullet">
    /// <item>The mapping between managed type and Objective-C classes</item>
    /// <item>The mapping between managed instances and their native counterparts</item>
    /// <item>The sending of message from .NET to Objective-C</item>
    /// </list>
    /// </para>
    /// <para>A lot of magic occurs behind the scene to ensure that managed type and instances are seen as native
    /// in the Objective-C runtime.</para>
    /// </summary>
    public static partial class ObjectiveCRuntime
    {
        private static readonly IList<string> scannedAssemblies = InitializeAssembliesToSkip();
        private static readonly Dictionary<IntPtr, Id> instances = new Dictionary<IntPtr, Id>(512);

        private static bool initialized;
        private static ProxyGenerator proxyProvider;
        private static IWrapperProvider wrapperProvider;
        private static DynamicMessagingGenerator messagingProvider;

        /// <summary>
        /// <para>Initializes the .NET/Objective-C bridge with no class handler callback.</para>
        /// <para>This method must be called AFTER the loading of the native libraries (see <see cref="LoadLibrary"/>) and
        /// BEFORE any use of the Objective-C classes.</para>
        /// </summary>
        /// 
        /// <example>
        /// <para>The following code shows how to use the <see cref="Initialize()"/> method:</para>
        /// <code>
        /// using System;
        /// using Monobjc;
        ///
        /// namespace MyApplication
        /// {
        ///     internal class Program
        ///     {
        ///         public static int Main(String[] args)
        ///         {
        ///             ...
        /// 
        ///             ObjectiveCRuntime.LoadFramework("Cocoa");
        ///             ObjectiveCRuntime.Initialize();
        /// 
        ///             ...
        ///         }
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void Initialize()
        {
            // Allow multiple calls without issue
            if (initialized)
            {
                return;
            }
            initialized = true;

            if (Logger.InfoEnabled)
            {
                Logger.Info("ObjectiveCRuntime", "Initialize Bridge " + Assembly.GetExecutingAssembly().GetName().Version);
            }

            // Instantiate providers
            proxyProvider = new ProxyGenerator();
            proxyProvider.Init();
            wrapperProvider = new WrapperGenerator();
            wrapperProvider.Init();
            messagingProvider = new DynamicMessagingGenerator();
            messagingProvider.Init();

            // Be sure that every new assembly gets scanned
            AppDomain.CurrentDomain.AssemblyLoad += CurrentDomain_AssemblyLoad;

            // Scan all the assemblies to search for Id subclasses to register.
            // If they are not registered within the Objective-C Runtime, then define them.
            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                ScanAssembly(assembly);
            }
        }

        /// <summary>
        /// Save the generated code to files.
        /// </summary>
        public static void DumpDll()
        {
            messagingProvider.Save();
            proxyProvider.Save();
            wrapperProvider.Save();
        }

        /// <summary>
        /// Adds a specific assembly name to the already scanned assemblies list, preventing the runtime from scanning it for exported types when loaded.
        /// </summary>
        /// <param name="assemblyName">
        /// The name of the assembly (i.e. 'System.Remoting' is enough, no need for signing details). 
        /// </param>
        public static void DoNotScanAssembly(String assemblyName)
        {
            scannedAssemblies.Add(assemblyName);
        }

        /// <summary>
        /// Scans the given assembly for new managed proxies.
        /// </summary>
        private static void ScanAssembly(Assembly assembly)
        {
            String name = assembly.GetName().Name;

            // Skip the assembly scan if :
            // - it is in the exclusion list
            // - it has already been scanned
            if (scannedAssemblies.Contains(name))
            {
                return;
            }

            if (Logger.InfoEnabled)
            {
                Logger.Info("ObjectiveCRuntime", "Processing assembly '" + name + "'");
            }

            try
            {
                foreach (Type type in assembly.GetExportedTypes())
                {
                    // Type must be an Id subclass
                    if (!typeof(Id).IsAssignableFrom(type))
                    {
                        continue;
                    }

                    // Test for the ObjectiveCClass attribute
                    ObjectiveCClassAttribute objectiveCClassAttribute = Attribute.GetCustomAttribute(type, typeof(ObjectiveCClassAttribute), false) as ObjectiveCClassAttribute;
                    if (objectiveCClassAttribute == null)
                    {
                        continue;
                    }

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("ObjectiveCRuntime", "Registering '" + type + "'");
                    }

                    // Test for constructors :a  managed wrapper must have a default constructor
                    // and a constructor that takes an IntPtr parameter.
                    ConstructorInfo constructor = type.GetConstructor(Type.EmptyTypes);
                    if (constructor == null)
                    {
                        throw new ObjectiveCException(String.Format(CultureInfo.CurrentCulture, Resources.ExposedTypeMustHaveADefaultConstructor, type.FullName));
                    }
                    constructor = type.GetConstructor(new[] { typeof(IntPtr) });
                    if (constructor == null)
                    {
                        throw new ObjectiveCException(String.Format(CultureInfo.CurrentCulture, Resources.ExposedTypeMustHaveAConstructorWithIntPtrParameter, type.FullName));
                    }

                    // If present, register all the type hierarchy
                    Stack<Type> hierarchy = new Stack<Type>();

                    // Go bottom-up in the hierarchy until a registered type is found
                    Type currentType = type;
                    while (Class.GetClassFromType(currentType) == null)
                    {
                        hierarchy.Push(currentType);
                        currentType = currentType.BaseType;
                        if (currentType == typeof(Id))
                        {
                            break;
                        }
                    }

                    if (hierarchy.Count > 0)
                    {
                        // Go top-down in the hierarchy and register every type
                        while (hierarchy.Count > 0)
                        {
                            currentType = hierarchy.Pop();
                            DefineClass(currentType);
                        }
                    }
                }
            }
            catch (ObjectiveCException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Warn("ObjectiveCRuntime", "Failed to parse assembly '" + name + "'");
                Logger.Warn("ObjectiveCRuntime", "-> Exception was raised " + ex);
            }

            // Store name to avoid future scan
            scannedAssemblies.Add(name);
        }

        /// <summary>
        /// Handles the AssemblyLoad event of the CurrentDomain control.
        /// </summary>
        private static void CurrentDomain_AssemblyLoad(Object sender, AssemblyLoadEventArgs args)
        {
            if (Logger.DebugEnabled)
            {
                Logger.Debug("ObjectiveCRuntime", "Domain has loaded the '" + args.LoadedAssembly + "' assembly");
            }

            ScanAssembly(args.LoadedAssembly);
        }

        /// <summary>
        /// Initializes the assemblies to skip.
        /// </summary>
        /// <returns></returns>
        private static IList<String> InitializeAssembliesToSkip()
        {
            IList<String> list = new List<String>(64)
                                     {
                                         // Our own assemblies
                                         "Monobjc",
                                         "Monobjc.Dynamic.Messaging",
                                         "Monobjc.Dynamic.Proxies",
                                         "Monobjc.Dynamic.Wrappers",
                                         // .NET assemblies
                                         "mscorlib",
                                         "System",
                                         "System.Configuration",
                                         "System.Configuration.Install",
                                         "System.Core",
                                         "System.Data",
                                         "System.Data.OracleClient",
                                         "System.Design",
                                         "System.DirectoryServices",
                                         "System.Drawing",
                                         "System.Drawing.Design",
                                         "System.EnterpriseServices",
                                         "System.Management",
                                         "System.Messaging",
                                         "System.Runtime.Remoting",
                                         "System.Runtime.Serialization.Formatters.Soap",
                                         "System.Security",
                                         "System.ServiceProcess",
                                         "System.Transactions",
                                         "System.Web",
                                         "System.Web.Extensions.Design",
                                         "System.Web.Services",
                                         "System.Windows.Forms",
                                         "System.Xml",
                                         "System.Xml.Core",
                                         // Mono assemblies
                                         "Mono.C5",
                                         "Mono.Cairo",
                                         "Mono.Cecil",
                                         "Mono.Cecil.Mdb",
                                         "Mono.CompilerServices.SymbolWriter",
                                         "Mono.Data",
                                         "Mono.Data.Sqlite",
                                         "Mono.Data.SqliteClient",
                                         "Mono.Data.SybaseClient",
                                         "Mono.Data.Tds",
                                         "Mono.Data.TdsClient",
                                         "Mono.GetOptions",
                                         "Mono.Http",
                                         "Mono.Mozilla",
                                         "Mono.Posix",
                                         "Mono.Security",
                                         "Mono.Security.Win32",
                                         "Mono.WebServer",
                                         "Mono.WebServer2",
                                         // Microsoft assemblies
                                         "Microsoft.Build.Engine",
                                         "Microsoft.Build.Framework",
                                         "Microsoft.Build.Tasks",
                                         "Microsoft.Build.Utilities",
                                         "Microsoft.JScript",
                                         "Microsoft.VisualBasic",
                                         "Microsoft.VisualC",
                                         "Microsoft.Vsa",
                                         // NUnit assemblies
                                         "nunit.core",
                                         "nunit.framework",
                                         "nunit.util"
                                     };
            return list;
        }
    }
}