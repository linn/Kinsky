//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;

namespace Monobjc.Bridge.Loaders
{
    /// <summary>
    /// Wrapper provider for the .NET/Objective-C protocol proxies.
    /// </summary>
    internal class WrapperLoader : CodeLoader, IWrapperProvider
    {
        private readonly IDictionary<Type, Type> wrappers = new Dictionary<Type, Type>(64);

        /// <summary>
        /// Initializes a new instance of the <see cref="WrapperLoader"/> class.
        /// </summary>
        public WrapperLoader()
            : base("Monobjc.Dynamic.Wrappers", "ObjectiveCWrapperTypes") {}

        /// <summary>
        /// Load the assmebly from disk and populate the wrapper cache.
        /// </summary>
        public override void Init()
        {
            base.Init();

            // Parse assembly to populate the cache
            Type[] types = this.Module.FindTypes((type, criteria) => typeof (IManagedWrapper).IsAssignableFrom(type), null);
            foreach (Type wrapperType in types)
            {
                Type protocolType = (Type) wrapperType.GetField("PROTOCOL", BindingFlags.Public | BindingFlags.Static).GetValue(null);
                this.wrappers.Add(protocolType, wrapperType);
            }
        }

        /// <summary>
        /// Gets the wrapper for the given protocol class.
        /// </summary>
        /// <typeparam name="TClass">The protocol class.</typeparam>
        /// <returns>A managed wrapper class</returns>
        public Type GetWrapper<TClass>() where TClass : class, IManagedWrapper
        {
            Type type = typeof (TClass);

            // Return the cached copy
            if (this.wrappers.ContainsKey(type))
            {
                return this.wrappers[type];
            }

            // TODO: I18N
            throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, "No managed wrapper found for {0}", type.FullName));
        }
    }
}