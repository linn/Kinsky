// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using System.Collections.Generic;
using System.Reflection;

namespace Monobjc.Bridge.Generators
{
    /// <summary>
    /// Dynamic code generator for the Objective-C messaging.
    /// </summary>
    internal partial class MessagingGenerator : CodeGenerator
    {
        private const String INNER_CALL = "__native_call";
        private const String LIBOJC_DYLIB = "libobjc";
        private const String TYPE_BASE_PATTERN = "Monobjc.Dynamic.Messaging.{0} [{1}](";
        private const String TYPE_PART_PATTERN = ",";
        private const String TYPE_END_PATTERN = ")";
        private const char TYPE_SEPARATOR = '.';
        private const char NAME_SEPARATOR = '_';

        private readonly IDictionary<String, MethodInfo> messagingMethods = new Dictionary<String, MethodInfo>(64);

        /// <summary>
        /// Initializes a new instance of the <see cref="MessagingGenerator"/> class.
        /// </summary>
        public MessagingGenerator()
            : base("Monobjc.Dynamic.Messaging", "ObjectiveCMessagingTypes") {}

        /// <summary>
        /// Sends the message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="receiver">The receiver.</param>
        /// <param name="selector">The selector.</param>
        /// <param name="parameters">The parameters.</param>
        public void SendMessage(String message, IntPtr receiver, IntPtr selector, params Object[] parameters)
        {
            Type returnType = typeof (void);
            Object[] objects = MergeParameters(receiver, selector, parameters);
            Type[] types = GetParametersTypes(objects);
            String typeName = GetMessagingTypeName(message, returnType, types);

            // Fetch target type from cache
            MethodInfo invoker;
            if (this.messagingMethods.ContainsKey(typeName))
            {
                invoker = this.messagingMethods[typeName];
            }
            else
            {
                if (Logger.DebugEnabled)
                {
                    Logger.Debug("MessagingGenerator", "Generating Messaging Method : " + typeName);
                }
                invoker = this.DefineMessagingMethod(message, typeName, returnType, types);
                this.messagingMethods.Add(typeName, invoker);
            }

            //Call the P/Invoke method
            invoker.Invoke(null, objects);
        }

        /// <summary>
        /// Sends the message.
        /// </summary>
        /// <typeparam name="TReturnType">The type of the return type.</typeparam>
        /// <param name="message">The message.</param>
        /// <param name="receiver">The receiver.</param>
        /// <param name="selector">The selector.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public TReturnType SendMessage<TReturnType>(String message, IntPtr receiver, IntPtr selector, params Object[] parameters)
        {
            Type returnType = typeof (TReturnType);

            Object[] objects = MergeParameters(receiver, selector, parameters);
            Type[] types = GetParametersTypes(objects);
            String typeName = GetMessagingTypeName(message, returnType, types);

            // Fetch target type from cache
            MethodInfo invoker;
            if (this.messagingMethods.ContainsKey(typeName))
            {
                invoker = this.messagingMethods[typeName];
            }
            else
            {
                if (Logger.DebugEnabled)
                {
                    Logger.Debug("MessagingGenerator", "Generating Messaging Method : " + typeName);
                }
                invoker = this.DefineMessagingMethod(message, typeName, returnType, types);
                this.messagingMethods.Add(typeName, invoker);
            }

            //Call the P/Invoke methods
            TReturnType result = (TReturnType) invoker.Invoke(null, objects);

            return result;
        }

        /// <summary>
        /// Sends the message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="receiver">The receiver.</param>
        /// <param name="selector">The selector.</param>
        /// <param name="parameters">The parameters.</param>
        public void SendMessageVarArgs(String message, IntPtr receiver, IntPtr selector, params Object[] parameters)
        {
            Type returnType = typeof (void);
            Object[] objects = MergeParametersVarArgs(receiver, selector, parameters);
            Type[] types = GetParametersTypes(objects);
            String typeName = GetMessagingTypeName(message, returnType, types);

            // Fetch target type from cache
            MethodInfo invoker;
            if (this.messagingMethods.ContainsKey(typeName))
            {
                invoker = this.messagingMethods[typeName];
            }
            else
            {
                if (Logger.DebugEnabled)
                {
                    Logger.Debug("MessagingGenerator", "Generating Messaging Method : " + typeName);
                }
                invoker = this.DefineMessagingMethod(message, typeName, returnType, types);
                this.messagingMethods.Add(typeName, invoker);
            }

            // Call the P/Invoke method
            invoker.Invoke(null, objects);
        }

        /// <summary>
        /// Sends the message.
        /// </summary>
        /// <typeparam name="TReturnType">The type of the return type.</typeparam>
        /// <param name="message">The message.</param>
        /// <param name="receiver">The receiver.</param>
        /// <param name="selector">The selector.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public TReturnType SendMessageVarArgs<TReturnType>(String message, IntPtr receiver, IntPtr selector, params Object[] parameters)
        {
            Type returnType = typeof (TReturnType);

            Object[] objects = MergeParametersVarArgs(receiver, selector, parameters);
            Type[] types = GetParametersTypes(objects);
            String typeName = GetMessagingTypeName(message, returnType, types);

            // Fetch target type from cache
            MethodInfo invoker;
            if (this.messagingMethods.ContainsKey(typeName))
            {
                invoker = this.messagingMethods[typeName];
            }
            else
            {
                if (Logger.DebugEnabled)
                {
                    Logger.Debug("MessagingGenerator", "Generating Messaging Method : " + typeName);
                }
                invoker = this.DefineMessagingMethod(message, typeName, returnType, types);
                this.messagingMethods.Add(typeName, invoker);
            }

            // Call the P/Invoke methods
            TReturnType result = (TReturnType) invoker.Invoke(null, objects);

            return result;
        }
    }
}