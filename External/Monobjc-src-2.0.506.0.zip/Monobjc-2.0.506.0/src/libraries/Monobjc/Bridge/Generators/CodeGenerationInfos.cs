//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Reflection;
using System.Runtime.InteropServices;
using Monobjc.Utils;

namespace Monobjc.Bridge.Generators
{
    /// <summary>
    /// Contains definitions of the fields and methods that can be used during dynamic code generation.
    /// </summary>
    internal static class CodeGenerationInfos
    {
        /// <summary>
        /// FieldInfo for <see cref="IntPtr.Zero"/>.
        /// </summary>
        public static FieldInfo INTPTR_ZERO = typeof (IntPtr).GetField("Zero");

        /// <summary>
        /// ConstructorInfo for <see cref="IntPtr"/> constructor.
        /// </summary>
        public static ConstructorInfo INTPTR_INT64 = typeof (IntPtr).GetConstructor(new[] {typeof (long)});

        /// <summary>
        /// MethodInfo for <see cref="SafeNativeMethods"/>.<see cref="SafeNativeMethods.object_getInstanceVariable"/>.
        /// </summary>
        public static MethodInfo NATIVEMETHODS_GETINSTANCEVARIABLE = typeof (SafeNativeMethods).GetMethod("object_getInstanceVariable", new[] {typeof (IntPtr), typeof (String), typeof (IntPtr)});

        /// <summary>
        /// MethodInfo for <see cref="SafeNativeMethods"/>.<see cref="SafeNativeMethods.object_setInstanceVariable"/>.
        /// </summary>
        public static MethodInfo NATIVEMETHODS_SETINSTANCEVARIABLE = typeof (SafeNativeMethods).GetMethod("object_setInstanceVariable", new[] {typeof (IntPtr), typeof (String), typeof (IntPtr)});

        /// <summary>
        /// MethodInfo for <see cref="Class"/>.<see cref="Class.GetClassFromType"/> getter.
        /// </summary>
        public static MethodInfo CLASS_GETCLASSFROMTYPE = typeof (Class).GetMethod("GetClassFromType", new[] {typeof (Type)});

        /// <summary>
        /// MethodInfo for <see cref="IManagedWrapper"/>.<see cref="IManagedWrapper.NativePointer"/> getter.
        /// </summary>
        public static MethodInfo IMANAGEDWRAPPER_GETNATIVEPOINTER = typeof(IManagedWrapper).GetProperty("NativePointer").GetGetMethod();

        /// <summary>
        /// MethodInfo for <see cref="Id"/>.<see cref="Id.NativePointer"/> getter.
        /// </summary>
        public static MethodInfo ID_GETNATIVEPOINTER = typeof(Id).GetProperty("NativePointer").GetGetMethod();

        /// <summary>
        /// MethodInfo for <see cref="Id"/>.<see cref="Id.NativePointer"/> setter.
        /// </summary>
        public static MethodInfo ID_SETNATIVEPOINTER = typeof (Id).GetProperty("NativePointer").GetSetMethod();

        /// <summary>
        /// MethodInfo for <see cref="Id"/>.<see cref="Id.NativePointer"/> getter.
        /// </summary>
        public static ConstructorInfo ID_CONSTRUCTOR_INTPTR = typeof (Id).GetConstructor(new[] {typeof (IntPtr)});

        /// <summary>
        /// MethodInfo for <see cref="ObjectiveCRuntime"/>.<see cref="ObjectiveCRuntime.GetInstance{TClass}(IntPtr)"/>.
        /// </summary>
        public static MethodInfo OBJECTIVECRUNTIME_GETINSTANCE = typeof (ObjectiveCRuntime).GetMethod("GetInstance", new[] {typeof (IntPtr)});

        /// <summary>
        /// MethodInfo for <see cref="ObjectiveCRuntime"/>.<see cref="ObjectiveCRuntime.Selector(string)"/>.
        /// </summary>
        public static MethodInfo OBJECTIVECRUNTIME_SELECTOR = typeof (ObjectiveCRuntime).GetMethod("Selector", new[] {typeof (String)});

#if ENABLE_FAST_PATH
        /// <summary>
        /// MethodInfo for <see cref="ObjectiveCRuntime"/>.<see cref="ObjectiveCRuntime.SendMessage(IManagedWrapper,string)"/>.
        /// </summary>
        public static MethodInfo OBJECTIVECRUNTIME_SENDMESSAGE_VOID_NOARGS = typeof(ObjectiveCRuntime).GetMethod("SendMessage", BindingFlags.Public | BindingFlags.Static, new CustomMethodBinder(false), new[] { typeof(Id), typeof(String) }, null);
#endif

        /// <summary>
        /// MethodInfo for <see cref="ObjectiveCRuntime"/>.<see cref="ObjectiveCRuntime.SendMessage(IManagedWrapper,string,object[])"/>.
        /// </summary>
        public static MethodInfo OBJECTIVECRUNTIME_SENDMESSAGE_VOID_ARGS = typeof(ObjectiveCRuntime).GetMethod("SendMessage", BindingFlags.Public | BindingFlags.Static, new CustomMethodBinder(false), new[] { typeof(Id), typeof(String), typeof(Object[]) }, null);

#if ENABLE_FAST_PATH
        /// <summary>
        /// MethodInfo for <see cref="ObjectiveCRuntime"/>.<see cref="ObjectiveCRuntime.SendMessage{TReturnType}(IManagedWrapper,string)"/>.
        /// </summary>
        public static MethodInfo OBJECTIVECRUNTIME_SENDMESSAGE_NOARGS_GENERIC = typeof(ObjectiveCRuntime).GetMethod("SendMessage", BindingFlags.Public | BindingFlags.Static, new CustomMethodBinder(true), new[] { typeof(Id), typeof(String) }, null);
#endif

        /// <summary>
        /// MethodInfo for <see cref="ObjectiveCRuntime"/>.<see cref="ObjectiveCRuntime.SendMessage{TReturnType}(IManagedWrapper,string,object[])"/>.
        /// </summary>
        public static MethodInfo OBJECTIVECRUNTIME_SENDMESSAGE_ARGS_GENERIC = typeof(ObjectiveCRuntime).GetMethod("SendMessage", BindingFlags.Public | BindingFlags.Static, new CustomMethodBinder(true), new[] { typeof(Id), typeof(String), typeof(Object[]) }, null);

        /// <summary>
        /// MethodInfo for <see cref="Marshal"/>.<see cref="Marshal.AllocHGlobal(int)"/>.
        /// </summary>
        public static MethodInfo MARSHAL_ALLOCHGLOBAL = typeof (Marshal).GetMethod("AllocHGlobal", new[] {typeof (Int32)});

        /// <summary>
        /// MethodInfo for <see cref="Marshal"/>.<see cref="Marshal.FreeHGlobal"/>.
        /// </summary>
        public static MethodInfo MARSHAL_FREEHGLOBAL = typeof (Marshal).GetMethod("FreeHGlobal", new[] {typeof (IntPtr)});

        /// <summary>
        /// MethodInfo for <see cref="Marshal"/>.<see cref="Marshal.GetDelegateForFunctionPointer"/>.
        /// </summary>
        public static MethodInfo MARSHAL_GETDELEGATEFORFUNCTIONPOINTER = typeof (Marshal).GetMethod("GetDelegateForFunctionPointer", new[] {typeof (IntPtr), typeof (Type)});

        /// <summary>
        /// MethodInfo for <see cref="Marshal"/>.<see cref="Marshal.PtrToStructure(IntPtr,Type)"/>.
        /// </summary>
        public static MethodInfo MARSHAL_PTRTOSTRUCTURE = typeof (Marshal).GetMethod("PtrToStructure", new[] {typeof (IntPtr), typeof (Type)});

        /// <summary>
        /// MethodInfo for <see cref="Marshal"/>.<see cref="Marshal.ReadIntPtr(IntPtr)"/>.
        /// </summary>
        public static MethodInfo MARSHAL_READINTPTR = typeof (Marshal).GetMethod("ReadIntPtr", new[] {typeof (IntPtr)});

        /// <summary>
        /// MethodInfo for <see cref="Marshal"/>.<see cref="Marshal.SizeOf(Type)"/>.
        /// </summary>
        public static MethodInfo MARSHAL_SIZEOF = typeof (Marshal).GetMethod("SizeOf", new[] {typeof (Type)});

        /// <summary>
        /// MethodInfo for <see cref="Marshal"/>.<see cref="Marshal.StructureToPtr"/>.
        /// </summary>
        public static MethodInfo MARSHAL_STRUCTURETOPTR = typeof (Marshal).GetMethod("StructureToPtr", new[] {typeof (Object), typeof (IntPtr), typeof (bool)});

        /// <summary>
        /// MethodInfo for <see cref="Marshal"/>.<see cref="Marshal.WriteInt16(IntPtr,short)"/>.
        /// </summary>
        public static MethodInfo MARSHAL_WRITEINT16 = typeof (Marshal).GetMethod("WriteInt16", new[] {typeof (IntPtr), typeof (Int16)});

        /// <summary>
        /// MethodInfo for <see cref="Marshal"/>.<see cref="Marshal.WriteInt32(IntPtr,int)"/>.
        /// </summary>
        public static MethodInfo MARSHAL_WRITEINT32 = typeof (Marshal).GetMethod("WriteInt32", new[] {typeof (IntPtr), typeof (Int32)});

        /// <summary>
        /// MethodInfo for <see cref="Marshal"/>.<see cref="Marshal.WriteInt64(IntPtr,long)"/>.
        /// </summary>
        public static MethodInfo MARSHAL_WRITEINT64 = typeof (Marshal).GetMethod("WriteInt64", new[] {typeof (IntPtr), typeof (Int64)});

        /// <summary>
        /// MethodInfo for <see cref="Marshal"/>.<see cref="Marshal.WriteIntPtr(IntPtr,IntPtr)"/>.
        /// </summary>
        public static MethodInfo MARSHAL_WRITEINTPTR = typeof (Marshal).GetMethod("WriteIntPtr", new[] {typeof (IntPtr), typeof (IntPtr)});

        /// <summary>
        /// MethodInfo for <see cref="Type"/>.<see cref="Type.GetTypeFromHandle"/>.
        /// </summary>
        public static MethodInfo TYPE_GETTYPEFROMHANDLE = typeof (Type).GetMethod("GetTypeFromHandle", new[] {typeof (RuntimeTypeHandle)});
    }
}