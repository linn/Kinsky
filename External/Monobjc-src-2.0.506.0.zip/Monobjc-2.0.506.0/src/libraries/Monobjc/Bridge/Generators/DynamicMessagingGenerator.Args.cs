//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Reflection;

namespace Monobjc.Bridge.Generators
{
    partial class DynamicMessagingGenerator
    {
        private static readonly Type[] PLATFORM_INVOKE_ARGS_TYPES = new[] { typeof(IntPtr), typeof(IntPtr), typeof(Object[]) };
#if ENABLE_SHORT_KEY
        private readonly IDictionary<int, Delegate> messagingMethodsArgs = new Dictionary<int, Delegate>(64);
#else
        private readonly IDictionary<String, Delegate> messagingMethodsArgs = new Dictionary<String, Delegate>(64);
#endif

        /// <summary>
        /// Sends the message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="receiver">The receiver.</param>
        /// <param name="selector">The selector.</param>
        /// <param name="parameters">The parameters.</param>
        public void SendMessage(String message, IntPtr receiver, IntPtr selector, params Object[] parameters)
        {
            Type returnType = typeof (void);
            Type[] types = GetParametersTypes(parameters);
#if ENABLE_SHORT_KEY
            int typeName = GetMessagingTypeName(message, returnType, types);
#else
            String typeName = GetMessagingTypeName(message, returnType, types).ToString("X");
#endif
            // Fetch invoke from cache
            PlatformInvokeArgs invoker;

            lock (this.messagingMethodsArgs)
            {
                if (this.messagingMethodsArgs.ContainsKey(typeName))
                {
                    invoker = (PlatformInvokeArgs) this.messagingMethodsArgs[typeName];
                }
                else
                {
                    if (Logger.DebugEnabled)
                    {
                        String signature = GetMessagingSignature(message, returnType, types);
#if ENABLE_SHORT_KEY
                        Logger.Debug("MessagingGenerator", String.Format("Generating Messaging Method {0} => {1}", typeName.ToString("X"), signature));
#else
                        Logger.Debug("MessagingGenerator", String.Format("Generating Messaging Method {0} => {1}", typeName, signature));
#endif
                    }
#if ENABLE_SHORT_KEY
                    MethodInfo methodInfo = this.DefineMessagingDelegate(message, typeName.ToString("X"), types);
#else
                    MethodInfo methodInfo = this.DefineMessagingDelegate(message, typeName, types);
#endif
                    invoker = (PlatformInvokeArgs) Delegate.CreateDelegate(typeof (PlatformInvokeArgs), methodInfo);
                    this.messagingMethodsArgs.Add(typeName, invoker);
                }
            }

            // Call the P/Invoke method
            invoker(receiver, selector, parameters);
        }

        /// <summary>
        /// Sends the message.
        /// </summary>
        /// <typeparam name="TReturnType">The type of the return type.</typeparam>
        /// <param name="message">The message.</param>
        /// <param name="receiver">The receiver.</param>
        /// <param name="selector">The selector.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns>The result</returns>
        public TReturnType SendMessage<TReturnType>(String message, IntPtr receiver, IntPtr selector, params Object[] parameters)
        {
            Type returnType = typeof (TReturnType);
            Type[] types = GetParametersTypes(parameters);
#if ENABLE_SHORT_KEY
            int typeName = GetMessagingTypeName(message, returnType, types);
#else
            String typeName = GetMessagingTypeName(message, returnType, types).ToString("X");
#endif
            // Fetch invoke from cache
            PlatformInvokeArgs<TReturnType> invoker;

            lock (this.messagingMethodsArgs)
            {
                if (this.messagingMethodsArgs.ContainsKey(typeName))
                {
                    invoker = (PlatformInvokeArgs<TReturnType>) this.messagingMethodsArgs[typeName];
                }
                else
                {
                    if (Logger.DebugEnabled)
                    {
                        String signature = GetMessagingSignature(message, returnType, types);
#if ENABLE_SHORT_KEY
                        Logger.Debug("MessagingGenerator", String.Format("Generating Messaging Method {0} => {1}", typeName.ToString("X"), signature));
#else
                        Logger.Debug("MessagingGenerator", String.Format("Generating Messaging Method {0} => {1}", typeName, signature));
#endif
                    }
#if ENABLE_SHORT_KEY
                    MethodInfo methodInfo = this.DefineMessagingDelegate<TReturnType>(message, typeName.ToString("X"), types);
#else
                    MethodInfo methodInfo = this.DefineMessagingDelegate<TReturnType>(message, typeName, types);
#endif
                    invoker = (PlatformInvokeArgs<TReturnType>) Delegate.CreateDelegate(typeof (PlatformInvokeArgs<TReturnType>), methodInfo);
                    this.messagingMethodsArgs.Add(typeName, invoker);
                }
            }

            // Call the P/Invoke method
            return invoker(receiver, selector, parameters);
        }
    }
}