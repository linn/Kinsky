//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using Monobjc.Properties;
using Monobjc.Runtime;

namespace Monobjc.Bridge.Generators
{
    internal partial class DynamicMessagingGenerator
    {
        /// <summary>
        /// <para>Define a messaging method that have the following call stack:</para>
        /// <pre>
        /// - void objc_msgsend_XXXX(IntPtr receiver, IntPtr selector, Object[] parameters)
        /// - void __inner_call(IntPtr receiver, IntPtr selector, XXXX a);
        /// </pre>
        /// </summary>
        private MethodInfo DefineMessagingDelegate(String message, String typeName, Type[] parameterTypes)
        {
            // Create invocation type
            TypeBuilder typeBuilder = this.Module.DefineType(typeName, CodeGenerationAttributes.PUBLIC_STATIC_TYPE);

            // Generate the unmarshalling code
            EmitCodeForBlittableType(typeBuilder, message, message, typeof (void), parameterTypes);

            // Create the type to force the generation of the IL.
            Type type = typeBuilder.CreateType();

            // Retrieve the method by its name to have a correct MethodInfo reference
            MethodInfo methodInfo = type.GetMethod(message);

            return methodInfo;
        }

        /// <summary>
        /// <para>Define a messaging method that have the following call stack:</para>
        /// <pre>
        /// - TReturnType objc_msgsend_XXXX(IntPtr receiver, IntPtr selector, Object[] parameters)
        /// - TReturnType __inner_call(IntPtr receiver, IntPtr selector, XXXX a);
        /// </pre>
        /// </summary>
        private MethodInfo DefineMessagingDelegate<TReturnType>(String message, String typeName, Type[] parameterTypes)
        {
            Type returnType = typeof (TReturnType);

            // Create invocation type
            TypeBuilder typeBuilder = this.Module.DefineType(typeName, CodeGenerationAttributes.PUBLIC_STATIC_TYPE);

            // If return type is a wrapper, then generate the wrapping/unwrapping code
            if (NeedWrapping(returnType))
            {
                // Generate the unmarshalling code
                EmitCodeForWrappedType(typeBuilder, message, returnType, parameterTypes);
            }
            else if (ArchitectureCallingConventions.Current.IsStructure(returnType))
            {
                if (ArchitectureCallingConventions.Current.IsSmallStructure(returnType))
                {
                    // Generate the unmarshalling code
                    EmitCodeForSmallStructure(typeBuilder, message, returnType, parameterTypes);
                }
                else
                {
                    // Generate the unmarshalling code
                    EmitCodeForBigStructure(typeBuilder, message, returnType, parameterTypes);
                }
            }
            else
            {
                String nativeMessage = message;
                if (ArchitectureCallingConventions.Current.IsFloatingType(returnType))
                {
                    // Special case for floating point return type on Intel x86.
                    // The reason is described in the following post :
                    // http://lists.apple.com/archives/Objc-language/2006/Jun/msg00012.html
                    if (message.Equals(CodeGenerationConstants.OBJC_MSG_SEND))
                    {
                        nativeMessage = message + "_fpret";
                    }
                }

                // Generate the unmarshalling code
                EmitCodeForBlittableType(typeBuilder, message, nativeMessage, returnType, parameterTypes);
            }

            // Create the type to force the generation of the IL.
            Type type = typeBuilder.CreateType();

            // Retrieve the method by its name to have a correct MethodInfo reference
            MethodInfo methodInfo = type.GetMethod(message);

            return methodInfo;
        }

        private static void EmitCodeForWrappedType(TypeBuilder typeBuilder, String message, Type returnType, Type[] parameterTypes)
        {
            // Retrieve the MethodInfo from the native call
            MethodInfo nativeInvoker = DefineNativeCallMethod(typeBuilder,
                                                              INNER_CALL,
                                                              message,
                                                              typeof (IntPtr),
                                                              parameterTypes);

            // Retrieve the instance from the runtime :
            // - if it is a subclass of Id, use return type directly
            // - if it is an interface, cast it afterwards.
            MethodInfo retrieveInstance = CodeGenerationInfos.OBJECTIVECRUNTIME_GETINSTANCE.MakeGenericMethod(new[] {returnType.IsInterface ? typeof (Id) : returnType});

            // Create the wrapping/unwrapping method to wrap the arguments
            MethodBuilder callBuilder = DefineCallMethod(typeBuilder,
                                                         message,
                                                         returnType,
#if ENABLE_FAST_PATH
                                                         parameterTypes.Length> 0 ? PLATFORM_INVOKE_ARGS_TYPES : PLATFORM_INVOKE_NOARGS_TYPES);
#else
                                                         PLATFORM_INVOKE_ARGS_TYPES);
#endif

            // Emit OpCodes
            ILGenerator generator = callBuilder.GetILGenerator();

            // Loads parameters on the stack
            EmitManagedToNativeParametersLoadOnStack(generator, parameterTypes);

            // Make the native call
            generator.Emit(OpCodes.Call, nativeInvoker);

            // Retrieve wrapper for the result
            generator.Emit(OpCodes.Call, retrieveInstance);

            // Cast to interface if needed
            if (returnType.IsInterface)
            {
                generator.Emit(OpCodes.Castclass, returnType);
            }

            generator.Emit(OpCodes.Ret);
        }

        private static void EmitCodeForSmallStructure(TypeBuilder typeBuilder, String message, Type returnType, Type[] parameterTypes)
        {
            // Compute the size of the structure
            int size = Marshal.SizeOf(returnType);

            Type mapType;
            MethodInfo writeInvoker;
            switch (size)
            {
                case 2:
                    mapType = typeof (Int16);
                    writeInvoker = CodeGenerationInfos.MARSHAL_WRITEINT16;
                    break;
                case 4:
                    mapType = typeof (Int32);
                    writeInvoker = CodeGenerationInfos.MARSHAL_WRITEINT32;
                    break;
                case 8:
                    mapType = typeof (Int64);
                    writeInvoker = CodeGenerationInfos.MARSHAL_WRITEINT64;
                    break;
                default:
                    throw new ObjectiveCCodeGenerationException(
                        String.Format(CultureInfo.CurrentCulture, Resources.CannotGenerateCodeSmallStructureNotHandled, returnType.FullName));
            }

            // Retrieve the MethodInfo from the native call
            MethodInfo nativeInvoker = DefineNativeCallMethod(typeBuilder,
                                                              INNER_CALL,
                                                              message,
                                                              mapType,
                                                              parameterTypes);

            // Create the wrapping/unwrapping method to wrap the arguments
            MethodBuilder callBuilder = DefineCallMethod(typeBuilder,
                                                         message,
                                                         returnType,
#if ENABLE_FAST_PATH
                                                         parameterTypes.Length> 0 ? PLATFORM_INVOKE_ARGS_TYPES : PLATFORM_INVOKE_NOARGS_TYPES);
#else
                                                         PLATFORM_INVOKE_ARGS_TYPES);
#endif

            // Emit OpCodes
            ILGenerator generator = callBuilder.GetILGenerator();

            // Declare local variables
            LocalBuilder mapper = generator.DeclareLocal(mapType);
            LocalBuilder pointer = generator.DeclareLocal(typeof (IntPtr));
            LocalBuilder result = generator.DeclareLocal(returnType);

            // Loads parameters on the stack
            EmitManagedToNativeParametersLoadOnStack(generator, parameterTypes);

            // Make the native call
            generator.Emit(OpCodes.Call, nativeInvoker);
            generator.Emit(OpCodes.Stloc, mapper);

            // Allocates a native memory zone to hold the result
            generator.Emit(OpCodes.Ldc_I4, size);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_ALLOCHGLOBAL);
            generator.Emit(OpCodes.Stloc, pointer);

            // Copy native memory from result to temporary block
            generator.Emit(OpCodes.Ldloc, pointer);
            generator.Emit(OpCodes.Ldloc, mapper);
            generator.Emit(OpCodes.Call, writeInvoker);

            // Unmarshal structure to the return type
            generator.Emit(OpCodes.Ldloc, pointer);
            generator.Emit(OpCodes.Ldtoken, returnType);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.TYPE_GETTYPEFROMHANDLE);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_PTRTOSTRUCTURE);
            generator.Emit(OpCodes.Unbox_Any, returnType);
            generator.Emit(OpCodes.Stloc, result);

            // Release the native memory
            generator.Emit(OpCodes.Ldloc, pointer);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_FREEHGLOBAL);

            generator.Emit(OpCodes.Ldloc, result);
            generator.Emit(OpCodes.Ret);
        }

        private static void EmitCodeForBigStructure(TypeBuilder typeBuilder, String message, Type returnType, Type[] parameterTypes)
        {
            // Put return type as first parameter
            Type[] nativeParameterTypes = new Type[parameterTypes.Length + 1];
            nativeParameterTypes[0] = typeof (IntPtr);
            Array.Copy(parameterTypes, 0, nativeParameterTypes, 1, parameterTypes.Length);

            // Retrieve the MethodInfo from the native call
            MethodInfo nativeInvoker = DefineNativeCallMethod(typeBuilder,
                                                              INNER_CALL,
                                                              message + "_stret",
                                                              typeof (void),
                                                              nativeParameterTypes);

            // Create the wrapping/unwrapping method to wrap the arguments
            MethodBuilder callBuilder = DefineCallMethod(typeBuilder,
                                                         message,
                                                         returnType,
#if ENABLE_FAST_PATH
                                                         parameterTypes.Length> 0 ? PLATFORM_INVOKE_ARGS_TYPES : PLATFORM_INVOKE_NOARGS_TYPES);
#else
                                                         PLATFORM_INVOKE_ARGS_TYPES);
#endif

            // Emit OpCodes
            ILGenerator generator = callBuilder.GetILGenerator();

            // Declare local variables
            LocalBuilder pointer = generator.DeclareLocal(typeof (IntPtr));
            LocalBuilder result = generator.DeclareLocal(returnType);

            // Allocates a native memory zone to be passed to the native call
            generator.Emit(OpCodes.Ldtoken, returnType);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.TYPE_GETTYPEFROMHANDLE);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_SIZEOF);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_ALLOCHGLOBAL);
            generator.Emit(OpCodes.Stloc, pointer);

            // Loads parameters on the stack
            generator.Emit(OpCodes.Ldloc, pointer);
            EmitManagedToNativeParametersLoadOnStack(generator, parameterTypes);

            // Make the native call
            generator.Emit(OpCodes.Call, nativeInvoker);

            // Unmarshal the result from the native memory block
            generator.Emit(OpCodes.Ldloc, pointer);
            generator.Emit(OpCodes.Ldtoken, returnType);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.TYPE_GETTYPEFROMHANDLE);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_PTRTOSTRUCTURE);
            generator.Emit(OpCodes.Unbox_Any, returnType);
            generator.Emit(OpCodes.Stloc, result);

            // Release the native memory block
            generator.Emit(OpCodes.Ldloc, pointer);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_FREEHGLOBAL);

            generator.Emit(OpCodes.Ldloc, result);
            generator.Emit(OpCodes.Ret);
        }

        private static void EmitCodeForBlittableType(TypeBuilder typeBuilder, String message, String nativeMessage, Type returnType, Type[] parameterTypes)
        {
            // Retrieve the MethodInfo from the native call
            MethodInfo pinvokeMethodInfo = DefineNativeCallMethod(typeBuilder,
                                                                  INNER_CALL,
                                                                  nativeMessage,
                                                                  returnType,
                                                                  parameterTypes);

            // Create the wrapping/unwrapping method to wrap the arguments
            MethodBuilder messagingMethodInfo = DefineCallMethod(typeBuilder,
                                                                 message,
                                                                 returnType,
#if ENABLE_FAST_PATH
                                                                 parameterTypes.Length> 0 ? PLATFORM_INVOKE_ARGS_TYPES : PLATFORM_INVOKE_NOARGS_TYPES);
#else
                                                                 PLATFORM_INVOKE_ARGS_TYPES);
#endif

            // Emit OpCodes
            ILGenerator generator = messagingMethodInfo.GetILGenerator();
            // Loads parameters on the stack
            EmitManagedToNativeParametersLoadOnStack(generator, parameterTypes);
            // Make the native call
            generator.Emit(OpCodes.Call, pinvokeMethodInfo);
            // Return directly the result
            generator.Emit(OpCodes.Ret);
        }

        /// <summary>
        /// Emits the OpCodes for the parameter loading on the stack. Use first short OpCodes and then
        /// generic loading OpCodes.
        /// </summary>
        private static void EmitManagedToNativeParametersLoadOnStack(ILGenerator generator, Type[] parameterTypes)
        {
            // Always load the first two parameters
            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Ldarg_1);

            // Each parameter is extracted from an array
            // If the parameter needs wrapping, a test for null is made
            for (int i = 0; i < parameterTypes.Length; i++)
            {
                generator.Emit(OpCodes.Ldarg_2);
                generator.Emit(OpCodes.Ldc_I4, i);

                if (NeedWrapping(parameterTypes[i]))
                {
                    Label nullValueLabel = generator.DefineLabel();
                    Label continueLabel = generator.DefineLabel();

                    // Load the object reference and cast it to the type
                    generator.Emit(OpCodes.Ldelem_Ref);
                    generator.Emit(OpCodes.Castclass, parameterTypes[i]);

                    // Test the object reference for null, by duplicating the value below
                    generator.Emit(OpCodes.Dup);
                    generator.Emit(OpCodes.Ldnull);
                    generator.Emit(OpCodes.Beq_S, nullValueLabel);

                    // If the value is not null, extract the native pointer
                    generator.Emit(OpCodes.Call, CodeGenerationInfos.ID_GETNATIVEPOINTER);
                    generator.Emit(OpCodes.Br_S, continueLabel);

                    // If the value is null value, pop the remaining value and load a zero pointer instead
                    generator.MarkLabel(nullValueLabel);
                    generator.Emit(OpCodes.Pop);
                    generator.Emit(OpCodes.Ldsfld, CodeGenerationInfos.INTPTR_ZERO);

                    // Continue parameter loading
                    generator.MarkLabel(continueLabel);
                }
                else if (parameterTypes[i].IsValueType)
                {
                    // Performs an unboxing
                    generator.Emit(OpCodes.Ldelem_Ref);
                    generator.Emit(OpCodes.Unbox_Any, parameterTypes[i]);
                }
                else
                {
                    // Performs a cast
                    generator.Emit(OpCodes.Ldelem_Ref);
                    generator.Emit(OpCodes.Castclass, parameterTypes[i]);
                }
            }
        }

        /// <summary>
        /// Defines the call method builder.
        /// </summary>
        private static MethodBuilder DefineCallMethod(TypeBuilder typeBuilder,
                                                      String name,
                                                      Type returnType,
                                                      Type[] parameterTypes)
        {
            MethodBuilder builder = typeBuilder.DefineMethod(name,
                                                             CodeGenerationAttributes.PUBLIC_STATIC_METHOD,
                                                             returnType,
                                                             parameterTypes);
            builder.DefineParameter(1, ParameterAttributes.None, "receiver");
            builder.DefineParameter(2, ParameterAttributes.None, "selector");
            if (parameterTypes.Length > 2)
            {
                builder.DefineParameter(3, ParameterAttributes.None, "parameters");
            }
            return builder;
        }

        /// <summary>
        /// Defines the native call method. Each wrapped parameter will be replaced by an <see cref="IntPtr"/>.
        /// </summary>
        private static MethodBuilder DefineNativeCallMethod(TypeBuilder typeBuilder,
                                                            String name,
                                                            String entryPoint,
                                                            Type returnType,
                                                            Type[] parameterTypes)
        {
            // Transform wrapped parameters into pointer
            int i = 0;
            Type[] wrappedParametersTypes = new Type[parameterTypes.Length + 2];
            wrappedParametersTypes[i++] = typeof (IntPtr);
            wrappedParametersTypes[i++] = typeof (IntPtr);
            for (int j = 0; j < parameterTypes.Length; j++)
            {
                wrappedParametersTypes[i++] = NeedWrapping(parameterTypes[j]) ? typeof (IntPtr) : parameterTypes[j];
            }

            // Create the MethodInfo for the native call
            MethodBuilder builder = typeBuilder.DefinePInvokeMethod(name,
                                                                    LIBOJC_DYLIB,
                                                                    entryPoint,
                                                                    CodeGenerationAttributes.PRIVATE_STATIC_PINVOKE_METHOD,
                                                                    CallingConventions.Standard,
                                                                    returnType,
                                                                    wrappedParametersTypes,
                                                                    CallingConvention.StdCall,
                                                                    CharSet.Auto);
            builder.DefineParameter(1, ParameterAttributes.None, "receiver");
            builder.DefineParameter(2, ParameterAttributes.None, "selector");
            return builder;
        }
    }
}