//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Monobjc.Bridge.Generators
{
    internal partial class ProxyGenerator
    {
        /// <summary>
        /// Collect every public fields with an attribute. Traverse the hierachy to include parent's one.
        /// The import/export must contains all the fields.
        /// </summary>
        private static void CollectInstanceVariables(Type type, ICollection<VariableTuple> tuples)
        {
            foreach (FieldInfo fieldInfo in type.GetFields(BindingFlags.Public |
                                                           BindingFlags.Instance))
            {
                ObjectiveCFieldAttribute objectiveCFieldAttribute =
                    (ObjectiveCFieldAttribute) Attribute.GetCustomAttribute(fieldInfo, typeof (ObjectiveCFieldAttribute));
                if (objectiveCFieldAttribute != null)
                {
                    VariableTuple tuple = new VariableTuple();
                    tuple.fieldInfo = fieldInfo;
                    tuple.declared = (fieldInfo.DeclaringType.Equals(type));

                    // Fillin structure with attribute informations
                    tuple.name = String.IsNullOrEmpty(objectiveCFieldAttribute.Name) ? fieldInfo.Name : objectiveCFieldAttribute.Name;
                    tuple.encoding = ObjectiveCEncoding.GetTypeEncoding(fieldInfo.FieldType);
                    tuple.size = ObjectiveCEncoding.GetTypeSize(fieldInfo.FieldType);

                    tuples.Add(tuple);
                }
            }
        }

        /// <summary>
        /// Collect every public instance method with an attribute.
        /// </summary>
        private static void CollectInstanceMethods(Type type, ICollection<MethodTuple> tuples)
        {
            // Collect instance methods
            foreach (MethodInfo methodInfo in type.GetMethods(BindingFlags.Public |
                                                              BindingFlags.Instance |
                                                              BindingFlags.DeclaredOnly))
            {
                ObjectiveCMessageAttribute attribute =
                    (ObjectiveCMessageAttribute) Attribute.GetCustomAttribute(methodInfo, typeof (ObjectiveCMessageAttribute));
                if (attribute != null)
                {
                    MethodTuple methodTuple = new MethodTuple();
                    methodTuple.methodBase = methodInfo;
                    methodTuple.ObjectiveCMessageAttribute = attribute;

                    // Use provided values if any
                    String selector = attribute.Selector;
                    String signature = attribute.Signature;

                    // Compute value if needed
                    if (String.IsNullOrEmpty(selector))
                    {
                        selector = ObjectiveCEncoding.GetSelector(methodTuple.methodBase);
                    }
                    methodTuple.selector = selector;

                    // Compute value if needed
                    if (String.IsNullOrEmpty(signature))
                    {
                        signature = ObjectiveCEncoding.GetSignature(methodTuple.methodBase);
                    }
                    methodTuple.signature = signature;

                    tuples.Add(methodTuple);
                }
            }
        }

        /// <summary>
        /// Collect every public static method with an attribute.
        /// </summary>
        private static void CollectStaticMethods(Type type, ICollection<MethodTuple> tuples)
        {
            // Collect class methods
            foreach (MethodInfo methodInfo in type.GetMethods(BindingFlags.Public |
                                                              BindingFlags.Static |
                                                              BindingFlags.DeclaredOnly))
            {
                ObjectiveCMessageAttribute attribute =
                    (ObjectiveCMessageAttribute) Attribute.GetCustomAttribute(methodInfo, typeof (ObjectiveCMessageAttribute));
                if (attribute != null)
                {
                    MethodTuple methodTuple = new MethodTuple();
                    methodTuple.methodBase = methodInfo;
                    methodTuple.ObjectiveCMessageAttribute = attribute;

                    // Use provided values if any
                    String selector = attribute.Selector;
                    String signature = attribute.Signature;

                    // Compute value if needed
                    if (String.IsNullOrEmpty(selector))
                    {
                        selector = ObjectiveCEncoding.GetSelector(methodTuple.methodBase);
                    }
                    methodTuple.selector = selector;

                    // Compute value if needed
                    if (String.IsNullOrEmpty(signature))
                    {
                        signature = ObjectiveCEncoding.GetSignature(methodTuple.methodBase);
                    }
                    methodTuple.signature = signature;

                    tuples.Add(methodTuple);
                }
            }
        }

        /// <summary>
        /// Collect every public constructor with an attribute.
        /// </summary>
        private static void CollectConstructors(Type type, ICollection<MethodTuple> tuples)
        {
            // Collect constructors
            foreach (ConstructorInfo constructorInfo in type.GetConstructors())
            {
                ObjectiveCMessageAttribute ObjectiveCMessageAttribute =
                    (ObjectiveCMessageAttribute) Attribute.GetCustomAttribute(constructorInfo, typeof (ObjectiveCMessageAttribute));
                if (ObjectiveCMessageAttribute != null)
                {
                    MethodTuple methodTuple = new MethodTuple();
                    methodTuple.methodBase = constructorInfo;
                    methodTuple.ObjectiveCMessageAttribute = ObjectiveCMessageAttribute;
                    tuples.Add(methodTuple);
                }
            }
        }

        /// <summary>
        /// Gets the return type of a method or a constructor.
        /// </summary>
        private static Type GetReturnType(MethodBase methodBase)
        {
            if (methodBase.IsConstructor)
            {
                return methodBase.DeclaringType;
            }
            return ((MethodInfo) methodBase).ReturnType;
        }

        /// <summary>
        /// Generates a unique name for a method or a constructor.
        /// </summary>
        private static String GetUniqueName(MethodBase methodBase)
        {
            StringBuilder builder = new StringBuilder();
            if (methodBase.IsConstructor)
            {
                builder.Append("InitWith");
            }
            else
            {
                builder.Append(methodBase.Name);
            }

            ParameterInfo[] infos = methodBase.GetParameters();
            for (int i = 0; i < infos.Length; i++)
            {
                builder.Append(NAME_SEPARATOR);
                builder.Append(infos[i].ParameterType.FullName.Replace(TYPE_SEPARATOR, NAME_SEPARATOR));
            }

            return builder.ToString();
        }

        /// <summary>
        /// Gets an array containing the types of a method or a constructor.
        /// </summary>
        private static Type[] GetParametersTypes(MethodBase methodBase)
        {
            ParameterInfo[] parameters = methodBase.GetParameters();
            Type[] types = new Type[parameters.Length];
            for (int i = 0; i < parameters.Length; i++)
            {
                types[i] = parameters[i].ParameterType;
            }
            return types;
        }
    }
}