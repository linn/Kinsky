//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System.Reflection;

namespace Monobjc.Bridge.Generators
{
    /// <summary>
    /// Contains constants for dynamic code generation.
    /// </summary>
    internal static class CodeGenerationAttributes
    {
        /// <summary>
        /// Used to build a "public static" type, known as class type.
        /// </summary>
        public const TypeAttributes PUBLIC_STATIC_TYPE = TypeAttributes.Public |
                                                         TypeAttributes.Abstract |
                                                         TypeAttributes.AutoClass |
                                                         TypeAttributes.Sealed |
                                                         TypeAttributes.BeforeFieldInit;

        /// <summary>
        /// Used to build a "public" type, known as type.
        /// </summary>
        public const TypeAttributes PUBLIC_TYPE = TypeAttributes.Public |
                                                  TypeAttributes.AutoClass |
                                                  TypeAttributes.BeforeFieldInit;

        /// <summary>
        /// Used to build a constructor.
        /// </summary>
        public const MethodAttributes PUBLIC_CONSTRUCTOR = MethodAttributes.Public |
                                                           MethodAttributes.SpecialName |
                                                           MethodAttributes.RTSpecialName |
                                                           MethodAttributes.HideBySig;

        /// <summary>
        /// Used to build a "public" method.
        /// </summary>
        public const MethodAttributes ACCESSOR_METHOD = MethodAttributes.Public |
                                                        MethodAttributes.SpecialName |
                                                        MethodAttributes.NewSlot |
                                                        MethodAttributes.Virtual |
                                                        MethodAttributes.HideBySig;

        /// <summary>
        /// Used to build a "public" method.
        /// </summary>
        public const MethodAttributes PUBLIC_METHOD = MethodAttributes.Public |
                                                      MethodAttributes.NewSlot |
                                                      MethodAttributes.Virtual |
                                                      MethodAttributes.Final |
                                                      MethodAttributes.HideBySig;

        /// <summary>
        /// Used to build a "public virtual" method.
        /// </summary>
        public const MethodAttributes PUBLIC_VIRTUAL_METHOD = MethodAttributes.Public |
                                                              MethodAttributes.Virtual |
                                                              MethodAttributes.HideBySig;

        /// <summary>
        /// Used to build a "public static" method.
        /// </summary>
        public const MethodAttributes PUBLIC_STATIC_METHOD = MethodAttributes.Public |
                                                             MethodAttributes.Static |
                                                             MethodAttributes.HideBySig;

        /// <summary>
        /// Used to build a "public static" method that will be bound to a P/Invoke call.
        /// </summary>
        public const MethodAttributes PUBLIC_STATIC_PINVOKE_METHOD = MethodAttributes.Public |
                                                                     MethodAttributes.Static |
                                                                     MethodAttributes.PinvokeImpl |
                                                                     MethodAttributes.HideBySig;

        /// <summary>
        /// Used to build "public" nested delegate.
        /// </summary>
        public const TypeAttributes PUBLIC_NESTED_DELEGATE = TypeAttributes.NestedPublic |
                                                             TypeAttributes.Class |
                                                             TypeAttributes.Sealed |
                                                             TypeAttributes.AnsiClass |
                                                             TypeAttributes.AutoClass;

        /// <summary>
        /// Used to build a delegate method.
        /// </summary>
        public const MethodAttributes PUBLIC_DELEGATE_METHOD = MethodAttributes.Public |
                                                               MethodAttributes.HideBySig |
                                                               MethodAttributes.NewSlot |
                                                               MethodAttributes.Virtual;

        /// <summary>
        /// Used to build a "private static" method.
        /// </summary>
        public const MethodAttributes PRIVATE_STATIC_METHOD = MethodAttributes.Private |
                                                              MethodAttributes.Static |
                                                              MethodAttributes.HideBySig;

        /// <summary>
        /// Used to build a "private static" method that will be bound to a P/Invoke call.
        /// </summary>
        public const MethodAttributes PRIVATE_STATIC_PINVOKE_METHOD = MethodAttributes.Private |
                                                                      MethodAttributes.Static |
                                                                      MethodAttributes.PinvokeImpl |
                                                                      MethodAttributes.HideBySig;

        /// <summary>
        /// Used to build a "private static" constructor.
        /// </summary>
        public const MethodAttributes PRIVATE_STATIC_CONSTRUCTOR = MethodAttributes.Private |
                                                                   MethodAttributes.SpecialName |
                                                                   MethodAttributes.RTSpecialName |
                                                                   MethodAttributes.Static;

        /// <summary>
        /// Used to build a "private static" field.
        /// </summary>
        public const FieldAttributes PRIVATE_STATIC_FIELD = FieldAttributes.Private |
                                                            FieldAttributes.Static;
    }
}