//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Text;
using Monobjc.Properties;

namespace Monobjc.Bridge.Generators
{
    internal partial class DynamicMessagingGenerator
    {
        /// <summary>
        /// <para>Merge parameters, by flattening the var-args array.</para>
        /// <para>The last parameter passed must be an object array that contains a list of arguments.</para>
        /// </summary>
        private static Object[] MergeParametersVarArgs(IntPtr selector, Object[] parameters)
        {
            Object[] varargs = (parameters[parameters.Length - 1] as Object[]);
            if (varargs == null)
            {
                throw new ObjectiveCCodeGenerationException(String.Format(Resources.CannotCallVarargsMessage, ObjectiveCRuntime.Selector(selector)));
            }
            Object[] array = new Object[(parameters.Length - 1) + varargs.Length];
            Array.Copy(parameters, array, parameters.Length - 1);
            Array.Copy(varargs, 0, array, (parameters.Length - 1), varargs.Length);

            return array;
        }

        /// <summary>
        /// <para>Build an array of <see cref="Type"/> from the parameters.</para>
        /// </summary>
        private static Type[] GetParametersTypes(Object[] parameters)
        {
            Type[] types = new Type[parameters.Length];
            for (int i = 0; i < parameters.Length; i++)
            {
                types[i] = parameters[i] != null ? parameters[i].GetType() : typeof (Id);
            }
            return types;
        }

        /// <summary>
        /// <para>Computes the proxy name from the return type and the parameter types.</para>
        /// </summary>
        private static int GetMessagingTypeName(String message, Type returnType, Type[] parameters)
        {
            int value = 17;
            value = 37*value + message.GetHashCode();
            value = 37*value + returnType.GetHashCode();
            for (int i = 0; i < parameters.Length; i++)
            {
                value = 37*value + parameters[i].GetHashCode();
            }
            return value;
        }

        /// <summary>
        /// <para>Builds the signature from the return type and the parameter types.</para>
        /// <para>This is for debugging purpose</para>
        /// </summary>
        private static String GetMessagingSignature(String message, Type returnType, Type[] types)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(returnType);
            builder.Append(" ");
            builder.Append(message);
            builder.Append("(");
            for (int i = 0; i < types.Length; i++)
            {
                if (i > 0)
                {
                    builder.Append(", ");
                }
                builder.Append(types[i]);
            }
            builder.Append(")");
            return builder.ToString();
        }
    }
}