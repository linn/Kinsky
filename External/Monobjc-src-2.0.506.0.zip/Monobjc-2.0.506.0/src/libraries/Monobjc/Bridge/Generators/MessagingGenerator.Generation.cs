// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using Monobjc.Properties;
using Monobjc.Runtime;

namespace Monobjc.Bridge.Generators
{
    internal partial class MessagingGenerator
    {
        /// <summary>
        /// Create the proxy type with the P/Invoke definition that matches the return type and the parameter types.
        /// <para>There are five cases :</para>
        /// <list type="number">
        /// <item>The return type is a managed wrapper (Id subclass)</item>
        /// <item>The return type is a small structure (blittable in one CPU register)</item>
        /// <item>The return type is a big structure</item>
        /// <item>The return type is a floating point type (on x86 CPU)</item>
        /// <item>The return type is directly blittable</item>
        /// </list>
        /// </summary>
        private MethodInfo DefineMessagingMethod(String message, String typeName, Type returnType, params Type[] parameterTypes)
        {
            // Create invocation type
            TypeBuilder typeBuilder = this.Module.DefineType(typeName, CodeGenerationAttributes.PUBLIC_STATIC_TYPE);

            // If return type is a wrapper, then generate the wrapping/unwrapping code
            if (NeedWrapping(returnType))
            {
                EmitCodeForWrappedType(typeBuilder, message, returnType, parameterTypes);
            }
            else if (ArchitectureCallingConventions.Current.IsStructure(returnType))
            {
                if (ArchitectureCallingConventions.Current.IsSmallStructure(returnType))
                {
                    EmitCodeForSmallStructure(typeBuilder, message, returnType, parameterTypes);
                }
                else
                {
                    EmitCodeForBigStructure(typeBuilder, message, returnType, parameterTypes);
                }
            }
            else
            {
                String nativeMessage = message;
                if (ArchitectureCallingConventions.Current.IsFloatingType(returnType))
                {
                    // Special case for floating point return type on Intel x86.
                    // The reason is described in the following post :
                    // http://lists.apple.com/archives/Objc-language/2006/Jun/msg00012.html
                    if (message.Equals(CodeGenerationConstants.OBJC_MSG_SEND))
                    {
                        nativeMessage = message + "_fpret";
                    }
                }

                EmitCodeForBlittableType(typeBuilder, message, nativeMessage, returnType, parameterTypes);
            }

            // Create the type to generate the IL.
            Type type = typeBuilder.CreateType();

            // Add method to the map
            MethodInfo invoker = type.GetMethod(message, BindingFlags.Public | BindingFlags.Static, null, parameterTypes, null);

            return invoker;
        }

        private static void EmitCodeForWrappedType(TypeBuilder typeBuilder, String message, Type returnType, params Type[] parameterTypes)
        {
            // Retrieve the MethodInfo from the native call
            MethodInfo nativeInvoker = DefineNativeCallMethod(typeBuilder,
                                                              INNER_CALL,
                                                              message,
                                                              CodeGenerationAttributes.PRIVATE_STATIC_PINVOKE_METHOD,
                                                              typeof (IntPtr),
                                                              parameterTypes);

            // Retrieve the instance from the runtime :
            // - if it is a subclass of Id, use return type directly
            // - if it is an interface, cast it afterwards.
            MethodInfo retrieveInstance;
            if (returnType.IsInterface)
            {
                retrieveInstance = CodeGenerationInfos.OBJECTIVECRUNTIME_GETINSTANCE.MakeGenericMethod(new[] {typeof (Id)});
            }
            else
            {
                retrieveInstance = CodeGenerationInfos.OBJECTIVECRUNTIME_GETINSTANCE.MakeGenericMethod(new[] {returnType});
            }

            // Create the wrapping/unwrapping method to wrap the arguments
            MethodBuilder callBuilder = DefineCallMethod(typeBuilder,
                                                         message,
                                                         returnType,
                                                         parameterTypes);

            // Emit OpCodes
            ILGenerator generator = callBuilder.GetILGenerator();

            // Loads parameters on the stack
            EmitManagedToNativeParametersLoadOnStack(generator, parameterTypes);

            // Make the native call
            generator.Emit(OpCodes.Call, nativeInvoker);

            // Retrieve wrapper for the result
            generator.Emit(OpCodes.Call, retrieveInstance);

            // Cast to interface if needed
            if (returnType.IsInterface)
            {
                generator.Emit(OpCodes.Castclass, returnType);
            }

            generator.Emit(OpCodes.Ret);
        }

        private static void EmitCodeForSmallStructure(TypeBuilder typeBuilder, String message, Type returnType, params Type[] parameterTypes)
        {
            // Compute the size of the structure
            int size = Marshal.SizeOf(returnType);

            Type mapType;
            MethodInfo writeInvoker;
            switch (size)
            {
                case 2:
                    mapType = typeof (Int16);
                    writeInvoker = CodeGenerationInfos.MARSHAL_WRITEINT16;
                    break;
                case 4:
                    mapType = typeof (Int32);
                    writeInvoker = CodeGenerationInfos.MARSHAL_WRITEINT32;
                    break;
                case 8:
                    mapType = typeof (Int64);
                    writeInvoker = CodeGenerationInfos.MARSHAL_WRITEINT64;
                    break;
                default:
                    throw new ObjectiveCCodeGenerationException(
                        String.Format(CultureInfo.CurrentCulture, Resources.CannotGenerateCodeSmallStructureNotHandled, returnType.FullName));
            }

            // Retrieve the MethodInfo from the native call
            MethodInfo nativeInvoker = DefineNativeCallMethod(typeBuilder,
                                                              INNER_CALL,
                                                              message,
                                                              CodeGenerationAttributes.PRIVATE_STATIC_PINVOKE_METHOD,
                                                              mapType,
                                                              parameterTypes);

            // Create the wrapping/unwrapping method to wrap the arguments
            MethodBuilder callBuilder = DefineCallMethod(typeBuilder,
                                                         message,
                                                         returnType,
                                                         parameterTypes);

            // Emit OpCodes
            ILGenerator generator = callBuilder.GetILGenerator();

            // Declare local variables
            LocalBuilder mapper = generator.DeclareLocal(mapType);
            LocalBuilder pointer = generator.DeclareLocal(typeof (IntPtr));
            LocalBuilder result = generator.DeclareLocal(returnType);

            // Loads parameters on the stack
            EmitManagedToNativeParametersLoadOnStack(generator, parameterTypes);

            // Make the native call
            generator.Emit(OpCodes.Call, nativeInvoker);
            generator.Emit(OpCodes.Stloc, mapper);

            // Allocates a native memory zone to hold the result
            generator.Emit(OpCodes.Ldc_I4, size);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_ALLOCHGLOBAL);
            generator.Emit(OpCodes.Stloc, pointer);

            // Copy native memory from result to temporary block
            generator.Emit(OpCodes.Ldloc, pointer);
            generator.Emit(OpCodes.Ldloc, mapper);
            generator.Emit(OpCodes.Call, writeInvoker);

            // Unmarshal structure to the return type
            generator.Emit(OpCodes.Ldloc, pointer);
            generator.Emit(OpCodes.Ldtoken, returnType);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.TYPE_GETTYPEFROMHANDLE);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_PTRTOSTRUCTURE);
            generator.Emit(OpCodes.Unbox_Any, returnType);
            generator.Emit(OpCodes.Stloc, result);

            // Release the native memory
            generator.Emit(OpCodes.Ldloc, pointer);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_FREEHGLOBAL);

            generator.Emit(OpCodes.Ldloc, result);
            generator.Emit(OpCodes.Ret);
        }

        private static void EmitCodeForBigStructure(TypeBuilder typeBuilder, String message, Type returnType, params Type[] parameterTypes)
        {
            // Put return type as first parameter
            Type[] nativeParameterTypes = new Type[parameterTypes.Length + 1];
            nativeParameterTypes[0] = typeof (IntPtr);
            Array.Copy(parameterTypes, 0, nativeParameterTypes, 1, parameterTypes.Length);

            // Retrieve the MethodInfo from the native call
            MethodInfo nativeInvoker = DefineNativeCallMethod(typeBuilder,
                                                              INNER_CALL,
                                                              message + "_stret",
                                                              CodeGenerationAttributes.PRIVATE_STATIC_PINVOKE_METHOD,
                                                              typeof (void),
                                                              nativeParameterTypes);

            // Create the wrapping/unwrapping method to wrap the arguments
            MethodBuilder callBuilder = DefineCallMethod(typeBuilder,
                                                         message,
                                                         returnType,
                                                         parameterTypes);

            // Emit OpCodes
            ILGenerator generator = callBuilder.GetILGenerator();

            // Declare local variables
            LocalBuilder pointer = generator.DeclareLocal(typeof (IntPtr));
            LocalBuilder result = generator.DeclareLocal(returnType);

            // Allocates a native memory zone to be passed to the native call
            generator.Emit(OpCodes.Ldtoken, returnType);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.TYPE_GETTYPEFROMHANDLE);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_SIZEOF);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_ALLOCHGLOBAL);
            generator.Emit(OpCodes.Stloc, pointer);

            // Loads parameters on the stack
            generator.Emit(OpCodes.Ldloc, pointer);
            EmitManagedToNativeParametersLoadOnStack(generator, parameterTypes);

            // Make the native call
            generator.Emit(OpCodes.Call, nativeInvoker);

            // Unmarshal the result from the native memory block
            generator.Emit(OpCodes.Ldloc, pointer);
            generator.Emit(OpCodes.Ldtoken, returnType);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.TYPE_GETTYPEFROMHANDLE);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_PTRTOSTRUCTURE);
            generator.Emit(OpCodes.Unbox_Any, returnType);
            generator.Emit(OpCodes.Stloc, result);

            // Release the native memory block
            generator.Emit(OpCodes.Ldloc, pointer);
            generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_FREEHGLOBAL);

            generator.Emit(OpCodes.Ldloc, result);
            generator.Emit(OpCodes.Ret);
        }

        private static void EmitCodeForBlittableType(TypeBuilder typeBuilder, String message, String nativeMessage, Type returnType,
                                                     params Type[] parameterTypes)
        {
            // If at least one parameter need wrapping/unwrapping, then generate the wrapping/unwrapping code
            if (NeedWrapping(parameterTypes))
            {
                // Retrieve the MethodInfo from the native call
                MethodInfo nativeInvoker = DefineNativeCallMethod(typeBuilder,
                                                                  INNER_CALL,
                                                                  nativeMessage,
                                                                  CodeGenerationAttributes.PRIVATE_STATIC_PINVOKE_METHOD,
                                                                  returnType,
                                                                  parameterTypes);

                // Create the wrapping/unwrapping method to wrap the arguments
                MethodBuilder callBuilder = DefineCallMethod(typeBuilder,
                                                             message,
                                                             returnType,
                                                             parameterTypes);

                // Emit OpCodes
                ILGenerator generator = callBuilder.GetILGenerator();

                // Loads parameters on the stack
                EmitManagedToNativeParametersLoadOnStack(generator, parameterTypes);

                // Make the native call
                generator.Emit(OpCodes.Call, nativeInvoker);

                // Return directly the result
                generator.Emit(OpCodes.Ret);
            }
            else
            {
                // No wrapping at all is required, so the P/Invoke is done directly
                DefineNativeCallMethod(typeBuilder,
                                       message,
                                       nativeMessage,
                                       CodeGenerationAttributes.PUBLIC_STATIC_PINVOKE_METHOD,
                                       returnType,
                                       parameterTypes);
            }
        }

        /// <summary>
        /// Emits the OpCodes for the parameter loading on the stack. Use first short OpCodes and then
        /// generic loading OpCodes.
        /// </summary>
        private static void EmitManagedToNativeParametersLoadOnStack(ILGenerator generator, params Type[] parameterTypes)
        {
            // Always two first parameters
            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Ldarg_1);

            // For the third parameter, use the short OpCode
            // For the fourth parameter, use the short OpCode
            // For the parameters left, use the long OpCode
            for (int i = 2; i < parameterTypes.Length; i++)
            {
                // For wrapped type (interface or Id subclass)
                if (NeedWrapping(parameterTypes[i]))
                {
                    Label nullValueLabel = generator.DefineLabel();
                    Label continueLabel = generator.DefineLabel();

                    // Load on the stack for test
                    switch (i)
                    {
                        case 2:
                            generator.Emit(OpCodes.Ldarg_2);
                            break;
                        case 3:
                            generator.Emit(OpCodes.Ldarg_3);
                            break;
                        default:
                            generator.Emit(OpCodes.Ldarg_S, i);
                            break;
                    }

                    // Test for nullity
                    generator.Emit(OpCodes.Ldnull);
                    generator.Emit(OpCodes.Beq_S, nullValueLabel);

                    // If not null, reload it on the stack
                    switch (i)
                    {
                        case 2:
                            generator.Emit(OpCodes.Ldarg_2);
                            break;
                        case 3:
                            generator.Emit(OpCodes.Ldarg_3);
                            break;
                        default:
                            generator.Emit(OpCodes.Ldarg_S, i);
                            break;
                    }

                    // Cast it if necessary and extract the pointer
                    if (parameterTypes[i].IsInterface)
                    {
                        generator.Emit(OpCodes.Castclass, typeof (Id));
                    }
                    generator.Emit(OpCodes.Call, CodeGenerationInfos.ID_GETNATIVEPOINTER);
                    generator.Emit(OpCodes.Br_S, continueLabel);

                    // If it is a null value, load a zero pointer
                    generator.MarkLabel(nullValueLabel);
                    generator.Emit(OpCodes.Ldsfld, CodeGenerationInfos.INTPTR_ZERO);

                    // Continue parameter loading
                    generator.MarkLabel(continueLabel);
                }
                else
                {
                    switch (i)
                    {
                        case 2:
                            generator.Emit(OpCodes.Ldarg_2);
                            break;
                        case 3:
                            generator.Emit(OpCodes.Ldarg_3);
                            break;
                        default:
                            generator.Emit(OpCodes.Ldarg_S, i);
                            break;
                    }
                }
            }
        }

        private static MethodBuilder DefineCallMethod(TypeBuilder typeBuilder,
                                                      String name,
                                                      Type returnType,
                                                      params Type[] parameterTypes)
        {
            MethodBuilder builder = typeBuilder.DefineMethod(name,
                                                             CodeGenerationAttributes.PUBLIC_STATIC_METHOD,
                                                             returnType,
                                                             parameterTypes);
            builder.DefineParameter(1, ParameterAttributes.None, "receiver");
            builder.DefineParameter(2, ParameterAttributes.None, "selector");
            return builder;
        }

        private static MethodBuilder DefineNativeCallMethod(TypeBuilder typeBuilder,
                                                            String name,
                                                            String entryPoint,
                                                            MethodAttributes attributes,
                                                            Type returnType,
                                                            params Type[] parameterTypes)
        {
            // Transform wrapped instance into pointer
            Type[] wrappedParametersTypes = new Type[parameterTypes.Length];
            Array.Copy(parameterTypes, wrappedParametersTypes, parameterTypes.Length);
            for (int i = 2; i < parameterTypes.Length; i++)
            {
                if (NeedWrapping(parameterTypes[i]))
                {
                    wrappedParametersTypes[i] = typeof (IntPtr);
                }
            }

            // Retrieve the MethodInfo from the native call
            MethodBuilder builder = typeBuilder.DefinePInvokeMethod(name,
                                                                    LIBOJC_DYLIB,
                                                                    entryPoint,
                                                                    attributes,
                                                                    CallingConventions.Standard,
                                                                    returnType,
                                                                    wrappedParametersTypes,
                                                                    CallingConvention.StdCall,
                                                                    CharSet.Auto);
            builder.DefineParameter(1, ParameterAttributes.None, "receiver");
            builder.DefineParameter(2, ParameterAttributes.None, "selector");
            return builder;
        }
    }
}