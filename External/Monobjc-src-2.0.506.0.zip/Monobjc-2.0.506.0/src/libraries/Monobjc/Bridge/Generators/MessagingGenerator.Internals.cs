// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using System.Globalization;
using System.Text;
using Monobjc.Properties;

namespace Monobjc.Bridge.Generators
{
    internal partial class MessagingGenerator
    {
        /// <summary>
        /// <para>Merge parameters, by inserting the receiver and the selector before.</para>
        /// </summary>
        private static Object[] MergeParameters(IntPtr receiver, IntPtr selector, params Object[] parameters)
        {
            Object[] array = new Object[2 + parameters.Length];
            array[0] = receiver;
            array[1] = selector;
            Array.Copy(parameters, 0, array, 2, parameters.Length);

            return array;
        }

        /// <summary>
        /// <para>Merge parameters, by inserting the receiver and the selector before.</para>
        /// <para>The last parameter passed must be an object array that contains a list of arguments.</para>
        /// </summary>
        private static Object[] MergeParametersVarArgs(IntPtr receiver, IntPtr selector, params Object[] parameters)
        {
            Object[] varargs = (parameters[parameters.Length - 1] as Object[]);
            if (varargs == null)
            {
                throw new ObjectiveCCodeGenerationException(String.Format(Resources.CannotCallVarargsMessage, ObjectiveCRuntime.Selector(selector)));
            }
            Object[] array = new Object[2 + (parameters.Length - 1) + varargs.Length];
            array[0] = receiver;
            array[1] = selector;
            Array.Copy(parameters, 0, array, 2, parameters.Length - 1);
            Array.Copy(varargs, 0, array, 2 + (parameters.Length - 1), varargs.Length);

            return array;
        }

        /// <summary>
        /// <para>Build an array of <see cref="Type"/> from the parameters.</para>
        /// </summary>
        private static Type[] GetParametersTypes(params Object[] parameters)
        {
            Type[] types = new Type[parameters.Length];
            for (int i = 0; i < parameters.Length; i++)
            {
                types[i] = parameters[i] != null ? parameters[i].GetType() : typeof (Id);
            }
            return types;
        }

        /// <summary>
        /// <para>Computes the proxy name from the return type and the parameter types.</para>
        /// </summary>
        private static String GetMessagingTypeName(String message, Type returnType, params Type[] parameters)
        {
            StringBuilder typeName = new StringBuilder();
            typeName.AppendFormat(CultureInfo.CurrentCulture, TYPE_BASE_PATTERN, message.ToUpperInvariant(), returnType.FullName.Replace(TYPE_SEPARATOR, NAME_SEPARATOR));
            for (int i = 2; i < parameters.Length; i++)
            {
                if (i > 2)
                {
                    typeName.Append(TYPE_PART_PATTERN);
                }
                typeName.Append(parameters[i].FullName.Replace(TYPE_SEPARATOR, NAME_SEPARATOR));
            }
            typeName.Append(TYPE_END_PATTERN);
            return typeName.ToString();
        }
    }
}