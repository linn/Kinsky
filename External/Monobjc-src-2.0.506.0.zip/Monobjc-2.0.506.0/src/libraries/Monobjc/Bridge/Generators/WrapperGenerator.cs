//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using Monobjc.Properties;

namespace Monobjc.Bridge.Generators
{
    /// <summary>
    /// Dynamic code generator for the .NET/Objective-C protocol proxies.
    /// </summary>
    internal partial class WrapperGenerator : CodeGenerator, IWrapperProvider
    {
        private const String WRAPPER_NAME_PATTERN = "Monobjc.Dynamic.Wrappers.{0}Impl";
        private readonly IDictionary<Type, Type> wrappers = new Dictionary<Type, Type>(64);

        /// <summary>
        /// Initializes a new instance of the <see cref="ProxyGenerator"/> class.
        /// </summary>
        public WrapperGenerator()
            : base("Monobjc.Dynamic.Wrappers", "ObjectiveCWrapperTypes") { }

        /// <summary>
        /// <para>Entry point for creating protocol wrapper.</para>
        /// <para>The given type must:
        /// <list type="bullet">
        /// <item>be an interface (defining a protocol for example)</item>
        /// <item>be tagged with the <see cref="ObjectiveCProtocolAttribute"/> attribute</item>
        /// <item>contains methods tagged with a <see cref="ObjectiveCMessageAttribute"/> attribute</item>
        /// <item>implements IManagedWrapper interface</item>
        /// </list>
        /// </para>
        /// </summary>
        /// <exception cref="ArgumentNullException">If the type is null</exception>
        /// <exception cref="ArgumentException">If the type is not an interface, if the type does not inherits from <see cref="IManagedWrapper"/> or if the type has no <see cref="ObjectiveCProtocolAttribute"/> attribute.</exception>
        public Type GetWrapper<TClass>() where TClass : class, IManagedWrapper
        {
            Type type = typeof(TClass);

            if (!type.IsInterface)
            {
                throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, Resources.TypeIsNotAnInterface, type.FullName));
            }
            if (!typeof(IManagedWrapper).IsAssignableFrom(type))
            {
                throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, Resources.TypeDoesNotInheritsFromIManagedWrapper, type.FullName));
            }

            lock (this.wrappers)
            {
                Type wrapper;

                // Return the cached copy
                if (this.wrappers.ContainsKey(type))
                {
                    wrapper = this.wrappers[type];
                }
                else
                {
                    // Check that the type has the required attribute
                    ObjectiveCProtocolAttribute protocolAttribute = Attribute.GetCustomAttribute(type, typeof (ObjectiveCProtocolAttribute)) as ObjectiveCProtocolAttribute;
                    if (protocolAttribute == null)
                    {
                        throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, Resources.TypeHasNoObjectiveCProtocolAttribute, type.FullName));
                    }

                    // Compute the name of the wrapper
                    String name = protocolAttribute.Name;
                    if (String.IsNullOrEmpty(name))
                    {
                        name = type.FullName;
                    }
                    String typeName = String.Format(CultureInfo.CurrentCulture, WRAPPER_NAME_PATTERN, name);

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("WrapperGenerator", "Generating Protocol Wrapper : " + typeName);
                    }

                    // Declare the wrapper type
                    TypeBuilder typeBuilder = this.Module.DefineType(typeName, CodeGenerationAttributes.PUBLIC_TYPE, typeof (Id));
                    typeBuilder.AddInterfaceImplementation(typeof (IManagedWrapper));
                    typeBuilder.AddInterfaceImplementation(type);

                    // Define an empty constructor
                    typeBuilder.DefineDefaultConstructor(CodeGenerationAttributes.PUBLIC_CONSTRUCTOR);

                    // Define a constructor with an IntPtr argument
                    ConstructorBuilder constructorBuilder = typeBuilder.DefineConstructor(CodeGenerationAttributes.PUBLIC_CONSTRUCTOR, CallingConventions.Standard, new[] {typeof (IntPtr)});
                    constructorBuilder.DefineParameter(1, ParameterAttributes.None, "nativePointer");
                    ILGenerator generator = constructorBuilder.GetILGenerator();
                    generator.Emit(OpCodes.Ldarg_0);
                    generator.Emit(OpCodes.Ldarg_1);
                    generator.Emit(OpCodes.Call, CodeGenerationInfos.ID_CONSTRUCTOR_INTPTR);
                    generator.Emit(OpCodes.Ret);

                    // Gets a list of methods
                    MethodInfo[] methods = type.GetMethods(BindingFlags.Public |
                                                           BindingFlags.Instance);

                    // Implements each interface method
                    // Method must be tagged properly
                    foreach (MethodInfo methodInfo in methods)
                    {
                        if (!methodInfo.Name.StartsWith("get_", StringComparison.InvariantCulture) &&
                            !methodInfo.Name.StartsWith("set_", StringComparison.InvariantCulture))
                        {
                            String message = CheckMethod(methodInfo);
                            ParameterInfo[] parameterInfos = methodInfo.GetParameters();
                            Type[] parameterTypes = GetParameterTypes(methodInfo);

                            // Define the implementation method
                            MethodBuilder methodBuilder = typeBuilder.DefineMethod(methodInfo.Name,
                                                                                   CodeGenerationAttributes.PUBLIC_METHOD,
                                                                                   methodInfo.ReturnType,
                                                                                   parameterTypes);
                            // Copy parameter names
                            for (int i = 0; i < parameterInfos.Length; i++)
                            {
                                methodBuilder.DefineParameter(i + 1, ParameterAttributes.None, parameterInfos[i].Name);
                            }

                            EmitMethodBody(methodBuilder, methodInfo, message);

                            typeBuilder.DefineMethodOverride(methodBuilder, methodInfo);
                        }
                    }

                    // Gets a list of properties
                    PropertyInfo[] properties = type.GetProperties(BindingFlags.Public |
                                                                   BindingFlags.Instance);
                    // Implements each interface method
                    // Method must be tagged properly
                    foreach (PropertyInfo propertyInfo in properties)
                    {
                        // Define the implementation property
                        PropertyBuilder propertyBuilder = typeBuilder.DefineProperty(propertyInfo.Name, PropertyAttributes.None, propertyInfo.PropertyType, null);

                        MethodInfo getterInfo = propertyInfo.GetGetMethod();
                        if (getterInfo != null)
                        {
                            String message = CheckMethod(getterInfo);

                            // Define the implementation getter
                            MethodBuilder getterMethodBuilder = typeBuilder.DefineMethod(getterInfo.Name,
                                                                                         CodeGenerationAttributes.ACCESSOR_METHOD,
                                                                                         propertyInfo.PropertyType,
                                                                                         Type.EmptyTypes);
                            EmitMethodBody(getterMethodBuilder, getterInfo, message);

                            typeBuilder.DefineMethodOverride(getterMethodBuilder, getterInfo);
                            propertyBuilder.SetGetMethod(getterMethodBuilder);
                        }

                        MethodInfo setterInfo = propertyInfo.GetSetMethod();
                        if (setterInfo != null)
                        {
                            String message = CheckMethod(setterInfo);

                            // Define the implementation setter
                            MethodBuilder setterMethodBuilder = typeBuilder.DefineMethod(setterInfo.Name,
                                                                                         CodeGenerationAttributes.ACCESSOR_METHOD,
                                                                                         null,
                                                                                         new[] {propertyInfo.PropertyType});
                            EmitMethodBody(setterMethodBuilder, setterInfo, message);

                            typeBuilder.DefineMethodOverride(setterMethodBuilder, setterInfo);
                            propertyBuilder.SetSetMethod(setterMethodBuilder);
                        }
                    }

                    // Build the wrapper
                    wrapper = typeBuilder.CreateType();
                    // Store the new type
                    this.wrappers[type] = wrapper;
                }

                return wrapper;
            }
        }
    }
}