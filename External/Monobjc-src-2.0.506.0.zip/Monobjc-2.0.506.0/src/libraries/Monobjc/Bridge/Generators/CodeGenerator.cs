//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Reflection;
using System.Reflection.Emit;

namespace Monobjc.Bridge.Generators
{
    /// <summary>
    /// A base type used for dynamic assembly generation.
    /// </summary>
    internal partial class CodeGenerator : IBridgeProvider
    {
        private readonly String assemblyName;
        private readonly String moduleName;

        /// <summary>
        /// Initializes a new instance of the <see cref="CodeGenerator"/> class.
        /// </summary>
        /// <param name="assemblyName">Name of the dynamic assembly.</param>
        /// <param name="moduleName">Name of the dynamic module.</param>
        protected CodeGenerator(String assemblyName, String moduleName)
        {
            this.assemblyName = assemblyName;
            this.moduleName = moduleName;
        }

        /// <summary>
        /// Init the dymaically generated DLL.
        /// </summary>
        public virtual void Init()
        {
            // Define dynamic assembly
            AssemblyName name = new AssemblyName {Name = this.assemblyName, Version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version};
            this.Assembly = AppDomain.CurrentDomain.DefineDynamicAssembly(name, AssemblyBuilderAccess.RunAndSave);
            // Define dynamic module
            this.Module = this.Assembly.DefineDynamicModule(this.moduleName, this.assemblyName + ".dll");
        }

        /// <summary>
        /// Save the dymaically generated DLL.
        /// </summary>
        public virtual void Save()
        {
            this.Assembly.Save(this.assemblyName + ".dll");
        }

        /// <summary>
        /// Gets the assembly builder.
        /// </summary>
        protected AssemblyBuilder Assembly { get; private set; }

        /// <summary>
        /// Gets the module builder.
        /// </summary>
        protected ModuleBuilder Module { get; private set; }
    }
}