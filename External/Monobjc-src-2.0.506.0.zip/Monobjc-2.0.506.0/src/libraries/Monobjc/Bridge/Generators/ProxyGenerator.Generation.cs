//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using Monobjc.Properties;

namespace Monobjc.Bridge.Generators
{
    internal partial class ProxyGenerator
    {
        private const String IMPORT_MEMBERS_METHOD = "ImportMembers";
        private const String EXPORT_MEMBERS_METHOD = "ExportMembers";
        private const String INVOKE_METHOD = "Invoke";
        private const String BEGININVOKE_METHOD = "BeginInvoke";
        private const String ENDINVOKE_METHOD = "EndInvoke";

        /// <summary>
        /// Defines an inner Delegate type for the method to be invoked from Objective-C runtime.
        /// </summary>
        private static Type DefineDelegate(TypeBuilder typeBuilder, MethodTuple tuple)
        {
            // Get info about the target method
            Type returnType = GetReturnType(tuple.methodBase);
            Type[] parameterTypes = GetParametersTypes(tuple.methodBase);

            // Create type for proxy method
            Type proxyReturnType = returnType;
            if (NeedWrapping(returnType))
            {
                proxyReturnType = typeof (IntPtr);
            }

            // Create the array of parameters for the proxy method
            Type[] proxyParameterTypes = new Type[parameterTypes.Length + 2];
            proxyParameterTypes[0] = typeof (IntPtr);
            proxyParameterTypes[1] = typeof (IntPtr);
            for (int i = 0; i < parameterTypes.Length; i++)
            {
                proxyParameterTypes[i + 2] = NeedWrapping(parameterTypes[i]) ? typeof (IntPtr) : parameterTypes[i];
            }

            // Build a unique delegate name
            String name = GetUniqueName(tuple.methodBase) + "Invoker";

            // Grab the parameters of the method
            Type[] beginParameterTypes = new Type[proxyParameterTypes.Length + 2];
            Array.Copy(proxyParameterTypes, 0, beginParameterTypes, 0, proxyParameterTypes.Length);
            beginParameterTypes[proxyParameterTypes.Length] = typeof (AsyncCallback);
            beginParameterTypes[proxyParameterTypes.Length + 1] = typeof (Object);

            // Define the delegate nested-type
            TypeBuilder delegateBuilder = typeBuilder.DefineNestedType(name,
                                                                       CodeGenerationAttributes.PUBLIC_NESTED_DELEGATE,
                                                                       typeof (MulticastDelegate));
            delegateBuilder.SetCustomAttribute(
                new CustomAttributeBuilder(typeof (MarshalAsAttribute).GetConstructor(new[] {typeof (UnmanagedType)}),
                                           new object[] {UnmanagedType.FunctionPtr}));

            // Define the mandatory constructor
            ConstructorBuilder constructorBuilder = delegateBuilder.DefineConstructor(CodeGenerationAttributes.PUBLIC_CONSTRUCTOR,
                                                                                      CallingConventions.Standard,
                                                                                      new[] {typeof (Object), typeof (IntPtr)});
            constructorBuilder.SetImplementationFlags(MethodImplAttributes.Runtime |
                                                      MethodImplAttributes.Managed);

            // Define the Invoke method for the delegate
            MethodBuilder methodBuilder = delegateBuilder.DefineMethod(INVOKE_METHOD,
                                                                       CodeGenerationAttributes.PUBLIC_DELEGATE_METHOD,
                                                                       CallingConventions.Standard,
                                                                       proxyReturnType, proxyParameterTypes);
            methodBuilder.SetImplementationFlags(MethodImplAttributes.Runtime |
                                                 MethodImplAttributes.Managed);
            methodBuilder.DefineParameter(1, ParameterAttributes.None, "receiver");
            methodBuilder.DefineParameter(2, ParameterAttributes.None, "selector");

            // Define the BeginInvoke method for the delegate
            methodBuilder = delegateBuilder.DefineMethod(BEGININVOKE_METHOD,
                                                         CodeGenerationAttributes.PUBLIC_DELEGATE_METHOD,
                                                         CallingConventions.Standard,
                                                         typeof (IAsyncResult), beginParameterTypes);
            methodBuilder.SetImplementationFlags(MethodImplAttributes.Runtime |
                                                 MethodImplAttributes.Managed);
            methodBuilder.DefineParameter(1, ParameterAttributes.None, "receiver");
            methodBuilder.DefineParameter(2, ParameterAttributes.None, "selector");
            methodBuilder.DefineParameter(beginParameterTypes.Length - 1, ParameterAttributes.None, "callback");
            methodBuilder.DefineParameter(beginParameterTypes.Length, ParameterAttributes.None, "obj");

            // Define the EndInvoke method for the delegate
            methodBuilder = delegateBuilder.DefineMethod(ENDINVOKE_METHOD,
                                                         CodeGenerationAttributes.PUBLIC_DELEGATE_METHOD,
                                                         CallingConventions.Standard,
                                                         proxyReturnType, new[] {typeof (IAsyncResult)});
            methodBuilder.SetImplementationFlags(MethodImplAttributes.Runtime |
                                                 MethodImplAttributes.Managed);
            methodBuilder.DefineParameter(1, ParameterAttributes.None, "result");

            // Generate the type
            return delegateBuilder.CreateType();
        }

        /// <summary>
        /// Defines a proxy method that is called from Objective-C runtime. This method retrieves the targeted managed instance and passes the parameters.
        /// </summary>
        private static MethodInfo DefineProxyMethod(TypeBuilder typeBuilder, MethodTuple tuple, MethodInfo importInvoker, MethodInfo exportInvoker)
        {
            // Get info about the target method
            Type returnType = GetReturnType(tuple.methodBase);
            Type[] parameterTypes = GetParametersTypes(tuple.methodBase);

            // Create type for proxy method
            Type proxyReturnType = returnType;
            if (NeedWrapping(returnType))
            {
                proxyReturnType = typeof (IntPtr);
            }

            // Create the array of parameters for the proxy method
            Type[] proxyParameterTypes = new Type[parameterTypes.Length + 2];
            proxyParameterTypes[0] = typeof (IntPtr);
            proxyParameterTypes[1] = typeof (IntPtr);
            for (int i = 0; i < parameterTypes.Length; i++)
            {
                proxyParameterTypes[i + 2] = NeedWrapping(parameterTypes[i]) ? typeof (IntPtr) : parameterTypes[i];
            }

            // Assign a unique name
            String name = GetUniqueName(tuple.methodBase);

            // Create a proxy method 
            MethodBuilder invoker = typeBuilder.DefineMethod(name,
                                                             CodeGenerationAttributes.PUBLIC_STATIC_METHOD,
                                                             CallingConventions.Standard,
                                                             proxyReturnType,
                                                             proxyParameterTypes);
            // Give name to parameters
            invoker.DefineParameter(1, ParameterAttributes.None, "receiver");
            invoker.DefineParameter(2, ParameterAttributes.None, "selector");

            // Retrieve the MethodInfo from the generic call
            MethodInfo retrieveInstance = CodeGenerationInfos.OBJECTIVECRUNTIME_GETINSTANCE.MakeGenericMethod(new[] {tuple.methodBase.DeclaringType});

            // Generates body
            ILGenerator generator = invoker.GetILGenerator();

            // Different behaviours:
            // - Constructor
            // - Static Method
            // - Instance Method
            if (tuple.methodBase.IsConstructor)
            {
                // Creates local variables for by-ref parameters
                IDictionary<int, LocalBuilder> byrefLocals = EmitByRefLocalVariables(generator, parameterTypes);

                // Loads the parameters on the stack.
                // For by-ref parameters, local variables are loaded instead. 
                EmitNativeToManagedParametersLoadOnStack(generator, byrefLocals, parameterTypes);

                // Make the call on the receiver
                generator.Emit(OpCodes.Newobj, (ConstructorInfo) tuple.methodBase);

                // Unwrap result if needed
                if (NeedWrapping(returnType))
                {
                    generator.Emit(OpCodes.Call, CodeGenerationInfos.ID_GETNATIVEPOINTER);
                }

                // Marshal by-ref local variables to their corresponding parameters
                EmitByRefLocalVariablesMarshalling(generator, byrefLocals);

                generator.Emit(OpCodes.Ret);
            }
            else if (tuple.methodBase.IsStatic)
            {
                bool isNotVoid = (returnType != typeof (void));

                // To store result before return
                LocalBuilder result = null;
                if (isNotVoid)
                {
                    result = NeedWrapping(returnType) ? generator.DeclareLocal(typeof (IntPtr)) : generator.DeclareLocal(returnType);
                }

                // Creates local variables for by-ref parameters
                IDictionary<int, LocalBuilder> byrefLocals = EmitByRefLocalVariables(generator, parameterTypes);

                // Loads the parameters on the stack.
                // For by-ref parameters, local variables are loaded instead. 
                EmitNativeToManagedParametersLoadOnStack(generator, byrefLocals, parameterTypes);

                // Make the call on the receiver (direct call as the method is static)
                generator.Emit(OpCodes.Call, (MethodInfo) tuple.methodBase);

                // Unwrap result if needed
                if (isNotVoid)
                {
                    // Unwraps the result if not null
                    if (NeedWrapping(returnType))
                    {
                        Label nullValueLabel = generator.DefineLabel();
                        Label continueLabel = generator.DefineLabel();

                        // Store result
                        LocalBuilder managedInstance = generator.DeclareLocal(returnType);
                        generator.Emit(OpCodes.Stloc, managedInstance);

                        // Test to see if instance is null
                        generator.Emit(OpCodes.Ldloc, managedInstance);
                        generator.Emit(OpCodes.Ldnull);
                        generator.Emit(OpCodes.Beq_S, nullValueLabel);

                        // If not null, extract the pointer
                        generator.Emit(OpCodes.Ldloc, managedInstance);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.ID_GETNATIVEPOINTER);
                        generator.Emit(OpCodes.Br_S, continueLabel);

                        // If null, load a zero pointer
                        generator.MarkLabel(nullValueLabel);
                        generator.Emit(OpCodes.Ldsfld, CodeGenerationInfos.INTPTR_ZERO);

                        generator.MarkLabel(continueLabel);
                    }

                    // Store the final result into the local
                    generator.Emit(OpCodes.Stloc, result);
                    // Load the result on the stack
                    generator.Emit(OpCodes.Ldloc, result);
                }

                // Marshal by-ref local variables to their corresponding parameters
                EmitByRefLocalVariablesMarshalling(generator, byrefLocals);

                generator.Emit(OpCodes.Ret);
            }
            else
            {
                bool isNotVoid = (returnType != typeof (void));

                // To store translated receiver
                LocalBuilder target = generator.DeclareLocal(tuple.methodBase.DeclaringType);

                // To store result before return
                LocalBuilder result = null;
                if (isNotVoid)
                {
                    result = NeedWrapping(returnType) ? generator.DeclareLocal(typeof (IntPtr)) : generator.DeclareLocal(returnType);
                }

                // Load the receiver on the stack
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Call, retrieveInstance);
                generator.Emit(OpCodes.Stloc, target);

                // Import members before the call
                if (tuple.ObjectiveCMessageAttribute.SynchronizeFields && (importInvoker != null))
                {
                    generator.Emit(OpCodes.Ldloc, target);
                    generator.Emit(OpCodes.Call, importInvoker);
                }

                // Creates local variables for by-ref parameters
                IDictionary<int, LocalBuilder> byrefLocals = EmitByRefLocalVariables(generator, parameterTypes);

                // Loads the parameters on the stack.
                // For by-ref parameters, local variables are loaded instead. 
                generator.Emit(OpCodes.Ldloc, target);
                EmitNativeToManagedParametersLoadOnStack(generator, byrefLocals, parameterTypes);

                // Make the call on the receiver
                generator.Emit(OpCodes.Call, (MethodInfo) tuple.methodBase);

                // Unwrap result if needed
                if (isNotVoid)
                {
                    // Unwraps the result if not null
                    if (NeedWrapping(returnType))
                    {
                        Label nullValueLabel = generator.DefineLabel();
                        Label continueLabel = generator.DefineLabel();

                        // Store result
                        LocalBuilder managedInstance = generator.DeclareLocal(returnType);
                        generator.Emit(OpCodes.Stloc, managedInstance);

                        // Test to see if instance is null
                        generator.Emit(OpCodes.Ldloc, managedInstance);
                        generator.Emit(OpCodes.Ldnull);
                        generator.Emit(OpCodes.Beq_S, nullValueLabel);

                        // If not null, extract the pointer
                        generator.Emit(OpCodes.Ldloc, managedInstance);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.IMANAGEDWRAPPER_GETNATIVEPOINTER);
                        generator.Emit(OpCodes.Br_S, continueLabel);

                        // If null, load a zero pointer
                        generator.MarkLabel(nullValueLabel);
                        generator.Emit(OpCodes.Ldsfld, CodeGenerationInfos.INTPTR_ZERO);

                        generator.MarkLabel(continueLabel);
                    }

                    // Store the final result into the local
                    generator.Emit(OpCodes.Stloc, result);
                }

                // Marshal by-ref local variables to their corresponding parameters
                EmitByRefLocalVariablesMarshalling(generator, byrefLocals);

                // Export members after the call
                if (tuple.ObjectiveCMessageAttribute.SynchronizeFields && (exportInvoker != null))
                {
                    generator.Emit(OpCodes.Ldloc, target);
                    generator.Emit(OpCodes.Call, exportInvoker);
                }

                // Load result if needed
                if (isNotVoid)
                {
                    generator.Emit(OpCodes.Ldloc, result);
                }

                generator.Emit(OpCodes.Ret);
            }

            return invoker;
        }

        /// <summary>
        /// Defines a methods that will transfer instance variables from the Objective-C runtime to the .NET runtime.
        /// </summary>
        private static MethodInfo DefineImportMethod(TypeBuilder typeBuilder, Type type, ICollection<VariableTuple> tuples)
        {
            MethodBuilder invoker = null;
            if (tuples.Count > 0)
            {
                // Create a import method 
                invoker = typeBuilder.DefineMethod(IMPORT_MEMBERS_METHOD,
                                                   CodeGenerationAttributes.PUBLIC_STATIC_METHOD,
                                                   CallingConventions.Standard,
                                                   typeof (void),
                                                   new[] {type});
                invoker.DefineParameter(1, ParameterAttributes.None, "instance");
                ILGenerator generator = invoker.GetILGenerator();

                // Declare local variable
                LocalBuilder receiver = generator.DeclareLocal(typeof (IntPtr));
                LocalBuilder pointerToPointer = generator.DeclareLocal(typeof (IntPtr));

                // Retrieve pointer to receiver
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Call, CodeGenerationInfos.ID_GETNATIVEPOINTER);
                generator.Emit(OpCodes.Stloc, receiver);

                // Create pointer for value
                generator.Emit(OpCodes.Ldtoken, typeof (IntPtr));
                generator.Emit(OpCodes.Call, CodeGenerationInfos.TYPE_GETTYPEFROMHANDLE);
                generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_SIZEOF);
                generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_ALLOCHGLOBAL);
                generator.Emit(OpCodes.Stloc, pointerToPointer);

                // Import native value into instance field
                foreach (VariableTuple tuple in tuples)
                {
                    String name = tuple.name;
                    FieldInfo fieldInfo = tuple.fieldInfo;
                    Type fieldType = fieldInfo.FieldType;

                    generator.Emit(OpCodes.Ldloc, receiver);
                    generator.Emit(OpCodes.Ldstr, name);
                    generator.Emit(OpCodes.Ldloc, pointerToPointer);
                    generator.Emit(OpCodes.Call, CodeGenerationInfos.NATIVEMETHODS_GETINSTANCEVARIABLE);
                    generator.Emit(OpCodes.Pop);

                    // Read the value from the pointer
                    generator.Emit(OpCodes.Ldarg_0);
                    generator.Emit(OpCodes.Ldloc, pointerToPointer);
                    generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_READINTPTR);

                    // Store it in a local variable
                    LocalBuilder pointer = generator.DeclareLocal(typeof (IntPtr));
                    generator.Emit(OpCodes.Stloc, pointer);

                    Label emptyValueLabel = generator.DefineLabel();
                    Label setValueLabel = generator.DefineLabel();

                    // Test the result pointer for nullity
                    generator.Emit(OpCodes.Ldloc, pointer);
                    generator.Emit(OpCodes.Ldsfld, CodeGenerationInfos.INTPTR_ZERO);
                    generator.Emit(OpCodes.Beq_S, emptyValueLabel);

                    if (NeedWrapping(fieldType))
                    {
                        // Retrieve the MethodInfo from the generic call
                        MethodInfo retrieveInstance = CodeGenerationInfos.OBJECTIVECRUNTIME_GETINSTANCE.MakeGenericMethod(new[] {fieldType});

                        // Retrieve the instance from the pointer
                        generator.Emit(OpCodes.Ldloc, pointer);
                        generator.Emit(OpCodes.Call, retrieveInstance);
                        generator.Emit(OpCodes.Br_S, setValueLabel);

                        // Load a null value
                        generator.MarkLabel(emptyValueLabel);
                        generator.Emit(OpCodes.Ldnull);
                    }
                    else if (fieldType.IsValueType)
                    {
                        // Unmarshal the value type
                        generator.Emit(OpCodes.Ldloc, pointer);
                        generator.Emit(OpCodes.Ldtoken, fieldType);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.TYPE_GETTYPEFROMHANDLE);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_PTRTOSTRUCTURE);
                        generator.Emit(OpCodes.Unbox_Any, fieldType);
                        generator.Emit(OpCodes.Br_S, setValueLabel);

                        // Make a default value for the value type
                        generator.MarkLabel(emptyValueLabel);
                        LocalBuilder defaultValue = generator.DeclareLocal(fieldType);
                        generator.Emit(OpCodes.Ldloc, defaultValue);
                    }
                    else
                    {
                        throw new ObjectiveCCodeGenerationException(
                            String.Format(CultureInfo.CurrentCulture, Resources.CannotGenerateCodeImportFieldNotSupported, fieldType.FullName));
                    }

                    generator.MarkLabel(setValueLabel);
                    generator.Emit(OpCodes.Stfld, fieldInfo);
                }

                // Free value pointer
                generator.Emit(OpCodes.Ldloc, pointerToPointer);
                generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_FREEHGLOBAL);

                generator.Emit(OpCodes.Ret);
            }
            return invoker;
        }

        /// <summary>
        /// Defines a methods that will transfer instance variables from the .NET runtime to the Objective-C runtime.
        /// </summary>
        private static MethodInfo DefineExportMethod(TypeBuilder typeBuilder, Type type, ICollection<VariableTuple> tuples)
        {
            if (tuples.Count > 0)
            {
                // Create a export method 
                MethodBuilder invoker = typeBuilder.DefineMethod(EXPORT_MEMBERS_METHOD,
                                                                 CodeGenerationAttributes.PUBLIC_STATIC_METHOD,
                                                                 CallingConventions.Standard,
                                                                 typeof (void),
                                                                 new[] {type});
                invoker.DefineParameter(1, ParameterAttributes.None, "instance");
                ILGenerator generator = invoker.GetILGenerator();

                // Declare local variable
                LocalBuilder receiver = generator.DeclareLocal(typeof (IntPtr));
                LocalBuilder pointer = generator.DeclareLocal(typeof (IntPtr));

                // Retrieve pointer to receiver
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Call, CodeGenerationInfos.ID_GETNATIVEPOINTER);
                generator.Emit(OpCodes.Stloc, receiver);

                // Export instance field to native value 
                foreach (VariableTuple tuple in tuples)
                {
                    String name = tuple.name;
                    FieldInfo fieldInfo = tuple.fieldInfo;
                    Type fieldType = fieldInfo.FieldType;

                    if (NeedWrapping(fieldType))
                    {
                        Label labelValueIsNull = generator.DefineLabel();
                        Label labelContinue = generator.DefineLabel();

                        // Test if instance field value is null
                        generator.Emit(OpCodes.Ldarg_0);
                        generator.Emit(OpCodes.Ldfld, fieldInfo);
                        generator.Emit(OpCodes.Ldnull);
                        generator.Emit(OpCodes.Ceq);
                        generator.Emit(OpCodes.Brtrue, labelValueIsNull);

                        // Value is not null
                        generator.Emit(OpCodes.Ldloc, receiver);
                        generator.Emit(OpCodes.Ldstr, name);
                        generator.Emit(OpCodes.Ldarg_0);
                        generator.Emit(OpCodes.Ldfld, fieldInfo);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.ID_GETNATIVEPOINTER);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.NATIVEMETHODS_SETINSTANCEVARIABLE);
                        generator.Emit(OpCodes.Pop);
                        generator.Emit(OpCodes.Br_S, labelContinue);

                        // Value is null
                        generator.MarkLabel(labelValueIsNull);
                        generator.Emit(OpCodes.Ldloc, receiver);
                        generator.Emit(OpCodes.Ldstr, name);
                        generator.Emit(OpCodes.Ldsfld, CodeGenerationInfos.INTPTR_ZERO);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.NATIVEMETHODS_SETINSTANCEVARIABLE);
                        generator.Emit(OpCodes.Pop);

                        // To keep on going
                        generator.MarkLabel(labelContinue);
                    }
                    else if (fieldType.IsValueType)
                    {
                        // Allocate native memory to store value type
                        generator.Emit(OpCodes.Ldtoken, fieldType);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.TYPE_GETTYPEFROMHANDLE);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_SIZEOF);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_ALLOCHGLOBAL);
                        generator.Emit(OpCodes.Stloc, pointer);

                        // Marshal instance field to native memory
                        generator.Emit(OpCodes.Ldarg_0);
                        generator.Emit(OpCodes.Ldfld, fieldInfo);
                        generator.Emit(OpCodes.Box, fieldType);
                        generator.Emit(OpCodes.Ldloc, pointer);
                        generator.Emit(OpCodes.Ldc_I4_0);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_STRUCTURETOPTR);

                        // Load first parameters
                        generator.Emit(OpCodes.Ldloc, receiver);
                        generator.Emit(OpCodes.Ldstr, name);
                        generator.Emit(OpCodes.Ldloc, pointer);
                        generator.Emit(OpCodes.Call, CodeGenerationInfos.NATIVEMETHODS_SETINSTANCEVARIABLE);
                        generator.Emit(OpCodes.Pop);

                        // Free value type storage
                        //generator.Emit(OpCodes.Ldloc, pointer);
                        //generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_FREEHGLOBAL);
                    }
                    else
                    {
                        throw new ObjectiveCCodeGenerationException(
                            String.Format(CultureInfo.CurrentCulture, Resources.CannotGenerateCodeExportFieldNotSupported, fieldType.FullName));
                    }
                }

                generator.Emit(OpCodes.Ret);

                return invoker;
            }

            return null;
        }

        /// <summary>
        /// Emit local variable for each by-ref parameters. These variables will hold the result until the marshalling occurs.
        /// </summary>
        private static IDictionary<int, LocalBuilder> EmitByRefLocalVariables(ILGenerator generator, Type[] parameterTypes)
        {
            IDictionary<int, LocalBuilder> byrefLocals = new Dictionary<int, LocalBuilder>();

            for (int i = 0; i < parameterTypes.Length; i++)
            {
                Type parameterType = parameterTypes[i];

                // For by-ref type, create a local variable and store it
                if (parameterType.IsByRef)
                {
                    // De-reference by-ref type to extract the correct type
                    Type localType = parameterType.GetElementType();
                    // Create the local variable of the de-referenced type
                    LocalBuilder local = generator.DeclareLocal(localType);
                    byrefLocals[i] = local;
                }
            }

            return byrefLocals;
        }

        /// <summary>
        /// Genenerate optimized IL for stacking parameters :
        /// - For the third or fourth parameter, use the short OpCode
        /// - For all the parameters left, use the long OpCode
        /// </summary>
        private static void EmitNativeToManagedParametersLoadOnStack(ILGenerator generator, IDictionary<int, LocalBuilder> byrefLocals, Type[] parameterTypes)
        {
            for (int i = 0; i < parameterTypes.Length; i++)
            {
                Type parameterType = parameterTypes[i];

                // For by-ref type, loads the local variable
                // Otherwise, loads the argument (wrapped or not)
                if (parameterType.IsByRef)
                {
                    generator.Emit(OpCodes.Ldloca, byrefLocals[i]);
                }
                else
                {
                    switch (i)
                    {
                        case 0:
                            generator.Emit(OpCodes.Ldarg_2);
                            break;
                        case 1:
                            generator.Emit(OpCodes.Ldarg_3);
                            break;
                        default:
                            generator.Emit(OpCodes.Ldarg_S, i + 2);
                            break;
                    }

                    // For wrapped type (interface or Id subclass)
                    if (NeedWrapping(parameterType))
                    {
                        MethodInfo wrapInstance = CodeGenerationInfos.OBJECTIVECRUNTIME_GETINSTANCE.MakeGenericMethod(new[] {parameterType});
                        generator.Emit(OpCodes.Call, wrapInstance);
                    }
                }
            }
        }

        /// <summary>
        /// Emit the code needed to marshal back the local variables to by-ref parameters.
        /// </summary>
        private static void EmitByRefLocalVariablesMarshalling(ILGenerator generator, IDictionary<int, LocalBuilder> byrefLocals)
        {
            foreach (int i in byrefLocals.Keys)
            {
                LocalBuilder local = byrefLocals[i];
                Type localType = local.LocalType;

                // Two cases:
                // - Wrapped objects
                // - Value types
                if (NeedWrapping(localType))
                {
                    Label nullValueLabel = generator.DefineLabel();
                    Label continueLabel = generator.DefineLabel();

                    // Load the target argument on the stack
                    generator.Emit(OpCodes.Ldarg_S, i + 2);

                    // Test for null on the by-ref local
                    generator.Emit(OpCodes.Ldloc, local);
                    generator.Emit(OpCodes.Ldnull);
                    generator.Emit(OpCodes.Beq_S, nullValueLabel);

                    // If not null, extract the pointer
                    generator.Emit(OpCodes.Ldloc, local);
                    generator.Emit(OpCodes.Call, CodeGenerationInfos.ID_GETNATIVEPOINTER);
                    generator.Emit(OpCodes.Br_S, continueLabel);

                    // If null, load a zero pointer
                    generator.MarkLabel(nullValueLabel);
                    generator.Emit(OpCodes.Ldsfld, CodeGenerationInfos.INTPTR_ZERO);

                    // Store the final result into the target argument
                    generator.MarkLabel(continueLabel);
                    generator.Emit(OpCodes.Call, CodeGenerationInfos.MARSHAL_WRITEINTPTR);
                }
                else
                {
                    // Store the final result into the target argument
                    // Optimize storage if type is simple
                    generator.Emit(OpCodes.Ldarg, i + 2);
                    generator.Emit(OpCodes.Ldloc, local);

                    if (localType == typeof (bool))
                    {
                        generator.Emit(OpCodes.Stind_I1);
                    }
                    else if (localType == typeof (short))
                    {
                        generator.Emit(OpCodes.Stind_I2);
                    }
                    else if (localType == typeof (Int32))
                    {
                        generator.Emit(OpCodes.Stind_I4);
                    }
                    else if (localType == typeof (Int64))
                    {
                        generator.Emit(OpCodes.Stind_I8);
                    }
                    else if (localType == typeof (float))
                    {
                        generator.Emit(OpCodes.Stind_R4);
                    }
                    else if (localType == typeof (double))
                    {
                        generator.Emit(OpCodes.Stind_R8);
                    }
                    else if (localType == typeof (IntPtr))
                    {
                        generator.Emit(OpCodes.Stind_I);
                    }
                    else
                    {
                        generator.Emit(OpCodes.Stobj, localType);
                    }
                }
            }
        }

        /// <summary>
        /// Once the proxy method is defined, create a delegate from this method. The resulting delegate (and its
        /// underlying native pointer) will be used as the IMP value for the method.
        /// </summary>
        private static void DefineNativeMethod(Type type, MethodTuple methodTuple)
        {
            // We cannot use the proxyMethodInfo as it is a dynamic builder
            // So we lookup for the same methodinfo but in a runtime manner.
            MethodInfo info = type.GetMethod(methodTuple.proxyMethodInfo.Name);

            // Fill structure
            methodTuple.function = Delegate.CreateDelegate(methodTuple.proxyDelegate, info);
        }
    }
}