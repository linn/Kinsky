//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using Monobjc.Properties;

namespace Monobjc.Bridge.Generators
{
    internal partial class WrapperGenerator
    {
        private static String CheckMethod(MemberInfo info)
        {
            ObjectiveCMessageAttribute attribute = Attribute.GetCustomAttribute(info, typeof (ObjectiveCMessageAttribute)) as ObjectiveCMessageAttribute;
            if (attribute == null)
            {
                throw new ObjectiveCCodeGenerationException(String.Format(CultureInfo.CurrentCulture, Resources.TheMethodOfTypeHasNotObjectiveCMessageAttribute, info.Name, info.DeclaringType));
            }
            String message = attribute.Selector;
            if (String.IsNullOrEmpty(message))
            {
                throw new ObjectiveCCodeGenerationException(String.Format(CultureInfo.CurrentCulture, Resources.TheMethodOfTypeHasAnInvalidObjectiveCMessageAttribute, info.Name, info.DeclaringType));
            }
            return message;
        }

        /// <summary>
        /// 
        /// </summary>
        private static Type[] GetParameterTypes(MethodInfo methodInfo)
        {
            ParameterInfo[] parameterInfos = methodInfo.GetParameters();
            Type[] parameterTypes = new Type[parameterInfos.Length];
            for (int i = 0; i < parameterInfos.Length; i++)
            {
                parameterTypes[i] = parameterInfos[i].ParameterType;
            }
            return parameterTypes;
        }

        /// <summary>
        /// 
        /// </summary>
        private static void EmitMethodBody(MethodBuilder methodBuilder, MethodInfo methodInfo, String message)
        {
            Type returnType = methodInfo.ReturnType;
            ILGenerator generator = methodBuilder.GetILGenerator();
            ParameterInfo[] parameterInfos = methodInfo.GetParameters();

            if (returnType == typeof (void))
            {
#if ENABLE_FAST_PATH
                MethodInfo sendMessageInvoker = (parameterInfos.Length > 0) ? CodeGenerationInfos.OBJECTIVECRUNTIME_SENDMESSAGE_VOID_ARGS : CodeGenerationInfos.OBJECTIVECRUNTIME_SENDMESSAGE_VOID_NOARGS;
#else
                MethodInfo sendMessageInvoker = CodeGenerationInfos.OBJECTIVECRUNTIME_SENDMESSAGE_VOID_ARGS;
#endif
                // Makes the actual call
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Ldstr, message);
                EmitParametersAsArrayOnStack(generator, parameterInfos);
                generator.Emit(OpCodes.Call, sendMessageInvoker);

                generator.Emit(OpCodes.Ret);
            }
            else
            {
#if ENABLE_FAST_PATH
                MethodInfo sendMessageInvoker = ((parameterInfos.Length > 0) ? CodeGenerationInfos.OBJECTIVECRUNTIME_SENDMESSAGE_ARGS_GENERIC : CodeGenerationInfos.OBJECTIVECRUNTIME_SENDMESSAGE_NOARGS_GENERIC).MakeGenericMethod(returnType);
#else
                MethodInfo sendMessageInvoker = CodeGenerationInfos.OBJECTIVECRUNTIME_SENDMESSAGE_ARGS_GENERIC.MakeGenericMethod(returnType);
#endif
                // Makes the actual call
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Ldstr, message);
                EmitParametersAsArrayOnStack(generator, parameterInfos);
                generator.Emit(OpCodes.Call, sendMessageInvoker);

                generator.Emit(OpCodes.Ret);
            }
        }

        /// <summary>
        /// Create an object array and put the method arguments in it, then load the array on the stack
        /// </summary>
        private static void EmitParametersAsArrayOnStack(ILGenerator generator, ParameterInfo[] infos)
        {
            int size = infos.Length;

#if ENABLE_FAST_PATH
            if (size == 0)
            {
                return;
            }
#endif
            // Create a local variable to hold the array
            LocalBuilder array = generator.DeclareLocal((new Object[0]).GetType());

            // Load array size on the stack
            switch (size)
            {
                case 0:
                    generator.Emit(OpCodes.Ldc_I4_0);
                    break;
                case 1:
                    generator.Emit(OpCodes.Ldc_I4_1);
                    break;
                case 2:
                    generator.Emit(OpCodes.Ldc_I4_2);
                    break;
                case 3:
                    generator.Emit(OpCodes.Ldc_I4_3);
                    break;
                case 4:
                    generator.Emit(OpCodes.Ldc_I4_4);
                    break;
                case 5:
                    generator.Emit(OpCodes.Ldc_I4_5);
                    break;
                case 6:
                    generator.Emit(OpCodes.Ldc_I4_6);
                    break;
                case 7:
                    generator.Emit(OpCodes.Ldc_I4_7);
                    break;
                case 8:
                    generator.Emit(OpCodes.Ldc_I4_8);
                    break;
                default:
                    generator.Emit(OpCodes.Ldc_I4, size);
                    break;
            }

            // Create the array
            generator.Emit(OpCodes.Newarr, typeof (Object));

            if (size > 0)
            {
                generator.Emit(OpCodes.Stloc, array);

                for (int i = 0; i < size; i++)
                {
                    ParameterInfo info = infos[i];

                    // Load array to fill
                    generator.Emit(OpCodes.Ldloc, array);

                    // Load array index to fill
                    switch (i)
                    {
                        case 0:
                            generator.Emit(OpCodes.Ldc_I4_0);
                            break;
                        case 1:
                            generator.Emit(OpCodes.Ldc_I4_1);
                            break;
                        case 2:
                            generator.Emit(OpCodes.Ldc_I4_2);
                            break;
                        case 3:
                            generator.Emit(OpCodes.Ldc_I4_3);
                            break;
                        case 4:
                            generator.Emit(OpCodes.Ldc_I4_4);
                            break;
                        case 5:
                            generator.Emit(OpCodes.Ldc_I4_5);
                            break;
                        case 6:
                            generator.Emit(OpCodes.Ldc_I4_6);
                            break;
                        case 7:
                            generator.Emit(OpCodes.Ldc_I4_7);
                            break;
                        case 8:
                            generator.Emit(OpCodes.Ldc_I4_8);
                            break;
                        default:
                            generator.Emit(OpCodes.Ldc_I4, size);
                            break;
                    }

                    // Load value to put
                    // As 'this' is the first argument (arg0), we need to shift the argument following
                    // Parameter 0 from method is arg1 in IL
                    // Parameter 1 from method is arg2 in IL
                    switch (i)
                    {
                        case 0:
                            generator.Emit(OpCodes.Ldarg_1);
                            break;
                        case 1:
                            generator.Emit(OpCodes.Ldarg_2);
                            break;
                        case 2:
                            generator.Emit(OpCodes.Ldarg_3);
                            break;
                        default:
                            generator.Emit(OpCodes.Ldarg_S, (i + 1));
                            break;
                    }

                    // Box value types
                    if (info.ParameterType.IsValueType)
                    {
                        generator.Emit(OpCodes.Box, info.ParameterType);
                    }

                    // Store reference in array
                    generator.Emit(OpCodes.Stelem_Ref);
                }

                // Load array on stack
                generator.Emit(OpCodes.Ldloc, array);
            }
        }
    }
}