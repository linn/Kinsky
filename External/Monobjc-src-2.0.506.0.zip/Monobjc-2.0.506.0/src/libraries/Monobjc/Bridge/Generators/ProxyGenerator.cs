//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;

namespace Monobjc.Bridge.Generators
{
    /// <summary>
    /// Dynamic code generator for the .NET/Objective-C proxies.
    /// </summary>
    internal partial class ProxyGenerator : CodeGenerator
    {
        private const String PROXY_NAME_PATTERN = "Monobjc.Dynamic.Proxies.{0}";
        private const char TYPE_SEPARATOR = '.';
        private const char NAME_SEPARATOR = '_';

        /// <summary>
        /// Initializes a new instance of the <see cref="ProxyGenerator"/> class.
        /// </summary>
        public ProxyGenerator()
            : base("Monobjc.Dynamic.Proxies", "ObjectiveCProxyTypes") {}

        /// <summary>
        /// Prepare the proxy creation
        /// - Collect instance variables
        /// - Collect instance methods
        /// - Collect constructors
        /// - Collect static methods
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="variableTuples">The variable tuples.</param>
        /// <param name="instanceTuples">The instance tuples.</param>
        /// <param name="classTuples">The class tuples.</param>
        public static void CollectStructures(Type type, List<VariableTuple> variableTuples, List<MethodTuple> instanceTuples, List<MethodTuple> classTuples)
        {
            // Collect type elements for the generation
            CollectInstanceVariables(type, variableTuples);
            CollectInstanceMethods(type, instanceTuples);
            CollectStaticMethods(type, classTuples);
            CollectConstructors(type, classTuples);
        }

        /// <summary>
        /// Entry point for creating proxy.
        /// 
        /// - Create a proxy type
        /// - Create import/export methods for instance variables
        /// - Create a proxy method and a delegate for each instance method
        /// - Create a proxy method and a delegate for each constructor
        /// - Create a proxy method and a delegate for each static method
        /// - Finalize the proxy type
        /// - Fill in list of objc_method with instance method
        /// - Fill in list of objc_method with constructors and static method
        /// </summary>
        public void CreateProxy(Type type, List<VariableTuple> variableTuples, List<MethodTuple> instanceTuples, List<MethodTuple> classTuples)
        {
            // Create proxy type
            String typeName = String.Format(CultureInfo.CurrentCulture, PROXY_NAME_PATTERN, type.FullName);
            TypeBuilder typeBuilder = this.Module.DefineType(typeName, CodeGenerationAttributes.PUBLIC_STATIC_TYPE);

            if (Logger.DebugEnabled)
            {
                Logger.Debug("ProxyGenerator", "Generating Proxy : " + typeName);
            }

            // Create import/export ivars methods
            MethodInfo importInvoker = DefineImportMethod(typeBuilder, type, variableTuples);
            MethodInfo exportInvoker = DefineExportMethod(typeBuilder, type, variableTuples);

            // Create proxy for instance methods
            for (int i = 0; i < instanceTuples.Count; i++)
            {
                MethodTuple methodTuple = instanceTuples[i];
                methodTuple.proxyDelegate = DefineDelegate(typeBuilder, methodTuple);
                methodTuple.proxyMethodInfo = DefineProxyMethod(typeBuilder, methodTuple, importInvoker, exportInvoker);
            }

            // Create proxy for class methods
            for (int i = 0; i < classTuples.Count; i++)
            {
                MethodTuple methodTuple = classTuples[i];
                methodTuple.proxyDelegate = DefineDelegate(typeBuilder, methodTuple);
                methodTuple.proxyMethodInfo = DefineProxyMethod(typeBuilder, methodTuple, importInvoker, exportInvoker);
            }

            // Finish the creation
            Type proxy = typeBuilder.CreateType();

            // Create objc_method structure with their delegates for instance methods
            for (int i = 0; i < instanceTuples.Count; i++)
            {
                MethodTuple methodTuple = instanceTuples[i];
                DefineNativeMethod(proxy, methodTuple);
            }

            // Create objc_method structure with their delegates for static methods
            for (int i = 0; i < classTuples.Count; i++)
            {
                MethodTuple methodTuple = classTuples[i];
                DefineNativeMethod(proxy, methodTuple);
            }
        }
    }
}