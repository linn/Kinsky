//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Reflection;

namespace Monobjc.Bridge.Generators
{
#if ENABLE_FAST_PATH
    partial class DynamicMessagingGenerator
    {
        private static readonly Type[] PLATFORM_INVOKE_NOARGS_TYPES = new[] { typeof(IntPtr), typeof(IntPtr) };
        private readonly IDictionary<Type, Delegate> messagingMethodsNoArgs = new Dictionary<Type, Delegate>(64);
        private readonly IDictionary<Type, Delegate> messagingSuperMethodsNoArgs = new Dictionary<Type, Delegate>(64);

        /// <summary>
        /// Sends the message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="receiver">The receiver.</param>
        /// <param name="selector">The selector.</param>
        public void SendMessage(String message, IntPtr receiver, IntPtr selector)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Sends the message.
        /// </summary>
        /// <typeparam name="TReturnType">The type of the return type.</typeparam>
        /// <param name="message">The message.</param>
        /// <param name="receiver">The receiver.</param>
        /// <param name="selector">The selector.</param>
        /// <returns>The result</returns>
        public TReturnType SendMessage<TReturnType>(String message, IntPtr receiver, IntPtr selector)
        {
            Type returnType = typeof(TReturnType);

            // Fetch invoke from cache
            PlatformInvokeNoArgs<TReturnType> invoker;

            lock (this.messagingMethodsNoArgs)
            {
                if (message.Equals(CodeGenerationConstants.OBJC_MSG_SEND))
                {
                    if (this.messagingMethodsNoArgs.ContainsKey(returnType))
                    {
                        invoker = (PlatformInvokeNoArgs<TReturnType>) this.messagingMethodsNoArgs[returnType];
                    }
                    else
                    {
                        String typeName = message + "_" + returnType;
                        MethodInfo methodInfo = DefineMessagingDelegate<TReturnType>(message, typeName, Type.EmptyTypes);
                        invoker = (PlatformInvokeNoArgs<TReturnType>) Delegate.CreateDelegate(typeof (PlatformInvokeNoArgs<TReturnType>), methodInfo);
                        this.messagingMethodsNoArgs.Add(returnType, invoker);
                    }
                }
                else
                {

                    if (this.messagingSuperMethodsNoArgs.ContainsKey(returnType))
                    {
                        invoker = (PlatformInvokeNoArgs<TReturnType>) this.messagingSuperMethodsNoArgs[returnType];
                    }
                    else
                    {
                        String typeName = message + "_" + returnType;
                        MethodInfo methodInfo = this.DefineMessagingDelegate<TReturnType>(message, typeName, Type.EmptyTypes);
                        invoker = (PlatformInvokeNoArgs<TReturnType>) Delegate.CreateDelegate(typeof (PlatformInvokeNoArgs<TReturnType>), methodInfo);
                        this.messagingSuperMethodsNoArgs.Add(returnType, invoker);
                    }
                }
            }

            // Call the P/Invoke method
            return invoker(receiver, selector);
        }
    }
#endif
}
