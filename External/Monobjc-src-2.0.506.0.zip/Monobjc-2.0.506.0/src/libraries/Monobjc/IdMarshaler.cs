//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Monobjc
{
    /// <summary>
    /// Custom marshaller for <see cref="Id"/> instances. This makes interop a breeze as it cuts a lot of code.
    /// </summary>
    public class IdMarshaler<TInstance> : ICustomMarshaler where TInstance : Id
    {
        private static readonly IdMarshaler<TInstance> instance = new IdMarshaler<TInstance>();

        /// <summary>
        /// Returns a shared instance of the custom marshaller.
        /// </summary>
        /// <param name="cookie">A cookie string from the interop layer</param>
        /// <returns>The shared instance</returns>
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static ICustomMarshaler GetInstance(String cookie)
        {
            return instance;
        }

        /// <summary>
        /// Converts the unmanaged data to managed data.
        /// </summary>
        /// <param name="pNativeData">A pointer to the unmanaged data to be wrapped.</param>
        /// <returns>
        /// Returns the managed view of the COM data.
        /// </returns>
        public Object MarshalNativeToManaged(IntPtr pNativeData)
        {
            return ObjectiveCRuntime.GetInstance<TInstance>(pNativeData);
        }

        /// <summary>
        /// Converts the managed data to unmanaged data.
        /// </summary>
        /// <param name="ManagedObj">The managed object to be converted.</param>
        /// <returns>
        /// Returns the COM view of the managed object.
        /// </returns>
        public IntPtr MarshalManagedToNative(Object ManagedObj)
        {
            TInstance id = ManagedObj as TInstance;
            if (id != null)
            {
                return id.NativePointer;
            }
            return IntPtr.Zero;
        }

        /// <summary>
        /// Performs necessary cleanup of the unmanaged data when it is no longer needed.
        /// </summary>
        /// <param name="pNativeData">A pointer to the unmanaged data to be destroyed.</param>
        public void CleanUpNativeData(IntPtr pNativeData) {}

        /// <summary>
        /// Performs necessary cleanup of the managed data when it is no longer needed.
        /// </summary>
        /// <param name="ManagedObj">The managed object to be destroyed.</param>
        public void CleanUpManagedData(Object ManagedObj) {}

        /// <summary>
        /// Returns the size of the native data to be marshaled.
        /// </summary>
        /// <returns>The size in bytes of the native data.</returns>
        public int GetNativeDataSize()
        {
            return IntPtr.Size;
        }
    }
}