//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;

namespace Monobjc.Runtime.ObjectiveC10
{
    /// <summary>
    /// <para>Contains an array of method definitions.</para>
    /// <para>The Objective-C declaration is :
    /// <code>
    /// struct objc_method_list
    /// {
    ///     struct objc_method_list *obsolete;
    ///     int method_count;
    ///     struct objc_method method_list[1];
    /// }
    /// </code>
    /// </para>
    /// </summary>
    /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
    [StructLayout(LayoutKind.Sequential)]
    internal struct objc_method_list
    {
        private static readonly int size = Marshal.SizeOf(typeof (objc_method_list));

        /// <summary>
        /// Reserved for future use.
        /// </summary>
        public IntPtr obsolete;

        /// <summary>
        /// An integer specifying the number of methods in the method list array.
        /// </summary>
        public int method_count;

        // Note: Due to limitations of the .NET framework, we cannot have variable-length structure array inside a structure.
        // struct objc_method method_list[1];

        /// <summary>
        /// Gets the size of this structure.
        /// </summary>
        /// <value>The size.</value>
        public static int Size
        {
            get { return size; }
        }

        /// <summary>
        /// Marshal a native pointer to an <see cref="objc_method_list"/> structure.
        /// </summary>
        /// <param name="pointer">The pointer to the native structure.</param>
        /// <returns>A <see cref="objc_method_list"/> structure.</returns>
        public static objc_method_list PtrToStructure(IntPtr pointer)
        {
            return (objc_method_list) Marshal.PtrToStructure(pointer, typeof (objc_method_list));
        }

        /// <summary>
        /// Marshal an <see cref="objc_method_list"/> structure to a native pointer.
        /// </summary>
        /// <param name="structure">The <see cref="objc_method_list"/> structure to marshal.</param>
        /// <returns>A pointer to the native structure.</returns>
        /// <remarks>Caller is responsible for freeing the allocated block of unmanaged memory.</remarks>
        public static IntPtr StructureToPtr(objc_method_list structure)
        {
            IntPtr pointer = Marshal.AllocHGlobal(Size);
            Marshal.StructureToPtr(structure, pointer, false);
            return pointer;
        }

        /// <summary>
        /// Gets the END_OF_METHODS_LIST constant used to terminate an array of objc_method_list when defining a class.
        /// <para>The caller must free the native memory block allocated if needed.</para>
        /// </summary>
        /// <value>The END_OF_METHODS_LIST value.</value>
        public static IntPtr END_OF_METHODS_LIST
        {
            get
            {
                IntPtr pointer = Marshal.AllocHGlobal(IntPtr.Size);
                Marshal.WriteIntPtr(pointer, (IntPtr) (-1));
                return pointer;
            }
        }
    }
}