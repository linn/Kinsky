//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Monobjc.Runtime.ObjectiveC10
{
    /// <summary>
    /// <para>Defines an Objective-C class.</para>
    /// <para>The compiler generates two <see cref="objc_class"/> data structures for each class defined in your source code: one for the class definition and one for the metaclass definition. You can create class definitions at runtime by creating these data structures and calling the <see cref="NativeMethods.objc_addClass"/> function.</para>
    /// <para>The Objective-C declaration is :
    /// <code>
    /// struct objc_class
    /// {
    ///     struct objc_class* isa;
    ///     struct objc_class* super_class;
    ///     const char* name;
    ///     long version;
    ///     long info;
    ///     long instance_size;
    ///     struct objc_ivar_list* ivars;
    ///     struct objc_method_list** methodLists;
    ///     struct objc_cache* cache;
    ///     struct objc_protocol_list* protocols;
    /// };
    /// </code>
    /// </para>
    /// </summary>
    /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    internal struct objc_class : IDisposable
    {
        private static readonly int size = Marshal.SizeOf(typeof (objc_class));

        /// <summary>
        /// Points to the metaclass of this class. If this class is a metaclass, the isa field points to the root metaclass (usually the metaclass for NSObject, but also possibly the metaclass for NSProxy or a root class of your own�a root class is any class that does not inherit from another class). This also means that the isa field for the metaclass of the root class points to itself.
        /// </summary>
        public IntPtr isa;

        /// <summary>
        /// Points to the <see cref="objc_class"/> data structure for the superclass of this class, or NULL if this is a root class.
        /// </summary>
        public IntPtr super_class;

        /// <summary>
        /// Points to a C string containing the name of the class.
        /// </summary>
        public IntPtr name;

        /// <summary>
        /// An integer indicating the version number of the class, which you can modify at runtime using the class_setVersion function. The compiler initially defines the version field as 0.
        /// </summary>
        public int version;

        /// <summary>
        /// Contains a set of bit flags used by the Objective-C runtime functions. You can manipulate them using the following masks:
        /// <list type="bullet">
        /// <item>The CLS_CLASS (0x1L) flag indicates that this definition represents a class, which contains instance methods and variable definitions that are allocated for each new instance of the class.</item>
        /// <item>The CLS_META (0x2L) flag indicates that this class definition represents a metaclass, which contains the list of methods that are not specific to any one instance of the class (class methods).</item>
        /// <item>The CLS_INITIALIZED (0x4L) flag indicates that the runtime has initialized this class. This flag should be set only by the objc_addClass function.</item>
        /// <item>The CLS_POSING (0x8L) flag indicates that this class is posing as another class.</item>
        /// <item>The CLS_MAPPED (0x10L) flag is used internally by the Objective-C runtime.</item>
        /// <item>The CLS_FLUSH_CACHE (0x20L) flag is used internally by the Objective-C runtime.</item>
        /// <item>The CLS_GROW_CACHE ( 0x40L) flag is used internally by the Objective-C runtime.</item>
        /// <item>The CLS_NEED_BIND (0x80L) flag is used internally by the Objective-C runtime.</item>
        /// <item>The CLS_METHOD_ARRAY (0x100L) flag indicates that the methodLists field is an array of pointers to objc_method_list data structures rather than a pointer to a single objc_method_list data structure.</item>
        /// </list>
        /// </summary>
        public InfoMasks info;

        /// <summary>
        /// An integer indicating the size of the instance variables used by this class. This value includes the value of the instance_size field of the superclass.
        /// </summary>
        public int instance_size;

        /// <summary>
        /// A pointer to an objc_ivar_list data structure describing the instance variables that are allocated for each instance of this class. This pointer may be NULL, in which case this class has no instance variables.
        /// </summary>
        public IntPtr ivars;

        /// <summary>
        /// If the CLS_METHOD_ARRAY flag is set, this field is an array of objc_method_list data structures that collectively specify all the instance methods that can be sent to objects that are instances of this class. If the CLS_METHOD_ARRAY flag is not set, this field is a pointer to a single objc_method_list data structure. If this class is a metaclass definition, this field specifies the class methods of the class.
        /// </summary>
        public IntPtr methodLists;

        /// <summary>
        /// A pointer to an objc_cache method cache data structure.
        /// </summary>
        public IntPtr cache;

        /// <summary>
        /// A pointer to a objc_protocol_list data structure. This is a list of the formal protocols this class claims to implement.
        /// </summary>
        public IntPtr protocols;

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="objc_class"/>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override String ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("objc_class(");
            builder.Append(Marshal.PtrToStringAnsi(this.name));
            builder.Append(" - ");
            builder.Append(this.info);
            builder.Append(")");
            return builder.ToString();
        }

        /// <summary>
        /// Marshal a native pointer to an <see cref="objc_class"/> structure.
        /// </summary>
        /// <param name="pointer">The pointer to the native structure.</param>
        /// <returns>A <see cref="objc_class"/> structure.</returns>
        public static objc_class PtrToStructure(IntPtr pointer)
        {
            return (objc_class) Marshal.PtrToStructure(pointer, typeof (objc_class));
        }

        /// <summary>
        /// Marshal an <see cref="objc_class"/> structure to a native pointer.
        /// </summary>
        /// <param name="structure">The <see cref="objc_class"/> structure to marshal.</param>
        /// <returns>A pointer to the native structure.</returns>
        /// <remarks>Caller is responsible for freeing the allocated block of unmanaged memory.</remarks>
        public static IntPtr StructureToPtr(objc_class structure)
        {
            IntPtr pointer = Marshal.AllocHGlobal(Size);
            Marshal.StructureToPtr(structure, pointer, true);
            return pointer;
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose() {}

        /// <summary>
        /// Gets the size of this structure.
        /// </summary>
        /// <value>The size.</value>
        public static int Size
        {
            get { return size; }
        }
    }
}