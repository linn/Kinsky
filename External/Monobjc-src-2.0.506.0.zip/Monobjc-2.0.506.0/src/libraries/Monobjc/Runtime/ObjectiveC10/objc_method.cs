//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Monobjc.Runtime.ObjectiveC10
{
    /// <summary>
    /// <para>Represents a method in a class definition.</para>
    /// <para>The compiler generates the method type encodings in a format that includes information on the size of the stack and the size occupied by the arguments. These numbers appear after each encoding in the method_types string. However, because the compiler historically generates them incorrectly, and because they differ depending on the CPU type, the runtime ignores them if they are present. These numbers are not required by the Objective-C runtime in Mac OS X v10.0 or later.</para>
    /// <para>The Objective-C declaration is :
    /// <code>
    /// struct objc_method
    /// {
    ///     SEL method_name;
    ///     char * method_types;
    ///     IMP method_imp;
    /// };
    /// </code>
    /// </para>
    /// </summary>
    /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    internal struct objc_method : IDisposable
    {
        private static readonly int size = Marshal.SizeOf(typeof (objc_method));

        /// <summary>
        /// A pointer of type SEL. Points to the method selector that uniquely identifies the name of this method.
        /// </summary>
        public IntPtr method_name;

        /// <summary>
        /// A pointer to a C string. This string contains the type encodings for the method�s argument. See �Type Encodings� for information on valid encoding formats.
        /// </summary>
        public IntPtr method_types;

        /// <summary>
        /// A pointer to the start of the method implementation. In a class definition that represents a formal protocol, this field is NULL.
        /// </summary>
        public Delegate method_imp;

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="objc_method"/>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> containing a fully qualified type name.
        /// </returns>
        public override String ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("objc_method(");
            builder.Append(Marshal.PtrToStringAnsi(SafeNativeMethods.sel_getName(this.method_name)));
            builder.Append(" - ");
            builder.Append(Marshal.PtrToStringAnsi(this.method_types));
            builder.Append(")");
            return builder.ToString();
        }

        /// <summary>
        /// Marshal a native pointer to an <see cref="objc_method"/> structure.
        /// </summary>
        /// <param name="pointer">The pointer to the native structure.</param>
        /// <returns>A <see cref="objc_method"/> structure.</returns>
        public static objc_method PtrToStructure(IntPtr pointer)
        {
            return (objc_method) Marshal.PtrToStructure(pointer, typeof (objc_method));
        }

        /// <summary>
        /// Marshal an <see cref="objc_method"/> structure to a native pointer.
        /// </summary>
        /// <param name="structure">The <see cref="objc_method"/> structure to marshal.</param>
        /// <returns>A pointer to the native structure.</returns>
        /// <remarks>Caller is responsible for freeing the allocated block of unmanaged memory.</remarks>
        public static IntPtr StructureToPtr(objc_method structure)
        {
            IntPtr pointer = Marshal.AllocHGlobal(Size);
            Marshal.StructureToPtr(structure, pointer, false);
            return pointer;
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose() {}

        /// <summary>
        /// Gets the size of this structure.
        /// </summary>
        /// <value>The size.</value>
        public static int Size
        {
            get { return size; }
        }
    }
}