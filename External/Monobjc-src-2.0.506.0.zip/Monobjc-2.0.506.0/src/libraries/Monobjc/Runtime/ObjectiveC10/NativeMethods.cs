//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;

namespace Monobjc.Runtime.ObjectiveC10
{
    /// <summary>
    /// <para>Exports native methods exposed in <c>libobjc.dylib</c> shared library.</para>
    /// <para>Thanks to .NET P/Invoke system, most of the marshalling work is automatic.</para>
    /// <para>These methods are specific to Mac OS X 10.4.</para>
    /// </summary>
    internal static class NativeMethods
    {
        /// <summary>
        /// <para>Adds a list of methods to a class definition.</para>
        /// <para>All the methods in the specified method list must be mapped to valid selectors before they can be added to the class. You can use the sel_registerName function to perform this operation.</para>
        /// <para>After you call class_addMethods, the class definition contains the pointer to the method list data structure that you passed in. You cannot release the memory occupied by this data structure until you have removed the methods from the class definition using the class_removeMethods function.</para>
        /// <para>The original declaration is :
        /// <code>
        /// void class_addMethods(Class aClass, struct objc_method_list* methodList)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="aClass">A pointer to an objc_class data structure. To add instance methods, pass the class definition to which you wish to add the methods. To add class methods, pass the metaclass (aClass->isa instead of aClass).</param>
        /// <param name="methodList">A pointer to an objc_method_list data structure containing an array of methods to add to the specified class definition.</param>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern void class_addMethods(IntPtr aClass, IntPtr methodList);

        /// <summary>
        /// <para>Globally override a specified class definition with a different class definition.</para>
        /// <para>You can use this function to globally override the definition of a class with an immediate subclass. Whenever a request is made of the original class, the imposter class is substituted as the receiver.</para>
        /// <para>Generally, this function is called by the poseAs: method of the NSObject class, so you should never need to call it yourself.</para>
        /// <para>The original declaration is :
        /// <code>
        /// Class class_poseAs(Class imposter, Class original);
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="imposter">A pointer to an objc_class data structure. Pass the class definition that replaces the original. The imposter class definition must be an immediate subclass of the original (that is, (imposter->super_class == original) must be a true statement), and the imposter must not contain instance variables (imposter->ivars must be NULL.)</param>
        /// <param name="original">A pointer to an objc_class data structure. Pass the class definition you wish to override.</param>
        /// <returns></returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern IntPtr class_poseAs(IntPtr imposter, IntPtr original);

        /// <summary>
        /// <para>Registers a class definition with the Objective-C runtime.</para>
        /// <para>Be sure that you have already set up the class definition correctly, with appropriate links to its metaclass definition and to the definition of its superclass. Listing 2 demonstrates how to properly create and add a class to the Objective-C runtime. Once a class is registered, you can get a pointer to the objc_class data structure of this class using the Foundation framework function NSClassFromString.</para>
        /// <para>The original declaration is :
        /// <code>
        /// void objc_addClass(Class myClass);
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="myClass">A pointer to an objc_class data structure. Pass the class definition you wish to register.</param>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern void objc_addClass(IntPtr myClass);

#if !MANAGED_SWIZZLING
        /// <summary>
        /// <para></para>
        /// </summary>
        [DllImport("@executable_path/libmonobjc.1.dylib", EntryPoint = "hook_thread_lifecycle")]
        public static extern int hook_thread_lifecycle();

        /// <summary>
        /// <para></para>
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        [DllImport("@executable_path/libmonobjc.1.dylib", EntryPoint = "set_dealloc_callback")]
        public static extern bool set_dealloc_callback(RuntimeBridge.DeallocCallback callback);

        /// <summary>
        /// <para></para> 
        /// </summary>
        /// <param name="cls"></param>
        /// <returns></returns>
        [DllImport("@executable_path/libmonobjc.1.dylib", EntryPoint = "intercept_dealloc_for")]
        public static extern bool intercept_dealloc_for(IntPtr cls);

        /// <summary>
        /// <para></para>
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        [DllImport("@executable_path/libmonobjc.1.dylib", EntryPoint = "add_object")]
        public static extern bool add_object(IntPtr target);

        /// <summary>
        /// <para></para>
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        [DllImport("@executable_path/libmonobjc.1.dylib", EntryPoint = "contains_object")]
        public static extern int contains_object(IntPtr target);

        /// <summary>
        /// <para></para>
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        [DllImport("@executable_path/libmonobjc.1.dylib", EntryPoint = "remove_object")]
        public static extern bool remove_object(IntPtr target);
#endif
    }
}