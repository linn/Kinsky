//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc.Runtime.ObjectiveC10
{
    /// <summary>
    /// <para>A set of bit flags used by the Objective-C runtime functions.</para>
    /// </summary>
    /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
    [Flags]
    internal enum InfoMasks
    {
        /// <summary>
        /// The CLS_CLASS (0x1) flag indicates that this definition represents a class, which contains instance methods and variable definitions that are allocated for each new instance of the class.
        /// </summary>
        CLS_CLASS = 0x0001,
        /// <summary>
        /// The CLS_META (0x2) flag indicates that this class definition represents a metaclass, which contains the list of methods that are not specific to any one instance of the class (class methods).
        /// </summary>
        CLS_META = 0x0002,
        /// <summary>
        /// The CLS_INITIALIZED (0x4) flag indicates that the runtime has initialized this class. This flag should be set only by the objc_addClass function.
        /// </summary>
        CLS_INITIALIZED = 0x0004,
        /// <summary>
        /// The CLS_POSING (0x8) flag indicates that this class is posing as another class.
        /// </summary>
        CLS_POSING = 0x0008,
        /// <summary>
        /// The CLS_MAPPED (0x10) flag is used internally by the Objective-C runtime.
        /// </summary>
        CLS_MAPPED = 0x0010,
        /// <summary>
        /// The CLS_FLUSH_CACHE (0x20) flag is used internally by the Objective-C runtime.
        /// </summary>
        CLS_FLUSH_CACHE = 0x0020,
        /// <summary>
        /// The CLS_GROW_CACHE ( 0x40) flag is used internally by the Objective-C runtime.
        /// </summary>
        CLS_GROW_CACHE = 0x0040,
        /// <summary>
        /// The CLS_NEED_BIND (0x80) flag is used internally by the Objective-C runtime.
        /// </summary>
        CLS_NEED_BIND = 0x0080,
        /// <summary>
        /// The CLS_METHOD_ARRAY (0x100) flag indicates that the methodLists field is an array of pointers to objc_method_list data structures rather than a pointer to a single objc_method_list data structure.
        /// <remarks>This flag is currently unused in the runtime (cf. runtime/objc-class.m source file). Use <see cref="CLS_NO_METHOD_ARRAY"/> flag instead.</remarks>
        /// </summary>
        CLS_METHOD_ARRAY = 0x0100,
        /// <summary>
        /// The JavaBridge constructs classes with this marker.
        /// </summary>
        CLS_JAVA_HYBRID = 0x0200,
        /// <summary>
        /// The JavaBridge constructs classes with this marker.
        /// </summary>
        CLS_JAVA_CLASS = 0x0400,
        /// <summary>
        /// The CLS_INITIALIZING (0x0800) flag indicates that the +initialize method is thread-safe.
        /// </summary>
        CLS_INITIALIZING = 0x0800,
        /// <summary>
        /// The CLS_FROM_BUNDLE (0x1000) flag indicates that the class supports bundle unloading.
        /// </summary>
        CLS_FROM_BUNDLE = 0x1000,
        /// <summary>
        /// The CLS_HAS_CXX_STRUCTORS (0x2000) flag indicates that the class has C++ ivars.
        /// </summary>
        CLS_HAS_CXX_STRUCTORS = 0x2000,
        /// <summary>
        /// The CLS_HAS_CXX_STRUCTORS (0x4000) flag indicates that the methods are not defined with an array.
        /// </summary>
        CLS_NO_METHOD_ARRAY = 0x4000,
        /// <summary>
        /// The CLS_HAS_LOAD_METHOD (0x8000) flag indicates that the class has a +load method.
        /// </summary>
        CLS_HAS_LOAD_METHOD = 0x8000,
    }
}