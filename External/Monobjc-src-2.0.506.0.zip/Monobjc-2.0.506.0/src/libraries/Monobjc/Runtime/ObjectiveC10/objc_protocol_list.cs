//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;

namespace Monobjc.Runtime.ObjectiveC10
{
    /// <summary>
    /// <para>Represents a list of formal protocols.</para>
    /// <para>A formal protocol is a class definition that declares a set of methods, which a class must implement. Such a class definition contains no instance variables. A class definition may promise to implement any number of formal protocols.</para>
    /// <para>The Objective-C declaration is :
    /// <code>
    /// struct objc_protocol_list
    /// {
    ///     struct objc_protocol_list *next;
    ///     int count;
    ///     Protocol *list[1];
    /// };
    /// </code>
    /// </para>
    /// </summary>
    /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
    [StructLayout(LayoutKind.Sequential)]
    internal struct objc_protocol_list
    {
        private static readonly int size = Marshal.SizeOf(typeof (objc_protocol_list));

        /// <summary>
        /// A pointer to another <see cref="objc_protocol_list"/> data structure.
        /// </summary>
        public IntPtr next;

        /// <summary>
        /// The number of protocols in this list.
        /// </summary>
        public int count;

        // Note: Due to limitations of the .NET framework, we cannot have variable-length structure array inside a structure.
        // struct Protocol *list[1];

        /// <summary>
        /// Gets the size of this structure.
        /// </summary>
        /// <value>The size.</value>
        public static int Size
        {
            get { return size; }
        }

        /// <summary>
        /// Marshal a native pointer to an <see cref="objc_protocol_list"/> structure.
        /// </summary>
        /// <param name="pointer">The pointer to the native structure.</param>
        /// <returns>A <see cref="objc_protocol_list"/> structure.</returns>
        public static objc_protocol_list PtrToStructure(IntPtr pointer)
        {
            return (objc_protocol_list) Marshal.PtrToStructure(pointer, typeof (objc_protocol_list));
        }

        /// <summary>
        /// Marshal an <see cref="objc_protocol_list"/> structure to a native pointer.
        /// </summary>
        /// <param name="structure">The <see cref="objc_protocol_list"/> structure to marshal.</param>
        /// <returns>A pointer to the native structure.</returns>
        /// <remarks>Caller is responsible for freeing the allocated block of unmanaged memory.</remarks>
        public static IntPtr StructureToPtr(objc_protocol_list structure)
        {
            IntPtr pointer = Marshal.AllocHGlobal(Size);
            Marshal.StructureToPtr(structure, pointer, false);
            return pointer;
        }
    }
}