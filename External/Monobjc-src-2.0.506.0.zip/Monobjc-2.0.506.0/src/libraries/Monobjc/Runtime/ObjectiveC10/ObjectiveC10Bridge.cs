//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using Monobjc.Bridge.Generators;
using Monobjc.Properties;

namespace Monobjc.Runtime.ObjectiveC10
{
    /// <summary>
    /// A <see cref="RuntimeBridge"/> implementation that is targeted on Mac OS X 10.4/Objective-C 1.0.
    /// </summary>
    internal class ObjectiveC10Bridge : RuntimeBridge
    {
        /// <summary>
        /// Gets the name of the class.
        /// </summary>
        /// <param name="nativePointer">A pointer to a class structure (opaque or not).</param>
        /// <returns>The class name</returns>
        public override String GetClassName(IntPtr nativePointer)
        {
            objc_class cls = objc_class.PtrToStructure(nativePointer);
            return Marshal.PtrToStringAnsi(cls.name);
        }

        /// <summary>
        /// Gets a pointer to the super class structure (opaque or not).
        /// </summary>
        /// <param name="nativePointer">A pointer to a class structure (opaque or not).</param>
        /// <returns>
        /// A pointer to a class structure (opaque or not).
        /// </returns>
        public override IntPtr GetSuperClass(IntPtr nativePointer)
        {
            objc_class cls = objc_class.PtrToStructure(nativePointer);
            return cls.super_class;
        }

        /// <summary>
        /// Defines the class, by using various attributes.
        /// </summary>
        /// <param name="generator">The dynamic proxy generator.</param>
        /// <param name="type">The type that contains the definition attibutes.</param>
        public override void DefineClass(ProxyGenerator generator, Type type)
        {
            if (type == null)
            {
                throw new ArgumentNullException("type", Resources.CannotDefineObjectiveCClassFromNullType);
            }

            // Check if the class is already mapped
            Class cls = Class.GetClass(type);
            if (cls != null)
            {
                return;
            }

            // Extract class name from attributes
            String className = ObjectiveCRuntime.ExtractClassName(type);

            // Check for class existence
            IntPtr existentClass = SafeNativeMethods.objc_lookUpClass(className);
            if (existentClass != IntPtr.Zero)
            {
                cls = new Class(existentClass);
                Class.MapClass(type, className, cls);
                return;
            }

            // Extract class name from attributes
            String superClassName = ObjectiveCRuntime.ExtractSuperClassName(type);

            // Get the superclass
            IntPtr superClassPtr = SafeNativeMethods.objc_lookUpClass(superClassName);
            if (superClassPtr == IntPtr.Zero)
            {
                throw new ObjectiveCException(String.Format(CultureInfo.CurrentCulture, Resources.CannotDefineClassBecauseSuperclassDoesNotExists, type, superClassName));
            }

            // Marshal the superclass structure
            objc_class superClassStruct = objc_class.PtrToStructure(superClassPtr);
            objc_class rootClassStruct = GetRootClass(superClassStruct);

            // Check to see if the defined class is posed
            bool interceptor = ObjectiveCRuntime.IsAnInterceptor(type);

            // Placeholders for structures
            List<ProxyGenerator.VariableTuple> variableTuples = new List<ProxyGenerator.VariableTuple>();
            List<ProxyGenerator.MethodTuple> instanceMethods = new List<ProxyGenerator.MethodTuple>();
            List<ProxyGenerator.MethodTuple> classMethods = new List<ProxyGenerator.MethodTuple>();

            // Collects the informations needed for class generation
            ProxyGenerator.CollectStructures(type, variableTuples, instanceMethods, classMethods);

#if MANAGED_SWIZZLING
            // Collects the base method implementation pointers for chained call
            if (interceptor)
            {
                for (int i = 0; i < instanceMethods.Count; i++)
                {
                    ProxyGenerator.MethodTuple tuple = instanceMethods[i];

                    IntPtr selector = SafeNativeMethods.sel_registerName(tuple.selector);
                    tuple.baseMethod = SafeNativeMethods.class_getInstanceMethod(superClassPtr, selector);
                    // HACK : Little hack to read the implementation pointer.
                    // When unmarshalling the Method to a objc_method, the implementation pointer
                    // is not correctly cast to a Delegate. So we read it straight from memory instead.
                    IntPtr pointer = new IntPtr(tuple.baseMethod.ToInt64() + 2*IntPtr.Size);
                    IntPtr value = Marshal.ReadIntPtr(pointer);

                    // Store the value
                    String key = superClassName + "@" + tuple.selector;
                    this.baseImplementations.Add(key, value);

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("ObjectiveC10Bridge", "Storing orginal method pointer for class '" + superClassName + "', method '" + tuple.selector + "' (IMP=0x" + value.ToString("x") + ")");
                    }
                }
            }
#else
            if (interceptor)
            {
                if (Logger.InfoEnabled)
                {
                    Logger.Info("ObjectiveC10Bridge", "Intercepting 'dealloc' calls for class " + superClassName);
                }
                this.InterceptDeallocFor(superClassPtr);
            }
#endif

            // Generates the proxy and the associated structures
            generator.CreateProxy(type, variableTuples, instanceMethods, classMethods);

            // Setup the meta class
            objc_class metaClassStuct = new objc_class();
            metaClassStuct.isa = rootClassStruct.isa;
            metaClassStuct.super_class = superClassStruct.isa;
            metaClassStuct.instance_size = objc_class.PtrToStructure(superClassStruct.isa).instance_size;
            metaClassStuct.name = Marshal.StringToHGlobalAnsi(className);
            metaClassStuct.info = InfoMasks.CLS_META;
            metaClassStuct.methodLists = objc_method_list.END_OF_METHODS_LIST;

            // Marshal the meta class
            IntPtr metaClassPtr = objc_class.StructureToPtr(metaClassStuct);

            // Setup the class
            objc_class objcClassStruct = new objc_class();
            objcClassStruct.isa = metaClassPtr;
            objcClassStruct.super_class = superClassPtr;
            objcClassStruct.name = metaClassStuct.name;
            objcClassStruct.info = InfoMasks.CLS_CLASS;
            objcClassStruct.methodLists = objc_method_list.END_OF_METHODS_LIST;
            objcClassStruct.ivars = IntPtr.Zero; // No ivars by default

            // Compute the size of the class
            int classSize = superClassStruct.instance_size;

            // Note : A root class or an imposter class cannot have ivars
            if (!interceptor && (variableTuples.Count > 0))
            {
                // Filter variables to select only those declared in this type
                List<ProxyGenerator.VariableTuple> declaredVariableTuples = variableTuples.FindAll(
                    delegate(ProxyGenerator.VariableTuple tuple) { return tuple.declared; });

                // Allocates a space large enough to hold both objc_ivar_list and objc_ivar structures.
                IntPtr ivarListPtr = Marshal.AllocHGlobal(objc_ivar_list.Size + declaredVariableTuples.Count*objc_ivar.Size);

                // Create a new objc_ivar_list
                objc_ivar_list ivarList = new objc_ivar_list();
                ivarList.count = declaredVariableTuples.Count;

                // Marshal the objc_ivar_list at the beginning of the allocated memory
                Marshal.StructureToPtr(ivarList, ivarListPtr, true);

                // Compute initial offset for marshalling of the first objc_ivar
                IntPtr marshalOffset = new IntPtr(ivarListPtr.ToInt64() + objc_ivar_list.Size);

                // Add each instance variable
                for (int i = 0; i < declaredVariableTuples.Count; i++)
                {
                    // Add the offset of the variable in the class
                    ProxyGenerator.VariableTuple tuple = declaredVariableTuples[i];

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("ObjectiveC10Bridge", "Adding instance variable '" + tuple.name + "'");
                    }

                    // Shift class size to include this instance variable
                    tuple.offset = classSize;
                    classSize += tuple.size;

                    // Build a new ivar and add it to the memory zone
                    objc_ivar ivar = new objc_ivar();
                    ivar.ivar_name = Marshal.StringToHGlobalAnsi(tuple.name);
                    ivar.ivar_type = Marshal.StringToHGlobalAnsi(tuple.encoding);
                    ivar.ivar_offset = tuple.offset;
                    Marshal.StructureToPtr(ivar, marshalOffset, true);

                    // Compute new offset for marshalling of the next objc_ivar
                    marshalOffset = new IntPtr(marshalOffset.ToInt64() + objc_ivar.Size);
                }

                objcClassStruct.ivars = ivarListPtr;
            }

            // Set up the class size (with instance variables)
            objcClassStruct.instance_size = classSize;

            // Marshal class
            IntPtr objcClassPtr = objc_class.StructureToPtr(objcClassStruct);

            // Register the class
            NativeMethods.objc_addClass(objcClassPtr);

            // Add instance methods
            {
                // Allocates a space large enough to hold both objc_method_list and objc_method structures.
                IntPtr instanceMethodListPointer = Marshal.AllocHGlobal(objc_method_list.Size + instanceMethods.Count*objc_method.Size);

                // Create a new objc_method_list
                objc_method_list methodList = new objc_method_list();
                methodList.obsolete = IntPtr.Zero;
                methodList.method_count = instanceMethods.Count;

                // Marshal the objc_method_list at the beginning of the allocated memory
                Marshal.StructureToPtr(methodList, instanceMethodListPointer, true);

                // Compute initial offset for marshalling of the first objc_method
                IntPtr marshalOffset = new IntPtr(instanceMethodListPointer.ToInt64() + objc_method_list.Size);

                // Add each instance variable
                for (int i = 0; i < instanceMethods.Count; i++)
                {
                    // Add the offset of the variable in the class
                    ProxyGenerator.MethodTuple tuple = instanceMethods[i];

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("ObjectiveC10Bridge", "Adding instance method '" + tuple.selector + "'");
                    }

                    // Build a new method and add it to the memory zone
                    objc_method method = new objc_method();
                    method.method_name = SafeNativeMethods.sel_registerName(tuple.selector);
                    method.method_types = Marshal.StringToHGlobalAnsi(tuple.signature);
                    method.method_imp = tuple.function;
                    Marshal.StructureToPtr(method, marshalOffset, true);

                    // Compute new offset for marshalling of the next objc_method
                    marshalOffset = new IntPtr(marshalOffset.ToInt64() + objc_method.Size);
                }

                // Add methods to the class
                NativeMethods.class_addMethods(objcClassPtr, instanceMethodListPointer);
            }

            // Add static methods
            {
                // Allocates a space large enough to hold both objc_method_list and objc_method structures.
                IntPtr classMethodListPointer = Marshal.AllocHGlobal(objc_method_list.Size + classMethods.Count*objc_method.Size);

                // Create a new objc_method_list
                objc_method_list methodList = new objc_method_list();
                methodList.obsolete = IntPtr.Zero;
                methodList.method_count = classMethods.Count;

                // Marshal the objc_method_list at the beginning of the allocated memory
                Marshal.StructureToPtr(methodList, classMethodListPointer, true);

                // Compute initial offset for marshalling of the first objc_method
                IntPtr marshalOffset = new IntPtr(classMethodListPointer.ToInt64() + objc_method_list.Size);

                // Add each instance variable
                for (int i = 0; i < classMethods.Count; i++)
                {
                    // Add the offset of the variable in the class
                    ProxyGenerator.MethodTuple tuple = classMethods[i];

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("ObjectiveC10Bridge", "Adding class method '" + tuple.selector + "'");
                    }

                    // Build a new method and add it to the memory zone
                    objc_method method = new objc_method();
                    method.method_name = SafeNativeMethods.sel_registerName(tuple.selector);
                    method.method_types = Marshal.StringToHGlobalAnsi(tuple.signature);
                    method.method_imp = tuple.function;
                    Marshal.StructureToPtr(method, marshalOffset, true);

                    // Compute new offset for marshalling of the next objc_method
                    marshalOffset = new IntPtr(marshalOffset.ToInt64() + objc_method.Size);
                }

                // Add methods to the meta-class
                NativeMethods.class_addMethods(metaClassPtr, classMethodListPointer);
            }

#if MANAGED_SWIZZLING
            // Redirect the method if needed
            // Note: redirect implementation only for instance methods
            if (interceptor)
            {
                for (int i = 0; i < instanceMethods.Count; i++)
                {
                    ProxyGenerator.MethodTuple tuple = instanceMethods[i];

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("ObjectiveC10Bridge", "Switching method implementation for '" + tuple.selector + "'");
                    }

                    IntPtr pointer = new IntPtr(tuple.baseMethod.ToInt64() + 2*IntPtr.Size);
                    Marshal.WriteIntPtr(pointer, Marshal.GetFunctionPointerForDelegate(tuple.function));
                }
            }
#endif

            // Map new class in the runtime maps
            cls = new Class(objcClassPtr);
            if (interceptor)
            {
                Class.MapClass(type, superClassName, cls.SuperClass);
            }
            else
            {
                Class.MapClass(type, className, cls);
            }
        }

        /// <summary>
        /// Climb up the class hierarchy to find out the root class.
        /// </summary>
        /// <param name="classStruct">The class struct.</param>
        /// <returns>The class at the top of the hierarchy</returns>
        private static objc_class GetRootClass(objc_class classStruct)
        {
            objc_class rootClassStruct = classStruct;
            while (rootClassStruct.super_class != IntPtr.Zero)
            {
                rootClassStruct = objc_class.PtrToStructure(rootClassStruct.super_class);
            }
            return rootClassStruct;
        }

#if !MANAGED_SWIZZLING
        /// <summary>
        /// TODO: doc
        /// </summary>
        public override void HookThreadLifecycle()
        {
            try
            {
                Logger.Info("ObjectiveC10Bridge", "Installing the thread management...");
		int result = NativeMethods.hook_thread_lifecycle();
                Logger.Info("ObjectiveC10Bridge", "Thread management selected: " + result);
            }
            catch(DllNotFoundException ex)
            {
                // TODO: I18N
                throw new ObjectiveCException("The 'libmonobjc.1.dylib' library was not found. Please check that you have correctly installed it.", ex);
            }
        }

        /// <summary>
        /// TODO: doc
        /// </summary>
        public override void SetDeallocCallback(DeallocCallback callback)
        {
            try
            {
                Logger.Info("ObjectiveC10Bridge", "Installing the dealloc callback");
                NativeMethods.set_dealloc_callback(callback);
            }
            catch(DllNotFoundException ex)
            {
                // TODO: I18N
                throw new ObjectiveCException("The 'libmonobjc.1.dylib' library was not found. Please check that you have correctly installed it.", ex);
            }
        }

        /// <summary>
        /// TODO: doc
        /// </summary>
        public override void InterceptDeallocFor(IntPtr cls)
        {
            NativeMethods.intercept_dealloc_for(cls);
        }

        /// <summary>
        /// TODO: doc
        /// </summary>
        public override void AddObject(IntPtr target)
        {
            NativeMethods.add_object(target);
        }

        /// <summary>
        /// TODO: doc
        /// </summary>
        public override bool ContainsObject(IntPtr target)
        {
            return (NativeMethods.contains_object(target) != 0);
        }

        /// <summary>
        /// TODO: doc
        /// </summary>
        public override void RemoveObject(IntPtr target)
        {
            NativeMethods.remove_object(target);
        }
#endif
    }
}