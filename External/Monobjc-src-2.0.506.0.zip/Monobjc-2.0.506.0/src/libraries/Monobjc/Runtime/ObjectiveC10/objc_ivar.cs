//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Monobjc.Runtime.ObjectiveC10
{
    /// <summary>
    /// <para>Specifies the name, type, and location of one instance variable.</para>
    /// <para>The <see cref="objc_ivar_list"/> data structure contains an array of <see cref="objc_ivar"/> elements, each of which indicates the name, type, and location of one instance variable.</para>
    /// <para>The Objective-C declaration is :
    /// <code>
    /// typedef struct objc_ivar *Ivar;
    /// 
    /// struct objc_ivar
    /// {
    ///     char* ivar_name;
    ///     char* ivar_type;
    ///     int ivar_offset;
    /// };
    /// </code>
    /// </para>
    /// </summary>
    /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    internal struct objc_ivar : IDisposable
    {
        private static readonly int size = Marshal.SizeOf(typeof (objc_ivar));

        /// <summary>
        /// A pointer to a C string containing the name of the instance variable.
        /// </summary>
        public IntPtr ivar_name;

        /// <summary>
        /// A pointer to a C string containing the type encoding of the variable. See "Type Encodings" for valid type encodings for instance variables.
        /// </summary>
        public IntPtr ivar_type;

        /// <summary>
        /// An integer indicating the location of this instance variable within the memory allocated for an instance of the class containing this variable. The offset is from the start of the instance memory to the location of this variable.
        /// </summary>
        public int ivar_offset;

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="objc_ivar"/>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> containing a fully qualified type name.
        /// </returns>
        public override String ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("objc_ivar(");
            builder.Append(Marshal.PtrToStringAnsi(this.ivar_name));
            builder.Append(" - ");
            builder.Append(Marshal.PtrToStringAnsi(this.ivar_type));
            builder.Append(" - ");
            builder.Append(this.ivar_offset);
            builder.Append(")");
            return builder.ToString();
        }

        /// <summary>
        /// Marshal a native pointer to an <see cref="objc_ivar"/> structure.
        /// </summary>
        /// <param name="pointer">The pointer to the native structure.</param>
        /// <returns>A <see cref="objc_ivar"/> structure.</returns>
        public static objc_ivar PtrToStructure(IntPtr pointer)
        {
            return (objc_ivar) Marshal.PtrToStructure(pointer, typeof (objc_ivar));
        }

        /// <summary>
        /// Marshal an <see cref="objc_ivar"/> structure to a native pointer.
        /// </summary>
        /// <param name="structure">The <see cref="objc_ivar"/> structure to marshal.</param>
        /// <returns>A pointer to the native structure.</returns>
        /// <remarks>Caller is responsible for freeing the allocated block of unmanaged memory.</remarks>
        public static IntPtr StructureToPtr(objc_ivar structure)
        {
            IntPtr pointer = Marshal.AllocHGlobal(Size);
            Marshal.StructureToPtr(structure, pointer, false);
            return pointer;
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose() {}

        /// <summary>
        /// Gets the size of this structure.
        /// </summary>
        /// <value>The size.</value>
        public static int Size
        {
            get { return size; }
        }
    }
}