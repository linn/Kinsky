//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using Monobjc.Bridge.Generators;
using Monobjc.Properties;

namespace Monobjc.Runtime.ObjectiveC20
{
    /// <summary>
    /// A <see cref="RuntimeBridge"/> implementation that is targeted on Mac OS X 10.5/Objective-C 2.0.
    /// </summary>
    internal class ObjectiveC20Bridge : RuntimeBridge
    {
        /// <summary>
        /// Gets the name of the class.
        /// </summary>
        /// <param name="nativePointer">A pointer to a class structure (opaque or not).</param>
        /// <returns>The class name</returns>
        public override String GetClassName(IntPtr nativePointer)
        {
            return Marshal.PtrToStringAnsi(NativeMethods.class_getName(nativePointer));
        }

        /// <summary>
        /// Gets a pointer to the super class structure (opaque or not).
        /// </summary>
        /// <param name="nativePointer">A pointer to a class structure (opaque or not).</param>
        /// <returns>
        /// A pointer to a class structure (opaque or not).
        /// </returns>
        public override IntPtr GetSuperClass(IntPtr nativePointer)
        {
            return NativeMethods.class_getSuperclass(nativePointer);
        }

        /// <summary>
        /// Defines the class, by using various attributes.
        /// </summary>
        /// <param name="generator">The dynamic proxy generator.</param>
        /// <param name="type">The type that contains the definition attibutes.</param>
        public override void DefineClass(ProxyGenerator generator, Type type)
        {
            if (type == null)
            {
                throw new ArgumentNullException("type", Resources.CannotDefineObjectiveCClassFromNullType);
            }

            // Check if the class is already mapped
            Class cls = Class.GetClass(type);
            if (cls != null)
            {
                return;
            }

            // Extract class name from attributes
            String className = ObjectiveCRuntime.ExtractClassName(type);

            // Check for class existence
            IntPtr existentClass = SafeNativeMethods.objc_lookUpClass(className);
            if (existentClass != IntPtr.Zero)
            {
                cls = new Class(existentClass);
                Class.MapClass(type, className, cls);
                return;
            }

            // Extract class name from attributes
            String superClassName = ObjectiveCRuntime.ExtractSuperClassName(type);

            // Get the superclass
            IntPtr superClassPtr = SafeNativeMethods.objc_lookUpClass(superClassName);
            if (superClassPtr == IntPtr.Zero)
            {
                throw new ObjectiveCException(String.Format(CultureInfo.CurrentCulture, Resources.CannotDefineClassBecauseSuperclassDoesNotExists, type, superClassName));
            }

            // Check to see if the defined class is posed
            bool interceptor = ObjectiveCRuntime.IsAnInterceptor(type);

            // Placeholders for structures
            List<ProxyGenerator.VariableTuple> variableTuples = new List<ProxyGenerator.VariableTuple>();
            List<ProxyGenerator.MethodTuple> instanceMethods = new List<ProxyGenerator.MethodTuple>();
            List<ProxyGenerator.MethodTuple> classMethods = new List<ProxyGenerator.MethodTuple>();

            // Collects the informations needed for class generation
            ProxyGenerator.CollectStructures(type, variableTuples, instanceMethods, classMethods);

#if MANAGED_SWIZZLING
            // Collects the base method implementation pointers for chained call
            if (interceptor)
            {
                for (int i = 0; i < instanceMethods.Count; i++)
                {
                    ProxyGenerator.MethodTuple tuple = instanceMethods[i];
                    IntPtr selector = SafeNativeMethods.sel_registerName(tuple.selector);
                    tuple.baseMethod = SafeNativeMethods.class_getInstanceMethod(superClassPtr, selector);
                    IntPtr value = NativeMethods.method_getImplementation(tuple.baseMethod);

                    // Store the value
                    String key = superClassName + "@" + tuple.selector;
                    this.baseImplementations.Add(key, value);

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("ObjectiveC20Bridge", "Storing orginal method pointer for class '" + superClassName + "', method '" + tuple.selector + "' (IMP=0x" + value.ToString("x") + ")");
                    }
                }
            }
#else
            if (interceptor)
            {
                if (Logger.InfoEnabled)
                {
                    Logger.Info("ObjectiveC20Bridge", "Intercepting 'dealloc' calls for class " + superClassName);
                }
                this.InterceptDeallocFor(superClassPtr);
            }
#endif

            // Generates the proxy and the associated structures
            generator.CreateProxy(type, variableTuples, instanceMethods, classMethods);

            // Compute the extra bytes needed to store the indexed ivars
            int extraSize = 0;

            // Note : A root class or an imposter class cannot have ivars
            if (!interceptor && (variableTuples.Count > 0))
            {
                // Filter variables to select only those declared in this type
                List<ProxyGenerator.VariableTuple> declaredVariableTuples = variableTuples.FindAll(
                    delegate(ProxyGenerator.VariableTuple tuple) { return tuple.declared; });

                // Add each instance variable
                for (int i = 0; i < declaredVariableTuples.Count; i++)
                {
                    ProxyGenerator.VariableTuple tuple = declaredVariableTuples[i];
                    extraSize += tuple.size;
                }
            }

            // Allocates both class and meta class
            IntPtr objcClassPtr = NativeMethods.objc_allocateClassPair(superClassPtr, className, extraSize);
            IntPtr metaClassPtr = NativeMethods.object_getClass(objcClassPtr);

            // Note : A root class or an imposter class cannot have ivars
            if (!interceptor && (variableTuples.Count > 0))
            {
                // Filter variables to select only those declared in this type
                List<ProxyGenerator.VariableTuple> declaredVariableTuples = variableTuples.FindAll(
                    delegate(ProxyGenerator.VariableTuple tuple) { return tuple.declared; });

                // Add each instance variable
                for (int i = 0; i < declaredVariableTuples.Count; i++)
                {
                    ProxyGenerator.VariableTuple tuple = declaredVariableTuples[i];

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("ObjectiveC20Bridge", "Adding instance variable '" + tuple.name + "'");
                    }

                    if (!NativeMethods.class_addIvar(objcClassPtr, tuple.name, tuple.size, 2, tuple.encoding))
                    {
                        throw new ObjectiveCClassMappingException(String.Format(CultureInfo.CurrentCulture, Resources.FailedToAddIvarToClass, tuple.name, className, type.FullName));
                    }
                }
            }

            // Add instance methods
            {
                // Add each instance method
                for (int i = 0; i < instanceMethods.Count; i++)
                {
                    ProxyGenerator.MethodTuple tuple = instanceMethods[i];

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("ObjectiveC20Bridge", "Adding instance method '" + tuple.selector + "'");
                    }

                    if (!NativeMethods.class_addMethod(objcClassPtr, SafeNativeMethods.sel_registerName(tuple.selector), tuple.function, tuple.signature))
                    {
                        throw new ObjectiveCClassMappingException(String.Format(CultureInfo.CurrentCulture, Resources.FailedToInstanceMethodToClass, tuple.selector, className, type.FullName));
                    }
                }
            }

            // Add static methods
            {
                // Add each static method
                for (int i = 0; i < classMethods.Count; i++)
                {
                    ProxyGenerator.MethodTuple tuple = classMethods[i];

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("ObjectiveC20Bridge", "Adding class method '" + tuple.selector + "'");
                    }

                    if (!NativeMethods.class_addMethod(metaClassPtr, SafeNativeMethods.sel_registerName(tuple.selector), tuple.function, tuple.signature))
                    {
                        throw new ObjectiveCClassMappingException(String.Format(CultureInfo.CurrentCulture, Resources.FailedToClassMethodToClass, tuple.selector, className, type.FullName));
                    }
                }
            }

            // Register the class
            NativeMethods.objc_registerClassPair(objcClassPtr);

#if MANAGED_SWIZZLING
            // Redirect the method if needed
            // Note: redirect implementation only for instance methods
            if (interceptor)
            {
                for (int i = 0; i < instanceMethods.Count; i++)
                {
                    ProxyGenerator.MethodTuple tuple = instanceMethods[i];

                    if (Logger.DebugEnabled)
                    {
                        Logger.Debug("ObjectiveC20Bridge", "Switching method implementation for '" + tuple.selector + "'");
                    }

                    NativeMethods.method_setImplementation(tuple.baseMethod, tuple.function);
                }
            }
#endif

            // Map new class in the runtime maps
            cls = new Class(objcClassPtr);
            if (interceptor)
            {
                Class.MapClass(type, superClassName, cls.SuperClass);
            }
            else
            {
                Class.MapClass(type, className, cls);
            }
        }

#if !MANAGED_SWIZZLING
        /// <summary>
        /// TODO: doc
        /// </summary>
        public override void HookThreadLifecycle()
        {
            try
            {
                Logger.Info("ObjectiveC20Bridge", "Installing the thread management...");
		int result = NativeMethods.hook_thread_lifecycle();
                Logger.Info("ObjectiveC20Bridge", "Thread management selected: " + result);
            }
            catch(DllNotFoundException ex)
            {
                // TODO: I18N
                throw new ObjectiveCException("The 'libmonobjc.2.dylib' library was not found. Please check that you have correctly installed it.", ex);
            }
        }

        /// <summary>
        /// TODO: doc
        /// </summary>
        /// <param name="callback">The callback.</param>
        public override void SetDeallocCallback(DeallocCallback callback)
        {
            try
            {
                Logger.Info("ObjectiveC20Bridge", "Installing the lifecycle callback");
                NativeMethods.set_dealloc_callback(callback);
            }
            catch (DllNotFoundException ex)
            {
                // TODO: I18N
                throw new ObjectiveCException("The 'libmonobjc.2.dylib' library was not found. Please check that you have correctly installed it.", ex);
            }
        }

        /// <summary>
        /// TODO: doc
        /// </summary>
        public override void InterceptDeallocFor(IntPtr cls)
        {
            NativeMethods.intercept_dealloc_for(cls);
        }

        /// <summary>
        /// TODO: doc
        /// </summary>
        public override void AddObject(IntPtr target)
        {
            NativeMethods.add_object(target);
        }

        /// <summary>
        /// TODO: doc
        /// </summary>
        public override bool ContainsObject(IntPtr target)
        {
            return (NativeMethods.contains_object(target) != 0);
        }

        /// <summary>
        /// TODO: doc
        /// </summary>
        public override void RemoveObject(IntPtr target)
        {
            NativeMethods.remove_object(target);
        }
#endif
    }
}