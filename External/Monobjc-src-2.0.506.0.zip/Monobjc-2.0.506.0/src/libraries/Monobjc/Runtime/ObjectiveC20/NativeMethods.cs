//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;

namespace Monobjc.Runtime.ObjectiveC20
{
    /// <summary>
    /// <para>Exports native methods exposed in <c>libobjc.dylib</c> shared library.</para>
    /// <para>Thanks to .NET P/Invoke system, most of the marshalling work is automatic.</para>
    /// <para>These methods are specific to Mac OS X 10.5.</para>
    /// </summary>
    internal static class NativeMethods
    {
        /// <summary>
        /// <para>Adds a new instance variable to a class.</para>
        /// <para>This function may only be called after <see cref="objc_allocateClassPair"/> and before <see cref="objc_registerClassPair"/>. Adding an instance variable to an existing class is not supported.</para>
        /// <para>The class must not be a metaclass. Adding an instance variable to a metaclass is not supported.</para>
        /// <para>The instance variable's minimum alignment in bytes is 1&lt;&lt;align. The minimum alignment of an instance variable depends on the ivar's type and the machine architecture. For variables of any pointer type, pass log2(sizeof(pointer_type)).</para>
        /// <para>The original declaration is :
        /// <code>
        /// BOOL class_addIvar(Class cls, const char *name, size_t size, uint8_t alignment, const char *types)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="cls">The class to which to add a variable.</param>
        /// <param name="name">The name.</param>
        /// <param name="size">The size.</param>
        /// <param name="alignment">The alignment.</param>
        /// <param name="types">The types.</param>
        /// <returns>
        /// YES if the variable was added successfully, otherwise NO (for example, the class already contains an instance variable with that name).
        /// </returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern bool class_addIvar(IntPtr cls, [MarshalAs(UnmanagedType.LPStr)] String name, int size, [MarshalAs(UnmanagedType.U1)] int alignment, [MarshalAs(UnmanagedType.LPStr)] String types);

        /// <summary>
        /// <para>Adds a new method to a class with a given name and implementation.</para>
        /// <para><see cref="class_addMethod"/> will add an override of a superclass's implementation, but will not replace an existing implementation in this class. To change an existing implementation, use method_setImplementation.</para>
        /// <para>An Objective-C method is simply a C function that take at least two arguments�self and _cmd. For example, given the following function:
        /// <code>
        /// void myMethodIMP(id self, SEL _cmd) 
        /// { 
        ///   // implementation .... 
        /// }
        /// </code>
        /// you can dynamically add it to a class as a method (called resolveThisMethodDynamically) like this:
        /// <code>
        /// class_addMethod([self class], @selector(resolveThisMethodDynamically), (IMP) myMethodIMP, "v@:"); 
        /// </code>
        /// </para>
        /// <para>The original declaration is :
        /// <code>
        /// BOOL class_addMethod(Class cls, SEL name, IMP imp, const char *types)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="cls">The class to which to add a method.</param>
        /// <param name="name">A selector that specifies the name of the method being added.</param>
        /// <param name="imp">A function which is the implementation of the new method. The function must take at least two arguments�self and _cmd.</param>
        /// <param name="types">An array of characters that describe the types of the arguments to the method. For possible values, see The Objective-C 2.0 Programming Language > The Runtime System > �Type Encodings�. Since the function must take at least two arguments�self and _cmd, the second and third characters must be �@:� (the first character is the return type).</param>
        /// <returns>
        /// YES if the method was added successfully, otherwise NO (for example, the class already contains an instance variable with that name).
        /// </returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern bool class_addMethod(IntPtr cls, IntPtr name, Delegate imp, [MarshalAs(UnmanagedType.LPStr)] String types);

        /// <summary>
        /// <para>Returns the name of a class.</para>
        /// <para>The original declaration is :
        /// <code>
        /// const char * class_getName(Class cls)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="cls">A class object.</param>
        /// <returns>The name of the class, or the empty string if cls is Nil.</returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern IntPtr class_getName(IntPtr cls);

        /// <summary>
        /// <para>Returns the name of a class.</para>
        /// <para>You should usually use NSObject�s superclass method instead of this function.</para>
        /// <para>The original declaration is :
        /// <code>
        /// Class class_getSuperclass(Class cls)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="cls">A class object.</param>
        /// <returns>The superclass of the class, or Nil if cls is a root class, or Nil if cls is Nil.</returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern IntPtr class_getSuperclass(IntPtr cls);

        /// <summary>
        /// <para>Returns the implementation of a method.</para>
        /// <para>The original declaration is :
        /// <code>
        /// IMP method_getImplementation(Method method)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="method">The method to inspect.</param>
        /// <returns>
        /// A function pointer of type IMP.
        /// </returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern IntPtr method_getImplementation(IntPtr method);

        /// <summary>
        /// <para>Sets the implementation of a method.</para>
        /// <para>The original declaration is :
        /// <code>
        /// IMP method_setImplementation(Method method, IMP imp)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="method">The method.</param>
        /// <param name="imp">The imp.</param>
        /// <returns>
        /// The previous implementation of the method.
        /// </returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern IntPtr method_setImplementation(IntPtr method, Delegate imp);

        /// <summary>
        /// <para>Creates a new class and metaclass.</para>
        /// <para>You can get a pointer to the new metaclass by calling <see cref="object_getClass"/>.</para>
        /// <para>To create a new class, start by calling <see cref="objc_allocateClassPair"/>. Then set the class's attributes with functions like <see cref="class_addMethod"/> and <see cref="class_addIvar"/>. When you are done building the class, call <see cref="objc_registerClassPair"/>. The new class is now ready for use.</para>
        /// <para>The original declaration is :
        /// <code>
        /// objc_allocateClassPair(Class superclass, const char *name, size_t extraBytes)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="superclass">The class to use as the new class's superclass, or Nil to create a new root class.</param>
        /// <param name="name">The string to use as the new class's name. The string will be copied.</param>
        /// <param name="extraBytes">The number of bytes to allocate for indexed ivars at the end of the class and metaclass objects. This should usually be 0.</param>
        /// <returns>
        /// The new class, or Nil if the class could not be created (for example, the desired name is already in use).
        /// </returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern IntPtr objc_allocateClassPair(IntPtr superclass, [MarshalAs(UnmanagedType.LPStr)] String name, int extraBytes);

        /// <summary>
        /// <para>Registers a class that was allocated using <see cref="objc_allocateClassPair"/>.</para>
        /// <para>The original declaration is :
        /// <code>
        /// void objc_registerClassPair(Class cls)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="cls">The class you want to register.</param>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern void objc_registerClassPair(IntPtr cls);

        /// <summary>
        /// <para>Returns the class of an object.</para>
        /// <para>The original declaration is :
        /// <code>
        /// Class object_getClass(id object)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="object">The object you want to inspect.</param>
        /// <returns>
        /// The class object of which object is an instance, or Nil if object is nil.
        /// </returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern IntPtr object_getClass(IntPtr @object);

#if !MANAGED_SWIZZLING
        /// <summary>
        /// <para></para>
        /// </summary>
        [DllImport("@executable_path/libmonobjc.2.dylib", EntryPoint = "hook_thread_lifecycle")]
        public static extern int hook_thread_lifecycle();

        /// <summary>
        /// <para></para>
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        [DllImport("@executable_path/libmonobjc.2.dylib", EntryPoint = "set_dealloc_callback")]
        public static extern bool set_dealloc_callback(RuntimeBridge.DeallocCallback callback);

        /// <summary>
        /// <para></para> 
        /// </summary>
        /// <param name="cls"></param>
        /// <returns></returns>
        [DllImport("@executable_path/libmonobjc.2.dylib", EntryPoint = "intercept_dealloc_for")]
        public static extern bool intercept_dealloc_for(IntPtr cls);

        /// <summary>
        /// <para></para>
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        [DllImport("@executable_path/libmonobjc.2.dylib", EntryPoint = "add_object")]
        public static extern bool add_object(IntPtr target);

        /// <summary>
        /// <para></para>
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        [DllImport("@executable_path/libmonobjc.2.dylib", EntryPoint = "contains_object")]
        public static extern int contains_object(IntPtr target);

        /// <summary>
        /// <para></para>
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        [DllImport("@executable_path/libmonobjc.2.dylib", EntryPoint = "remove_object")]
        public static extern bool remove_object(IntPtr target);
#endif
    }
}