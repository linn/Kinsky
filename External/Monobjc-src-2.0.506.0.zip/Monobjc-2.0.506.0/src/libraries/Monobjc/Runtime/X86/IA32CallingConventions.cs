//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;

namespace Monobjc.Runtime.X86
{
    /// <summary>
    /// 32bits Intel Architecture conventions.
    /// </summary>
    internal class IA32CallingConventions : ArchitectureCallingConventions
    {
        /// <summary>
        /// Determines whether the specified type must be treated as a floating type.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>
        /// 	<c>true</c> if the specified type must be treated as a floating type; otherwise, <c>false</c>.
        /// </returns>
        public override bool IsFloatingType(Type type)
        {
            return (type == typeof (float) || type == typeof (double));
        }

        /// <summary>
        /// Determines whether the specified type is a small structure, which means that it can be marshalled directly through processor registers.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>
        /// 	<c>true</c> if the specified type is a small structure; otherwise, <c>false</c>.
        /// </returns>
        public override bool IsSmallStructure(Type type)
        {
            return (Marshal.SizeOf(type) <= 8);
        }

        /// <summary>
        /// Gets a value indicating whether this architecture has a big-endian byte ordering.
        /// </summary>
        /// <value><c>true</c> if this architecture has big-endian byte ordering; otherwise, <c>false</c>.</value>
        public override bool IsBigEndian
        {
            get { return false; }
        }

        /// <summary>
        /// Gets a value indicating whether this architecture is a 64 bits one.
        /// </summary>
        /// <value><c>true</c> if this architecture is a 64 bits one; otherwise, <c>false</c>.</value>
        public override bool Is64Bits
        {
            get { return false; }
        }
    }
}