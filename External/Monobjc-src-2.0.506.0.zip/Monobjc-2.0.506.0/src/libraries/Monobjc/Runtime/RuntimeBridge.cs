//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using Monobjc.Bridge.Generators;
using Monobjc.Properties;
using Monobjc.Runtime.ObjectiveC10;
using Monobjc.Runtime.ObjectiveC20;
#if MANAGED_SWIZZLING
using System.Collections.Generic;
#endif

namespace Monobjc.Runtime
{
    /// <summary>
    /// <para>The RuntimeBridge is responsible to manage all the runtime specific tasks:</para>
    /// <list type="bullet">
    /// <item>Class creation and registration</item>
    /// <item>Method creation and registration</item>
    /// <item>Class lookup</item>
    /// <item>...</item>
    /// </list>
    /// <para>These tasks differs from one runtime to another so they are grouped.</para>
    /// </summary>
    internal abstract class RuntimeBridge
    {
        // Hold the singleton RuntimeBridge
        private static RuntimeBridge current;

#if MANAGED_SWIZZLING
        /// <summary>
        /// Contains for each imposter class a map between a method and the base implementation.
        /// </summary>
        protected readonly IDictionary<string, IntPtr> baseImplementations = new Dictionary<String, IntPtr>();
#else
        /// <summary>
        /// TODO: doc
        /// </summary>
        /// <param name="target"></param>
        internal delegate void DeallocCallback(IntPtr target);

        /// <summary>
        /// TODO: doc
        /// </summary>
        private static readonly DeallocCallback CALLBACK = RemoveTarget;
#endif

        /// <summary>
        /// Gets the current platform conventions.
        /// </summary>
        /// <value>The current platform conventions.</value>
        public static RuntimeBridge Current
        {
            [MethodImpl(MethodImplOptions.Synchronized)]
            get
            {
                if (current == null)
                {
                    OSVersion version = Gestalt.GetOSVersion();
                    Logger.Info("RuntimeBridge", "Operating system detected : " + version);
                    switch (version)
                    {
                        case OSVersion.MACOS_10_4:
                            current = new ObjectiveC10Bridge();
                            break;
                        case OSVersion.MACOS_10_5:
                            current = new ObjectiveC20Bridge();
                            break;
                        case OSVersion.MACOS_10_6:
                            current = new ObjectiveC20Bridge();
                            break;
                        default:
                            throw new ObjectiveCException(String.Format(CultureInfo.CurrentCulture, Resources.MacOSXVersionNotSupported, version));
                    }
                    Logger.Info("RuntimeBridge", "Using the '" + current.GetType().Name + "' strategy");
#if !MANAGED_SWIZZLING
                    current.HookThreadLifecycle();
                    current.SetDeallocCallback(CALLBACK);
#endif
                }
                return current;
            }
        }

        /// <summary>
        /// Gets the name of the class.
        /// </summary>
        /// <param name="nativePointer">A pointer to a class structure (opaque or not).</param>
        /// <returns>The class name</returns>
        public abstract String GetClassName(IntPtr nativePointer);

        /// <summary>
        /// Gets a pointer to the super class structure (opaque or not).
        /// </summary>
        /// <param name="nativePointer">A pointer to a class structure (opaque or not).</param>
        /// <returns>A pointer to a class structure (opaque or not).</returns>
        public abstract IntPtr GetSuperClass(IntPtr nativePointer);

        /// <summary>
        /// Defines the class, by using various attributes.
        /// </summary>
        /// <param name="generator">The dynamic proxy generator.</param>
        /// <param name="type">The type that contains the definition attibutes.</param>
        public abstract void DefineClass(ProxyGenerator generator, Type type);

#if MANAGED_SWIZZLING
        /// <summary>
        /// Gets the base method implementation pointer.
        /// </summary>
        /// <param name="className">Name of the class.</param>
        /// <param name="selector">The selector.</param>
        /// <returns>A pointer to the method implementation</returns>
        public IntPtr GetBaseImplementationPointer(String className, String selector)
        {
            String key = className + "@" + selector;
            if (this.baseImplementations.ContainsKey(key))
            {
                return this.baseImplementations[key];
            }
            throw new ObjectiveCException(String.Format(CultureInfo.CurrentCulture, Resources.InvalidBaseImplementationMethodPointer, className, selector));
        }
#else
        /// <summary>
        /// TODO: MISSING
        /// </summary>
        public abstract void HookThreadLifecycle();

        /// <summary>
        /// Install the dealloc callback method that will remove instance from bridge's cache.
        /// </summary>
        /// <param name="callback">The callback.</param>
        public abstract void SetDeallocCallback(DeallocCallback callback);

        /// <summary>
        /// Install a dealloc callback for all instances of the given class.
        /// </summary>
        /// <param name="cls">The class.</param>
        public abstract void InterceptDeallocFor(IntPtr cls);

        /// <summary>
        /// Add a target in the bridge's cache.
        /// </summary>
        /// <param name="target">The target to add.</param>
        public abstract void AddObject(IntPtr target);

        /// <summary>
        /// Test if a target is in the bridge's cache.
        /// </summary>
        /// <param name="target">The target.</param>
        public abstract bool ContainsObject(IntPtr target);

        /// <summary>
        /// Remove a target from the bridge's cache.
        /// </summary>
        /// <param name="target">The target.</param>
        public abstract void RemoveObject(IntPtr target);

        /// <summary>
        /// Callback method called when an instance is removed from the bridg�'s cache.
        /// </summary>
        /// <param name="pointer"></param>
        private static void RemoveTarget(IntPtr pointer)
        {
            ObjectiveCRuntime.RemoveInstance(pointer);
        }
#endif
    }
}