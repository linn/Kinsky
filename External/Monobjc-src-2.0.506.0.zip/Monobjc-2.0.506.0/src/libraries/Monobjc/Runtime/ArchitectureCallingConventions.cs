//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using Monobjc.Properties;
using Monobjc.Runtime.PowerPC;
using Monobjc.Runtime.X86;

namespace Monobjc.Runtime
{
    /// <summary>
    /// <para>Utility class to adapt marshalling behaviour to the platform.</para>
    /// <para>For example, small value types can be returned directly from processor registers. As it depends of the processor  behaviour must be adapted for each platform or processor.</para>
    /// <para>For more details, see the "Introduction to Mac OS X ABI Function Call Guide" (http://developer.apple.com/documentation/DeveloperTools/Conceptual/LowLevelABI/Introduction.html).</para>
    /// </summary>
    internal abstract class ArchitectureCallingConventions
    {
        private bool allowDynamicCode;
        private static ArchitectureCallingConventions current;

        /// <summary>
        /// Gets the current platform conventions.
        /// </summary>
        /// <value>The current platform conventions.</value>
        public static ArchitectureCallingConventions Current
        {
            get
            {
                if (current == null)
                {
                    NXArchInfo archinfo = NXArchInfo.NXGetLocalArchInfo();
                    switch (archinfo.cputype)
                    {
                        case CPU_TYPE.CPU_TYPE_POWERPC:
                            current = new PPC32CallingConventions();
                            break;
                        case CPU_TYPE.CPU_TYPE_POWERPC64:
                            current = new PPC64CallingConventions();
                            Logger.Warn("ArchitectureCallingConventions", String.Format(CultureInfo.CurrentCulture, Resources.ArchitectureNotTested, archinfo.CpuType));
                            break;
                        case CPU_TYPE.CPU_TYPE_X86:
                            current = new IA32CallingConventions();
                            break;
                        case CPU_TYPE.CPU_TYPE_X86_64:
                            current = new IA64CallingConventions();
                            Logger.Warn("ArchitectureCallingConventions", String.Format(CultureInfo.CurrentCulture, Resources.ArchitectureNotTested, archinfo.CpuType));
                            break;
                        default:
                            throw new NotSupportedException(String.Format(CultureInfo.CurrentCulture, Resources.ArchitectureNotSupported, archinfo.CpuType));
                    }

                    Logger.Info("ArchitectureCallingConventions", "Architecture detected is:");
                    Logger.Info("ArchitectureCallingConventions", "\tCPU Type       : " + archinfo.CpuType);
                    Logger.Info("ArchitectureCallingConventions", "\tCPU Sub-Type   : " + archinfo.CpuSubType);
                    Logger.Info("ArchitectureCallingConventions", "\tByte ordering  : " + (current.IsBigEndian ? "Big-Endian" : "Little-Endian"));
                    Logger.Info("ArchitectureCallingConventions", "\t64 bits        : " + (current.Is64Bits ? "YES" : "NO"));
                }
                return current;
            }
        }

        /// <summary>
        /// Determines whether the specified type must be treated as a floating type.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>
        /// 	<c>true</c> if the specified type must be treated as a floating type; otherwise, <c>false</c>.
        /// </returns>
        public abstract bool IsFloatingType(Type type);

        /// <summary>
        /// Determines whether the specified type is structure.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>
        /// 	<c>true</c> if the specified type is structure; otherwise, <c>false</c>.
        /// </returns>
        public virtual bool IsStructure(Type type)
        {
            return (type.IsValueType && !type.IsEnum && !type.Namespace.Equals("System"));
        }

        /// <summary>
        /// Determines whether the specified type is a small structure, which means that it can be marshalled directly through processor registers.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>
        /// 	<c>true</c> if the specified type is a small structure; otherwise, <c>false</c>.
        /// </returns>
        public abstract bool IsSmallStructure(Type type);

        /// <summary>
        /// Gets a value indicating whether this architecture has a big-endian byte ordering.
        /// </summary>
        /// <value><c>true</c> if this architecture has big-endian byte ordering; otherwise, <c>false</c>.</value>
        public abstract bool IsBigEndian { get; }

        /// <summary>
        /// Gets a value indicating whether this architecture is a 64 bits one.
        /// </summary>
        /// <value><c>true</c> if this architecture is a 64 bits one; otherwise, <c>false</c>.</value>
        public abstract bool Is64Bits { get; }

        /// <summary>
        /// Gets a value indicating whether dynamic code generation is allowed.
        /// </summary>
        /// <value><c>true</c> if dynamic code generation is allowed; otherwise, <c>false</c>.</value>
        public virtual bool AllowDynamicCode
        {
            get
            {
                String debug = Environment.GetEnvironmentVariable("MONOBJC_STATIC");
                this.allowDynamicCode = Boolean.Parse(debug ?? "false");
                return this.allowDynamicCode;
            }
        }
    }
}