//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Monobjc.Runtime
{
    /// <summary>
    /// <para>This structure is used to hold the name of the architecture and the corresponding CPU
    /// type and CPU subtype, together with the architecture's byte order and a brief description string.</para>
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    internal struct NXArchInfo
    {
        /// <summary>
        /// The name of the architecture.
        /// </summary>
        [MarshalAs(UnmanagedType.LPStr)]
        public String name;

        /// <summary>
        /// The corresponding CPU type.
        /// </summary>
        public CPU_TYPE cputype;

        /// <summary>
        /// The corresponding CPU subtype.
        /// </summary>
        public int cpusubtype;

        /// <summary>
        /// The architecture's byte order.
        /// </summary>
        public NXByteOrder byteorder;

        /// <summary>
        /// A brief description string.
        /// </summary>
        [MarshalAs(UnmanagedType.LPStr)]
        public String description;

        /// <summary>
        /// Returns the CPU type as a string.
        /// </summary>
        /// <value>The CPU type.</value>
        public String CpuType
        {
            get { return this.cputype.ToString(); }
        }

        /// <summary>
        /// Returns the CPU subtype as a string.
        /// </summary>
        /// <value>The CPU subtype.</value>
        public String CpuSubType
        {
            get
            {
                // Select correct enumeration according to the CPU type.
                Type enumType = null;
                switch (this.cputype)
                {
                    case CPU_TYPE.CPU_TYPE_ANY:
                    case CPU_TYPE.CPU_TYPE_ARM:
                    case CPU_TYPE.CPU_TYPE_I860:
                    case CPU_TYPE.CPU_TYPE_ALPHA:
                        enumType = typeof (CPU_SUBTYPE_ANY);
                        break;
                    case CPU_TYPE.CPU_TYPE_VAX:
                        enumType = typeof (CPU_SUBTYPE_VAX);
                        break;
                    case CPU_TYPE.CPU_TYPE_MC680x0:
                        enumType = typeof (CPU_SUBTYPE_MC680x0);
                        break;
                    case CPU_TYPE.CPU_TYPE_X86:
                    case CPU_TYPE.CPU_TYPE_X86_64:
                        enumType = typeof (CPU_SUBTYPE_I386);
                        break;
                    case CPU_TYPE.CPU_TYPE_MIPS:
                        enumType = typeof (CPU_SUBTYPE_MIPS);
                        break;
                    case CPU_TYPE.CPU_TYPE_MC98000:
                        enumType = typeof (CPU_SUBTYPE_MC98000);
                        break;
                    case CPU_TYPE.CPU_TYPE_HPPA:
                        enumType = typeof (CPU_SUBTYPE_HPPA);
                        break;
                    case CPU_TYPE.CPU_TYPE_MC88000:
                        enumType = typeof (CPU_SUBTYPE_MC88000);
                        break;
                    case CPU_TYPE.CPU_TYPE_SPARC:
                        enumType = typeof (CPU_SUBTYPE_SPARC);
                        break;
                    case CPU_TYPE.CPU_TYPE_POWERPC:
                    case CPU_TYPE.CPU_TYPE_POWERPC64:
                        enumType = typeof (CPU_SUBTYPE_POWERPC);
                        break;
                }

                // Try to parse the value and return the name.
                if (enumType != null)
                {
                    return Enum.GetName(enumType, this.cpusubtype);
                }

                return String.Empty;
            }
        }

        /// <summary>
        /// Returns the details of this instance.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> containing the details of this instance.
        /// </returns>
        public override String ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("NXArchInfo:");
            builder.AppendLine(this.name);
            builder.AppendLine(this.CpuType);
            builder.AppendLine(this.CpuSubType);
            builder.AppendLine(this.byteorder.ToString());
            builder.AppendLine(this.description);
            return builder.ToString();
        }

        /// <summary>
        /// Returns the <see cref="NXArchInfo"/> for the local host, or null if none is known.
        /// </summary>
        /// <returns>A <see cref="NXArchInfo"/> structure.</returns>
        public static NXArchInfo NXGetLocalArchInfo()
        {
            IntPtr result = SafeNativeMethods.NXGetLocalArchInfo();
            NXArchInfo info = (NXArchInfo) Marshal.PtrToStructure(result, typeof (NXArchInfo));
            return info;
        }
    }

    /// <summary>
    /// Byte ordering enumeration, exposed in <see cref="NXArchInfo"/>.
    /// </summary>
    internal enum NXByteOrder
    {
        /// <summary>
        /// The byte ordering is unknown.
        /// </summary>
        NX_UnknownByteOrder,
        /// <summary>
        /// The byte ordering is "Little Endian".
        /// </summary>
        NX_LittleEndian,
        /// <summary>
        /// The byte ordering is "Big Endian".
        /// </summary>
        NX_BigEndian
    }

    /// <summary>
    /// Type of the CPU, exposed in <see cref="NXArchInfo"/>.
    /// </summary>
    internal enum CPU_TYPE
    {
        /// <summary>
        /// The CPU type is unknown.
        /// </summary>
        CPU_TYPE_ANY = -1,
        /// <summary>
        /// The CPU type is VAX.
        /// </summary>
        CPU_TYPE_VAX = 1,
        /// <summary>
        /// The CPU type is Motorola MC680x0.
        /// </summary>
        CPU_TYPE_MC680x0 = 6,
        /// <summary>
        /// The CPU type is Intel x86.
        /// </summary>
        CPU_TYPE_X86 = 7,
        /// <summary>
        /// The CPU type is Intel x86 64 bits.
        /// </summary>
        CPU_TYPE_X86_64 = CPU_TYPE_X86 | 0x01000000,
        /// <summary>
        /// The CPU type is MIPS.
        /// </summary>
        CPU_TYPE_MIPS = 8,
        /// <summary>
        /// The CPU type is Motorola MC98000.
        /// </summary>
        CPU_TYPE_MC98000 = 10,
        /// <summary>
        /// The CPU type is HP-PA Risc.
        /// </summary>
        CPU_TYPE_HPPA = 11,
        /// <summary>
        /// The CPU type is ARM.
        /// </summary>
        CPU_TYPE_ARM = 12,
        /// <summary>
        /// The CPU type is Motorola MC88000.
        /// </summary>
        CPU_TYPE_MC88000 = 13,
        /// <summary>
        /// The CPU type is Sun Sparc.
        /// </summary>
        CPU_TYPE_SPARC = 14,
        /// <summary>
        /// The CPU type is I860.
        /// </summary>
        CPU_TYPE_I860 = 15,
        /// <summary>
        /// The CPU type is Digital Alpha.
        /// </summary>
        CPU_TYPE_ALPHA = 16,
        /// <summary>
        /// The CPU type is IBM PowerPC.
        /// </summary>
        CPU_TYPE_POWERPC = 18,
        /// <summary>
        /// The CPU type is IBM PowerPC 64 bits.
        /// </summary>
        CPU_TYPE_POWERPC64 = CPU_TYPE_POWERPC | 0x01000000,
    }

    /// <summary>
    /// CPU subtype for the any type.
    /// </summary>
    internal enum CPU_SUBTYPE_ANY
    {
        CPU_SUBTYPE_MULTIPLE = -1,
        CPU_SUBTYPE_LITTLE_ENDIAN = 0,
        CPU_SUBTYPE_BIG_ENDIAN = 1,
    }

    /// <summary>
    /// VAX CPU subtypes
    /// </summary>
    internal enum CPU_SUBTYPE_VAX
    {
        CPU_SUBTYPE_VAX_ALL = 0,
        CPU_SUBTYPE_VAX780 = 1,
        CPU_SUBTYPE_VAX785 = 2,
        CPU_SUBTYPE_VAX750 = 3,
        CPU_SUBTYPE_VAX730 = 4,
        CPU_SUBTYPE_UVAXI = 5,
        CPU_SUBTYPE_UVAXII = 6,
        CPU_SUBTYPE_VAX8200 = 7,
        CPU_SUBTYPE_VAX8500 = 8,
        CPU_SUBTYPE_VAX8600 = 9,
        CPU_SUBTYPE_VAX8650 = 10,
        CPU_SUBTYPE_VAX8800 = 11,
        CPU_SUBTYPE_UVAXIII = 12,
    }

    /// <summary>
    /// Motorola MC680x0 CPU subtypes
    /// </summary>
    internal enum CPU_SUBTYPE_MC680x0
    {
        CPU_SUBTYPE_MC680x0_ALL = 1,
        CPU_SUBTYPE_MC68030 = 1,
        CPU_SUBTYPE_MC68040 = 2,
        CPU_SUBTYPE_MC68030_ONLY = 3,
    }

    /// <summary>
    /// Intel I386 CPU subtypes
    /// </summary>
    internal enum CPU_SUBTYPE_I386
    {
        CPU_SUBTYPE_I386_ALL = 3,
        CPU_SUBTYPE_386 = 3,
        CPU_SUBTYPE_486 = 4,
        CPU_SUBTYPE_486SX = 4 + 128,
        CPU_SUBTYPE_586 = 5,
        CPU_SUBTYPE_PENT = 5,
        CPU_SUBTYPE_PENTPRO = 6 + 16,
        CPU_SUBTYPE_PENTII_M3 = 6 + 64,
        CPU_SUBTYPE_PENTII_M5 = 6 + 256,
        CPU_SUBTYPE_CELERON = 7 + 512,
        CPU_SUBTYPE_CELERON_MOBILE = 7 + 1024,
        CPU_SUBTYPE_PENTIUM_3 = 8,
        CPU_SUBTYPE_PENTIUM_3_M = 8 + 16,
        CPU_SUBTYPE_PENTIUM_3_XEON = 8 + 32,
        CPU_SUBTYPE_PENTIUM_M = 9,
        CPU_SUBTYPE_PENTIUM_4 = 10,
        CPU_SUBTYPE_PENTIUM_4_M = 10 + 16,
        CPU_SUBTYPE_ITANIUM = 11,
        CPU_SUBTYPE_ITANIUM_2 = 11 + 16,
        CPU_SUBTYPE_XEON = 12,
        CPU_SUBTYPE_XEON_MP = 12 + 16,
    }

    /// <summary>
    /// MIPS CPU subtypes
    /// </summary>
    internal enum CPU_SUBTYPE_MIPS
    {
        CPU_SUBTYPE_MIPS_ALL = 0,
        CPU_SUBTYPE_MIPS_R2300 = 1,
        CPU_SUBTYPE_MIPS_R2600 = 2,
        CPU_SUBTYPE_MIPS_R2800 = 3,
        CPU_SUBTYPE_MIPS_R2000a = 4, /* pmax */
        CPU_SUBTYPE_MIPS_R2000 = 5,
        CPU_SUBTYPE_MIPS_R3000a = 6, /* 3max */
        CPU_SUBTYPE_MIPS_R3000 = 7,
    }

    /// <summary>
    /// Motorola MC98000 CPU subtypes
    /// </summary>
    internal enum CPU_SUBTYPE_MC98000
    {
        CPU_SUBTYPE_MC98000_ALL = 0,
        CPU_SUBTYPE_MC98601 = 1,
    }

    /// <summary>
    /// Hewlett Packard PA CPU subtypes
    /// </summary>
    internal enum CPU_SUBTYPE_HPPA
    {
        CPU_SUBTYPE_HPPA_ALL = 0,
        CPU_SUBTYPE_HPPA_7100 = 0, /* compat */
        CPU_SUBTYPE_HPPA_7100LC = 1,
    }

    /// <summary>
    /// Motorola MC88000 CPU subtypes
    /// </summary>
    internal enum CPU_SUBTYPE_MC88000
    {
        CPU_SUBTYPE_MC88000_ALL = 0,
        CPU_SUBTYPE_MC88100 = 1,
        CPU_SUBTYPE_MC88110 = 2,
    }

    /// <summary>
    /// Sun Sparc CPU subtypes
    /// </summary>
    internal enum CPU_SUBTYPE_SPARC
    {
        CPU_SUBTYPE_SPARC_ALL = 0,
        CPU_SUBTYPE_I860_ALL = 0,
        CPU_SUBTYPE_I860_860 = 1,
    }

    /// <summary>
    /// Motorola PowerPC CPU subtypes
    /// </summary>
    internal enum CPU_SUBTYPE_POWERPC
    {
        CPU_SUBTYPE_POWERPC_ALL = 0,
        CPU_SUBTYPE_POWERPC_601 = 1,
        CPU_SUBTYPE_POWERPC_602 = 2,
        CPU_SUBTYPE_POWERPC_603 = 3,
        CPU_SUBTYPE_POWERPC_603e = 4,
        CPU_SUBTYPE_POWERPC_603ev = 5,
        CPU_SUBTYPE_POWERPC_604 = 6,
        CPU_SUBTYPE_POWERPC_604e = 7,
        CPU_SUBTYPE_POWERPC_620 = 8,
        CPU_SUBTYPE_POWERPC_750 = 9,
        CPU_SUBTYPE_POWERPC_7400 = 10,
        CPU_SUBTYPE_POWERPC_7450 = 11,
        CPU_SUBTYPE_POWERPC_970 = 100,
    }
}