//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;

namespace Monobjc.Runtime
{
    /// <summary>
    /// <para>Specifies the superclass of an instance.</para>
    /// <para>The compiler generates an <see cref="objc_super"/> data structure when it encounters the super keyword as the receiver of a message. It specifies the class definition of the particular superclass that should be messaged.</para>
    /// <para>The Objective-C declaration is :
    /// <code>
    /// struct objc_super
    /// {
    ///     id receiver;
    ///     Class class;
    /// };
    /// </code>
    /// </para>
    /// </summary>
    /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
    [StructLayout(LayoutKind.Sequential)]
    internal struct objc_super
    {
        private static readonly int size = Marshal.SizeOf(typeof (objc_super));

        /// <summary>
        /// A pointer of type id. Specifies an instance of a class.
        /// </summary>
        public IntPtr receiver;

        /// <summary>
        /// A pointer to a Class data structure. Specifies the particular superclass of the instance to message.
        /// </summary>
        public IntPtr super_class;

        /// <summary>
        /// Initializes a new instance of the <see cref="objc_super"/> class.
        /// </summary>
        /// <param name="receiver">The receiver.</param>
        /// <param name="super_class">The super_class.</param>
        public objc_super(IntPtr receiver, IntPtr super_class)
        {
            this.receiver = receiver;
            this.super_class = super_class;
        }

        /// <summary>
        /// Gets the size of this structure.
        /// </summary>
        /// <value>The size.</value>
        public static int Size
        {
            get { return size; }
        }

        /// <summary>
        /// Marshal a native pointer to an <see cref="objc_super"/> structure.
        /// </summary>
        /// <param name="value">The pointer to the native structure.</param>
        /// <returns>A <see cref="objc_super"/> structure.</returns>
        public static objc_super PtrToStructure(IntPtr value)
        {
            return (objc_super) Marshal.PtrToStructure(value, typeof (objc_super));
        }

        /// <summary>
        /// Marshal an <see cref="objc_super"/> structure to a native pointer.
        /// </summary>
        /// <param name="structure">The <see cref="objc_super"/> structure to marshal.</param>
        /// <returns>A pointer to the native structure.</returns>
        /// <remarks>Caller is responsible for freeing the allocated block of unmanaged memory.</remarks>
        public static IntPtr StructureToPtr(objc_super structure)
        {
            IntPtr pointer = Marshal.AllocHGlobal(Size);
            Marshal.StructureToPtr(structure, pointer, false);
            return pointer;
        }
    }
}