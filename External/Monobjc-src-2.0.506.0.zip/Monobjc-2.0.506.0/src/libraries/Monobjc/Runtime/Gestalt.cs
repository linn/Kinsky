//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
namespace Monobjc.Runtime
{
    /// <summary>
    /// <para>Utility class to makes Gestalt requests to the system.</para>
    /// </summary>
    internal static class Gestalt
    {
        /// <summary>
        /// <para>Return the MacOS version of the operating system.</para>
        /// </summary>
        /// <returns>A <see cref="OSVersion"/> value</returns>
        internal static OSVersion GetOSVersion()
        {
            // 'sysv' OSType
            const int selector = 0x73797376;
            int sysVersion = 0;
            SafeNativeMethods.Gestalt(selector, ref sysVersion);

            OSVersion version;

            if (sysVersion < (int) OSVersion.MACOS_10_0)
            {
                version = OSVersion.MACOS_Unrecognized;
            }
            else if (sysVersion < (int) OSVersion.MACOS_10_1)
            {
                version = OSVersion.MACOS_10_0;
            }
            else if (sysVersion < (int) OSVersion.MACOS_10_2)
            {
                version = OSVersion.MACOS_10_1;
            }
            else if (sysVersion < (int) OSVersion.MACOS_10_3)
            {
                version = OSVersion.MACOS_10_2;
            }
            else if (sysVersion < (int) OSVersion.MACOS_10_4)
            {
                version = OSVersion.MACOS_10_3;
            }
            else if (sysVersion < (int) OSVersion.MACOS_10_5)
            {
                version = OSVersion.MACOS_10_4;
            }
            else if (sysVersion < (int) OSVersion.MACOS_10_6)
            {
                version = OSVersion.MACOS_10_5;
            }
            else
            {
                version = OSVersion.MACOS_10_6;
            }

            return version;
        }
    }

    /// <summary>
    /// <para>Enumeration that holds hexadecimal values for MacOS system version.</para>
    /// </summary>
    internal enum OSVersion
    {
        /// <summary>
        /// Default value
        /// </summary>
        MACOS_Unrecognized = 0x0000,
        /// <summary>
        /// Value for MacOS 10.0.x a.k.a. Cheetah
        /// </summary>
        MACOS_10_0 = 0x1000,
        /// <summary>
        /// Value for MacOS 10.1.x a.k.a. Puma
        /// </summary>
        MACOS_10_1 = 0x1010,
        /// <summary>
        /// Value for MacOS 10.2.x a.k.a. Jaguar
        /// </summary>
        MACOS_10_2 = 0x1020,
        /// <summary>
        /// Value for MacOS 10.3.x a.k.a. Panther
        /// </summary>
        MACOS_10_3 = 0x1030,
        /// <summary>
        /// Value for MacOS 10.4.x a.k.a. Tiger
        /// </summary>
        MACOS_10_4 = 0x1040,
        /// <summary>
        /// Value for MacOS 10.5.x a.k.a. Leopard
        /// </summary>
        MACOS_10_5 = 0x1050,
        /// <summary>
        /// Value for MacOS 10.6.x a.k.a. Snow Leopard
        /// </summary>
        MACOS_10_6 = 0x1060,
    }
}