//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using Monobjc.Properties;

namespace Monobjc
{
    /// <summary>
    /// <para>This type represents a native object in the Objective-C runtime and is referenced through a memory pointer.</para>
    /// <para>For each managed instance is associated a native pointer that allows a two-way messaging between the .NET and the Objective-C runtime.</para>
    /// </summary>
    public partial class Id : IManagedWrapper, IDisposable, IEquatable<Id>
    {
        private IntPtr pointer = IntPtr.Zero;

        /// <summary>
        /// Initializes a new instance of the <see cref="Id"/> class.
        /// </summary>
        public Id() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="Id"/> class.
        /// </summary>
        /// <param name="value">The value.</param>
        public Id(IntPtr value)
        {
            this.NativePointer = value;
        }

        /// <summary>
        /// <para>Gets the class of the underlying instance.</para>
        /// <para>The result could be very different from the one returned by the <see cref="MappedClass"/> property,
        /// as the value returned is the result of the message "class" being passed to the native instance.</para>
        /// </summary>
        /// <value>The class.</value>
        /// <remarks>Original signature is '- (Class)class'</remarks>
        public Class Class
        {
            get { return ObjectiveCRuntime.SendMessage<Class>(this, "class"); }
        }

        /// <summary>
        /// <para>Gets the class mapped to this managed instance.</para>
        /// <para>The result could be very different from the one returned by the <see cref="Class"/> property,
        /// as the value returned is the result of the class mapped to the managed type.</para>
        /// </summary>
        /// <value>The native class mapped to this instance.</value>
        public Class MappedClass
        {
            get { return Class.GetClassFromObject(this); }
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public virtual void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Equalses the specified id.
        /// </summary>
        /// <param name="id">The id.</param>
        /// <returns></returns>
        public bool Equals(Id id)
        {
            if (id == null)
            {
                return false;
            }
            return Equals(this.pointer, id.pointer);
        }

        /// <summary>
        /// Cast the current instance to the given type. the cast is dynamically tested for safety
        /// </summary>
        /// <typeparam name="TInstance">The type of the instance.</typeparam>
        /// <returns>The cast instance</returns>
        /// <exception cref="ObjectiveCClassCastException">If an error occured during the cast</exception>
        public TInstance CastTo<TInstance>() where TInstance : class, IManagedWrapper
        {
            return ObjectiveCRuntime.CastTo<TInstance>(this);
        }

        /// <summary>
        /// Try to cast the current instance to the given type. The cast is dynamically tested for safety.
        /// </summary>
        /// <typeparam name="TInstance">The type of the instance.</typeparam>
        /// <returns>The cast instance or null if the cast is not valid</returns>
        public TInstance CastAs<TInstance>() where TInstance : class, IManagedWrapper
        {
            return ObjectiveCRuntime.CastAs<TInstance>(this);
        }

        /// <summary>
        /// <para>Gets or sets the underlying native pointer.</para>
        /// </summary>
        /// <value>The native pointer.</value>
        public IntPtr NativePointer
        {
            get { return this.pointer; }
            set
            {
                if (value == IntPtr.Zero)
                {
                    throw new ArgumentNullException("value", Resources.NativePointerCannotBeSetToZero);
                }
                if (value != this.NativePointer)
                {
                    this.pointer = ObjectiveCRuntime.MapInstance(value, this);
                }
            }
        }

        /// <summary>
        /// Determines whether the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <param name="obj">The <see cref="T:System.Object"></see> to compare with the current <see cref="T:System.Object"></see>.</param>
        /// <returns>
        /// true if the specified <see cref="T:System.Object"></see> is equal to the current <see cref="T:System.Object"></see>; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(this, obj))
            {
                return true;
            }
            return this.Equals(obj as Id);
        }

        /// <summary>
        /// Serves as a hash function for a particular type. <see cref="M:System.Object.GetHashCode"></see> is suitable for use in hashing algorithms and data structures like a hash table.
        /// </summary>
        /// <returns>
        /// A hash code for the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override int GetHashCode()
        {
            return this.pointer.GetHashCode();
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        /// <param name="cleanManaged"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool cleanManaged)
        {
            ObjectiveCRuntime.RemoveInstance(this);
        }

        /// <summary>
        /// Implements the operator !=.
        /// </summary>
        /// <param name="id1">The id1.</param>
        /// <param name="id2">The id2.</param>
        /// <returns>The result of the operator.</returns>
        public static bool operator !=(Id id1, Id id2)
        {
            return !Equals(id1, id2);
        }

        /// <summary>
        /// Implements the operator ==.
        /// </summary>
        /// <param name="id1">The id1.</param>
        /// <param name="id2">The id2.</param>
        /// <returns>The result of the operator.</returns>
        public static bool operator ==(Id id1, Id id2)
        {
            return Equals(id1, id2);
        }
    }
}