//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using Monobjc.Properties;

namespace Monobjc
{
    /// <summary>
    /// <para>Exposes a field to the Objective-C runtime, so it can be manipulated from the runtime.</para>
    /// <para>When the tagged type (with the <see cref="ObjectiveCClassAttribute"/>) is registered in the Objective-C
    /// runtime, all the tagged fields will be exported, which means they will be accessible from native classes.</para>
    /// <para>Fields declared by <see cref="ObjectiveCFieldAttribute"/> are synchronized before and after method calls if required (see <see cref="ObjectiveCMessageAttribute"/>).</para>
    /// </summary>
    /// 
    /// <example>
    /// <para>The following example shows how to use the <see cref="ObjectiveCFieldAttribute"/> attribute.</para>
    /// <code>
    /// [ObjectiveCClass]
    /// public class MyOwnType1 : NSObject
    /// {
    ///     [ObjectiveCField]
    ///     public bool myBool;
    /// 
    ///     [ObjectiveCField]
    ///     public NSString aString;
    /// 
    ///     public MyOwnType1()
    ///     {
    ///         ...
    ///     }
    ///     ...
    /// }
    /// </code>
    /// </example>
    [AttributeUsage(AttributeTargets.Field)]
    public sealed class ObjectiveCFieldAttribute : Attribute
    {
        private readonly String name;
        private int size = -1;

        /// <summary>
        /// <para>Initializes a new instance of the <see cref="ObjectiveCFieldAttribute"/> class.</para>
        /// </summary>
        public ObjectiveCFieldAttribute()
        {
            this.name = String.Empty;
        }

        /// <summary>
        /// <para>Initializes a new instance of the <see cref="ObjectiveCFieldAttribute"/> class.</para>
        /// <para>Note: the name MUST be an ANSI identifier.</para>
        /// </summary>
        public ObjectiveCFieldAttribute(String name)
        {
            this.name = name;
        }

        /// <summary>
        /// <para>Gets the name to be used when the enclosing type is registered within the Objective-C runtime.</para>
        /// </summary>
        /// <value>The name to use.</value>
        public String Name
        {
            get { return this.name; }
        }

        /// <summary>
        /// Gets or sets the type encoding to be used when the enclosing type is registered within the Objective-C runtime.
        /// <para>Use this property if you want to override the default mapping computed by <see cref="ObjectiveCEncoding"/>.</para>
        /// </summary>
        /// <value>The type encoding to use.</value>
        public String Encoding { get; set; }

        /// <summary>
        /// Gets or sets the size to be used when the enclosing type is registered within the Objective-C runtime.
        /// <para>Use this property if you want to override the default size computed by <see cref="ObjectiveCEncoding"/>.</para>
        /// </summary>
        /// <value>The size to use.</value>
        public int Size
        {
            get { return this.size; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", Resources.ValueMustBeGreaterThanZero);
                }
                this.size = value;
            }
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override String ToString()
        {
            return String.Format(CultureInfo.CurrentCulture,
                                 Resources.ObjectiveCFieldString,
                                 this.Name,
                                 this.Encoding,
                                 this.Size);
        }
    }
}