//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using Monobjc.Properties;
using Monobjc.Runtime;

namespace Monobjc
{
    public partial class ObjectiveCRuntime
    {
        /// <summary>
        /// <para>Defines the class in the Objective-C runtime.</para>
        /// <para>If the class is already defined in the Objective-C runtime, it does nothing.</para>
        /// <para>If the class is not defined in the Objective-C runtime, build a proxy that will
        /// be exported and exposed to the Objective-C runtime.</para>
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>A <see cref="Class"/> instance for the type.</returns>
        private static void DefineClass(Type type)
        {
            RuntimeBridge.Current.DefineClass(proxyProvider, type);
        }

        /// <summary>
        /// Extract the class name to use when defining a new class :
        /// <list type="number">
        /// <item>Check for the presence of a <see cref="ObjectiveCClassAttribute"/> on the type. If the attribute is missing, an exception is thrown.</item>
        /// <item>Check for the name value of the <see cref="ObjectiveCClassAttribute"/>. If the attribute doesn't supply a name, the short name of the Type is used.</item>
        /// </list>
        /// </summary>
        internal static String ExtractClassName(Type type)
        {
            String className;

            // Check that the type has a register attribute as we don't define type without register attribute
            ObjectiveCClassAttribute objectiveCClassAttribute = Attribute.GetCustomAttribute(type, typeof (ObjectiveCClassAttribute), false) as ObjectiveCClassAttribute;
            if (objectiveCClassAttribute == null)
            {
                throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, Resources.NoClassAttributeFoundForType, type.FullName));
            }
            else
            {
                // Use attribute value if any
                if (!String.IsNullOrEmpty(objectiveCClassAttribute.Name))
                {
                    className = objectiveCClassAttribute.Name;
                }
                else
                {
                    className = type.Name;
                }
            }

            return className;
        }

        /// <summary>
        /// Extract the super class name to use when defining a new class :
        /// <list type="number">
        /// <item>Check for the presence of a <see cref="ObjectiveCClassAttribute"/> on the base type. If the attribute is missing, an exception is thrown unless this is a for a Root Class.</item>
        /// <item>Check for the name value of the <see cref="ObjectiveCClassAttribute"/>. If the attribute doesn't supply a name, the short name of the Type is used.</item>
        /// <item>Check for the name found previously and correct it if the super class name is the imposter one.</item>
        /// </list>
        /// </summary>
        internal static String ExtractSuperClassName(Type type)
        {
            String className;

            // Check that the type has a register attribute as we don't define type without register attribute
            ObjectiveCClassAttribute objectiveCClassAttribute = Attribute.GetCustomAttribute(type, typeof (ObjectiveCClassAttribute), false) as ObjectiveCClassAttribute;
            if (objectiveCClassAttribute == null)
            {
                throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, Resources.NoClassAttributeFoundForType, type.FullName));
            }

            // Check that the type has a register attribute as we don't define type with a broken hierarchy.
            ObjectiveCClassAttribute superObjectiveCClassAttribute = Attribute.GetCustomAttribute(type.BaseType, typeof (ObjectiveCClassAttribute), false) as ObjectiveCClassAttribute;

            if (superObjectiveCClassAttribute == null)
            {
                if (objectiveCClassAttribute.Interceptor)
                {
                    className = objectiveCClassAttribute.InterceptCallsFor;
                }
                else
                {
                    throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, Resources.NoClassAttributeFoundForBaseType, type.FullName));
                }
            }
            else
            {
                if (superObjectiveCClassAttribute.Interceptor)
                {
                    className = superObjectiveCClassAttribute.InterceptCallsFor;
                }
                else if (!String.IsNullOrEmpty(superObjectiveCClassAttribute.Name))
                {
                    className = superObjectiveCClassAttribute.Name;
                }
                else
                {
                    className = type.BaseType.Name;
                }
            }

            return className;
        }

        /// <summary>
        /// Determines whether the specified type is an interceptor.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>
        /// 	<c>true</c> if the specified type is an interceptor; otherwise, <c>false</c>.
        /// </returns>
        internal static bool IsAnInterceptor(Type type)
        {
            bool result;

            // Check that the type has a register attribute as we don't define type without register attribute
            ObjectiveCClassAttribute objectiveCClassAttribute = Attribute.GetCustomAttribute(type, typeof (ObjectiveCClassAttribute), false) as ObjectiveCClassAttribute;
            if (objectiveCClassAttribute == null)
            {
                throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, Resources.NoClassAttributeFoundForType, type.FullName));
            }
            else
            {
                result = objectiveCClassAttribute.Interceptor;
            }

            return result;
        }

        /// <summary>
        /// Dumps the class mappings of the currently registered clases. Use for debugging purpose only.
        /// </summary>
        public static void DumpClasses()
        {
            Class.DumpClasses();
        }
    }
}