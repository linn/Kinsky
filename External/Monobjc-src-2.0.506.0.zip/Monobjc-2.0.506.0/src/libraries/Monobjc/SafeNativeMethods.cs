//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Monobjc
{
    /// <summary>
    /// <para>Exports native methods exposed in <c>libobjc.dylib</c> shared library.</para>
    /// <para>Thanks to .NET P/Invoke system, most of the marshalling work is automatic.</para>
    /// <para>The following methods are safe for use on both Mac OS X 10.4 et Mac OS X 10.5.</para>
    /// </summary>
    internal static class SafeNativeMethods
    {
        /// <summary>
        /// <para>Loads and links a dynamic library or bundle.</para>
        /// <para>This function examines the Mach-O file specified by path. If the image is compatible with the current process and has not already been loaded into the process, the image is loaded and linked. If the image contains initializer functions, they are executed before this function returns.</para>
        /// <para>Subsequent calls to dlopen to load the same image return the same handle, but the internal reference count for the handle is incremented. Therefore, all dlopen calls must be balanced with dlclose calls.</para>
        /// <para>For efficiency, the RTLD_LAZY binding mode is preferred over RTLD_NOW. However, using RTLD_NOW ensures that any undefined symbols are discovered during the call to dlopen.</para>
        /// <para>The dynamic loader looks in the paths specified by a set of environment variables, and in the process�s current directory, when it searches for a library. These paths are called dynamic loader search paths. The environment variables are LD_LIBRARY_PATH, DYLD_LIBRARY_PATH, and DYLD_FALLBACK_LIBRARY_PATH. The default value of DYLD_FALLBACK_LIBRARY_PATH (used when this variable is not set), is $HOME/lib;/usr/local/lib;/usr/lib.</para>
        /// <para>The order in which the search paths are searched depends on whether path is a filename (it does not contain a slash) or a pathname (it contains at least one slash).</para>
        /// <para>When path is a filename, the dynamic loader searches for the library in the search paths in the following order:
        /// <list type="number">
        /// <item>$LD_LIBRARY_PATH</item>
        /// <item>$DYLD_LIBRARY_PATH</item>
        /// <item>The process�s working directory</item>
        /// <item>$DYLD_FALLBACK_LIBRARY_PATH</item>
        /// </list>
        /// </para>
        /// <para>When path is a pathname, the dynamic loader searches for the library in the search paths in the following order:
        /// <list type="number">
        /// <item>$DYLD_LIBRARY_PATH</item>
        /// <item>The given pathname</item>
        /// <item>$DYLD_FALLBACK_LIBRARY_PATH using the filename</item>
        /// </list>
        /// </para>
        /// <para>If this function cannot open an image, it sets an error condition that can be accessed with dlerror.</para>
        /// <para>The original declaration is :
        /// <code>
        /// void* dlopen(const char* path, int mode);
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="path">Path to the image to open.</param>
        /// <param name="type">Specifies when the loaded image�s external symbols are bound to their definitions in dependent libraries (lazy or at load time) and the visibility of the image�s exported symbols (global or local). The value of this parameter is made up by ORing one binding behavior value with one visibility specification value. The following values specify the binding behavior:
        /// <list type="bullet">
        /// <item>RTLD_LAZY (default): Each external symbol reference is bound the first time it�s used.</item>
        /// <item>RTLD_NOW: All external symbol references are bound immediately.</item>
        /// </list>
        /// The following values specify external symbol visibility:
        /// <list type="bullet">
        /// <item>RTLD_GLOBAL (default): The loaded image�s exported symbols are available to any images that use a flat namespace or to calls to dlsym when using a special handle (see dlsym for details).</item>
        /// <item>RTLD_LOCAL: The loaded image�s exported symbols are generally hidden. They are available only to dlsym invocations that use the handle returned by this function.</item>
        /// </list>
        /// </param>
        /// <returns>A handle that can be used with calls to dlsym and dlclose.</returns>
        /// <remarks>For more details, see the Mac OS X ABI Dynamic Loader Reference (http://developer.apple.com/documentation/DeveloperTools/Reference/MachOReference/index.html).</remarks>
        [DllImport("libSystem", CharSet = CharSet.Ansi, BestFitMapping = false, ThrowOnUnmappableChar = true)]
        public static extern IntPtr dlopen([MarshalAs(UnmanagedType.LPStr)] String path, RuntimeLoadingOptions type);

        /// <summary>
        /// <para>Get diagnostic information.</para>
        /// <para>dlerror() returns a null-terminated character string describing the last error that occurred on this thread during a call to dlopen(), dlsym(), or dlclose(). If no such error has occurred, dlerror() returns a null pointer. At each call to dlerror(), the error indication is reset. Thus in the case of two calls to dlerror(), where the second call follows the first immediately, the second call will always return a null pointer.</para>
        /// </summary>
        /// <returns></returns>
        [DllImport("libSystem", CharSet = CharSet.Ansi)]
        public static extern IntPtr dlerror();

        /// <summary>
        /// <para>Copies the path of the main executable into the buffer buf. The bufsize parameter should initially be the size of the buffer.</para>
        /// <para>Note that _NSGetExecutablePath() will return a path to the executable not a real path to the executable. That is, the path may be a symbolic link and not the real file. With deep directories the total bufsize needed could be more than MAXPATHLEN.</para>
        /// <param name="buf">The buffer</param>
        /// <param name="bufsize">The buffer size. It should initially be the size of the buffer.</param>
        /// </summary>
        /// <remarks>See <cref href="http://developer.apple.com/Mac/library/documentation/Darwin/Reference/ManPages/man3/dyld.3.html"/> for more details</remarks>
        /// <returns>This function returns 0 if the path was successfully copied. It returns -1 if the buffer is not large enough, and * bufsize is set to the size required.</returns>
        [DllImport("libSystem", CharSet = CharSet.Ansi)]
        public static extern int _NSGetExecutablePath(StringBuilder buf, ref uint bufsize);

        /// <summary>
        /// <para>Returns the <see cref="Monobjc.Runtime.NXArchInfo"/> for the local host, or null if none is known.</para>
        /// </summary>
        /// <returns>A pointer to a <see cref="Monobjc.Runtime.NXArchInfo"/> structure.</returns>
        [DllImport("libSystem", CharSet = CharSet.Ansi)]
        public static extern IntPtr NXGetLocalArchInfo();

        /// <summary>
        /// <para>Returns a pointer to the data structure describing a given class method for a given class.</para>
        /// <para>Note that this function searches superclasses for implementations.</para>
        /// <para>The original declaration is :
        /// <code>
        /// Method class_getClassMethod(Class aClass, SEL aSelector)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="aClass">A pointer to a class definition. Pass the class that contains the method you want to retrieve.</param>
        /// <param name="aSelector">A pointer of type SEL. Pass the selector of the method you want to retrieve.</param>
        /// <returns>
        /// A pointer to the Method data structure that corresponds to the implementation of the selector specified by aSelector for the class specified by aClass, or NULL if the specified class or its superclasses do not contain an instance method with the specified selector. 
        /// </returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern IntPtr class_getClassMethod(IntPtr aClass, IntPtr aSelector);

        /// <summary>
        /// <para>Returns a specified instance method for a given class.</para>
        /// <para>Note that this function searches superclasses for implementations.</para>
        /// <para>The original declaration is :
        /// <code>
        /// Method class_getInstanceMethod(Class aClass, SEL aSelector)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="aClass">The class you want to inspect.</param>
        /// <param name="aSelector">The selector of the method you want to retrieve.</param>
        /// <returns>
        /// The method that corresponds to the implementation of the selector specified by aSelector for the class specified by aClass, or NULL if the specified class or its superclasses do not contain an instance method with the specified selector. 
        /// </returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc")]
        public static extern IntPtr class_getInstanceMethod(IntPtr aClass, IntPtr aSelector);

        /// <summary>
        /// <para>Returns a pointer to the class definition of the specified class.</para>
        /// <para>If the specified class is not registered with the Objective-C runtime, <see cref="objc_getClass"/> returns nil.</para>
        /// <para><see cref="objc_getClass"/> is different from <see cref="objc_lookUpClass"/> in that if the class is not registered, <see cref="objc_getClass"/> calls the class handler callback and then checks a second time to see whether the class is registered. <see cref="objc_lookUpClass"/> does not call the class handler callback.</para>
        /// <para>The original declaration is :
        /// <code>
        /// id objc_getClass(const char *aClassName)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="aClassName">A C string. Pass the name of the class to look up.</param>
        /// <returns>An id pointing to the Class object for the named class, or nil if the class is not registered with the Objective-C runtime.</returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc", CharSet = CharSet.Ansi, BestFitMapping = false, ThrowOnUnmappableChar = true)]
        public static extern IntPtr objc_getClass([MarshalAs(UnmanagedType.LPStr)] String aClassName);

        /// <summary>
        /// <para>Returns a pointer to the class definition of the specified class.</para>
        /// <para>If the specified class is not registered with the Objective-C runtime, this function returns nil.</para>
        /// <para><see cref="objc_getClass"/> is different from this function in that if the class is not registered, <see cref="objc_getClass"/> calls the class handler callback and then checks a second time to see whether the class is registered. This function does not call the class handler callback.</para>
        /// <para>The original declaration is :
        /// <code>
        /// id objc_lookUpClass(const char *aClassName)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="aClassName">A C string. Pass the name of the class to look up.</param>
        /// <returns>An id pointing to the Class object for the named class, or nil if the class is not registered with the Objective-C runtime.</returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc", CharSet = CharSet.Ansi, BestFitMapping = false, ThrowOnUnmappableChar = true)]
        public static extern IntPtr objc_lookUpClass([MarshalAs(UnmanagedType.LPStr)] String aClassName);

        /// <summary>
        /// <para>Obtains the value of an instance variable of a class instance.</para>
        /// <para>The original declaration is :
        /// <code>
        /// Ivar object_getInstanceVariable(id object, const char *name, void  **value);
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="target">A pointer to an instance of a class. Pass the object containing the instance variable whose value you wish to obtain.</param>
        /// <param name="name">A C string. Pass the name of the instance variable whose value you wish to obtain.</param>
        /// <param name="value">A pointer to a pointer to a value. On output, contains a pointer to the value of the instance variable.</param>
        /// <returns>A pointer to the objc_ivar data structure that defines the type and name of the instance variable specified by name.</returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc", CharSet = CharSet.Ansi, BestFitMapping = false, ThrowOnUnmappableChar = true)]
        public static extern IntPtr object_getInstanceVariable(IntPtr target, [MarshalAs(UnmanagedType.LPStr)] String name, IntPtr value);

        /// <summary>
        /// <para>Changes the value of an instance variable of a class instance.</para>
        /// <para>The original declaration is :
        /// <code>
        /// Ivar object_setInstanceVariable(id object, const char *name, void  *value);
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="target">A pointer to an instance of a class. Pass the object containing the instance variable whose value you wish to modify.</param>
        /// <param name="name">A C string. Pass the name of the instance variable whose value you wish to modify.</param>
        /// <param name="value">A pointer to a value. Pass a pointer to the new value for the instance variable.</param>
        /// <returns>A pointer to the objc_ivar data structure that defines the type and name of the instance variable specified by name.</returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc", CharSet = CharSet.Ansi, BestFitMapping = false, ThrowOnUnmappableChar = true)]
        public static extern IntPtr object_setInstanceVariable(IntPtr target, [MarshalAs(UnmanagedType.LPStr)] String name, IntPtr value);

        /// <summary>
        /// <para>Returns the name of the method specified by the selector.</para>
        /// <para>This function is one of two ways to retrieve the name of a selector. You can also cast a selector pointer directly to a C string pointer (const char *), but you cannot use an arbitrary C string as a selector because selectors are C strings that are indexed by pointer. See SEL for more information.</para>
        /// <para>The original declaration is :
        /// <code>
        /// const char* sel_getName(SEL aSelector)
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="aSelector">A pointer of type SEL. Pass the selector whose name you wish to determine.</param>
        /// <returns>A C string indicating the name of the selector.</returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc", CharSet = CharSet.Ansi)]
        public static extern IntPtr sel_getName(IntPtr aSelector);

        /// <summary>
        /// <para>Registers a method with the Objective-C runtime system, maps the method name to a selector, and returns the selector value.</para>
        /// <para>You must register a method name with the Objective-C runtime system to obtain the method�s selector before you can add the method to a class definition. If the method name has already been registered, this function simply returns the selector.</para>
        /// <para>The original declaration is :
        /// <code>
        /// SEL sel_registerName(const char *str);
        /// </code>
        /// </para>
        /// </summary>
        /// <param name="str">A pointer to a C string. Pass the name of the method you wish to register.</param>
        /// <returns>A pointer of type SEL specifying the selector for the named method.</returns>
        /// <remarks>For more details, see the Objective-C Runtime Reference (http://developer.apple.com/DOCUMENTATION/Cocoa/Reference/ObjectiveCRuntimeRef/index.html).</remarks>
        [DllImport("libobjc", CharSet = CharSet.Ansi, BestFitMapping = false, ThrowOnUnmappableChar = true)]
        public static extern IntPtr sel_registerName([MarshalAs(UnmanagedType.LPStr)] String str);

        /// <summary>
        /// Obtains information about the operating environment.
        /// </summary>
        /// <param name="selector">The selector code for the information you need. You can provide any of the four-character sequences defined in "Gestalt Manager Constants."</param>
        /// <param name="response">On input, Gestalt interprets this parameter as an address at which it is to place the result returned by the selector function. Gestalt ignores any information already at this address.
        /// On return, a pointer to the requested information whose format depends on the selector code specified in the selector parameter. Note that the Gestalt function returns the response from all selectors in a long word, which occupies 4 bytes. When not all 4 bytes are needed, the significant information appears in the low-order byte or bytes.</param>
        /// <returns>A result code.</returns>
        [DllImport("/System/Library/Frameworks/CoreServices.framework/CoreServices")]
        public static extern short Gestalt(int selector, ref int response);
    }
}