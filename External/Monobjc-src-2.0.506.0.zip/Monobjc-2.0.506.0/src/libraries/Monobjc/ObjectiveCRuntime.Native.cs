//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Monobjc.Properties;

namespace Monobjc
{
    public static partial class ObjectiveCRuntime
    {
        private const String SYSTEM_SCOPE = "/System/Library/Frameworks/{0}.framework/{0}";
        private const String SHARED_SCOPE = "/Library/Frameworks/{0}.framework/{0}";
        private const String USER_SCOPE = "~/Library/Frameworks/{0}.framework/{0}";
        private const String PRIVATE_SCOPE = "{1}/Contents/Frameworks/{0}.framework/{0}";

        // Holds a list of loaded libraries
        private static readonly IList<String> loadedLibraries = new List<String>();
        // Holds the path to the main bundle
        private static String mainBundlePath;

        /// <summary>
        /// Loads a dynamic library using the Mac OS X ABI (Application Binary Interface).
        /// </summary>
        /// <param name="path">The path to the library to load.</param>
        /// <param name="options">The loading flags to use.</param>
        /// <exception cref="ObjectiveCException">If the library cannot be found</exception>
        public static void LoadLibrary(String path, RuntimeLoadingOptions options)
        {
            // Avoid multiple loads, because it basically changes nothing.
            // It just increments the reference count on the handle which we don't care.
            if (loadedLibraries.Contains(path))
            {
                return;
            }

            if (Logger.DebugEnabled)
            {
                Logger.Debug("ObjectiveCRuntime", "Loading native library " + path);
            }

            // Try to load the library
            IntPtr result = SafeNativeMethods.dlopen(path, options);
            if (result == IntPtr.Zero)
            {
                // Gets the error message
                String cause = Marshal.PtrToStringAuto(SafeNativeMethods.dlerror());
                String message = String.Format(CultureInfo.CurrentCulture, Resources.DynamicLibraryCannotBeLoaded, path, cause);
                throw new ObjectiveCException(message);
            }

            // Add the library to the loaded ones to avoid multiple load
            loadedLibraries.Add(path);
        }

        /// <summary>
        /// Loads a Mac OS framework bundle by searching for the common places.
        /// </summary>
        /// <param name="name">The name of the framework to load.</param>
        /// <exception cref="ObjectiveCException">If the framework cannot be found</exception>
        public static void LoadFramework(String name)
        {
            String path;

            // Search for system scope framework
            path = String.Format(CultureInfo.CurrentCulture, SYSTEM_SCOPE, name);
            if (Logger.DebugEnabled)
            {
                Logger.Debug("ObjectiveCRuntime", "Trying location " + path);
            }
            if (File.Exists(path))
            {
                LoadLibrary(path, RuntimeLoadingOptions.Lazy);
                return;
            }

            // Search for machine scope framework
            path = String.Format(CultureInfo.CurrentCulture, SHARED_SCOPE, name);
            if (Logger.DebugEnabled)
            {
                Logger.Debug("ObjectiveCRuntime", "Trying location " + path);
            }
            if (File.Exists(path))
            {
                LoadLibrary(path, RuntimeLoadingOptions.Lazy);
                return;
            }

            // Search for user scope framework
            path = String.Format(CultureInfo.CurrentCulture, USER_SCOPE, name);
            if (Logger.DebugEnabled)
            {
                Logger.Debug("ObjectiveCRuntime", "Trying location " + path);
            }
            if (File.Exists(path))
            {
                LoadLibrary(path, RuntimeLoadingOptions.Lazy);
                return;
            }

            // Search for private framework
            path = String.Format(CultureInfo.CurrentCulture, PRIVATE_SCOPE, name, MainBundlePath);
            if (Logger.DebugEnabled)
            {
                Logger.Debug("ObjectiveCRuntime", "Trying location " + path);
            }
            if (File.Exists(path))
            {
                LoadLibrary(path, RuntimeLoadingOptions.Lazy);
                return;
            }

            throw new ObjectiveCException(String.Format(CultureInfo.CurrentCulture, Resources.CannotLocateFrameworkInStandardLocations, name));
        }

        /// <summary>
        /// Gets the path to the current bundle.
        /// </summary>
        /// <value>An absolute path to the main bundle.</value>
        public static String MainBundlePath
        {
            get
            {
                if (mainBundlePath == null)
                {
                    // We use an empty buffer to get the path length
                    StringBuilder buf = new StringBuilder();
                    uint size = 0;
                    int ret = SafeNativeMethods._NSGetExecutablePath(buf, ref size);

                    // We should have the expected size now
                    // Call again to retrieve the value
                    if (ret == -1)
                    {
                        // TODO: Do not recreate the StringBuilder
                        buf = new StringBuilder(Convert.ToInt32(size));
                        SafeNativeMethods._NSGetExecutablePath(buf, ref size);
                    }
                    String executablePath = buf.ToString();

		            if (Logger.DebugEnabled)
            		{
		                Logger.Debug("ObjectiveCRuntime", "executablePath=" + executablePath);
            		}
            		
                    // The bundle path is derived from the executable path:
                    // - When using a managed bundle, the path is "/.../.../<MyApp>.app/<MyApp>"
                    // - When using a native bundle, the path is "/.../.../<MyApp>.app/Content/MacOS/<MyApp>"
                    String mainBundle = Path.GetFileName(executablePath) + ".app";
                    mainBundlePath = executablePath;
                    do
                    {
			            if (Logger.DebugEnabled)
    	        		{
			                Logger.Debug("ObjectiveCRuntime", "mainBundlePath=" + mainBundlePath);
            			}
            			
                        mainBundlePath = Path.GetDirectoryName(mainBundlePath);
                        
                        if (mainBundlePath.EndsWith(mainBundle))
                        {
                            break;
                        }
                    }
                    while (mainBundlePath.Length > 0);
                }
                return mainBundlePath;
            }
        }
    }
}