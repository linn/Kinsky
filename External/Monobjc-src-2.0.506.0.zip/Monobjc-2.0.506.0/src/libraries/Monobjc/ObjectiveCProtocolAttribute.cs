//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Globalization;
using Monobjc.Properties;

namespace Monobjc
{
    /// <summary>
    /// <para>Allows a .NET interface to be registered within the Objective-C runtime.</para>
    /// <para>When a native instance is returned, the Objective-C runtime provides a wrapper that allows
    /// calls to the native instance through the methods of the interface.</para>
    /// </summary>
    /// 
    /// <example>
    /// <para>The following example shows how to use the <see cref="ObjectiveCProtocolAttribute"/> attribute.</para>
    /// <para>The type <c>MyOwnType1</c> will be registered with the "MyOwnType1" name.
    /// <code>
    /// [ObjectiveCProtocolAttribute]
    /// public interface MyOwnInterface1
    /// {
    ///     ...
    /// }
    /// </code>
    /// </para>
    /// <para>The type <c>MyOwnType2</c> will be registered with the "Type2" name.
    /// <code>
    /// [ObjectiveCProtocolAttribute("Interface2")]
    /// public interface MyOwnInterface2
    /// {
    ///     ...
    /// }
    /// </code>
    /// </para>
    /// </example>
    [AttributeUsage(AttributeTargets.Interface)]
    public sealed class ObjectiveCProtocolAttribute : Attribute
    {
        private readonly String name;

        /// <summary>
        /// <para>Initializes a new instance of the <see cref="ObjectiveCProtocolAttribute"/> class.</para>
        /// </summary>
        public ObjectiveCProtocolAttribute()
        {
            this.name = String.Empty;
        }

        /// <summary>
        /// <para>Initializes a new instance of the <see cref="ObjectiveCProtocolAttribute"/> class.</para>
        /// <para>Note: the name MUST be an ANSI identifier.</para>
        /// </summary>
        /// <param name="name">The name to use when registering the interface in the Objective-C runtime.</param>
        public ObjectiveCProtocolAttribute(String name)
        {
            this.name = name;
        }

        /// <summary>
        /// Gets or sets the name to use when registering the interface in the Objective-C runtime.
        /// </summary>
        /// <value>The name to use.</value>
        public String Name
        {
            get { return this.name; }
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override String ToString()
        {
            return String.Format(CultureInfo.CurrentCulture,
                                 Resources.ObjectiveCProtocolString,
                                 this.Name);
        }
    }
}