﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using Monobjc.Runtime;

namespace Monobjc
{
    partial class Id
    {
        /// <summary>
        /// <para>Sends a message to this receiver (either a Class or an object instance).</para>
        /// <para>The last parameter passed must be an object array that contains the variable list of arguments</para>
        /// </summary>
        /// <param name="selector">The selector.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public void SendMessageVarArgs(String selector, params Object[] parameters)
        {
            ObjectiveCRuntime.SendMessageVarArgs(this, selector, parameters);
        }

        /// <summary>
        /// <para>Sends a message to this receiver (either a Class or an object instance).</para>
        /// <para>The last parameter passed must be an object array that contains the variable list of arguments</para>
        /// </summary>
        /// <typeparam name="TReturnType">The type of the return type.</typeparam>
        /// <param name="selector">The selector.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public TReturnType SendMessageVarArgs<TReturnType>(String selector, params Object[] parameters)
        {
            return ObjectiveCRuntime.SendMessageVarArgs<TReturnType>(this, selector, parameters);
        }

        /// <summary>
        /// <para>Sends a message to the super instance of this receiver.</para>
        /// <para>The last parameter passed must be an object array that contains the variable list of arguments</para>
        /// <para>Details for the construction of the <see cref="objc_super"/> structure can be
        /// found here at http://www.omnigroup.com/mailman/archive/macosx-dev/2005-November/057962.html</para>
        /// </summary>
        /// <param name="cls">The class of the receiver.</param>
        /// <param name="selector">The selector.</param>
        /// <param name="parameters">The parameters.</param>
        public void SendMessageSuperVarArgs(Class cls, string selector, params object[] parameters)
        {
            ObjectiveCRuntime.SendMessageSuper(this, cls, selector, parameters);
        }

        /// <summary>
        /// <para>Sends a message to the super instance of this receiver.</para>
        /// <para>The last parameter passed must be an object array that contains the variable list of arguments</para>
        /// <para>Details for the construction of the <see cref="objc_super"/> structure can be
        /// found here at http://www.omnigroup.com/mailman/archive/macosx-dev/2005-November/057962.html</para>
        /// </summary>
        /// <typeparam name="TReturnType">The type of the return type.</typeparam>
        /// <param name="cls">The class of the receiver.</param>
        /// <param name="selector">The selector.</param>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public TReturnType SendMessageSuperVarArgs<TReturnType>(Class cls, string selector, params object[] parameters)
        {
            return ObjectiveCRuntime.SendMessageSuper<TReturnType>(this, cls, selector, parameters);
        }
    }
}