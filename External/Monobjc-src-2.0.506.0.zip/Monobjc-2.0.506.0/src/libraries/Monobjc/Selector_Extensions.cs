﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;

namespace Monobjc
{
    /// <summary>
    /// <para>Contains extension methods to ease the selector transformations.</para>
    /// </summary>
    public static class Selector_Extensions
    {
        /// <summary>
        /// Convert the selector into its string representation.
        /// </summary>
        /// <param name="selector">The selector.</param>
        /// <returns>The string representation</returns>
        public static String ToSelector(this IntPtr selector)
        {
            return ObjectiveCRuntime.Selector(selector);
        }

        /// <summary>
        /// Convert the selector into its pointer representation.
        /// </summary>
        /// <param name="selector">The selector.</param>
        /// <returns>The pointer representation</returns>
        public static IntPtr ToSelector(this String selector)
        {
            return ObjectiveCRuntime.Selector(selector);
        }
    }
}