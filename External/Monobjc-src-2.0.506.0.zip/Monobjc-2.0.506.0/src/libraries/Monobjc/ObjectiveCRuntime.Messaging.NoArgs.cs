//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;
using Monobjc.Bridge.Generators;
using Monobjc.Runtime;

namespace Monobjc
{
#if ENABLE_FAST_PATH
    public partial class ObjectiveCRuntime
    {
        /// <summary>
        /// <para>Sends a message to an Objective-C receiver (either a Class or an object instance).</para>
        /// </summary>
        /// <param name="receiver">The receiver.</param>
        /// <param name="selector">The selector.</param>
        public static void SendMessage(IManagedWrapper receiver, String selector)
        {
            if (receiver == null)
            {
                throw new ArgumentNullException("receiver");
            }
            if (String.IsNullOrEmpty(selector))
            {
                throw new ArgumentNullException("selector");
            }
            if (Logger.TraceEnabled)
            {
                LogSendMessage("SendMessage", receiver, selector);
            }
            IntPtr SEL = SafeNativeMethods.sel_registerName(selector);
            objc_msgSend(receiver.NativePointer, SEL);
        }

        /// <summary>
        /// <para>Sends a message to an Objective-C receiver (either a Class or an object instance).</para>
        /// </summary>
        /// <typeparam name="TReturnType">The type of the return type.</typeparam>
        /// <param name="receiver">The receiver.</param>
        /// <param name="selector">The selector.</param>
        /// <returns></returns>
        public static TReturnType SendMessage<TReturnType>(IManagedWrapper receiver, String selector)
        {
            if (receiver == null)
            {
                throw new ArgumentNullException("receiver");
            }
            if (String.IsNullOrEmpty(selector))
            {
                throw new ArgumentNullException("selector");
            }
            if (Logger.TraceEnabled)
            {
                LogSendMessage("SendMessage", receiver, selector);
            }
            IntPtr SEL = SafeNativeMethods.sel_registerName(selector);
            return messagingProvider.SendMessage<TReturnType>(CodeGenerationConstants.OBJC_MSG_SEND, receiver.NativePointer, SEL);
        }

        /// <summary>
        /// <para>Sends a message to the super instance of an Objective-C object instance.</para>
        /// <para>Details for the construction of the <see cref="objc_super"/> structure can be
        /// found here at http://www.omnigroup.com/mailman/archive/macosx-dev/2005-November/057962.html</para>
        /// </summary>
        /// <param name="receiver">The receiver.</param>
        /// <param name="cls">The class of the receiver.</param>
        /// <param name="selector">The selector.</param>
        public static void SendMessageSuper(IManagedWrapper receiver, Class cls, String selector)
        {
            if (receiver == null)
            {
                throw new ArgumentNullException("receiver");
            }
            if (cls == null)
            {
                throw new ArgumentNullException("cls");
            }
            if (String.IsNullOrEmpty(selector))
            {
                throw new ArgumentNullException("selector");
            }
            if (Logger.TraceEnabled)
            {
                LogSendMessage("SendMessageSuper", receiver, selector);
            }
            objc_super structure = new objc_super(receiver.NativePointer, cls.SuperClass.NativePointer);
            IntPtr super = objc_super.StructureToPtr(structure);
            IntPtr SEL = SafeNativeMethods.sel_registerName(selector);
            objc_msgSendSuper(super, SEL);
            Marshal.FreeHGlobal(super);
        }

        /// <summary>
        /// <para>Sends a message to the super instance of an Objective-C object instance.</para>
        /// <para>Details for the construction of the <see cref="objc_super"/> structure can be
        /// found here at http://www.omnigroup.com/mailman/archive/macosx-dev/2005-November/057962.html</para>
        /// </summary>
        /// <typeparam name="TReturnType">The type of the return type.</typeparam>
        /// <param name="receiver">The receiver.</param>
        /// <param name="cls">The class of the receiver.</param>
        /// <param name="selector">The selector.</param>
        /// <returns></returns>
        public static TReturnType SendMessageSuper<TReturnType>(IManagedWrapper receiver, Class cls, String selector)
        {
            if (receiver == null)
            {
                throw new ArgumentNullException("receiver");
            }
            if (cls == null)
            {
                throw new ArgumentNullException("cls");
            }
            if (String.IsNullOrEmpty(selector))
            {
                throw new ArgumentNullException("selector");
            }
            if (Logger.TraceEnabled)
            {
                LogSendMessage("SendMessageSuper", receiver, selector);
            }
            objc_super structure = new objc_super(receiver.NativePointer, cls.SuperClass.NativePointer);
            IntPtr super = objc_super.StructureToPtr(structure);
            IntPtr SEL = SafeNativeMethods.sel_registerName(selector);
            TReturnType result = messagingProvider.SendMessage<TReturnType>(CodeGenerationConstants.OBJC_MSG_SEND_SUPER, super, SEL);
            Marshal.FreeHGlobal(super);
            return result;
        }

        /// <summary>
        /// Fast-path call for message sending without arguments.
        /// </summary>
        [DllImport("libobjc", EntryPoint = "objc_msgSend", CharSet = CharSet.Ansi, BestFitMapping = false, ThrowOnUnmappableChar = true)]
        private static extern void objc_msgSend(IntPtr theReceiver, IntPtr theSelector);

        /// <summary>
        /// Fast-path call for message sending to super without arguments.
        /// </summary>
        [DllImport("libobjc", EntryPoint = "objc_msgSendSuper", CharSet = CharSet.Ansi, BestFitMapping = false, ThrowOnUnmappableChar = true)]
        private static extern void objc_msgSendSuper(IntPtr theReceiver, IntPtr theSelector);
    }
#endif
}