namespace Monobjc.AddressBook
{
    public enum ABPersonFlags
    {
#if MACOSX_10_6
#else
#endif
        kABShowAsMask = 000007,
        kABShowAsPerson = 000000,
        kABShowAsCompany = 000001,
#if MACOSX_10_6
        kABShowAsResource = 000002,
#endif
#if MACOSX_10_6
        kABShowAsRoom = 000003,
#endif
        kABNameOrderingMask = 000070,
        kABDefaultNameOrdering = 000000,
        kABFirstNameFirst = 000040,
        kABLastNameFirst = 000020,
    }
}
