//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.AddressBook
{
    public partial class AddressBookFramework
    {
        public static readonly NSString kABUIDProperty = NSString.NSPinnedString("UID");

        public static readonly NSString kABCreationDateProperty = NSString.NSPinnedString("Creation");

        public static readonly NSString kABModificationDateProperty = NSString.NSPinnedString("Modification");

        public static readonly NSString kABFirstNameProperty = NSString.NSPinnedString("First");

        public static readonly NSString kABLastNameProperty = NSString.NSPinnedString("Last");

        public static readonly NSString kABFirstNamePhoneticProperty = NSString.NSPinnedString("FirstPhonetic");

        public static readonly NSString kABLastNamePhoneticProperty = NSString.NSPinnedString("LastPhonetic");

        public static readonly NSString kABBirthdayProperty = NSString.NSPinnedString("Birthday");

        public static readonly NSString kABOrganizationProperty = NSString.NSPinnedString("Organization");

        public static readonly NSString kABJobTitleProperty = NSString.NSPinnedString("JobTitle");

        public static readonly NSString kABHomePageProperty = NSString.NSPinnedString("HomePage");

        public static readonly NSString kABURLsProperty = NSString.NSPinnedString("URLs");

#if MACOSX_10_5
        public static readonly NSString kABCalendarURIsProperty = NSString.NSPinnedString("calendarURIs");
#endif

        public static readonly NSString kABEmailProperty = NSString.NSPinnedString("Email");

        public static readonly NSString kABAddressProperty = NSString.NSPinnedString("Address");

        public static readonly NSString kABPhoneProperty = NSString.NSPinnedString("Phone");

        public static readonly NSString kABAIMInstantProperty = NSString.NSPinnedString("AIMInstant");

        public static readonly NSString kABJabberInstantProperty = NSString.NSPinnedString("JabberInstant");

        public static readonly NSString kABMSNInstantProperty = NSString.NSPinnedString("MSNInstant");

        public static readonly NSString kABYahooInstantProperty = NSString.NSPinnedString("YahooInstant");

        public static readonly NSString kABICQInstantProperty = NSString.NSPinnedString("ICQInstant");

        public static readonly NSString kABNoteProperty = NSString.NSPinnedString("Note");

        public static readonly NSString kABMiddleNameProperty = NSString.NSPinnedString("Middle");

        public static readonly NSString kABMiddleNamePhoneticProperty = NSString.NSPinnedString("MiddlePhonetic");

        public static readonly NSString kABTitleProperty = NSString.NSPinnedString("Title");

        public static readonly NSString kABSuffixProperty = NSString.NSPinnedString("Suffix");

        public static readonly NSString kABNicknameProperty = NSString.NSPinnedString("Nickname");

        public static readonly NSString kABMaidenNameProperty = NSString.NSPinnedString("MaidenName");

        public static readonly NSString kABOtherDatesProperty = NSString.NSPinnedString("ABDate");

        public static readonly NSString kABRelatedNamesProperty = NSString.NSPinnedString("ABRelatedNames");

        public static readonly NSString kABDepartmentProperty = NSString.NSPinnedString("ABDepartment");

        public static readonly NSString kABPersonFlags = NSString.NSPinnedString("ABPersonFlags");

        public static readonly NSString kABEmailWorkLabel = NSString.NSPinnedString("_$!<Work>!$_");

        public static readonly NSString kABEmailHomeLabel = NSString.NSPinnedString("_$!<Home>!$_");

#if MACOSX_10_6
        public static readonly NSString kABEmailMobileMeLabel = NSString.NSPinnedString("TODO");
#endif

        public static readonly NSString kABAddressHomeLabel = NSString.NSPinnedString("_$!<Home>!$_");

        public static readonly NSString kABAddressWorkLabel = NSString.NSPinnedString("_$!<Work>!$_");

        public static readonly NSString kABAddressStreetKey = NSString.NSPinnedString("Street");

        public static readonly NSString kABAddressCityKey = NSString.NSPinnedString("City");

        public static readonly NSString kABAddressStateKey = NSString.NSPinnedString("State");

        public static readonly NSString kABAddressZIPKey = NSString.NSPinnedString("ZIP");

        public static readonly NSString kABAddressCountryKey = NSString.NSPinnedString("Country");

        public static readonly NSString kABAddressCountryCodeKey = NSString.NSPinnedString("CountryCode");

        public static readonly NSString kABPhoneWorkLabel = NSString.NSPinnedString("_$!<Work>!$_");

        public static readonly NSString kABPhoneHomeLabel = NSString.NSPinnedString("_$!<Home>!$_");

#if MACOSX_10_6
        public static readonly NSString kABPhoneiPhoneLabel = NSString.NSPinnedString("iPhone");
#endif

        public static readonly NSString kABPhoneMobileLabel = NSString.NSPinnedString("_$!<Mobile>!$_");

        public static readonly NSString kABPhoneMainLabel = NSString.NSPinnedString("_$!<Main>!$_");

        public static readonly NSString kABPhoneHomeFAXLabel = NSString.NSPinnedString("_$!<HomeFAX>!$_");

        public static readonly NSString kABPhoneWorkFAXLabel = NSString.NSPinnedString("_$!<WorkFAX>!$_");

        public static readonly NSString kABPhonePagerLabel = NSString.NSPinnedString("_$!<Pager>!$_");

        public static readonly NSString kABMotherLabel = NSString.NSPinnedString("_$!<Mother>!$_");

        public static readonly NSString kABFatherLabel = NSString.NSPinnedString("_$!<Father>!$_");

        public static readonly NSString kABParentLabel = NSString.NSPinnedString("_$!<Parent>!$_");

        public static readonly NSString kABSisterLabel = NSString.NSPinnedString("_$!<Sister>!$_");

        public static readonly NSString kABChildLabel = NSString.NSPinnedString("_$!<Child>!$_");

        public static readonly NSString kABFriendLabel = NSString.NSPinnedString("_$!<Friend>!$_");

        public static readonly NSString kABSpouseLabel = NSString.NSPinnedString("_$!<Spouse>!$_");

        public static readonly NSString kABPartnerLabel = NSString.NSPinnedString("_$!<Partner>!$_");

        public static readonly NSString kABAssistantLabel = NSString.NSPinnedString("_$!<Assistant>!$_");

        public static readonly NSString kABManagerLabel = NSString.NSPinnedString("_$!<Manager>!$_");

        public static readonly NSString kABAIMWorkLabel = NSString.NSPinnedString("_$!<Work>!$_");

        public static readonly NSString kABAIMHomeLabel = NSString.NSPinnedString("_$!<Home>!$_");

#if MACOSX_10_6
        public static readonly NSString kABAIMMobileMeLabel = NSString.NSPinnedString("TODO");
#endif

        public static readonly NSString kABJabberWorkLabel = NSString.NSPinnedString("_$!<Work>!$_");

        public static readonly NSString kABJabberHomeLabel = NSString.NSPinnedString("_$!<Home>!$_");

        public static readonly NSString kABMSNWorkLabel = NSString.NSPinnedString("_$!<Work>!$_");

        public static readonly NSString kABMSNHomeLabel = NSString.NSPinnedString("_$!<Home>!$_");

        public static readonly NSString kABYahooWorkLabel = NSString.NSPinnedString("_$!<Work>!$_");

        public static readonly NSString kABYahooHomeLabel = NSString.NSPinnedString("_$!<Home>!$_");

        public static readonly NSString kABICQWorkLabel = NSString.NSPinnedString("_$!<Work>!$_");

        public static readonly NSString kABICQHomeLabel = NSString.NSPinnedString("_$!<Home>!$_");

        public static readonly NSString kABWorkLabel = NSString.NSPinnedString("_$!<Work>!$_");

        public static readonly NSString kABHomeLabel = NSString.NSPinnedString("_$!<Home>!$_");

        public static readonly NSString kABOtherLabel = NSString.NSPinnedString("_$!<Other>!$_");

        public static readonly NSString kABGroupNameProperty = NSString.NSPinnedString("GroupName");
    }
}
