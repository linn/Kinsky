//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.AddressBook
{
    public partial class ABMutableMultiValue
    {
        public virtual NSString AddValueWithLabel(Id value, NSString label)
        {
            return ObjectiveCRuntime.SendMessage<NSString>(this, "addValue:withLabel:", value, label);
        }

        public virtual NSString InsertValueWithLabelAtIndex(Id value, NSString label, uint index)
        {
            return ObjectiveCRuntime.SendMessage<NSString>(this, "insertValue:withLabel:atIndex:", value, label, index);
        }

        public virtual bool RemoveValueAndLabelAtIndex(uint index)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "removeValueAndLabelAtIndex:", index);
        }

        public virtual bool ReplaceLabelAtIndexWithLabel(uint index, NSString label)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "replaceLabelAtIndex:withLabel:", index, label);
        }

        public virtual bool ReplaceValueAtIndexWithValue(uint index, Id value)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "replaceValueAtIndex:withValue:", index, value);
        }

        public virtual bool SetPrimaryIdentifier(NSString identifier)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "setPrimaryIdentifier:", identifier);
        }
    }
}
