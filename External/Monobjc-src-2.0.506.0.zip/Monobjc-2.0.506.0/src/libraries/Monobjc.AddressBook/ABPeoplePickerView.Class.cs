//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using Monobjc.Cocoa;

namespace Monobjc.AddressBook
{
    public partial class ABPeoplePickerView
    {
        public virtual void AddProperty(NSString property)
        {
            ObjectiveCRuntime.SendMessage(this, "addProperty:", property);
        }

        public virtual void ClearSearchField(Id sender)
        {
            ObjectiveCRuntime.SendMessage(this, "clearSearchField:", sender);
        }

        public virtual NSString ColumnTitleForProperty(NSString property)
        {
            return ObjectiveCRuntime.SendMessage<NSString>(this, "columnTitleForProperty:", property);
        }

        public virtual void DeselectAll(Id sender)
        {
            ObjectiveCRuntime.SendMessage(this, "deselectAll:", sender);
        }

        public virtual void DeselectGroup(ABGroup group)
        {
            ObjectiveCRuntime.SendMessage(this, "deselectGroup:", group);
        }

        public virtual void DeselectIdentifierForPerson(NSString identifier, ABPerson person)
        {
            ObjectiveCRuntime.SendMessage(this, "deselectIdentifier:forPerson:", identifier, person);
        }

        public virtual void DeselectRecord(ABRecord record)
        {
            ObjectiveCRuntime.SendMessage(this, "deselectRecord:", record);
        }

        public virtual void EditInAddressBook(Id sender)
        {
            ObjectiveCRuntime.SendMessage(this, "editInAddressBook:", sender);
        }

        public virtual void RemoveProperty(NSString property)
        {
            ObjectiveCRuntime.SendMessage(this, "removeProperty:", property);
        }

        public virtual NSArray SelectedIdentifiersForPerson(ABPerson person)
        {
            return ObjectiveCRuntime.SendMessage<NSArray>(this, "selectedIdentifiersForPerson:", person);
        }

        public virtual void SelectGroupByExtendingSelection(ABGroup group, bool extend)
        {
            ObjectiveCRuntime.SendMessage(this, "selectGroup:byExtendingSelection:", group, extend);
        }

        public virtual void SelectIdentifierForPersonByExtendingSelection(NSString identifier, ABPerson person, bool extend)
        {
            ObjectiveCRuntime.SendMessage(this, "selectIdentifier:forPerson:byExtendingSelection:", identifier, person, extend);
        }

        public virtual void SelectInAddressBook(Id sender)
        {
            ObjectiveCRuntime.SendMessage(this, "selectInAddressBook:", sender);
        }

        public virtual void SelectRecordByExtendingSelection(ABRecord record, bool extend)
        {
            ObjectiveCRuntime.SendMessage(this, "selectRecord:byExtendingSelection:", record, extend);
        }

        public virtual void SetColumnTitleForProperty(NSString title, NSString property)
        {
            ObjectiveCRuntime.SendMessage(this, "setColumnTitle:forProperty:", title, property);
        }

        public virtual NSView AccessoryView
        {
            get { return ObjectiveCRuntime.SendMessage<NSView>(this, "accessoryView"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAccessoryView:", value); }
        }

        public virtual bool AllowsGroupSelection
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "allowsGroupSelection"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAllowsGroupSelection:", value); }
        }

        public virtual bool AllowsMultipleSelection
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "allowsMultipleSelection"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAllowsMultipleSelection:", value); }
        }

        public virtual NSString AutosaveName
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "autosaveName"); }
            set { ObjectiveCRuntime.SendMessage(this, "setAutosaveName:", value); }
        }

        public virtual NSString DisplayedProperty
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "displayedProperty"); }
            set { ObjectiveCRuntime.SendMessage(this, "setDisplayedProperty:", value); }
        }

        public virtual IntPtr GroupDoubleAction
        {
            get { return ObjectiveCRuntime.SendMessage<IntPtr>(this, "groupDoubleAction"); }
            set { ObjectiveCRuntime.SendMessage(this, "setGroupDoubleAction:", value); }
        }

        public virtual IntPtr NameDoubleAction
        {
            get { return ObjectiveCRuntime.SendMessage<IntPtr>(this, "nameDoubleAction"); }
            set { ObjectiveCRuntime.SendMessage(this, "setNameDoubleAction:", value); }
        }

        public virtual NSArray Properties
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "properties"); }
        }

        public virtual NSArray SelectedGroups
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "selectedGroups"); }
        }

        public virtual NSArray SelectedRecords
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "selectedRecords"); }
        }

        public virtual NSArray SelectedValues
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "selectedValues"); }
        }

        public virtual Id Target
        {
            get { return ObjectiveCRuntime.SendMessage<Id>(this, "target"); }
            set { ObjectiveCRuntime.SendMessage(this, "setTarget:", value); }
        }

        public virtual ABPeoplePickerSelectionBehavior ValueSelectionBehavior
        {
            get { return ObjectiveCRuntime.SendMessage<ABPeoplePickerSelectionBehavior>(this, "valueSelectionBehavior"); }
            set { ObjectiveCRuntime.SendMessage(this, "setValueSelectionBehavior:", value); }
        }
    }
}
