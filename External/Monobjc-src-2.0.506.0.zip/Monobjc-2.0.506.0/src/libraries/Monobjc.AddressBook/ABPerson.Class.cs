//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using Monobjc.Cocoa;

namespace Monobjc.AddressBook
{
    public partial class ABPerson
    {
        public static int AddPropertiesAndTypes(NSDictionary properties)
        {
            return ObjectiveCRuntime.SendMessage<int>(ABPersonClass, "addPropertiesAndTypes:", properties);
        }

        public static void CancelLoadingImageDataForTag(int tag)
        {
            ObjectiveCRuntime.SendMessage(ABPersonClass, "cancelLoadingImageDataForTag:", tag);
        }

        public static int RemoveProperties(NSArray properties)
        {
            return ObjectiveCRuntime.SendMessage<int>(ABPersonClass, "removeProperties:", properties);
        }

        public static ABSearchElement SearchElementForPropertyLabelKeyValueComparison(NSString property, NSString label, NSString key, Id value, ABSearchComparison comparison)
        {
            return ObjectiveCRuntime.SendMessage<ABSearchElement>(ABPersonClass, "searchElementForProperty:label:key:value:comparison:", property, label, key, value, comparison);
        }

        public static ABPropertyType TypeOfProperty(NSString property)
        {
            return ObjectiveCRuntime.SendMessage<ABPropertyType>(ABPersonClass, "typeOfProperty:", property);
        }

        public virtual int BeginLoadingImageDataForClient(IABImageClient client)
        {
            return ObjectiveCRuntime.SendMessage<int>(this, "beginLoadingImageDataForClient:", client);
        }

        public virtual Id InitWithVCardRepresentation(NSData vCardData)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithVCardRepresentation:", vCardData);
        }

        public virtual bool SetImageData(NSData data)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "setImageData:", data);
        }

        public static NSArray Properties
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(ABPersonClass, "properties"); }
        }

#if MACOSX_10_5
        public virtual IntPtr Identity
        {
            get { return ObjectiveCRuntime.SendMessage<IntPtr>(this, "identity"); }
        }
#endif

#if MACOSX_10_5
        public virtual NSString IdentityUniqueId
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "identityUniqueId"); }
        }
#endif

        public virtual NSData ImageData
        {
            get { return ObjectiveCRuntime.SendMessage<NSData>(this, "imageData"); }
        }

        public virtual NSArray ParentGroups
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "parentGroups"); }
        }

        public virtual NSData VCardRepresentation
        {
            get { return ObjectiveCRuntime.SendMessage<NSData>(this, "vCardRepresentation"); }
        }
    }
}
