//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using System;
using System.Runtime.InteropServices;
using Monobjc.Cocoa;

namespace Monobjc.AddressBook
{
    public partial class ABAddressBook
    {
        public virtual bool AddRecord(ABRecord record)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "addRecord:", record);
        }

        public virtual NSAttributedString FormattedAddressFromDictionary(NSDictionary address)
        {
            return ObjectiveCRuntime.SendMessage<NSAttributedString>(this, "formattedAddressFromDictionary:", address);
        }

        public virtual NSString RecordClassFromUniqueId(NSString uniqueId)
        {
            return ObjectiveCRuntime.SendMessage<NSString>(this, "recordClassFromUniqueId:", uniqueId);
        }

        public virtual ABRecord RecordForUniqueId(NSString uniqueId)
        {
            return ObjectiveCRuntime.SendMessage<ABRecord>(this, "recordForUniqueId:", uniqueId);
        }

        public virtual NSArray RecordsMatchingSearchElement(ABSearchElement search)
        {
            return ObjectiveCRuntime.SendMessage<NSArray>(this, "recordsMatchingSearchElement:", search);
        }

        public virtual bool RemoveRecord(ABRecord record)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "removeRecord:", record);
        }

#if MACOSX_10_5
        public virtual bool SaveAndReturnError(out NSError error)
        {
            IntPtr pointer = Marshal.AllocHGlobal(Marshal.SizeOf(typeof (IntPtr)));
            bool result = ObjectiveCRuntime.SendMessage<bool>(ABAddressBookClass, "saveAndReturnError:", pointer);
            error = ObjectiveCRuntime.GetInstance<NSError>(Marshal.ReadIntPtr(pointer));
            Marshal.FreeHGlobal(pointer);
            return result;
        }
#endif

#if MACOSX_10_5
        public static ABAddressBook AddressBook
        {
            get { return ObjectiveCRuntime.SendMessage<ABAddressBook>(ABAddressBookClass, "addressBook"); }
        }
#endif

        public static ABAddressBook SharedAddressBook
        {
            get { return ObjectiveCRuntime.SendMessage<ABAddressBook>(ABAddressBookClass, "sharedAddressBook"); }
        }

        public virtual NSString DefaultCountryCode
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "defaultCountryCode"); }
        }

        public virtual int DefaultNameOrdering
        {
            get { return ObjectiveCRuntime.SendMessage<int>(this, "defaultNameOrdering"); }
        }

        public virtual NSArray Groups
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "groups"); }
        }

        public virtual bool HasUnsavedChanges
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "hasUnsavedChanges"); }
        }

        public virtual ABPerson Me
        {
            get { return ObjectiveCRuntime.SendMessage<ABPerson>(this, "me"); }
            set { ObjectiveCRuntime.SendMessage(this, "setMe:", value); }
        }

        public virtual NSArray People
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "people"); }
        }

        public virtual bool Save()
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "save");
        }
    }
}
