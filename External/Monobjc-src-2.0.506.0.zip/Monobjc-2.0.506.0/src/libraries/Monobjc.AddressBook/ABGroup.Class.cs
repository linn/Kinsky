﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.AddressBook
{
    public partial class ABGroup
    {
        public static int AddPropertiesAndTypes(NSDictionary properties)
        {
            return ObjectiveCRuntime.SendMessage<int>(ABGroupClass, "addPropertiesAndTypes:", properties);
        }

        public static int RemoveProperties(NSArray properties)
        {
            return ObjectiveCRuntime.SendMessage<int>(ABGroupClass, "removeProperties:", properties);
        }

        public static ABSearchElement SearchElementForPropertyLabelKeyValueComparison(NSString property, NSString label, NSString key, Id value, ABSearchComparison comparison)
        {
            return ObjectiveCRuntime.SendMessage<ABSearchElement>(ABGroupClass, "searchElementForProperty:label:key:value:comparison:", property, label, key, value, comparison);
        }

        public static ABPropertyType TypeOfProperty(NSString property)
        {
            return ObjectiveCRuntime.SendMessage<ABPropertyType>(ABGroupClass, "typeOfProperty:", property);
        }

        public virtual bool AddMember(ABPerson person)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "addMember:", person);
        }

        public virtual bool AddSubgroup(ABGroup group)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "addSubgroup:", group);
        }

        public virtual NSString DistributionIdentifierForPropertyPerson(NSString property, ABPerson person)
        {
            return ObjectiveCRuntime.SendMessage<NSString>(this, "distributionIdentifierForProperty:person:", property, person);
        }

        public virtual bool RemoveMember(ABPerson person)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "removeMember:", person);
        }

        public virtual bool RemoveSubgroup(ABGroup group)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "removeSubgroup:", group);
        }

        public virtual bool SetDistributionIdentifierForPropertyPerson(NSString identifier, NSString property, ABPerson person)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "setDistributionIdentifier:forProperty:person:", identifier, property, person);
        }

        public static NSArray Properties
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(ABGroupClass, "properties"); }
        }

        public virtual NSArray Members
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "members"); }
        }

        public virtual NSArray ParentGroups
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "parentGroups"); }
        }

        public virtual NSArray Subgroups
        {
            get { return ObjectiveCRuntime.SendMessage<NSArray>(this, "subgroups"); }
        }
    }
}
