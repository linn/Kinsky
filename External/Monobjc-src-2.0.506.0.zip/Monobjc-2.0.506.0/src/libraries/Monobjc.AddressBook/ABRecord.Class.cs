﻿//
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
//
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
//
using Monobjc.Cocoa;

namespace Monobjc.AddressBook
{
    public partial class ABRecord
    {
#if MACOSX_10_5
        public virtual Id InitWithAddressBook(ABAddressBook addressBook)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "initWithAddressBook:", addressBook);
        }
#endif

        public virtual bool RemoveValueForProperty(NSString property)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "removeValueForProperty:", property);
        }

        public virtual bool SetValueForProperty(Id value, NSString property)
        {
            return ObjectiveCRuntime.SendMessage<bool>(this, "setValue:forProperty:", value, property);
        }

        public virtual Id ValueForProperty(NSString property)
        {
            return ObjectiveCRuntime.SendMessage<Id>(this, "valueForProperty:", property);
        }

        public virtual bool IsReadOnly
        {
            get { return ObjectiveCRuntime.SendMessage<bool>(this, "isReadOnly"); }
        }

        public virtual NSString UniqueId
        {
            get { return ObjectiveCRuntime.SendMessage<NSString>(this, "uniqueId"); }
        }
    }
}
