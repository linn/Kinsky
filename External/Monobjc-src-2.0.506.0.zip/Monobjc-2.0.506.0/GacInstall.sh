#!/bin/bash

echo "======================================="
echo " __  __                   _     _      "
echo "|  \/  | ___  _ __   ___ | |__ (_) ___ "
echo "| |\/| |/ _ \| '_ \ / _ \| '_ \| |/ __|"
echo "| |  | | (_) | | | | (_) | |_) | | (__ "
echo "|_|  |_|\___/|_| |_|\___/|_.__// |\___|"
echo "                             |__/      "
echo "GAC Installer                          "
echo "======================================="
echo

if [ $UID != 0 ]; then
	echo "!!! You must run this script with sudo !!!"
	echo "Relaunch by invoking: sudo $0"
	exit 1
fi

MONO_DIR="/Library/Frameworks/Mono.framework/Versions/Current"
if [ ! -d $MONO_DIR ]; then
	echo "Cannot find Mono.framework. Is it installed ?"
	exit 1
fi

VERSIONS="1.0 2.0"

# Perform the installation for each version
for version in $VERSIONS; do
	echo
	echo "Installing Monobjc $version..."
	echo "=============================="
	
	LIB_DIR="$MONO_DIR/lib/mono/monobjc-$version"

	# Create directory
	mkdir -p "$LIB_DIR"
	
	# Create the dylib mapping file
	CONFIG_FILE="./dist/$version/Monobjc.dll.config"
	cat > "$CONFIG_FILE" <<EOF
<configuration>
  <dllmap dll="@executable_path/libmonobjc.1.dylib" target="$LIB_DIR/libmonobjc.1.dylib"/>
  <dllmap dll="@executable_path/libmonobjc.2.dylib" target="$LIB_DIR/libmonobjc.2.dylib"/>
</configuration>
EOF

	# Copy native libraries
	cp ./dist/libmonobjc.1.dylib "$LIB_DIR"
	cp ./dist/libmonobjc.2.dylib "$LIB_DIR"

	# Register the Monobjc assemblies in the GAC
	for file in `ls dist/$version/Monobjc*.dll`; do
		gacutil -i "$file" -package monobjc-$version
	done

	# Create the list of assemblies
	LIB_LIST="Libraries="
	LIB_REFERENCES="Libs:"
	for file in `ls dist/$version/Monobjc*.dll`; do
		assembly=`basename $file`
		LIB_LIST="$LIB_LIST \${pkglibdir}/$assembly"
		LIB_REFERENCES="$LIB_REFERENCES -r:\${pkglibdir}/$assembly"
	done
	
	# Create the PKG-CONFIG file
	PC_FILE="$MONO_DIR/share/pkgconfig/monobjc-$version.pc"
	cat > "$PC_FILE" <<EOF
prefix=$MONO_DIR
exec_prefix=\${prefix}
pkglibdir=\${exec_prefix}/lib/mono/monobjc-$version
Libraries=$LIB_LIST

Name: Monobjc
Description: Monobjc Bridge $version
Version: $version

Requires: 
Libs: $LIB_REFERENCES
EOF

done
