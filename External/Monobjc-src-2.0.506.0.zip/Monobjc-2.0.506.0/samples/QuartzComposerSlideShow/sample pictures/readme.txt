The pictures in this folder are taken with my nikon d80 in spring-time 2010.
You can copy or use these pictures for personal use only.

Regards,
Andreas