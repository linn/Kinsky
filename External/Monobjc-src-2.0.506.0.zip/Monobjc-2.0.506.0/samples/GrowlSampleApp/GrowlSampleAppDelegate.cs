// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using Monobjc.Cocoa;
using Monobjc.Growl;

namespace Monobjc.Samples.GrowlSampleApp
{
    [ObjectiveCClass]
    public partial class GrowlSampleAppDelegate : NSObject
    {
        private static readonly Class GrowlSampleAppDelegateClass = Class.GetClassFromType(typeof (GrowlSampleAppDelegate));

        /// <summary>
        /// Initializes a new instance of the <see cref="GrowlSampleAppDelegate"/> class.
        /// </summary>
        public GrowlSampleAppDelegate() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="GrowlSampleAppDelegate"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public GrowlSampleAppDelegate(IntPtr nativePointer) : base(nativePointer) {}

        [ObjectiveCMessage("awakeFromNib")]
        public void AwakeFromNib()
        {
            // Register ourselves as a Growl delegate
            GrowlApplicationBridge.GrowlDelegate = this;

            GrowlApplicationBridge.NotifyWithTitleDescriptionNotificationNameIconDataPriorityIsStickyClickContext(@"Hello!",
                                                                                                                  @"Sample App Started",
                                                                                                                  @"Example",
                                                                                                                  null,
                                                                                                                  0,
                                                                                                                  false,
                                                                                                                  NSDate.Date);
		}
        
        [ObjectiveCMessage("notify:")]
        public void Notify()
        {
            GrowlApplicationBridge.NotifyWithTitleDescriptionNotificationNameIconDataPriorityIsStickyClickContext(@"Hello Again!",
                                                                                                                  @"You clicked the button",
                                                                                                                  @"Example",
                                                                                                                  null,
                                                                                                                  0,
                                                                                                                  false,
                                                                                                                  NSDate.Date);
        }
        
        [ObjectiveCMessage("growlNotificationWasClicked:")]
        public void GrowlNotificationWasClicked(Id context)
        {
			// Use a standard alert to display the message
            AppKitFramework.NSRunAlertPanel("Notification Clicked", "Hello, Growl!", "OK", null, null);
        }
    }
}
