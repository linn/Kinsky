// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using Monobjc.AddressBook;
using Monobjc.Cocoa;

namespace Monobjc.Samples.CocoaPeoplePicker
{
    [ObjectiveCClass]
    public class MyPeoplePickerController : NSObject
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MyPeoplePickerController"/> class.
        /// </summary>
        public MyPeoplePickerController() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="MyPeoplePickerController"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public MyPeoplePickerController(IntPtr nativePointer)
            : base(nativePointer) {}

        [ObjectiveCField]
        public ABPeoplePickerView ppView;

        [ObjectiveCMessage("getGroups:")]
        public void GetGroups(Id sender)
        {
            NSArray groups = this.ppView.SelectedGroups;
            Console.WriteLine("getGroups: {0} groups selected", groups.Count);
            uint count = groups.Count;
            for (int index = 0; index < count; index++)
            {
                ABRecord record = groups[index].CastTo<ABRecord>();
                Console.WriteLine("  Group {0}: {1}", index, record.UniqueId);
            }
        }

        [ObjectiveCMessage("getRecords:")]
        public void GetRecords(Id sender)
        {
            NSArray records = this.ppView.SelectedRecords;
            Console.WriteLine("getRecords: {0} records selected", records.Count);
            uint count = records.Count;
            for (int index = 0; index < count; index++)
            {
                ABRecord record = records[index].CastTo<ABRecord>();
                Console.WriteLine("  Record {0}: {1}", index, record.UniqueId);
            }
        }

        [ObjectiveCMessage("viewProperty:")]
        public void ViewProperty(NSButton sender)
        {
            NSString property = null;
            switch (sender.Tag)
            {
                case 0: // Phone
                    property = AddressBookFramework.kABPhoneProperty;
                    break;
                case 1: // Address
                    property = AddressBookFramework.kABAddressProperty;
                    break;
                case 2: // Email
                    property = AddressBookFramework.kABEmailProperty;
                    break;
                case 3: // AIM
                    property = AddressBookFramework.kABAIMInstantProperty;
                    break;
                case 4: // Homepage
                    property = AddressBookFramework.kABHomePageProperty;
                    break;
                default:
                    break;
            }
            if (sender.State == NSCellStateValue.NSOnState)
            {
                this.ppView.AddProperty(property);
            }
            else
            {
                this.ppView.RemoveProperty(property);
            }
        }

        [ObjectiveCMessage("setGroupSelection:")]
        public void SetGroupSelection(NSButton sender)
        {
            this.ppView.AllowsGroupSelection = (sender.State == NSCellStateValue.NSOnState);
        }

        [ObjectiveCMessage("setMultiRecordSelection:")]
        public void SetMultiRecordSelection(NSButton sender)
        {
            this.ppView.AllowsMultipleSelection = (sender.State == NSCellStateValue.NSOnState);
        }

        [ObjectiveCMessage("editInAB:")]
        public void EditInAB(Id sender)
        {
            this.ppView.EditInAddressBook(sender);
        }

        [ObjectiveCMessage("selectInAB:")]
        public void SelectInAB(Id sender)
        {
            this.ppView.SelectInAddressBook(sender);
        }
    }
}