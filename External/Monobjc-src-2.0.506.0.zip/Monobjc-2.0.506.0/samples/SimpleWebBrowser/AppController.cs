// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using Monobjc.Cocoa;
using Monobjc.WebKit;

namespace Monobjc.Samples.SimpleWebBrowser
{
    [ObjectiveCClass]
    public class AppController : NSObject
    {
        [ObjectiveCField]
        public NSProgressIndicator indicator;

        [ObjectiveCField]
        public NSTextField urlText;

        [ObjectiveCField]
        public WebView webView;

        [ObjectiveCField]
        public NSWindow window;

        public AppController() {}

        public AppController(IntPtr nativePointer)
            : base(nativePointer) {}

        [ObjectiveCMessage("awakeFromNib")]
        public void AwakeFromNib()
        {
            this.webView.SetFrameLoadDelegate(d =>
                                                  {
                                                      d.WebViewDidStartProvisionalLoadForFrame += this.WebViewDidStartProvisionalLoadForFrame;
                                                      d.WebViewDidFinishLoadForFrame += this.WebViewDidFinishLoadForFrame;
                                                      d.WebViewDidReceiveTitleForFrame += this.WebViewDidReceiveTitleForFrame;
                                                  });
        }

        [ObjectiveCMessage("fetch:")]
        public void Fetch(Id sender)
        {
            this.webView.MainFrame.LoadRequest(NSURLRequest.RequestWithURL(NSURL.URLWithString(this.urlText.StringValue)));
        }

        private void WebViewDidStartProvisionalLoadForFrame(WebView sender, WebFrame frame)
        {
            this.indicator.IsHidden = false;
            this.indicator.StartAnimation(null);
        }

        private void WebViewDidFinishLoadForFrame(WebView sender, WebFrame frame)
        {
            this.indicator.StopAnimation(null);
            this.indicator.IsHidden = true;
        }

        private void WebViewDidReceiveTitleForFrame(WebView sender, NSString title, WebFrame frame)
        {
            this.window.Title = title;
        }
    }
}