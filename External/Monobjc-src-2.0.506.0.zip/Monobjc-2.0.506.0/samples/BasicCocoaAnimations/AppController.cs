// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using Monobjc.Cocoa;

namespace Monobjc.Samples.BasicCocoaAnimations
{
    [ObjectiveCClass]
    public class AppController : NSObject
    {
        private static readonly Class AppControllerClass = Class.GetClassFromType(typeof (AppController));

        private MainWindowController mainWindowController;
        private InspectorController inspectorController;

        /// <summary>
        /// Initializes a new instance of the <see cref="AppController"/> class.
        /// </summary>
        public AppController() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="AppController"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public AppController(IntPtr nativePointer)
            : base(nativePointer) {}

        [ObjectiveCMessage("awakeFromNib")]
        public void AwakeFromNib()
        {
            this.ShowMainWindow(null);
        }

        [ObjectiveCMessage("dealloc", SynchronizeFields = false)]
        public void Dealloc()
        {
            this.mainWindowController.SafeRelease();
            this.inspectorController.SafeRelease();
            this.SendMessageSuper(AppControllerClass, "dealloc");
        }

        [ObjectiveCMessage("showMainWindow:")]
        public void ShowMainWindow(Id sender)
        {
            if (this.mainWindowController == null)
            {
                this.mainWindowController = new MainWindowController();
            }
            this.mainWindowController.ShowWindow(null);
        }

        [ObjectiveCMessage("showInspector:")]
        public void ShowInspector(Id sender)
        {
            if (this.inspectorController == null)
            {
                this.inspectorController = new InspectorController();
            }
            this.inspectorController.ShowWindow(null);
        }
    }
}