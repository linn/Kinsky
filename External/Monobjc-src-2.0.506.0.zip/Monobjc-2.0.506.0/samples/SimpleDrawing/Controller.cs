// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using System.IO;
using Monobjc.Cocoa;
using Monobjc.Samples.SimpleDrawing.Properties;

namespace Monobjc.Samples.SimpleDrawing
{
    [ObjectiveCClass]
    public class Controller : NSObject
    {
        private static readonly Class ControllerClass = Class.GetClassFromType(typeof (Controller));

        [ObjectiveCField]
        public NSImageView imageView;

        /// <summary>
        /// Initializes a new instance of the <see cref="Controller"/> class.
        /// </summary>
        public Controller() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="Controller"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public Controller(IntPtr nativePointer)
            : base(nativePointer) {}

        [ObjectiveCMessage("awakeFromNib")]
        public void AwakeFromNib()
        {
            NSImage image = Resources.logo;
            this.imageView.Image = image;
        }

        [ObjectiveCMessage("createImage:")]
        public void Create(Id sender)
        {
            // Creates an image that has a size of 200 x 200
            NSImage image = new NSImage(new NSSize(200.0f, 200.0f));

            // Lock the focus, so the current graphical context is now associated with the image
            image.LockFocus();

            // Set the blue color as current color
            NSColor.WhiteColor.Set();
            // Fill the whole image with the blue color
            NSBezierPath.FillRect(new NSRect(NSPoint.NSZeroPoint, image.Size));

            // Don't forget to unlock the focus as each lock must be matched by a unlock
            image.UnlockFocus();

            // Assign the image to the NSImageView
            this.imageView.Image = image;

            // We can release this instance, as it is now retained by the NSImageView
            image.Release();
        }

        [ObjectiveCMessage("loadFromFile:")]
        public void LoadFromFile(Id sender)
        {
            // Get a NSOpenPanel instance and configure it with image extensions.
            NSOpenPanel panel = NSOpenPanel.OpenPanel;
            panel.CanChooseFiles = true;
            panel.CanChooseDirectories = false;
            panel.AllowsMultipleSelection = false;
            NSArray types = NSArray.ArrayWithObjects((NSString) "bmp",
                                                     (NSString) "jpg",
                                                     (NSString) "jpeg",
                                                     (NSString) "gif",
                                                     (NSString) "png",
                                                     (NSString) "tif",
                                                     (NSString) "tiff",
                                                     null);
            if (panel.RunModalForTypes(types) == NSPanel.NSOKButton)
            {
                // Get the selected filename
                NSString filename = panel.Filename;

                // Create an instance from the file (the image is autoreleased)
                NSImage image = NSImage.ImageFromFile(filename);

                // Assign the new image to the NSImageView
                this.imageView.Image = image;
            }
        }

        [ObjectiveCMessage("loadEmbedded:")]
        public void LoadEmbedded(Id sender)
        {
            // The image is loaded from an embedded resource (the image is autoreleased)
            NSImage image = NSImage.ImageFromResource(typeof (Controller), "logo.png");

            // Assign the new image to the NSImageView
            this.imageView.Image = image;
        }

        [IBAction]
        [ObjectiveCMessage("saveToFile:")]
        public void SaveToFile(Id sender)
        {
            // Don't do anything if there is no image
            NSImage image = this.imageView.Image;
            if (image == null)
            {
                AppKitFramework.NSRunAlertPanel("Cannot Save Image", "There is no image to save !!!", "OK", null, null);
                return;
            }

            // Get a NSSavePanel instance and configure it.
            NSSavePanel panel = NSSavePanel.SavePanel;
            panel.AllowedFileTypes = NSArray.ArrayWithObjects((NSString) "tif",
                                                              (NSString) "tiff",
                                                              null);
            panel.CanCreateDirectories = true;
            if (panel.RunModal() == NSPanel.NSOKButton)
            {
                // Get the selected filename
                NSString filename = panel.Filename;

                // Save the image to the file in TIFF format
                NSData data = image.TIFFRepresentation;
                File.WriteAllBytes(filename, data.GetBuffer());
            }
        }

        [ObjectiveCMessage("resizeImage:")]
        public void ResizeImage(Id sender)
        {
            // The image is loaded from an embedded resource (the image is autoreleased)
            NSImage source = NSImage.ImageFromResource(typeof (Controller), "logo.png");

            // Creates a destination image that has a size of 200 x 200
            NSImage destination = new NSImage(new NSSize(200.0f, 200.0f));

            // Lock the focus, so the current graphical context is now associated with the image
            destination.LockFocus();

            // We draw the image by using different source and destination rects, so the image is stretch
            source.DrawInRectFromRectOperationFraction(new NSRect(NSPoint.NSZeroPoint, destination.Size),
                                                       new NSRect(NSPoint.NSZeroPoint, source.Size),
                                                       NSCompositingOperation.NSCompositeSourceOver, 1.0f);

            // Don't forget to unlock the focus as each lock must be matched by a unlock
            destination.UnlockFocus();

            // Assigns the image to the view
            this.imageView.Image = destination;

            // We can release this instance, as it is now retained by the NSImageView
            destination.Release();
        }

        [ObjectiveCMessage("drawImage:")]
        public void DrawImage(Id sender)
        {
            // The image is loaded from an embedded resource (the image is autoreleased)
            NSImage source = NSImage.ImageFromResource(typeof (Controller), "medium.png");

            // Creates an image that has a size of 200 x 200
            NSImage destination = new NSImage(new NSSize(200.0f, 200.0f));

            // Lock the focus, so the current graphical context is now associated with the image
            destination.LockFocus();

            // Set the blue color as current color
            NSColor.WhiteColor.Set();
            // Fill the whole image with the blue color
            NSBezierPath.FillRect(new NSRect(NSPoint.NSZeroPoint, destination.Size));

            // Draw the image at various positions, with various opacity
            source.CompositeToPointOperationFraction(new NSPoint(10.0f, 10.0f), NSCompositingOperation.NSCompositeSourceOver, 0.25f);
            source.CompositeToPointOperationFraction(new NSPoint(30.0f, 30.0f), NSCompositingOperation.NSCompositeSourceOver, 0.5f);
            source.CompositeToPointOperationFraction(new NSPoint(50.0f, 50.0f), NSCompositingOperation.NSCompositeSourceOver, 0.75f);
            source.CompositeToPointOperationFraction(new NSPoint(70.0f, 70.0f), NSCompositingOperation.NSCompositeSourceOver, 1.0f);

            // Don't forget to unlock the focus as each lock must be matched by a unlock
            destination.UnlockFocus();

            // Assign the image to the NSImageView
            this.imageView.Image = destination;

            // We can release this instance, as it is now retained by the NSImageView
            destination.Release();
        }

        [ObjectiveCMessage("drawText:")]
        public void DrawText(Id sender)
        {
            // Creates an image that has a size of 200 x 200
            NSImage destination = new NSImage(new NSSize(200.0f, 200.0f));

            // Lock the focus, so the current graphical context is now associated with the image
            destination.LockFocus();

            // Set the blue color as current color
            NSColor.WhiteColor.Set();
            // Fill the whole image with the blue color
            NSBezierPath.FillRect(new NSRect(NSPoint.NSZeroPoint, destination.Size));

            NSString str = "Sample Text To Draw";
            NSDictionary dict;

            dict = NSDictionary.DictionaryWithObjectsAndKeys(NSFont.LabelFontOfSize(NSFont.LabelFontSize), NSAttributedString.NSFontAttributeName,
                                                             null);

            str.DrawAtPointWithAttributes(new NSPoint(10.0f, 20.0f), dict);

            dict = NSDictionary.DictionaryWithObjectsAndKeys(NSFont.SystemFontOfSize(NSFont.SystemFontSize), NSAttributedString.NSFontAttributeName,
                                                             NSColor.BlueColor, NSAttributedString.NSForegroundColorAttributeName,
                                                             null);
            str.DrawAtPointWithAttributes(new NSPoint(10.0f, 40.0f), dict);

            dict = NSDictionary.DictionaryWithObjectsAndKeys(NSFont.UserFontOfSize(NSFont.SystemFontSize), NSAttributedString.NSFontAttributeName,
                                                             NSNumber.NumberWithEnum(NSUnderlineStyle.NSUnderlineStyleSingle), NSAttributedString.NSUnderlineStyleAttributeName,
                                                             NSColor.RedColor, NSAttributedString.NSUnderlineColorAttributeName,
                                                             null);
            str.DrawAtPointWithAttributes(new NSPoint(10.0f, 60.0f), dict);

            dict = NSDictionary.DictionaryWithObjectsAndKeys(NSFont.SystemFontOfSize(NSFont.SystemFontSize), NSAttributedString.NSFontAttributeName,
                                                             null);
            str.DrawAtPointWithAttributes(new NSPoint(10.0f, 30.0f), dict);

            dict = NSDictionary.DictionaryWithObjectsAndKeys(NSFont.TitleBarFontOfSize(NSFont.SystemFontSize), NSAttributedString.NSFontAttributeName,
                                                             null);
            str.DrawAtPointWithAttributes(new NSPoint(10.0f, 30.0f), dict);

            dict = NSDictionary.DictionaryWithObjectsAndKeys(NSFont.UserFixedPitchFontOfSize(NSFont.SystemFontSize), NSAttributedString.NSFontAttributeName, null);
            str.DrawAtPointWithAttributes(new NSPoint(10.0f, 70.0f), dict);

            // Don't forget to unlock the focus as each lock must be matched by a unlock
            destination.UnlockFocus();

            // Assign the image to the NSImageView
            this.imageView.Image = destination;

            // We can release this instance, as it is now retained by the NSImageView
            destination.Release();
        }

        [ObjectiveCMessage("drawShapes:")]
        public void DrawShapes(Id sender)
        {
            // Creates an image that has a size of 200 x 200
            NSImage destination = new NSImage(new NSSize(200.0f, 200.0f));

            // Lock the focus, so the current graphical context is now associated with the image
            destination.LockFocus();

            // Set the blue color as current color
            NSColor.WhiteColor.Set();
            // Fill the whole image with the blue color
            NSBezierPath.FillRect(new NSRect(NSPoint.NSZeroPoint, destination.Size));

            // Create a rectangle and draw it with stroke
            NSBezierPath path = NSBezierPath.BezierPathWithRect(new NSRect(10.0f, 10.0f, 100.0f, 100.0f));
            NSColor.BlueColor.Set();
            path.Stroke();

            // Create a rectangle and draw it with fill and stroke
            path = NSBezierPath.BezierPathWithRect(new NSRect(80.0f, 30.0f, 100.0f, 40.0f));
            NSColor.GreenColor.Set();
            path.Fill();
            NSColor.BlackColor.Set();
            path.Stroke();

            // Create an oval and draw it with stroke
            path = NSBezierPath.BezierPathWithOvalInRect(new NSRect(20.0f, 130.0f, 100.0f, 60.0f));
            NSColor.RedColor.Set();
            path.Stroke();

            // Create a circle and draw it with fill and stroke
            path = NSBezierPath.BezierPathWithOvalInRect(new NSRect(90.0f, 90.0f, 100.0f, 100.0f));
            NSColor.MagentaColor.Set();
            path.Fill();
            NSColor.BlackColor.Set();
            path.Stroke();

            // Don't forget to unlock the focus as each lock must be matched by a unlock
            destination.UnlockFocus();

            // Assign the image to the NSImageView
            this.imageView.Image = destination;

            // We can release this instance, as it is now retained by the NSImageView
            destination.Release();
        }

        [ObjectiveCMessage("invert:")]
        public void Invert(Id sender)
        {
            // The image is loaded from an embedded resource (the image is autoreleased)
            NSImage source = NSImage.ImageFromResource(typeof (Controller), "logo.png");

            NSBitmapImageRep rep = source.Representations.ObjectAtIndex<NSBitmapImageRep>(0);
            CIImage image = new CIImage(rep);

            CIFilter filter = CIFilter.FilterWithName("CIColorInvert");
            filter.SetDefaults();
            filter.SetValueForKey(image, "inputImage");

            CIImage result = filter.ValueForKey("outputImage").CastTo<CIImage>();

            // Creates a destination representation that has a size of 200 x 200
            NSBitmapImageRep bitmapImageRep = new NSBitmapImageRep(IntPtr.Zero,
                                                                   (int) source.Size.width,
                                                                   (int) source.Size.height,
                                                                   8,
                                                                   4,
                                                                   true,
                                                                   false,
                                                                   "NSCalibratedRGBColorSpace",
                                                                   (int) (4*source.Size.width), 32);
            NSGraphicsContext graphicsContext = NSGraphicsContext.GraphicsContextWithBitmapImageRep(bitmapImageRep);
            CIContext ciContext = graphicsContext.CIContext;
            ciContext.DrawImageAtPointFromRect(result, CGPoint.CGPointZero, image.Extent);

            image.Release();

            NSImage destination = new NSImage(source.Size);
            destination.AddRepresentation(bitmapImageRep);
            bitmapImageRep.Release();

            // Assigns the image to the view
            this.imageView.Image = destination;
        }

        [ObjectiveCMessage("draw:")]
        public void Draw(Id sender)
        {
            // Create a new image for drawing. This could be an existing image.
            NSImage destination = new NSImage(new NSSize(200.0f, 100.0f));

            // We lock the focus, so the drawing will occurs in the image context
            destination.LockFocus();

            NSColor.LightGrayColor.Set();
            NSBezierPath.FillRect(new NSRect(NSPoint.NSZeroPoint, destination.Size));

            NSColor.BlueColor.Set();
            NSRect rect = new NSRect(10.0f, 10.0f, 100.0f, 40.0f);
            // If you want a pixel exact drawing, you should inset the rect by half the stroke's width
            rect = rect.InsetRect(0.5f, 0.5f);
            NSBezierPath.StrokeRect(rect);

            NSColor.YellowColor.Set();
            NSBezierPath path = NSBezierPath.BezierPathWithOvalInRect(new NSRect(80.0f, 40.0f, 100.0f, 40.0f));
            path.Fill();

            NSColor.RedColor.Set();
            NSBezierPath.StrokeLineFromPointToPoint(new NSPoint(20.0f, 80.0f), new NSPoint(180.0f, 20.0f));

            // Each lock must be matched by a unlock
            destination.UnlockFocus();

            // Assigns the image to the view
            this.imageView.Image = destination;
            destination.Release();
        }
    }
}