// 
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2010  Laurent Etiemble
// 
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
// 
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
// 
using System;
using System.Runtime.InteropServices;
using Monobjc.Cocoa;
using Monobjc.OpenGL;
using Monobjc.QuartzComposer;

namespace Monobjc.Samples.QuartzComposerTexture
{
	[ObjectiveCClass]
	public class PBufferRenderer : NSObject
	{
		public static readonly Class PBufferRendererClass = Class.GetClassFromType(typeof(PBufferRenderer));

		NSOpenGLPixelBuffer			_pixelBuffer;
		NSOpenGLContext				_pixelBufferContext;
		QCRenderer					_renderer;
		NSOpenGLContext				_textureContext;
		uint							_textureTarget;
		uint							_textureName;
		IntPtr						_textureNamePtr; // Pointer to global texture name
		const  uint					GL_TEXTURE_RECTANGLE_EXT = 0x84F5;
		const  uint					GL_TEXTURE_BINDING_RECTANGLE_EXT = 0x84F6;
		
		
		public PBufferRenderer (){}
		public PBufferRenderer (IntPtr nativePointer):base(nativePointer){}
		
		[ObjectiveCMessage("init")]
		public override Id Init ()
		{
			Console.WriteLine ("Init called\n");
			return this.SendMessageSuper<Id>(PBufferRendererClass, "init");
		}

		
		[ObjectiveCMessage("initWithCompositionPath:textureTarget:textureWidth:textureHeight:openGLContext:")]
		public Id InitWithCompositionPath(NSString path, uint target, uint width, uint height, NSOpenGLContext context, NSOpenGLPixelFormat format)
		{
											context.CGLContextObj();
			uint								saveTextureName;
			
			//Check parameters - Rendering at sizes smaller than 16x16 will likely produce garbage and we only support 2D or RECT textures
			if (path.Length == 0 || ((target != OpenGLFramework.GL_TEXTURE_2D) && (target != GL_TEXTURE_RECTANGLE_EXT)) || (width < 16) || (height < 16) || (context == null)) {
				this.Release();
				return null;
			}
			
			if(this.NativePointer == this.SendMessageSuper<IntPtr>(PBufferRendererClass, "init"))
			{
				//Keep the target OpenGL context around
				_textureContext = context.Retain<NSOpenGLContext>();
			
				//Create the OpenGL pBuffer to render into
				_pixelBuffer = new NSOpenGLPixelBuffer(target, OpenGLFramework.GL_RGBA, 0, (int)width, (int)height);
				if (_pixelBuffer == null) {
					Console.WriteLine ("Cannot create OpenGL pixel buffer");
					this.Release();
					return null;
				}
				
				//Create the OpenGL context to use to render in the pBuffer (with color and depth buffers) - It needs to be shared to ensure both contexts have identical virtual screen lists
				_pixelBufferContext = new NSOpenGLContext(format, _textureContext);
				if (_pixelBufferContext == null) {
					Console.WriteLine ("Cannot create OpenGL context");
					this.Release();
					return null;
				}
				
				//Attach the OpenGL context to the pBuffer (make sure it uses the same virtual screen as the primary OpenGL context)
				_pixelBufferContext.SetPixelBufferCubeMapFaceMipMapLevelCurrentVirtualScreen(_pixelBuffer,0,0,_textureContext.CurrentVirtualScreen);
				
				//Create the QuartzComposer Renderer with that OpenGL context and the specified composition file
				_renderer = new QCRenderer(_pixelBufferContext, format, path);
				if (_renderer == null) {
					Console.WriteLine ("Cannot create QCRenderer");
					this.Release();
					return null;
				}
				
				//Create the texture on the target OpenGL context
				_textureTarget = target;
				
				_textureNamePtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(uint))); 	  			// alloc unmanaged mem
				OpenGLFramework.glGenTextures(1, _textureNamePtr);
				
				
				//Configure the texture - For extra safety, we save and restore the currently bound texture
				
				IntPtr saveTextureNamePointer = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(uint)) );	 //Alloc unmanaged mem
				OpenGLFramework.glGetIntegerv((_textureTarget == GL_TEXTURE_RECTANGLE_EXT ? GL_TEXTURE_BINDING_RECTANGLE_EXT : OpenGLFramework.GL_TEXTURE_BINDING_2D), saveTextureNamePointer);
				
				_textureName = (uint)Marshal.ReadInt32(_textureNamePtr);
				OpenGLFramework.glBindTexture(_textureTarget, _textureName);
				
				OpenGLFramework.glTexParameteri(_textureTarget, OpenGLFramework.GL_TEXTURE_MIN_FILTER, (int)OpenGLFramework.GL_LINEAR);
				OpenGLFramework.glTexParameteri(_textureTarget, OpenGLFramework.GL_TEXTURE_MAG_FILTER, (int)OpenGLFramework.GL_LINEAR);
				if (_textureTarget == GL_TEXTURE_RECTANGLE_EXT) {
					OpenGLFramework.glTexParameteri(_textureTarget, OpenGLFramework.GL_TEXTURE_WRAP_S, (int)OpenGLFramework.GL_CLAMP_TO_EDGE);
					OpenGLFramework.glTexParameteri(_textureTarget, OpenGLFramework.GL_TEXTURE_WRAP_T, (int)OpenGLFramework.GL_CLAMP_TO_EDGE);
				}
				else {
					OpenGLFramework.glTexParameteri(_textureTarget, OpenGLFramework.GL_TEXTURE_WRAP_S, (int)OpenGLFramework.GL_REPEAT);
					OpenGLFramework.glTexParameteri(_textureTarget, OpenGLFramework.GL_TEXTURE_WRAP_T, (int)OpenGLFramework.GL_REPEAT);		
				}
				saveTextureName = (uint)Marshal.ReadInt32(saveTextureNamePointer);
				OpenGLFramework.glBindTexture(_textureTarget, saveTextureName);
				
				//Update the texture immediately
				this.UpdateTextureForTime(0.0f);
				
				// Free unmanaged mem
				Marshal.FreeHGlobal(saveTextureNamePointer);
				
			}
			return this;
		}
		

		public void UpdateTextureOnTargetContext()
		{
			_textureContext.CGLContextObj();
			
			uint 		saveTextureName;
			
			//Save the currently bound texture
			
			IntPtr saveTextureNamePtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(uint)));
			OpenGLFramework.glGetIntegerv((_textureTarget == GL_TEXTURE_RECTANGLE_EXT ? GL_TEXTURE_BINDING_RECTANGLE_EXT : OpenGLFramework.GL_TEXTURE_BINDING_2D), saveTextureNamePtr);
		
			//Bind the texture and update its contents
			_textureName = (uint)Marshal.ReadInt32(_textureNamePtr);
			OpenGLFramework.glBindTexture(_textureTarget, _textureName);
			
			_textureContext.SetTextureImageToPixelBufferColorBuffer(_pixelBuffer, OpenGLFramework.GL_FRONT);
#if DEBUG
			string attr = string.Format("Pixelbuffer MipMapLevel = {0}\n" +
			                            "Pixelbuffer TextureTarget = {1}\n" +
			                            "TextureTarget {2}\n"+
			                            "TextureName {3}\n",0, _pixelBuffer.TextureTarget,
		 		                            					  _textureTarget, _textureName);
			Console.WriteLine (attr);
#endif
			
			//Restore the previously bound texture
			saveTextureName = (uint)Marshal.ReadInt32(saveTextureNamePtr);
			OpenGLFramework.glBindTexture(_textureTarget, saveTextureName);
			
			Marshal.FreeHGlobal(saveTextureNamePtr);
		}
		
		[ObjectiveCMessage("updateTextureForTime:")]
		public bool UpdateTextureForTime(double time)
		{
			_pixelBufferContext.CGLContextObj();

			bool 				success;
			uint					error;
			NSOpenGLPixelBuffer	pBuffer;
			
			//Make sure the virtual screen for the pBuffer and its rendering context match the target one
			if (_textureContext.CurrentVirtualScreen != _pixelBufferContext.CurrentVirtualScreen) {
				pBuffer = new NSOpenGLPixelBuffer(_textureTarget, OpenGLFramework.GL_RGBA, 0, _pixelBuffer.PixelsWide, _pixelBuffer.PixelsHigh);
				if (pBuffer != null) {
					_pixelBufferContext.ClearDrawable();
					_pixelBuffer.Release();
					_pixelBuffer = pBuffer;
					_pixelBufferContext.SetPixelBufferCubeMapFaceMipMapLevelCurrentVirtualScreen(_pixelBuffer, 0, 0, _textureContext.CurrentVirtualScreen);
				}
				else {
					Console.WriteLine ("Cannot create OpenGL pixel buffer");
					return false;
				}
			}
			
			//Render a frame from the composition at the specified time in the pBuffer
			success = _renderer.RenderAtTimeArguments(time, null);
			
			//IMPORTANT: Make sure all OpenGL rendering commands were sent to the pBuffer OpenGL context
			glFlushRenderAPPLE();
			
			//Update the texture in the target OpenGL context from the contents of the pBuffer
			this.UpdateTextureOnTargetContext();
			
			if ((error = OpenGLFramework.glGetError()) != 0) {
				Console.WriteLine ("OpenGL error 0x{0:X}",error);
			}
			
			return success;
		}
		
		public uint TextureTarget
		{
			[ObjectiveCMessage("textureTarget")]
			get { return _textureTarget;}
		}
			
		public uint TextureName
		{
			[ObjectiveCMessage("textureName")]
			get {
					_textureName = (uint)Marshal.ReadInt32(_textureNamePtr);	
					return _textureName;
			}
		}
		
		public int TextureWidth
		{
			[ObjectiveCMessage("textureWidth")]
			get { return _pixelBuffer.PixelsWide;}
		}
		
		public int TextureHeight
		{
			[ObjectiveCMessage("textureHeight")]
			get { return _pixelBuffer.PixelsHigh;}
		}
		
		public float TextureCoordSMin
		{
			[ObjectiveCMessage("textureCoordSMin")]
			get { return 0.0f;}
		}

		public float TextureCoordSMax
		{
			[ObjectiveCMessage("textureCoordSMax")]
			get { return (_textureTarget == GL_TEXTURE_RECTANGLE_EXT ? (float)_pixelBuffer.PixelsWide : 1.0f);}
		}
		
		public float TextureCoordTMin
		{
			[ObjectiveCMessage("textureCoordTMin")]
			get { return 0.0f;}
		}
		
		public float TextureCoordTMax
		{
			[ObjectiveCMessage("textureCoordTMax")]
			get {return (_textureTarget == GL_TEXTURE_RECTANGLE_EXT ? (float)_pixelBuffer.PixelsHigh : 1.0f);}
		}
		
		[ObjectiveCMessage("dealloc")]
		public void Dealloc()
		{
			_textureContext.CGLContextObj();
			//Destroy the texture on the target OpenGL context
			_textureName = (uint)Marshal.ReadInt32(_textureNamePtr);
			if (_textureName != 0) {
				OpenGLFramework.glDeleteTextures(1, _textureNamePtr);
				Marshal.FreeHGlobal(_textureNamePtr);
			}
			
			//Destroy the renderer
			_renderer.Release();
			
			//Destroy OpenGL context
			_pixelBufferContext.ClearDrawable();
			_pixelBufferContext.Release();
			
			//Destroy OpenGL pixel buffer
			_pixelBuffer.Release();
			
			//Release target OpenGL context
			_textureContext.Release();
			
			this.SendMessageSuper(PBufferRendererClass, "dealloc");
		}
		
#region InterOp functions "DO NOT MODIFY"
		[DllImport("/System/Libraries/Frameworks/OpenGL.framework/OpenGL", EntryPoint="glFlushRenderAPPLE")]
		public static extern void glFlushRenderAPPLE();
#endregion
		
	}
}
