// 
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2010  Laurent Etiemble
// 
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
// 
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
// 
using System;
using System.Runtime.InteropServices;
using Monobjc.Cocoa;
using Monobjc.OpenGL;

namespace Monobjc.Samples.QuartzComposerTexture
{

	[ObjectiveCClass]
	public class AppController : NSObject
	{
		public static readonly Class AppControllerClass = Class.GetClassFromType(typeof(AppController));
		
		[ObjectiveCField]
		public NSOpenGLView 		renderView;
		
		[ObjectiveCField]		
		public NSApplication		app;
		
		PBufferRenderer		_pBufferRenderer;
		NSTimer				_renderTimer;
		double				_startTime;
		const double			kRenderFPS = 60.0;
		
		
		public AppController (){	}
		
		public AppController (IntPtr nativePointer) : base(nativePointer){}
		
		[ObjectiveCMessage("awakeFromNib")]
		public void AwakeFromNib ()
		{	
			//Setting up event delegate handlers
			app.SetDelegate( a => { 	a.ApplicationDidFinishLaunching += ApplicationDidFinishLaunching;
									a.ApplicationWillTerminate += ApplicationWillTerminate;
								  });
			renderView.Window.SetDelegate( w => w.WindowShouldClose += WindowShouldClose);
			
		}

		public void ApplicationDidFinishLaunching(NSNotification notification)
		{
			int 								swapInterval = 1;
			
			renderView.OpenGLContext.SetValuesForParameter(new int[]{swapInterval}, NSOpenGLContextParameter.NSOpenGLCPSwapInterval);
			
			//Prompt the user for a Quartz Composer composition immediately
			this.OpenComposition(null);
			
			NSNotificationCenter.DefaultCenter.AddObserverSelectorNameObject(this, ObjectiveCRuntime.Selector("updateRenderView:"), NSView.NSViewGlobalFrameDidChangeNotification, renderView);
			
			//Create a timer which will regularly call our rendering method
			_renderTimer = new NSTimer(null,(1.0 / kRenderFPS), this, ObjectiveCRuntime.Selector("_renderGLScene:"),null, true);
			NSRunLoop.CurrentRunLoop.AddTimerForMode(_renderTimer, NSRunLoop.NSDefaultRunLoopMode);
			NSRunLoop.CurrentRunLoop.AddTimerForMode(_renderTimer, NSRunLoop.NSModalPanelRunLoopMode);
			NSRunLoop.CurrentRunLoop.AddTimerForMode(_renderTimer, NSRunLoop.NSEventTrackingRunLoopMode);
			_startTime = -1.0f;
			Console.WriteLine ("applicationDidFinishLaunching event");
			
		}
			
		
		[IBAction]
		[ObjectiveCMessage("openComposition:")]
		public void OpenComposition(Id sender)
		{
			NSOpenPanel	openPanel = NSOpenPanel.OpenPanel;
			
			//Prompt the user for a Quartz Composer composition file
			openPanel.AllowsMultipleSelection = false;
			openPanel.CanChooseDirectories = false;
			openPanel.CanChooseFiles = true;
			if (openPanel.RunModalForDirectoryFileTypes(null, null, NSArray.ArrayWithObject(NSString.NSPinnedString("qtz"))) == NSOpenPanel.NSOKButton) {
					//Destroy the current pBuffer renderer and create a new one
					if(_pBufferRenderer != null)
						_pBufferRenderer.Release();
					_pBufferRenderer = new PBufferRenderer(); 
					_pBufferRenderer.InitWithCompositionPath(openPanel.Filename, OpenGLFramework.GL_TEXTURE_2D, 512, 512, renderView.OpenGLContext, renderView.PixelFormat);	 
			}
		}
		
		[ObjectiveCMessage("_renderGLScene:")]
		public void RenderGLScene(NSTimer timer)
		{
			//renderView.OpenGLContext.CGLContextObj();
			
			NSDate  date = new NSDate();
			double  time = date.TimeIntervalSinceReferenceDate;
			int[]	viewport = new int[4];
			
			// Compute the local time
			if (_startTime < 0.0) {
				_startTime = time;
			}
			time = time - _startTime;
			
			// Clear background
			OpenGLFramework.glClearColor(0.25f,0.25f,0.25f, 0.25f);
			OpenGLFramework.glClear(OpenGLFramework.GL_COLOR_BUFFER_BIT | OpenGLFramework.GL_DEPTH_BUFFER_BIT);
			
			// Save & configure projection matrix
			OpenGLFramework.glMatrixMode(OpenGLFramework.GL_PROJECTION_MATRIX);
			
			IntPtr viewPortPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(int)) * viewport.Length); // Init unmanaged mem
			
			OpenGLFramework.glGetIntegerv(OpenGLFramework.GL_VIEWPORT, viewPortPtr);
			OpenGLFramework.glPushMatrix();
			
			Marshal.Copy(viewPortPtr, viewport,0, viewport.Length); // copy unmanaged array back
			OpenGLFramework.glOrtho(-1.0,1.0, -1.0 * (float)viewport[3] / (float)viewport[2], 1.0 * (float)viewport[3] / (float)viewport[2], -1.0, -1.0);
			
			// Save & configure modelview matrix ( make it rotate with time )
			OpenGLFramework.glMatrixMode(OpenGLFramework.GL_MODELVIEW_MATRIX);
			OpenGLFramework.glPushMatrix();
			OpenGLFramework.glRotatef((float)(time * 360.0 / 5), 0.0f, 0.0f, 1.0f);
			
			// Confgure texturing
			if (_pBufferRenderer != null) {
				_pBufferRenderer.UpdateTextureForTime(time);
				OpenGLFramework.glEnable(_pBufferRenderer.TextureTarget);
				OpenGLFramework.glBindTexture(_pBufferRenderer.TextureTarget, _pBufferRenderer.TextureName);
				OpenGLFramework.glTexEnvi(OpenGLFramework.GL_TEXTURE_ENV, OpenGLFramework.GL_TEXTURE_ENV_MODE, (int)OpenGLFramework.GL_REPLACE);
			}
			else {
				OpenGLFramework.glColor4f(1.0f,1.0f,1.0f,1.0f);
			}
			
			//Draw textured quad
			OpenGLFramework.glBegin(OpenGLFramework.GL_QUADS);
				OpenGLFramework.glTexCoord2f(_pBufferRenderer.TextureCoordSMin, _pBufferRenderer.TextureCoordTMin);
				OpenGLFramework.glVertex3f(-0.5f, -0.5f, 0.0f);
				OpenGLFramework.glTexCoord2f(_pBufferRenderer.TextureCoordSMax, _pBufferRenderer.TextureCoordTMin);
				OpenGLFramework.glVertex3f(0.5f, -0.5f, 0.0f);
				OpenGLFramework.glTexCoord2f(_pBufferRenderer.TextureCoordSMax, _pBufferRenderer.TextureCoordTMax);
				OpenGLFramework.glVertex3f(0.5f, 0.5f, 0.0f);
				OpenGLFramework.glTexCoord2f(_pBufferRenderer.TextureCoordSMin, _pBufferRenderer.TextureCoordTMax);
				OpenGLFramework.glVertex3f(-0.5f, 0.5f, 0.0f);
			OpenGLFramework.glEnd();
			
			//Restore texture settings
			if (_pBufferRenderer != null) {
				OpenGLFramework.glDisable(_pBufferRenderer.TextureTarget);
			}
			
			//Restore modelview and projection matrices
			OpenGLFramework.glPopMatrix();
			OpenGLFramework.glMatrixMode(OpenGLFramework.GL_PROJECTION_MATRIX);
			OpenGLFramework.glPopMatrix();
			
			//Display new frame
			//_glContext.FlushBuffer();
			renderView.OpenGLContext.FlushBuffer();
			
			//Free unmanaged mem
			Marshal.FreeHGlobal(viewPortPtr);
		}
		
		[ObjectiveCMessage("updateRenderView:")]
		public void UpdateRenderView(NSNotification notification)
		{
		//	renderView.OpenGLContext.CGLContextObj();
			NSRect 	frame = renderView.Frame;
			
			//Notify the OpenGL context its rendering view has changed
			renderView.OpenGLContext.Update();
			
			//Update the OpenGL viewport
			OpenGLFramework.glViewport(0,0, (int)frame.size.width, (int)frame.size.height);
			
			//Render OpenGL scene immediately
			this.RenderGLScene(null);
			
		}
		
		public bool WindowShouldClose(Id sender)
		{
			NSApplication.SharedApplication.Terminate(this);
		
			return true;
		}
		
		public void ApplicationWillTerminate(NSNotification notification)
		{
			//Stop the timer
			_renderTimer.Invalidate();
			
			//Stop observing the rendering view
			NSNotificationCenter.DefaultCenter.RemoveObserverNameObject(this, NSView.NSViewGlobalFrameDidChangeNotification, renderView);
		}
		
		[ObjectiveCMessage("dealloc")]
		public void Dealloc()
		{
			//Release our objects
			_renderTimer.Release();
			_pBufferRenderer.Release();
			renderView.OpenGLContext.Release();
			
			this.SendMessageSuper(AppControllerClass, "dealloc");
		}
	}
}
