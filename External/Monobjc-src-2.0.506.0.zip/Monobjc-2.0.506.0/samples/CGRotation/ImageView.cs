// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using Monobjc.Cocoa;

namespace Monobjc.Samples.CGRotation
{
    [ObjectiveCClass]
    public class ImageView : NSView
    {
        private static readonly Class ImageViewClass = Class.GetClassFromType(typeof (ImageView));
        private ImageInfo image;

        /// <summary>
        /// Initializes a new instance of the <see cref="ImageView"/> class.
        /// </summary>
        public ImageView() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="ImageView"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public ImageView(IntPtr nativePointer)
            : base(nativePointer) {}

        [ObjectiveCMessage("initWithFrame:")]
        public override Id InitWithFrame(NSRect frame)
        {
            this.NativePointer = this.SendMessageSuper<IntPtr>(ImageViewClass, "initWithFrame:", frame);

            return this;
        }

        [ObjectiveCMessage("dealloc", SynchronizeFields = false)]
        public void Dealloc()
        {
            ImageUtils.IIRelease(ref this.image);

            this.SendMessageSuper(ImageViewClass, "dealloc");
        }

        public ImageInfo Image
        {
            get { return this.image; }
            set
            {
                if (!Equals(value, this.image))
                {
                    ImageUtils.IIRelease(ref this.image);
                    this.image = value;
                    this.NeedsDisplay = true;
                }
            }
        }

        [ObjectiveCMessage("drawRect:")]
        public override void DrawRect(NSRect rect)
        {
            // Obtain the current context
            IntPtr ctx = NSGraphicsContext.CurrentContext.GraphicsPort;

            // Draw the image in the context
            ImageUtils.IIDrawImageTransformed(ref this.image, ctx, CGRect.CGRectMake(rect.origin.x, rect.origin.y, rect.size.width, rect.size.height));

            // Draw the view border, just a simple stroked rectangle
            CGContext.AddRect(ctx, CGRect.CGRectMake(rect.origin.x, rect.origin.y, rect.size.width, rect.size.height));
            CGContext.SetRGBStrokeColor(ctx, 1.0f, 0.0f, 0.0f, 1.0f);
            CGContext.StrokePath(ctx);
        }

        public void SetRotation(float value)
        {
            this.image.fRotation = value;
        }

        public void SetScaleX(float value)
        {
            this.image.fScaleX = value;
        }

        public void SetScaleY(float value)
        {
            this.image.fScaleY = value;
        }

        public void SetTranslateX(float value)
        {
            this.image.fTranslateX = value;
        }

        public void SetTranslateY(float value)
        {
            this.image.fTranslateY = value;
        }
    }
}