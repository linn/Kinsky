// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using Monobjc.Cocoa;
using Monobjc.DiscRecording;

namespace Monobjc.Samples.Eraser
{
    [ObjectiveCClass]
    public class AppController : NSObject
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AppController"/> class.
        /// </summary>
        public AppController() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="AppController"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public AppController(IntPtr nativePointer)
            : base(nativePointer) {}

        /// <summary>
        /// When the application finishes launching, we'll set up a notification to be sent when the
        /// erase completes. This notification is sent by the DREraseProgressPanel to observers
        /// when the erase is 100% finished.
        /// </summary>
        [ObjectiveCMessage("applicationDidFinishLaunching:")]
        public void ApplicationDidFinishLaunching(NSNotification notification)
        {
            // Gets the DRErase icon and assign it another name
            NSImage icon = NSImage.ImageNamed(DiscRecordingFramework.DREraseIcon);
            icon.SetName("OldDREraseIcon");

            // Gets the Monobjc icon and assign it as default icon
            icon = new NSImage(NSBundle.MainBundle.PathForImageResource("Monobjc.icns"));
            icon.SetName(DiscRecordingFramework.DREraseIcon);

            NSNotificationCenter.DefaultCenter.AddObserverSelectorNameObject(this,
                                                                             ObjectiveCRuntime.Selector("eraseCompleted:"),
                                                                             DREraseProgressPanel.DREraseProgressPanelDidFinishNotification,
                                                                             null);

            this.EraseCompleted(null);
        }

        /// <summary>
        /// Every time the erase completes, put up the erase dialog and let the user pick another
        /// drive to use for erasing discs.
        /// </summary>
        [ObjectiveCMessage("eraseCompleted:")]
        public void EraseCompleted(NSNotification notification)
        {
            DREraseSetupPanel esp = DREraseSetupPanel.SetupPanel;
            esp.Delegate = this;

            if (esp.RunSetupPanel() == NSPanel.NSOKButton)
            {
                DREraseProgressPanel epp = DREraseProgressPanel.ProgressPanel;
                epp.Delegate = this;
                epp.BeginProgressPanelForErase(esp.EraseObject);

                /* If you wanted to run this as a sheet you would have done
                 * [epp beginProgressSheetForErase:[esp eraseObject]];
                 */
            }
            else
            {
                NSApplication.SharedApplication.Terminate(this);
            }
        }

        [ObjectiveCMessage("setupPanel:deviceCouldBeTarget:")]
        public bool SetupPanelDeviceCouldBeTarget(DRSetupPanel aPanel, DRDevice device)
        {
            return true;
        }

        [ObjectiveCMessage("eraseProgressPanel:eraseDidFinish:")]
        public bool EraseProgressPanelEraseDidFinish(DREraseProgressPanel theErasePanel, DRErase erase)
        {
            NSDictionary eraseStatus = erase.Status;
            NSString state = eraseStatus[DiscRecordingFramework.DRStatusStateKey].CastTo<NSString>();

            if (state.IsEqualToString(DiscRecordingFramework.DRStatusStateFailed))
            {
                NSDictionary errorStatus = eraseStatus[DiscRecordingFramework.DRErrorStatusKey].CastTo<NSDictionary>();
                NSString errorString = errorStatus[DiscRecordingFramework.DRErrorStatusErrorStringKey].CastTo<NSString>();

                Console.WriteLine("The erase failed (" + errorString + ")!");
            }
            else
            {
                Console.WriteLine("Erase finished fine");            }

            return true;
        }    }
}