// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using Monobjc.Cocoa;
using Monobjc.QuickTime;

namespace Monobjc.Samples.QTKitPlayer
{
    [ObjectiveCClass]
    public class MyDocument : NSDocument
    {
        private static readonly Class MyDocumentClass = Class.GetClassFromType(typeof (MyDocument));

        [ObjectiveCField]
        public QTMovieView mMovieView;

        public MyDocument() {}

        public MyDocument(IntPtr nativePointer)
            : base(nativePointer) {}

        public override NSString WindowNibName
        {
            [ObjectiveCMessage("windowNibName")]
            get { return new NSString("MyDocument"); }
        }

        [ObjectiveCMessage("windowControllerDidLoadNib:")]
        public override void WindowControllerDidLoadNib(NSWindowController aController)
        {
            this.SendMessageSuper(MyDocumentClass, "windowControllerDidLoadNib:", aController);

            if (this.FileURL != null)
            {
                NSError error;
                QTMovie movie = QTMovie.MovieWithURLError(this.FileURL, out error);

                movie.SetAttributeForKey((NSNumber) true, QTMovie.QTMovieEditableAttribute);
                this.mMovieView.Movie = movie;
            }        }

        [ObjectiveCMessage("dataRepresentationOfType:")]
        public override NSData DataRepresentationOfType(NSString aType)
        {
            return null;
        }

        [ObjectiveCMessage("loadDataRepresentation:ofType:")]
        public bool LoadDataRepresentation(NSData data, NSString aType)
        {
            return true;
        }

        [ObjectiveCMessage("saveDocument:")]
        public override void SaveDocument(Id sender)
        {
            this.mMovieView.Movie.UpdateMovieFile();
            this.UpdateChangeCount(NSDocumentChangeType.NSChangeCleared);
        }
    }
}