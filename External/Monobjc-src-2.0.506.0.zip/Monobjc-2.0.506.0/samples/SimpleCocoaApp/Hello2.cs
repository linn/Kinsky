// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using Monobjc.Cocoa;

namespace Monobjc.Samples.SimpleCocoaApp
{
    [ObjectiveCClass]
    public class Hello2 : NSObject
    {
        /// <summary>
        /// message3 displays the text contained in this "messageTextField" NSTextField object
        /// </summary>
        [ObjectiveCField]
        public NSTextField messageTextField;

        /// <summary>
        /// Initializes a new instance of the <see cref="Hello2"/> class.
        /// </summary>
        public Hello2() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="Hello2"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public Hello2(IntPtr nativePointer)
            : base(nativePointer) {}

        [ObjectiveCMessage("message1:")]
        public void Message1(Id sender)
        {
            // Use a standard alert to display the message
            AppKitFramework.NSRunAlertPanel("Message1, Hello2", "Hello, Cocoa!", "OK", null, null);
        }

        [ObjectiveCMessage("message2:")]
        public void Message2(Id sender)
        {
            // Use a standard alert to display the message
            AppKitFramework.NSRunAlertPanel("Message2, Hello2", "Hello again, Cocoa!", "OK", null, null);
        }

        [ObjectiveCMessage("message3:")]
        public void Message3(Id sender)
        {
            // Use a standard alert to display the message
            AppKitFramework.NSRunAlertPanel("Message3, Hello2", this.messageTextField.StringValue, "OK", null, null);
        }
    }
}