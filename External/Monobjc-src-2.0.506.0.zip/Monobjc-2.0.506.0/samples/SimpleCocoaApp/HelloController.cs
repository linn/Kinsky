// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using Monobjc.Cocoa;

namespace Monobjc.Samples.SimpleCocoaApp
{
    [ObjectiveCClass]
    public class HelloController : NSObject
    {
        /// <summary>
        /// points to the Hello1 object
        /// </summary>
        [ObjectiveCField]
        public Hello1 hello1;

        /// <summary>
        /// points to the Hello2 object
        /// </summary>
        [ObjectiveCField]
        public Hello2 hello2;

        /// <summary>
        /// points to the "Say Hello To The World of Cocoa" NSButton
        /// </summary>
        [ObjectiveCField]
        public NSButton helloButton;

        /// <summary>
        /// points to the radio group NSMatrix
        /// </summary>
        [ObjectiveCField]
        public NSMatrix messageRadio;

        /// <summary>
        /// points to the NSPopUpButton
        /// </summary>
        [ObjectiveCField]
        public NSPopUpButton objectPopUp;

        /// <summary>
        /// Initializes a new instance of the <see cref="HelloController"/> class.
        /// </summary>
        public HelloController() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="HelloController"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public HelloController(IntPtr nativePointer)
            : base(nativePointer) {}

        /// <summary>
        /// This method is called when the user picks a different message 
        /// to display by clicking a different radio button
        /// </summary>
        [ObjectiveCMessage("switchMessage:")]
        public void SwitchMessage(Id sender)
        {
            // sender is the NSMatrix containing the radio buttons.
            // We ask the sender for which row (radio button) is selected and add one
            // to compensate for counting from zero.
            int which = ((NSMatrix) sender).SelectedRow + 1;

            // We now set our NSButton's action to be the message corresponding to the radio button selection.
            // +[NSString stringWithFormat:...] is used to concatenate "message" and the message number.  
            // NSSelectorFromString converts the message name string to an actual message structure that
            // Objective-C can use.
            this.helloButton.Action = ObjectiveCRuntime.Selector(String.Format("message{0}:", which));
        }

        /// <summary>
        /// This method is called when the user picks a different object to 
        /// receive messages using the PopUp menu
        /// </summary>
        [ObjectiveCMessage("switchObject:")]
        public void SwitchObject(Id sender)
        {
            // sender is the NSPopUpMenu containing Hello object choices.
            // We ask the sender for which menu item is selected and add one
            // to compensate for counting from zero.
            int which = ((NSPopUpButton) sender).IndexOfSelectedItem + 1;

            // Based on which menu item is selected, we set the target (the receiving object)
            // of the helloButton to point to either hello1 or hello2.
            if (which == 1)
            {
                this.helloButton.Target = this.hello1;
            }
            else
            {
                this.helloButton.Target = this.hello2;
            }
        }

        /// <summary>
        /// awakeFromNib is called when this object is done being unpacked from the nib file;
        /// at this point, we can do any needed initialization before turning app control over to the user
        /// </summary>
        [ObjectiveCMessage("awakeFromNib")]
        public void AwakeFromNib() {}
    }
}