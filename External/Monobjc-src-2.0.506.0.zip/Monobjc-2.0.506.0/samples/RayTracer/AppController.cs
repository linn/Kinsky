// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using System.Threading;
using Monobjc.Cocoa;

/*
 * Original ray tracing code from Luke Hoban.
 * http://blogs.msdn.com/lukeh/archive/2007/04/03/a-ray-tracer-in-c-3-0.aspx
 */

namespace Monobjc.Samples.RayTracer
{
    [ObjectiveCClass]
    public class AppController : NSObject
    {
        private const int width = 600;
        private const int height = 600;

        [ObjectiveCField]
        public NSImageView imageView;

        private NSBitmapImageRep imageRep;

        /// <summary>
        /// Initializes a new instance of the <see cref="AppController"/> class.
        /// </summary>
        public AppController() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="AppController"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public AppController(IntPtr nativePointer)
            : base(nativePointer) {}

        [ObjectiveCMessage("applicationDidFinishLaunching:")]
        public void ApplicationDidFinishLaunching(NSNotification notification)
        {
            NSThread.MakeMultiThreaded();

            this.imageRep = new NSBitmapImageRep(IntPtr.Zero,
                                                 width,
                                                 height,
                                                 8,
                                                 4,
                                                 true,
                                                 false,
                                                 "NSCalibratedRGBColorSpace",
                                                 4*width,
                                                 32);
            NSImage image = new NSImage(new NSSize(width, height));
            image.AddRepresentation(this.imageRep);
            this.imageView.Image = image;

            Thread t = new Thread(this.DoComputation);
            t.IsBackground = true;
            t.Start();
        }

        private void DoComputation()
        {
            NSAutoreleasePool pool = new NSAutoreleasePool();

            RayTracer rayTracer = new RayTracer(width, height, (int x, int y, NSColor color) =>
                                                                   {
                                                                       this.imageRep.SetColorAtXY(color, x, y);
                                                                       if (x == 0)
                                                                       {
                                                                           this.imageView.Invoke(new MethodInvoker(() => this.imageView.SetNeedsDisplay()));
                                                                       }
                                                                   });
            rayTracer.Render(rayTracer.DefaultScene);

            this.imageView.Invoke(new MethodInvoker(() => this.imageView.SetNeedsDisplay()));

            pool.Release();
        }
    }
}