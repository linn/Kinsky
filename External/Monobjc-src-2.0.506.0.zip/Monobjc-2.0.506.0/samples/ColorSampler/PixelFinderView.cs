// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using System.Globalization;
using Monobjc.Cocoa;

namespace Monobjc.Samples.ColorSampler
{
    [ObjectiveCClass]
    public class PixelFinderView : NSImageView
    {
        [ObjectiveCField]
        public NSColorWell colorWell;

        [ObjectiveCField]
        public NSColorWell redWell;

        [ObjectiveCField]
        public NSColorWell greenWell;

        [ObjectiveCField]
        public NSColorWell blueWell;

        [ObjectiveCField]
        public NSImageView magnifiedImageView;

        [ObjectiveCField]
        public NSTextField reportText;

        /// <summary>
        /// Initializes a new instance of the <see cref="PixelFinderView"/> class.
        /// </summary>
        public PixelFinderView() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="PixelFinderView"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public PixelFinderView(IntPtr nativePointer)
            : base(nativePointer) {}

        [ObjectiveCMessage("mouseDown:")]
        public override void MouseDown(NSEvent theEvent)
        {
            this.MouseDragged(theEvent);
        }

        [ObjectiveCMessage("mouseDragged:")]
        public override void MouseDragged(NSEvent theEvent)
        {
            NSPoint where = this.ConvertPointFromView(theEvent.LocationInWindow, null);

            if (!NSRect.NSContainsRect(this.Bounds, NSRect.NSMakeRect(where.x, where.y, 1.0f, 1.0f)))
            {
                return;
            }

            NSColor pixelColor;

            float red, green, blue;

            this.LockFocus(); // NSReadPixel pulls data out of the current focused graphics context, so -lockFocus is necessary here.
            pixelColor = AppKitFramework.NSReadPixel(where);
            this.UnlockFocus(); // always balance -lockFocus with an -unlockFocus.

            red = pixelColor.RedComponent;
            green = pixelColor.GreenComponent;
            blue = pixelColor.BlueComponent;

            this.colorWell.Color = pixelColor;

            this.redWell.Color = NSColor.ColorWithCalibratedRedGreenBlueAlpha(red, 0, 0, 1);
            this.greenWell.Color = NSColor.ColorWithCalibratedRedGreenBlueAlpha(0, green, 0, 1);
            this.blueWell.Color = NSColor.ColorWithCalibratedRedGreenBlueAlpha(0, 0, blue, 1);

            this.magnifiedImageView.Image = this.Snapshot(NSRect.NSMakeRect(where.x - 5.0f, where.y - 5.0f, 10f, 10f));
            this.reportText.StringValue = String.Format(CultureInfo.CurrentCulture, "At: ({0},{1}) R={2:0.00} G={3:0.00} B={4:0.00}", where.x, where.y, red, green, blue);
        }

        [ObjectiveCMessage("mouseUp:")]
        public override void MouseUp(NSEvent theEvent)
        {
            this.MouseDragged(theEvent);
        }

        [ObjectiveCMessage("snapshot")]
        public NSImage Snapshot()
        {
            return this.Snapshot(this.Bounds);
        }

        [ObjectiveCMessage("snapshot:")]
        public NSImage Snapshot(NSRect sourceRect)
        {
            NSImage snapshot = new NSImage(sourceRect.size);

            this.LockFocus();
            NSBitmapImageRep rep = new NSBitmapImageRep(sourceRect).SafeAutorelease();
            this.UnlockFocus();

            snapshot.AddRepresentation(rep);
            snapshot.Autorelease();
            return snapshot;
        }
    }
}