// 
// This file is part of Monobjc, a .NET/Objective-C bridge
// Copyright (C) 2007-2010  Laurent Etiemble
// 
// Monobjc is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// any later version.
// 
// Monobjc is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with Monobjc. If not, see <http://www.gnu.org/licenses/>.
// 
using System;
using Monobjc.Cocoa;
using Monobjc.QuartzComposer;

namespace Monobjc.Samples.AnimatedCompositionLayer
{
    [ObjectiveCClass]
    public class AppController : NSObject
    {
        [ObjectiveCField]
        public NSWindow window;

        public AppController() {}
        public AppController(IntPtr nativePointer) : base(nativePointer) {}

        [ObjectiveCMessage("applicationDidFinishLaunching:")]
        public void ApplicationDidFinishLaunching(NSNotification notification)
        {
            QCComposition composition;
            AnimatedView view;

            /* Get a composition from the repository */
            composition = QCCompositionRepository.SharedCompositionRepository.CompositionWithIdentifier(new NSString("/defocus"));
            if (composition == null)
            {
                NSApplication.SharedApplication.Terminate(null);
            }

            /* Configure the content view of the window to use a Core Animation layer */
            view = new AnimatedView(NSRect.NSMakeRect(0, 0, 100, 100));
            view.WantsLayer = true;
            view.Layer = QCCompositionLayer.CompositionLayerWithComposition(composition);
            this.window.ContentView = view;
            view.Release();

            /* Show window */
            this.window.MakeKeyAndOrderFront(null);
        }

        [ObjectiveCMessage("windowWillClose:")]
        public void WindowWillClose(NSNotification notification)
        {
            NSApplication.SharedApplication.Terminate(null);
        }
    }

    [ObjectiveCClass]
    public class AnimatedView : NSView
    {
        private static Random random;

        public AnimatedView() {}
        public AnimatedView(IntPtr nativePointer) : base(nativePointer) {}
        public AnimatedView(NSRect frameRect) : base(frameRect) {}

        [ObjectiveCMessage("mouseDown:")]
        public override void MouseDown(NSEvent theEvent)
        {
            /* Animate composition parameters "size" and "primary color" through a Core Animation transaction of 1 second duration */
            CATransaction.Begin();
            CATransaction.SetValueForKey(NSNumber.NumberWithFloat(1.0f), CATransaction.kCATransactionAnimationDuration);
            this.Layer.SetValueForKeyPath(NSNumber.NumberWithFloat(this.rand()), new NSString("patch.size.value"));
            Id rgb = new Id();
            rgb.NativePointer = CGColor.CreateGenericRGB(this.rand(), this.rand(), this.rand(), 1.0f);
            this.Layer.SetValueForKeyPath(rgb, NSString.StringWithFormat("patch.%@.value", QCComposition.QCCompositionInputPrimaryColorKey));
            CATransaction.Commit();
        }

        private float rand()
        {
            if (random == null)
            {
                random = new Random();
            }
            return Convert.ToSingle(random.NextDouble());
        }
    }
}