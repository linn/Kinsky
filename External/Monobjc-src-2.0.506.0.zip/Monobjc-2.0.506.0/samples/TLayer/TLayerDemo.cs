// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using Monobjc.Cocoa;

namespace Monobjc.Samples.TLayer
{
    [ObjectiveCClass]
    public class TLayerDemo : NSObject
    {
        [ObjectiveCField]
        public TLayerView tlayerView;

        [ObjectiveCField]
        public ShadowOffsetView shadowOffsetView;

        [ObjectiveCField]
        public NSSlider shadowRadiusSlider;

        [ObjectiveCField]
        public NSButton transparencyLayerButton;

        [ObjectiveCField]
        public NSColorWell colorWell;

        /// <summary>
        /// Initializes a new instance of the <see cref="TLayerDemo"/> class.
        /// </summary>
        public TLayerDemo() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="TLayerDemo"/> class.
        /// </summary>
        /// <param name="nativePointer">The native pointer.</param>
        public TLayerDemo(IntPtr nativePointer)
            : base(nativePointer) {}

        [ObjectiveCMessage("initialize")]
        public new static void Initialize()
        {
            NSColorPanel.SharedColorPanel.ShowsAlpha = true;
        }

        [ObjectiveCMessage("init")]
        public override Id Init()
        {
            Id self = ObjectiveCRuntime.SendMessageSuper<Id>(this, Class.GetClassFromType(typeof (TLayerDemo)), "init");
            if (self == null)
            {
                return null;
            }

            if (!NSBundle.LoadNibNamedOwner("TLayerDemo", this))
            {
                Console.WriteLine("Failed to load TLayerDemo.nib");
                this.Release();
                return null;
            }

            this.shadowOffsetView.Scale = 40;
            this.shadowOffsetView.Offset = CGSize.CGSizeMake(-30, -30);
            this.tlayerView.ShadowOffset = CGSize.CGSizeMake(-30, -30);

            this.ShadowRadiusChanged(this.shadowRadiusSlider);

            /* Better to do this as a subclass of NSControl.... */
            NSNotificationCenter.DefaultCenter.AddObserverSelectorNameObject(this,
                                                                             ObjectiveCRuntime.Selector("shadowOffsetChanged:"),
                                                                             ShadowOffsetView.ShadowOffsetChanged,
                                                                             null);

            return self;
        }

        [ObjectiveCMessage("awakeFromNib")]
        public void AwakeFromNib()
        {
            // Needed in order to have instance field filled.
        }

        [ObjectiveCMessage("dealloc", SynchronizeFields = false)]
        public void Dealloc()
        {
            NSNotificationCenter.DefaultCenter.RemoveObserver(this);
            ObjectiveCRuntime.SendMessageSuper(this, Class.GetClassFromType(typeof (AppDelegate)), "dealloc");
        }

        public NSWindow Window
        {
            [ObjectiveCMessage("window")]
            get { return this.tlayerView.Window; }
        }

        [ObjectiveCMessage("shadowRadiusChanged:")]
        public void ShadowRadiusChanged(Id sender)
        {
            this.tlayerView.ShadowRadius = this.shadowRadiusSlider.FloatValue;
        }

        [ObjectiveCMessage("toggleTransparencyLayers:")]
        public void ToggleTransparencyLayers(Id sender)
        {
            this.tlayerView.UsesTransparencyLayers = (this.transparencyLayerButton.State == NSCellStateValue.NSOnState);
        }

        [ObjectiveCMessage("shadowOffsetChanged:")]
        public void ShadowOffsetChanged(NSNotification notification)
        {
            CGSize offset = notification.Object.SendMessage<CGSize>("offset");
            this.tlayerView.ShadowOffset = offset;
        }
    }
}