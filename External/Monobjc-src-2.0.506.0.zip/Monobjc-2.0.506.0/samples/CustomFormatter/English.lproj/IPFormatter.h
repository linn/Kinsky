#import <Cocoa/Cocoa.h>

@interface IPFormatter : NSFormatter {

}

@end
