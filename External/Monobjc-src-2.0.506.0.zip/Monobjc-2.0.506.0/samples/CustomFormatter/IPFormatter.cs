// 
// Monobjc : a .NET/Objective-C bridge
// Copyright (C) 2007-2009  Laurent Etiemble
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 
using System;
using System.Net;
using System.Runtime.InteropServices;
using Monobjc.Cocoa;

namespace Monobjc.Samples.CustomFormatter
{
    [ObjectiveCClass]
    public class IPFormatter : NSFormatter
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="IPFormatter"/> class.
        /// </summary>
        public IPFormatter() {}

        /// <summary>
        /// Initializes a new instance of the <see cref="IPFormatter"/> class.
        /// </summary>
        /// <param name="nativeObject">The native object.</param>
        public IPFormatter(IntPtr nativeObject)
            : base(nativeObject) {}

        [ObjectiveCMessage("stringForObjectValue:")]
        public override NSString StringForObjectValue(Id anObject)
        {
            if (anObject == null)
            {
                return NSString.String;
            }
            // This example is simple as the object is a NSString
            // For a real formatter, you should convert the object to a string.
            return anObject.CastAs<NSString>();
        }

        [ObjectiveCMessage("getObjectValue:forString:errorDescription:")]
        public bool GetObjectValueForStringErrorDescription(IntPtr anObject, NSString str, IntPtr error)
        {
            // First, we convert the NSString to a String to parse it more easily
            String stringToParse = str;

            // If we cannot parse the string correctly into an IPAddress, then reject it
            IPAddress address;
            if (!IPAddress.TryParse(stringToParse, out address))
            {
                if (anObject != IntPtr.Zero)
                {
                    Marshal.WriteIntPtr(anObject, IntPtr.Zero);
                }
                if (error != IntPtr.Zero)
                {
                    // Marshal back the error message (the NSString is autoreleased)
                    NSString errorMessage = "Invalid IPv4 Address";
                    Marshal.WriteIntPtr(error, errorMessage.NativePointer);
                }
                return false;
            }

            // Marshal back the object (the NSString is autoreleased)
            NSString obj = address.ToString();
            if (anObject != IntPtr.Zero)
            {
                Marshal.WriteIntPtr(anObject, obj.NativePointer);
            }
            if (error != IntPtr.Zero)
            {
                Marshal.WriteIntPtr(error, IntPtr.Zero);
            }
            return true;
        }

        [ObjectiveCMessage("attributedStringForObjectValue:withDefaultAttributes:")]
        public override NSAttributedString AttributedStringForObjectValueWithDefaultAttributes(Id anObject, NSDictionary attributes)
        {
            NSAttributedString str = new NSAttributedString(this.StringForObjectValue(anObject), attributes);
            return str.Autorelease<NSAttributedString>();
        }
    }
}